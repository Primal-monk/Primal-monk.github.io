#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "menus/Language.h" // Tm() - see that file's header comment
#include <cmath>
#include <cctype>
#include <cfloat>
#include <Windows.h>

// Local alias so this file's own strings can just call Tm(...) like every
// other menu file, without a "Language::" prefix on every single line.
using Language::Tm;

// Detect real player pawns, draw a colored box on them, sized/colored by distance.
//
// PREVIOUS BUG (wrong locations, spun around with the mouse): camera position/
// rotation were being approximated (pawn location + eye height, controller's
// Rotation field). That's not actually what the game renders with. Fixed by
// reading PlayerCamera->CameraCache.POV — the real Location/Rotation/FOV the
// engine itself just used to render the frame. Still a raw field read, no
// ProcessEvent call (see the threading note from before — scripted calls from
// this render-thread loop are what caused the earlier crash).
//
// Box size/position now come from each pawn's real collision cylinder
// (CylinderComponent->CollisionHeight/Radius) projected to screen, instead of
// a fixed pixel size — so distant enemies get smaller boxes automatically.
// Head box is derived from the top slice of that same cylinder.
//
// ARCHITECTURE NOTE: GatherAndCache() (including the head-bone lookup) is
// called from hkPresent (main.cpp), same as RenderBoxes(). An attempt was
// made to move this to fire from inside HookedProcessEvent instead (safer
// against a cross-thread race, same idea as the grayscale fix), but that
// broke boxes entirely — PostRender likely fires at a different point in the
// frame than Present, before camera/world state is fully finalized. Reverted
// back here since this is the confirmed-working configuration. The
// GatherAndCache()/g_CachedGather split is kept (gather once, draw from
// cache) since it's still a reasonable structure, just both pieces run from
// the same place again now.

namespace VisibilityBoxes {

    inline bool enabled = true;   // ON by default: the skeleton only draws when boxes are on
    inline bool showHeadBox = true;
    inline bool showNameLabels = true;
    inline bool showHealthBars = true;
    inline bool showAllyHealthBars = false;    // ally health - only drawn when they're actually behind a wall (see hiddenBehindWall below); visible normally otherwise, same as everything else wallCheckEnabled gates
    inline bool showAllyCauterize = true;      // dark-blue ally box while heals are reduced
    inline bool showCautDebugReason = false;   // print the raw eReason code
    inline float cautBoxColor[3] = { 0.12f, 0.20f, 0.62f }; // dark blue
    inline bool showAllyHealthNumbers = false; // exact % above the ally bar
    inline bool showUltIcon = true;
    inline bool showWallIndicator = false; // REMOVED from the UI - the wall test never resolved, so this stays off
    inline bool use3DBoxes = true;         // ON by default — far more readable from any angle
    inline bool use3DHeadBox = true;       // same treatment for the head marker
    // When boxes are in FLAT 2D mode (use3DBoxes off), this fixes the same
    // "box vanishes when flying directly overhead" problem a different way:
    // instead of switching to a true 3D volume, size a flat, camera-facing
    // rectangle purely from distance (see DrawBillboardBox). ON by default
    // since it's a strict improvement with no real downside at normal angles.
    inline bool billboardBoxes2D = true;

    // ---- Movement/telemetry overlays ----
    inline bool showDistance = false;      // numeric distance in metres
    inline bool showSpeed = false;         // speed magnitude in m/s
    inline bool showDirectionArrow = false;// 3D velocity projected as an arrow from the box
    inline bool showVerticalState = false; // RISING / FALLING / GROUND
    inline bool showTracers = false;       // line from bottom of screen to each enemy
    // Predicted-position box: a second, white box drawn where the enemy WILL be,
    // based on their real velocity and your weapon's projectile travel time. It's
    // a visual aid only — you still aim and shoot it yourself.
    inline bool showPredictBox = true;   // ON by default, alongside Enable boxes
    // Independent from use3DBoxes — the white box gets its OWN 2D/3D choice so
    // it can stay flat while enemy/ally boxes are 3D, or vice versa. Off by
    // default (2D) even though use3DBoxes defaults on, per explicit request.
    inline bool predictBoxUse3D = false;
    // When on, and this enemy is a projectile-speed champion (not hitscan),
    // the normal red/current-position box is hidden entirely for them and
    // ONLY the white predicted box is drawn — never both at once.
    inline bool predictBoxOnlyMode = false;
    inline bool predictUseProjectileSpeed = true; // prefer the table over the SDK value
    inline float predictManualLead = 0.1f;        // was 0.3 — far too high, per testing
    inline bool predictManualOverride = false;
    // OFF by default now — subtracting our own velocity made the box jump around
    // (especially while jumping, since our Z velocity got subtracted too).
    inline bool predictAccountForOwnVelocity = false;
    // Ignore the target's VERTICAL velocity. A jumping enemy otherwise throws the
    // box far above/below them, which is never where you actually want to shoot.
    inline bool predictIgnoreVertical = true;

    // ================= LEAD CALIBRATION =================
    // The old model was lead = worldDistance / tableSpeed. That is wrong: the
    // table's "u/s" figures are NOT the same unit as the game's world
    // coordinates, so dividing one by the other produced leads several times too
    // large (the "box flies 5x too far in front" report).
    //
    // Calibrated empirically instead. Measured in-game: Maeve (table 400) feels
    // right at 0.10s, and a projectile twice as fast wants 0.05s. That is a
    // simple inverse relationship:
    //
    //          lead_seconds = kLeadConstant / tableSpeed        (k = 40)
    //
    // Check against the table: Maeve 400 -> 0.100s, Cassie 630 -> 0.063s,
    // Seris 150 -> 0.267s (slowest projectile, most lead), Evie 200 -> 0.200s.
    // Those all match how those projectiles actually feel.
    //
    // Deliberately NOT distance-scaled: real lead aiming is a small, fairly
    // constant offset at combat ranges, and distance scaling is what made it
    // swing wildly. The constant is exposed as a slider so it can be re-tuned.
    // Reduced 40 -> 34 after live testing: 40 still projected slightly too far
    // ahead across the board. Maeve now lands at 34/400 = 0.085s.
    inline float predictLeadConstant = 34.0f;

    inline float LeadSecondsForSpeed(float tableSpeed) {
        if (tableSpeed <= 1.0f) return 0.0f;              // hitscan / unknown
        float lead = predictLeadConstant / tableSpeed;
        if (lead > 0.6f) lead = 0.6f;                     // sanity clamp
        return lead;
    }

    // ================= PROJECTILE SPEED TABLE =================
    // Keyed on the pawn's INTERNAL class name (what we actually read off the
    // pawn), not the display name. speed <= 0 means HITSCAN -> never show a
    // prediction box, because there is nothing to lead.
    //
    // Using a table rather than UTgDeviceFire::GetProjectileSpeed() because that
    // returned a non-zero value for hitscan weapons, which is exactly why a box
    // was appearing on Lex. The table is authoritative.
    struct ChampProjectile { const char* internalName; float speed; };
    static const ChampProjectile g_ProjectileSpeeds[] = {
        // ---- PROJECTILE ----
        { "Ash",         300.0f },
        { "Azaan",       400.0f },
        { "BarrierTank", 350.0f },  // Inara
        { "Makoa",       250.0f },
        { "Terminus",    300.0f },
        { "Lazarus",     300.0f },  // possible internal name for Terminus
        { "Yagorath",    200.0f },
        { "BombQueen",   300.0f },  // Betty la Bomba
        { "BombKing",    300.0f },
        { "Cassie",      630.0f },
        { "Dredge",      350.0f },
        { "Drogoz",      250.0f },
        { "Imani",       420.0f },
        { "Longbow",     350.0f },  // Sha Lin (300 -> 400+ charged, mid value)
        { "Tiberius",    350.0f },
        { "Fairy",       300.0f },  // Willo
        { "Grover",      350.0f },
        { "Druid",       350.0f },  // Io
        { "Vampire",     300.0f },  // Lillith
        { "MalDamba",    240.0f },
        { "Pip",         300.0f },
        { "Bunny",       250.0f },  // Rei
        { "Oracle",      150.0f },  // Seris
        { "Caspian",     400.0f },
        { "Evie",        200.0f },
        { "Blades",      400.0f },  // Maeve
        { "Moji",        350.0f },
        { "Nyx",         300.0f },
        { "Shadow",      400.0f },  // Vatu
        { "Corrupter",   302.5f },  // Vora
        // ---- HITSCAN (0 = no prediction box) ----
        { "Talus", 0.0f }, { "Skye", 0.0f }, { "Omen", 0.0f }, // Koga handled above
        // KOGA IS SPECIAL — he swaps between SMGs (hitscan) and CLAWS (projectile,
        // roughly Maeve speed). Listed as a projectile here so the box exists by
        // default; live stance detection below overrides it when he's on SMGs.
        { "Koga", 400.0f },
        { "Buck", 0.0f }, { "Androxus", 0.0f }, { "Demon", 0.0f }, { "Grohk", 0.0f },
        { "Furia", 0.0f }, { "Corvus", 0.0f }, { "Commander", 0.0f }, // Octavia
        { "Kasumi", 0.0f }, { "Ruckus", 0.0f }, { "Raum", 0.0f }, { "Barik", 0.0f },
        { "Atlas", 0.0f }, { "Seven", 0.0f },   // VII
        { "Lex", 0.0f }, { "Ying", 0.0f }, { "Astro", 0.0f },        // Jenos
        { "Churchill", 0.0f },  // Vivian
        { "Viktor", 0.0f }, { "Tyra", 0.0f }, { "Owl", 0.0f },       // Strix
        { "Princess", 0.0f },   // Lian
        { "Kinessa", 0.0f }, { "Vanguard", 0.0f },                   // Khan
        { "Saati", 0.0f },      // listed Hitscan in the speed table
        { "Fernando", 0.0f }, { "Gauntlet", 0.0f }, { "Darklord", 0.0f }, // Torvald / Zhin: melee-ish, no lead
    };

    // Returns: >0 projectile speed, 0 hitscan, -1 unknown champion.
    inline float GetProjectileSpeedForChampion(const char* internalName) {
        if (!internalName || !internalName[0]) return -1.0f;
        for (const auto& c : g_ProjectileSpeeds) {
            if (_stricmp(internalName, c.internalName) == 0) return c.speed;
        }
        return -1.0f;
    }

    inline float velocityArrowScale = 0.6f;// how far ahead the arrow predicts (seconds)

    // Paladins uses Unreal units; ~52.5 uu per metre is the usual Paladins
    // conversion (the game's own "feet" readouts line up with this).
    inline float UnitsToMetres(float units) { return units / 52.5f; }

    // ---- Your own weapon's projectile speed ----
    // UTgDeviceFire::GetProjectileSpeed() is the game's own accessor. It's a
    // SCRIPTED call (goes through ProcessEvent), so it's throttled hard and
    // cached rather than read per frame. Returns 0 for hitscan weapons — those
    // have no projectile, which is itself useful to know.
    inline float g_MyProjectileSpeed = -1.0f;   // -1 = not read yet
    inline ULONGLONG g_LastProjSpeedMs = 0;

    inline float TryReadProjectileSpeed(SDK::ATgDevice* weapon) {
        __try {
            if (!weapon) return -1.0f;
            int mode = (int)weapon->CurrentFireMode;
            int count = (int)weapon->m_FireMode.Num();
            if (mode < 0 || mode >= count) return -1.0f;
            SDK::UTgDeviceFire* fm = weapon->m_FireMode[mode];
            if (!fm) return -1.0f;
            return fm->GetProjectileSpeed();
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1.0f; }
    }

    inline void UpdateProjectileSpeedThrottled() {
        ULONGLONG now = GetTickCount64();
        if (now - g_LastProjSpeedMs < 500) return;
        g_LastProjSpeedMs = now;
        if (!Globals::LocalWeapon || !Globals::LocalPawn) { g_MyProjectileSpeed = -1.0f; return; }
        g_MyProjectileSpeed = TryReadProjectileSpeed(Globals::LocalWeapon);
    }

    // ========================================================================
    // BORDER COLOUR VIA THE RANGE TRICK
    //
    // Observation that started this: on Drogoz in fire mode 2, enemy borders turn
    // YELLOW at every distance. The game colours the enemy outline based on
    // whether the target is inside the weapon's EFFECTIVE RANGE — in range = red,
    // out of range = yellow.
    //
    // That means border colour is driven by DATA, not just by a material we can't
    // reach. Range isn't a plain field though — it's computed by
    // UTgDeviceFire::IsWithinEffectiveRange(float) / GetEffectiveRange(). Since we
    // hook ProcessEvent, we can intercept those calls and overwrite the RESULT,
    // which is the same technique the aim hook uses on GetAdjustedAimNative.
    //
    // Forcing IsWithinEffectiveRange to FALSE should make every enemy read as
    // out-of-range, i.e. permanently yellow borders — a real recolour achieved
    // through game logic rather than material editing.
    //
    // WARNING, and it's a real one: the game may use this same function for
    // DAMAGE FALLOFF as well as border colour. If so, forcing it false could
    // reduce your damage. That's why it's off by default and clearly labelled —
    // test it and watch your damage numbers.
    inline bool forceOutOfRangeBorders = false;
    inline bool forceInRangeBorders = false;
    inline int  g_RangeHookHits = 0;

    struct PlainVec { float x, y, z; };

    enum class BoxKind { Ally, Enemy, Other }; // Other = deployable/turret/pet/structure — not a real player

    struct BoxEntry {
        PlainVec worldPos;
        float collisionHeight;
        float collisionRadius;
        BoxKind kind;
        SDK::ATgPawn* pawnPtr; // raw pointer, POD — safe to carry outside the SEH scope
        char championName[32]; // from the pawn's class name, e.g. "Kinessa"
        char playerName[32];   // from PlayerReplicationInfo->PlayerName
        float healthPct;       // 0..1, -1 = unknown (deployables/others)
        bool ultReady;
        PlainVec headWorldPos; // pre-resolved during gather (ProcessEvent thread), see hasHeadWorldPos
        bool hasHeadWorldPos;
        PlainVec velocity;     // raw Pawn->Velocity, world units/sec — drives speed + direction readouts
        int healMitigatorCount;  // >0 = healing is being reduced (cauterize etc)
        int healMitigatorReason; // eReason of the first entry, -1 if none
        PlainVec bones[64];    // skeleton joints in WORLD space, see kBones
        bool boneGot[64];      // per-bone success flag (a missing bone is skipped, not fatal)
        bool hasBones;
        bool isVisible;        // true = actually rendered on screen right now (not behind a wall). See wallCheckEnabled.
    };

    // ---- WALL CHECK (for aim lock / trigger bot gating, NOT the same thing
    // as the LineOfSightTo-based "no through walls" boxes/reticle-LOS below) ----
    //
    // That other mechanism (GetCachedLos / LineOfSightTo) is a SCRIPTED call,
    // throttled to one real check per frame across every cached enemy, and it
    // was flagged unreliable ("did not resolve reliably... ignored enemies
    // that were plainly visible" — see reticleRequireLos below). Rather than
    // trust aim lock / trigger bot to that same flaky path, this is a second,
    // independent method: a PLAIN FIELD READ, no scripted call, no per-frame
    // budget, safe to check every enemy every frame.
    //
    // UPrimitiveComponent::LastRenderTime is written by the engine's own
    // renderer ONLY when that mesh is actually drawn this frame. An occluded
    // mesh (behind a wall) stops getting it bumped, so comparing it to
    // WorldInfo->TimeSeconds tells us "on screen right now" for free.
    inline bool wallCheckEnabled = true;
    inline float wallCheckToleranceSeconds = 0.15f; // how stale LastRenderTime may be and still count as visible

    struct GatherResult {
        BoxEntry entries[32];
        int count;
        PlainVec camLoc;
        float camPitch, camYaw;
        float fov;
        bool ok;
    };

    // ---- Target reticle config. Declared up here (not next to
    // RenderTargetReticle further down) because GatherAndCache and
    // UpdateLosCacheOnePerFrame both need to check these to decide whether to
    // resolve head bones / run LOS checks at all. ----
    // Set every frame by RecoverySuite when head lock is armed.
    //
    // THIS IS WHY HEAD LOCK AIMED AT CHESTS. Head bone positions were only
    // resolved when the head BOX was being drawn, the reticle needed them, or
    // the skeleton was on - head lock was not in that list. With none of those
    // active, hasHeadWorldPos stayed false for every enemy, so head lock fell
    // through to the body position and looked like it was simply ignoring the
    // yellow box.
    //
    // Head lock now declares that it needs them, like every other consumer.
    inline bool g_ExternalWantsHeadPos = false;

    // ---- HEAD BONE CACHE ---------------------------------------------------
    // GetBoneLocation is a SCRIPTED ProcessEvent call and GatherAndCache runs on
    // the RENDER thread. The skeleton read directly below already knows this and
    // refreshes ONE enemy per frame; the head-bone read never got the same
    // treatment and was calling it for every enemy, every frame.
    //
    // That is what threw:
    //   Assertion failed: i>=0 && (i<Num()||...)  [AntiCheatArray.h:230]
    //   ProcessEvent -> GetBoneLocation -> TryGetHeadBoneWorldPos -> hkPresent
    //
    // Same fix as the skeleton: refresh one enemy per frame, everyone else reads
    // the last good value. A head box that is one frame stale is invisible; a
    // crash is not.
    static const int kHeadCacheMax = 32;
    inline void*    g_HeadCachePawn[kHeadCacheMax] = {};
    inline PlainVec g_HeadCachePos[kHeadCacheMax]  = {};
    inline bool     g_HeadCacheOk[kHeadCacheMax]   = {};
    inline int      g_HeadCacheCount = 0;
    inline int      g_HeadRefreshCursor = 0;

    inline int HeadCacheSlot(void* pawn) {
        for (int i = 0; i < g_HeadCacheCount; ++i)
            if (g_HeadCachePawn[i] == pawn) return i;
        if (g_HeadCacheCount < kHeadCacheMax) {
            int s = g_HeadCacheCount++;
            g_HeadCachePawn[s] = pawn;
            g_HeadCacheOk[s] = false;
            return s;
        }
        return -1;
    }

    inline void ResetHeadCache() {
        g_HeadCacheCount = 0;
        g_HeadRefreshCursor = 0;
    }

    inline bool reticleEnabled = true;   // ON by default - it is display-only
    inline int  reticleStyle = 0;        // 0 = dot, 1 = circle, 2 = crosshair
    inline float reticleSize = 3.0f;    // 6 was too fat; 3 is the tested size
    inline bool reticleHeadDistinct = true;
    // FORCED OFF and no longer exposed in the UI. The LOS test did not resolve
    // reliably, so with this on the reticle ignored enemies that were plainly
    // visible. Left as a variable so the LOS code below still compiles.
    inline bool reticleRequireLos = false;
    // Live state, readable by other UI (e.g. to show a text hint)
    inline bool g_ReticleOnEnemy = false;
    inline bool g_ReticleOnHead = false;
    inline bool g_ReticleOnPredictionBox = false;  // PURPLE reticle - cursor on white prediction box
    inline char g_ReticleTargetName[32] = {};
    inline SDK::ATgPawn* g_ReticleTargetPawn = nullptr;

    // Raw field read, no ProcessEvent: Pawn->PlayerReplicationInfo (TgRepInfo_Player)
    // ->r_TaskForce (TgRepInfo_TaskForce, a TeamInfo) ->TeamIndex.
    inline int GetTeamIndexRaw(SDK::ATgPawn* pawn) {
        if (!pawn || !pawn->PlayerReplicationInfo) return -1;
        SDK::ATgRepInfo_Player* pri = (SDK::ATgRepInfo_Player*)pawn->PlayerReplicationInfo;
        if (!pri->r_TaskForce) return -1;
        return pri->r_TaskForce->TeamIndex;
    }

    // Pure C-buffer copies — deliberately NOT using std::string/FName::GetName()
    // (which returns std::string) since these get called from inside
    // SafeGatherBoxes's __try block, and MSVC forbids __try sharing a function
    // scope with any object that needs unwinding, even a temporary from a
    // called function's return value. Raw char*/wchar_t* only.
    inline void CopyClassNameToBuf(SDK::UClass* cls, char* outBuf, size_t bufSize) {
        outBuf[0] = 0;
        if (!cls || cls->Name.Index == 0) return;
        auto& names = SDK::FName::GetGlobalNames();
        if (!names.IsValidIndex((size_t)cls->Name.Index)) return;
        SDK::FNameEntry* entry = names[cls->Name.Index];
        if (!entry) return;
        const char* ansi = entry->GetAnsiName();
        if (!ansi) return;
        // Strip the "TgPawn_" class-name prefix so it reads as just "Kinessa"
        // instead of "TgPawn_Kinessa".
        const char* prefix = "TgPawn_";
        size_t prefixLen = 7;
        const char* src = (_strnicmp(ansi, prefix, prefixLen) == 0) ? ansi + prefixLen : ansi;
        strncpy_s(outBuf, bufSize, src, _TRUNCATE);
    }

    // NOTE ON PLACEMENT: these two live HERE, not up with the other prediction
    // config, because they depend on things declared further down the file —
    // SolveInterceptTime needs struct PlainVec, and UpdateMyChampionSpeed needs
    // CopyClassNameToBuf (immediately above). Declaring them earlier produced
    // "missing type specifier" / "undeclared identifier" build errors.

    // Our own champion's projectile speed, resolved from the local pawn's class
    // name once per pawn change (cheap, no scripted calls).
    inline char  g_MyChampInternal[32] = {};
    inline float g_MyTableSpeed = -1.0f;
    // ---- KOGA STANCE DETECTION ----
    // Koga swaps between SMGs (hitscan) and claws (projectile, ~Maeve speed) via
    // ATgDevice_NinjaSwap. ATgPawn_Koga::m_bUseSecondWeapon tracks which set is
    // live. Which value means "claws" isn't documented, so the flag is exposed in
    // the UI along with an invert toggle — check it in game and flip if needed.
    //
    // Unlike the champion table this must be re-read EVERY frame, since he swaps
    // mid-fight (the table is only refreshed on pawn change).
    inline bool  kogaInvertStance = false;
    inline bool  kogaAssumeClaws = true;   // if detection looks wrong, just always assume claws
    inline int   g_KogaSecondWeaponFlag = -1; // -1 = not Koga / unreadable
    inline float kogaClawSpeed = 400.0f;

    inline bool TryReadKogaSecondWeapon(int* outFlag) {
        __try {
            if (!Globals::LocalPawn) return false;
            SDK::ATgPawn_Koga* k = (SDK::ATgPawn_Koga*)Globals::LocalPawn;
            *outFlag = k->m_bUseSecondWeapon ? 1 : 0;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline void UpdateMyChampionSpeed() {
        if (!Globals::LocalPawn) { g_MyChampInternal[0] = 0; g_MyTableSpeed = -1.0f; g_KogaSecondWeaponFlag = -1; return; }
        static SDK::APawn* lastPawn = nullptr;
        if (Globals::LocalPawn != lastPawn) {
            lastPawn = Globals::LocalPawn;
            CopyClassNameToBuf(((SDK::ATgPawn*)Globals::LocalPawn)->Class, g_MyChampInternal, sizeof(g_MyChampInternal));
            g_MyTableSpeed = GetProjectileSpeedForChampion(g_MyChampInternal);
        }

        // Koga only: re-evaluate every frame, because he swaps weapons mid-fight.
        if (_stricmp(g_MyChampInternal, "Koga") == 0) {
            int flag = -1;
            if (TryReadKogaSecondWeapon(&flag)) {
                g_KogaSecondWeaponFlag = flag;
                if (kogaAssumeClaws) {
                    g_MyTableSpeed = kogaClawSpeed; // always predict, never miss a claw window
                } else {
                    bool onClaws = kogaInvertStance ? (flag == 0) : (flag == 1);
                    g_MyTableSpeed = onClaws ? kogaClawSpeed : 0.0f; // 0 = hitscan SMGs, no box
                }
            } else {
                g_KogaSecondWeaponFlag = -1;
                g_MyTableSpeed = kogaClawSpeed; // couldn't read — fail toward showing the box
            }
        }
    }

    // ITERATIVE INTERCEPT SOLVE.
    // One pass (t = dist/speed) is wrong because the target moves during flight,
    // so the distance you divided by is already stale. Iterating converges on the
    // true intercept: recompute distance to the predicted point, re-solve t,
    // repeat. Three passes is plenty at these speeds.
    //
    // relVel is the target's velocity minus ours when "account for own velocity"
    // is on — that keeps the box stable while YOU strafe, instead of it sliding
    // around because the whole world is moving relative to you.
    inline float SolveInterceptTime(const PlainVec& shooterPos, const PlainVec& targetPos,
                                    const PlainVec& relVel, float projSpeed) {
        if (projSpeed <= 1.0f) return 0.0f;
        float dx = targetPos.x - shooterPos.x;
        float dy = targetPos.y - shooterPos.y;
        float dz = targetPos.z - shooterPos.z;
        float t = sqrtf(dx * dx + dy * dy + dz * dz) / projSpeed;
        for (int i = 0; i < 3; i++) {
            float px = targetPos.x + relVel.x * t;
            float py = targetPos.y + relVel.y * t;
            float pz = targetPos.z + relVel.z * t;
            float ex = px - shooterPos.x, ey = py - shooterPos.y, ez = pz - shooterPos.z;
            float d = sqrtf(ex * ex + ey * ey + ez * ez);
            t = d / projSpeed;
            if (t > 5.0f) return 0.0f; // unreachable, don't draw a nonsense box
        }
        return t;
    }

    inline void CopyFStringToBuf(const SDK::FString& s, char* outBuf, size_t bufSize) {
        outBuf[0] = 0;
        if (!s.IsValid()) return;
        const wchar_t* w = s.c_str();
        size_t i = 0;
        for (; i < bufSize - 1 && w[i] != 0; i++) {
            outBuf[i] = (w[i] < 128) ? (char)w[i] : '?'; // crude ASCII-only narrow, fine for names
        }
        outBuf[i] = 0;
    }

    // IMANI ICE MODE: detect which fire mode she's in and use correct speed
    // Ice mode splits projectiles, fire mode doesn't - both have same speed for now
    inline float GetImmediateProjectileSpeed() {
        if (!Globals::LocalWeapon) return g_MyTableSpeed;
        float trySpeed = TryReadProjectileSpeed(Globals::LocalWeapon);
        return (trySpeed >= 0.0f) ? trySpeed : g_MyTableSpeed;
    }

    // Everything that touches game memory lives in here, one SEH scope, plain data only.
    inline GatherResult SafeGatherBoxes() {
        GatherResult result;
        result.count = 0;
        result.ok = false;

        __try {
            if (!Globals::LocalController || !Globals::LocalPawn) return result;

            SDK::ATgPlayerController* myController = (SDK::ATgPlayerController*)Globals::LocalController;
            SDK::ATgPawn* myPawn = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!myPawn->WorldInfo) return result;

            if (!myController->PlayerCamera) return result;
            const SDK::FTPOV& pov = myController->PlayerCamera->CameraCache.POV;
            result.camLoc = { pov.Location.X, pov.Location.Y, pov.Location.Z };
            result.camPitch = (float)pov.Rotation.Pitch;
            result.camYaw = (float)pov.Rotation.Yaw;
            result.fov = (pov.FOV > 1.0f) ? pov.FOV : 90.0f;

            int myTeam = GetTeamIndexRaw(myPawn);

            SDK::UClass* tgPawnClass = SDK::ATgPawn::StaticClass();
            // Turrets/pets/towers/siege walls/lane pushers are ALL subclasses of
            // ATgPawn in this SDK too — only ATgPawn_Character (and below) is an
            // actual playable champion. That's how we tell real players apart
            // from deployables that just happen to share the same base class.
            SDK::UClass* tgCharacterClass = SDK::ATgPawn_Character::StaticClass();

            SDK::APawn* pawn = myPawn->WorldInfo->PawnList;
            int safety = 0;
            while (pawn && safety < 100 && result.count < 32) {
                safety++;
                SDK::APawn* next = pawn->NextPawn;

                if (pawn == Globals::LocalPawn) { pawn = next; continue; }
                if (pawn->bDeleteMe || pawn->bPendingDelete) { pawn = next; continue; }
                if (pawn->bTearOff) { pawn = next; continue; } // dying/dead — engine's own "about to go away" flag
                if (!tgPawnClass || !pawn->IsA(tgPawnClass)) { pawn = next; continue; }

                SDK::ATgPawn* tgPawn = (SDK::ATgPawn*)pawn;

                // Real players need BOTH: actually being a Character-derived
                // class AND having a valid PlayerReplicationInfo. Class alone
                // wasn't reliable — some cosmetic doubles/illusions are also
                // Character subclasses. A PRI is only assigned to an actual
                // player-controlled slot, so requiring both filters out
                // deployables/turrets/pets/illusions much more reliably.
                bool isRealCharacter = tgCharacterClass && pawn->IsA(tgCharacterClass) && tgPawn->PlayerReplicationInfo;

                // Also drop it if the real player behind it is already dead —
                // this is what was leaving boxes lingering on kills.
                if (isRealCharacter) {
                    SDK::ATgRepInfo_Player* pri = (SDK::ATgRepInfo_Player*)tgPawn->PlayerReplicationInfo;
                    if (pri->r_nHealthCurrent <= 0) { pawn = next; continue; }
                }

                float height = 44.0f, radius = 22.0f; // sane fallback if no cylinder found
                if (pawn->CylinderComponent) {
                    height = pawn->CylinderComponent->CollisionHeight;
                    radius = pawn->CylinderComponent->CollisionRadius;
                }

                BoxEntry& e = result.entries[result.count];
                e.worldPos = { pawn->Location.X, pawn->Location.Y, pawn->Location.Z };
                e.collisionHeight = height;
                e.collisionRadius = radius;
                e.pawnPtr = tgPawn;
                CopyClassNameToBuf(pawn->Class, e.championName, sizeof(e.championName));
                e.playerName[0] = 0;
                e.healthPct = -1.0f;
                e.hasHeadWorldPos = false;
                e.ultReady = false;
                // Raw field read, same as Location — no ProcessEvent call, so
                // it's safe inside this SEH scope. Units/sec in world space.
                e.velocity = { pawn->Velocity.X, pawn->Velocity.Y, pawn->Velocity.Z };

                // WALL CHECK — plain field read, see the comment on
                // wallCheckEnabled above. Defaults to visible (fail OPEN) if
                // unreadable or never-rendered-yet, so a bad read degrades to
                // "wall check does nothing" rather than "nothing ever fires".
                e.isVisible = true;
                if (wallCheckEnabled && tgPawn->Mesh) {
                    float lastRender = tgPawn->Mesh->LastRenderTime;
                    if (lastRender > 0.0f) {
                        e.isVisible = (myPawn->WorldInfo->TimeSeconds - lastRender) <= wallCheckToleranceSeconds;
                    }
                }

                // CAUTERIZE / heal-reduction detection.
                // ATgPawn::s_PawnHealMitigators is a plain TArray of
                // FPawnHealMitigator { ATgPawn* MitigatingPawn; eReason; }.
                // The game adds an entry whenever something is suppressing heals
                // on this pawn, so a non-empty array IS "healing reduced". This is
                // a RAW array read — no scripted call — so it's safe right here in
                // the gather alongside Location/Velocity.
                e.healMitigatorCount = 0;
                e.healMitigatorReason = -1;
                {
                    int mc = tgPawn->s_PawnHealMitigators.Num();
                    if (mc > 0 && mc < 64) { // sanity bound against a garbage read
                        e.healMitigatorCount = mc;
                        e.healMitigatorReason = (int)tgPawn->s_PawnHealMitigators[0].eReason.GetValue();
                    }
                }

                if (!isRealCharacter) {
                    e.kind = BoxKind::Other;
                } else {
                    int theirTeam = GetTeamIndexRaw(tgPawn);
                    e.kind = (theirTeam == myTeam) ? BoxKind::Ally : BoxKind::Enemy;
                    SDK::ATgRepInfo_Player* pri = (SDK::ATgRepInfo_Player*)tgPawn->PlayerReplicationInfo;
                    CopyFStringToBuf(pri->PlayerName, e.playerName, sizeof(e.playerName));
                    if (pri->r_nHealthMaximum > 0) {
                        e.healthPct = (float)pri->r_nHealthCurrent / (float)pri->r_nHealthMaximum;
                        if (e.healthPct < 0.0f) e.healthPct = 0.0f;
                        if (e.healthPct > 1.0f) e.healthPct = 1.0f;
                    }
                    if (pri->r_nRequiredUltimateCharge > 0) {
                        e.ultReady = pri->r_nUltimateCharge >= pri->r_nRequiredUltimateCharge;
                    }
                }
                result.count++;

                pawn = next;
            }

            result.ok = true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            result.count = 0;
            result.ok = false;
        }

        return result;
    }

    // FIXED: two sign/order bugs here were the actual cause of boxes drifting
    // to the wrong side and swinging incorrectly as the camera turned.
    // (1) "right" used yaw-90; UE3's yaw convention (turning positive yaw turns
    //     you clockwise from above) means right is yaw+90, not yaw-90 — the old
    //     version pointed left instead of right.
    // (2) "up" was computed as right x fwd, which pointed toward the ground;
    //     the correct world-up-facing cross product is fwd x right.
    inline void RotatorToVectors(float pitch16, float yaw16, PlainVec& fwd, PlainVec& right, PlainVec& up) {
        float pitch = pitch16 * (3.14159265f / 32768.0f);
        float yaw   = yaw16   * (3.14159265f / 32768.0f);
        fwd.x = cosf(pitch) * cosf(yaw);
        fwd.y = cosf(pitch) * sinf(yaw);
        fwd.z = sinf(pitch);
        right.x = cosf(yaw + 1.5707963f);
        right.y = sinf(yaw + 1.5707963f);
        right.z = 0.0f;
        up.x = fwd.y * right.z - fwd.z * right.y;
        up.y = fwd.z * right.x - fwd.x * right.z;
        up.z = fwd.x * right.y - fwd.y * right.x;
    }

    inline bool WorldToScreen(const PlainVec& worldPos, const PlainVec& camPos,
        const PlainVec& fwd, const PlainVec& right, const PlainVec& up,
        float fovDegrees, float screenW, float screenH, ImVec2& outScreen) {
        PlainVec delta{ worldPos.x - camPos.x, worldPos.y - camPos.y, worldPos.z - camPos.z };
        float depth = delta.x * fwd.x + delta.y * fwd.y + delta.z * fwd.z;
        if (depth < 10.0f) return false;
        float rightAmt = delta.x * right.x + delta.y * right.y + delta.z * right.z;
        float upAmt = delta.x * up.x + delta.y * up.y + delta.z * up.z;
        float fovRad = fovDegrees * (3.14159265f / 180.0f);
        float screenScale = (screenW / 2.0f) / tanf(fovRad / 2.0f);
        outScreen.x = (screenW / 2.0f) + (rightAmt / depth) * screenScale;
        outScreen.y = (screenH / 2.0f) - (upAmt / depth) * screenScale;
        return true;
    }

    // Real head-bone position instead of a guessed top-slice of the collision
    // cylinder. GetBoneLocation is a SCRIPTED call (goes through ProcessEvent,
    // same category as what caused the earlier crash) — so this is throttled
    // hard: each pawn's head position is cached and only actually re-queried
    // every ~150ms, not every frame, cutting call volume by ~10x versus doing
    // it live every frame for every enemy. Still SEH-wrapped as a second layer.
    // Purely positional data for drawing a box — nothing here selects, tracks,
    // or acts on a target.
    struct HeadCacheEntry {
        SDK::ATgPawn* pawn;
        PlainVec headPos;
        ULONGLONG lastUpdateMs;
        bool valid;
    };
    inline HeadCacheEntry g_HeadCache[32] = {};

    // ========================================================================
    // SKELETON / BONE ESP
    //
    // Bone names taken from the real dump (PaladinsBoneDump.txt, 206 bones on
    // the shared rig). We only use the 19 that form a readable skeleton —
    // fingers, twist bones, prop/weapon attachment bones and cosmetic bones are
    // all skipped since they add ~190 scripted calls for no visual gain.
    //
    // These come off the pawn's MAIN mesh (APawn::Mesh), not m_HeadMesh, which
    // only carries the head. Positions are returned in WORLD space (Space=0),
    // so they project through the exact same WorldToScreen path as everything
    // else — which is what makes the skeleton correctly 3D and perspective
    // accurate rather than a flat overlay.
    //
    // COST: GetBoneLocation is a scripted ProcessEvent call. 19 bones x 6
    // enemies would be ~114 calls per frame, which is far too many. So results
    // are cached per pawn with a TTL and only a couple of pawns are refreshed
    // per frame (round-robin) — same strategy as the head bone cache.
    // ========================================================================
    inline bool showSkeleton = false;
    inline bool skeletonThick = false;      // thicker limbs, toward a silhouette
    inline float skeletonThickness = 1.8f;
    inline bool skeletonJoints = true;      // circles at each joint
    inline float skeletonJointRadius = 2.5f;

    // ---- BONE OUTLINE MODE -------------------------------------------------
    // The idea: the game draws a coloured outline around each enemy and we have
    // never found a way to recolour it. So draw our OWN outline instead, using
    // the bone positions we already have.
    //
    // Each limb becomes a hollow capsule - two parallel lines offset either side
    // of the bone, with a circle stroked at every joint. The circles are what
    // makes it read as ONE continuous border rather than a pile of separate
    // segments: they cover the open ends of the parallel lines, so no limb has a
    // visible start or finish. Joint dots are meaningless in this mode and are
    // skipped automatically.
    inline bool  skeletonOutlineMode  = false;
    inline float skeletonOutlineWidth = 9.0f;   // full width of the hollow tube
    inline float skeletonOutlineLine  = 1.6f;   // stroke weight of the outline
    inline float skeletonOutlineColor[4] = { 1.0f, 0.25f, 0.85f, 1.0f };
    inline bool  skeletonOutlineUseOwnColor = true;

    // Draw the skeleton on ALLIES as well as enemies.
    inline bool  skeletonAllies = false;

    // Strokes one limb as a hollow capsule side. The end caps are deliberately
    // NOT drawn here - the joint circles in the caller cover them, which is what
    // removes the segment-end seams.
    inline void DrawHollowLimb(ImDrawList* d, ImVec2 a, ImVec2 b,
                               float halfW, ImU32 col, float lw) {
        float dx = b.x - a.x, dy = b.y - a.y;
        float len = sqrtf(dx * dx + dy * dy);
        if (len < 0.01f) return;
        float nx = -dy / len * halfW;
        float ny =  dx / len * halfW;
        d->AddLine(ImVec2(a.x + nx, a.y + ny), ImVec2(b.x + nx, b.y + ny), col, lw);
        d->AddLine(ImVec2(a.x - nx, a.y - ny), ImVec2(b.x - nx, b.y - ny), col, lw);
    }

    // ---- CRASH + JITTER FIX ----
    // The first version built FNames with FName(const char*). That constructor
    // walks the ENTIRE global name table (~200k entries), calling GetName() —
    // which allocates a std::string — on every one, through the anti-cheat
    // array's bounds-checked operator[]. That produced both the crash
    //     "i>=0 && (i<Num()||(i==0 && Num()==0))"
    // (a TArray bounds assertion) and the heavy jitter.
    //
    // PaladinsBoneDump.txt gives the name-table INDEX for every bone, and
    // FName(int) is a free, allocation-less constructor. So we use the indices
    // and never search. Each one is validated once against its expected name
    // (bounds-checked), so a mismatched game build degrades to "bone unusable"
    // instead of crashing.
    struct BoneDef { const char* name; int nameIndex; int group; };
    // groups: 0=core(always) 1=arms 2=hands 3=legs 4=fingers 5=props
    static const BoneDef kBones[] = {
        { "pelvis",     172412, 0 }, // 0
        { "Spine",      115504, 0 }, // 1
        { "spine1",     132838, 0 }, // 2
        { "spine2",     132839, 0 }, // 3
        { "Neck",       110366, 0 }, // 4
        { "head",       103263, 0 }, // 5
        { "l_clavicle", 171008, 1 }, // 6
        { "L_UpperArm", 104093, 1 }, // 7
        { "L_Forearm",  104075, 1 }, // 8
        { "l_hand",     132117, 2 }, // 9
        { "r_clavicle", 172438, 1 }, // 10
        { "R_UpperArm", 113347, 1 }, // 11
        { "R_Forearm",  112906, 1 }, // 12
        { "r_hand",     132532, 2 }, // 13
        { "L_Thigh",    104090, 3 }, // 14
        { "L_Calf",     104065, 3 }, // 15
        { "L_Foot",     104073, 3 }, // 16
        { "R_Thigh",    113336, 3 }, // 17
        { "R_Calf",     112748, 3 }, // 18
        { "R_Foot",     112904, 3 }, // 19
        // fingers — left hand
        { "l_finger0",  171015, 4 }, { "l_finger01", 171016, 4 }, { "l_finger02", 171017, 4 },
        { "l_finger1",  132109, 4 }, { "l_finger11", 171018, 4 }, { "l_finger12", 171019, 4 },
        { "l_finger2",  132110, 4 }, { "l_finger21", 171020, 4 }, { "l_finger22", 171021, 4 },
        { "l_finger3",  132111, 4 }, { "l_finger31", 171022, 4 }, { "l_finger32", 171023, 4 },
        { "l_finger4",  174458, 4 }, { "l_finger41", 174459, 4 }, { "l_finger42", 174460, 4 },
        // fingers — right hand
        { "r_finger0",  172443, 4 }, { "r_finger01", 172444, 4 }, { "r_finger02", 172445, 4 },
        { "r_finger1",  132530, 4 }, { "r_finger11", 172446, 4 }, { "r_finger12", 172447, 4 },
        { "r_finger2",  132531, 4 }, { "r_finger21", 172448, 4 }, { "r_finger22", 172449, 4 },
        { "r_finger3",  172450, 4 }, { "r_finger31", 172451, 4 }, { "r_finger32", 172452, 4 },
        { "r_finger4",  176307, 4 }, { "r_finger41", 176308, 4 },
        // weapon/prop attachment
        { "prop2",      172421, 5 },
    };
    static const int kBoneCount = (int)(sizeof(kBones) / sizeof(kBones[0]));

    static const int kBoneLinks[][2] = {
        {0,1},{1,2},{2,3},{3,4},{4,5},        // spine + neck + head
        {3,6},{6,7},{7,8},{8,9},              // left arm
        {3,10},{10,11},{11,12},{12,13},       // right arm
        {0,14},{14,15},{15,16},               // left leg
        {0,17},{17,18},{18,19},               // right leg
        // fingers chain off the hands (indices 20+ in kBones order)
        {9,20},{20,21},{21,22},  {9,23},{23,24},{24,25},
        {9,26},{26,27},{27,28},  {9,29},{29,30},{30,31},
        {9,32},{32,33},{33,34},
        {13,35},{35,36},{36,37}, {13,38},{38,39},{39,40},
        {13,41},{41,42},{42,43}, {13,44},{44,45},{45,46},
        {13,47},{47,48},
        {13,49}, // prop/weapon off the right hand
    };

    // Per-group enables. Core is always on; the rest are opt-in so you can dial
    // detail up until the whole rig is drawn.
    inline bool boneGroupArms = true;
    inline bool boneGroupHands = true;
    inline bool boneGroupLegs = true;
    inline bool boneGroupFingers = false;
    inline bool boneGroupProps = false;
    inline int  boneRefreshHz = 20;   // how often a given pawn's bones re-read

    inline bool BoneGroupEnabled(int group) {
        switch (group) {
            case 0: return true;
            case 1: return boneGroupArms;
            case 2: return boneGroupHands;
            case 3: return boneGroupLegs;
            case 4: return boneGroupFingers;
            case 5: return boneGroupProps;
        }
        return false;
    }

    // Validated once. Confirms the dumped index really maps to the expected
    // bone name on THIS build; if not, that bone is disabled rather than risking
    // a bad lookup.
    inline SDK::FName g_BoneFNames[64];
    inline bool g_BoneUsable[64] = {};
    inline bool g_BoneNamesResolved = false;
    inline int  g_BoneValidCount = 0;

    // One safe read of a single name-table entry. Bounds-checked, no
    // std::string anywhere (GetName() allocates — GetAnsiName() does not).
    inline bool TryGetNameAt(size_t idx, char* out, size_t outSize) {
        out[0] = 0;
        __try {
            auto& names = SDK::FName::GetGlobalNames();
            if (!names.IsValidIndex(idx)) return false;
            SDK::FNameEntry* entry = names[idx];
            if (!entry) return false;
            const char* ansi = entry->GetAnsiName();
            if (!ansi) return false;
            strncpy_s(out, outSize, ansi, _TRUNCATE);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline size_t TryGetNameCount() {
        __try { return SDK::FName::GetGlobalNames().Num(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    inline void ResolveBoneNames() {
        if (g_BoneNamesResolved) return;
        g_BoneNamesResolved = true;
        g_BoneValidCount = 0;

        char buf[128];

        // PASS 1 — try the dumped indices. Free when they're right.
        for (int i = 0; i < kBoneCount && i < 64; i++) {
            g_BoneUsable[i] = false;
            if (TryGetNameAt((size_t)kBones[i].nameIndex, buf, sizeof(buf)) &&
                _stricmp(buf, kBones[i].name) == 0) {
                g_BoneFNames[i] = SDK::FName(kBones[i].nameIndex);
                g_BoneUsable[i] = true;
                g_BoneValidCount++;
            }
        }
        if (g_BoneValidCount > 0) return;

        // PASS 2 — the dump came from a different build, so the indices are
        // meaningless here. Scan the name table ONCE and match by name.
        //
        // This is what FName(const char*) does, but SAFELY: bounds-checked
        // access, GetAnsiName() instead of GetName() (no std::string
        // allocation), and every entry read inside SEH. The unsafe version is
        // what produced the "i>=0 && (i<Num()...)" TArray assertion.
        size_t total = TryGetNameCount();
        if (total == 0 || total > 4000000) return; // implausible, bail
        for (size_t idx = 0; idx < total && g_BoneValidCount < kBoneCount; idx++) {
            if (!TryGetNameAt(idx, buf, sizeof(buf))) continue;
            if (!buf[0]) continue;
            for (int i = 0; i < kBoneCount && i < 64; i++) {
                if (g_BoneUsable[i]) continue;
                if (_stricmp(buf, kBones[i].name) != 0) continue;
                g_BoneFNames[i] = SDK::FName((int)idx);
                g_BoneUsable[i] = true;
                g_BoneValidCount++;
                break;
            }
        }
    }

    struct BoneCacheEntry {
        SDK::ATgPawn* pawn;
        PlainVec bones[64];
        bool got[64];
        ULONGLONG lastUpdateMs;
        bool valid;
    };
    inline BoneCacheEntry g_BoneCache[32] = {};
    inline int g_BoneRefreshCursor = 0;

    // Each bone is read in its OWN __try. One bad bone therefore can't abort the
    // whole skeleton or take the process down — it just goes missing.
    inline bool TryReadOneBone(SDK::ATgPawn* pawn, int boneIdx, PlainVec* out) {
        __try {
            SDK::FVector v = pawn->Mesh->GetBoneLocation(g_BoneFNames[boneIdx], 0);
            out->x = v.X; out->y = v.Y; out->z = v.Z;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryHasMesh(SDK::ATgPawn* pawn) {
        __try { return pawn && pawn->Mesh != nullptr; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline int g_BoneCacheFilled = 0;   // how many cache slots currently hold valid bones
    inline int g_BoneLastReadCount = 0; // bones successfully read on the last pass
    inline int g_BoneFallbackReads = 0; // times the render-thread fallback had to step in
    // ON by default because this is what made the skeleton actually render. The
    // safe-thread path is preferred and runs first; this only fires when that
    // hasn't produced anything for a given pawn.
    inline bool boneRenderThreadFallback = true;

    inline bool TryReadAllBones(SDK::ATgPawn* pawn, PlainVec* out, bool* got) {
        if (!TryHasMesh(pawn)) { g_BoneLastReadCount = -1; return false; } // -1 = no mesh
        int any = 0;
        for (int i = 0; i < kBoneCount && i < 64; i++) {
            got[i] = false;
            if (!g_BoneUsable[i]) continue;          // failed validation
            if (!BoneGroupEnabled(kBones[i].group)) continue; // group turned off
            if (TryReadOneBone(pawn, i, &out[i])) { got[i] = true; any++; }
        }
        g_BoneLastReadCount = any;
        return any > 0;
    }

    // Returns cached bones if fresh; refreshes only if this pawn is the one
    // whose turn it is this frame (keeps the scripted-call budget bounded).
    inline bool TryGetBones(SDK::ATgPawn* pawn, PlainVec* out, bool* got, bool allowRefresh) {
        if (!pawn) return false;
        ResolveBoneNames();
        if (g_BoneValidCount == 0) return false; // nothing validated, don't try
        ULONGLONG now = GetTickCount64();

        int slot = -1;
        for (int i = 0; i < 32; i++) if (g_BoneCache[i].pawn == pawn) { slot = i; break; }
        if (slot == -1) {
            // BUG FIX: the READ-ONLY (render thread) path used to fall through
            // here and CLAIM a slot, resetting valid=false and evicting whatever
            // the safe thread had just filled in. Every frame, for every enemy.
            // Net effect: the safe thread wrote bones and the render thread wiped
            // them, so hasBones was permanently false and nothing ever drew —
            // even though 50/50 names validated fine.
            //
            // Only the refreshing caller (the safe thread) may allocate slots.
            if (!allowRefresh) return false;
            ULONGLONG oldest = (ULONGLONG)-1;
            for (int i = 0; i < 32; i++) {
                if (!g_BoneCache[i].pawn) { slot = i; break; }
                if (g_BoneCache[i].lastUpdateMs < oldest) { oldest = g_BoneCache[i].lastUpdateMs; slot = i; }
            }
            g_BoneCache[slot].pawn = pawn;
            g_BoneCache[slot].valid = false;
            g_BoneCache[slot].lastUpdateMs = 0;
        }

        BoneCacheEntry& e = g_BoneCache[slot];
        ULONGLONG ttl = (boneRefreshHz > 0) ? (ULONGLONG)(1000 / boneRefreshHz) : 50;
        bool stale = (now - e.lastUpdateMs) > ttl;
        if (stale && allowRefresh) {
            if (TryReadAllBones(pawn, e.bones, e.got)) {
                e.valid = true;
                e.lastUpdateMs = now;
            }
        }
        if (!e.valid) return false;
        for (int i = 0; i < kBoneCount && i < 64; i++) { out[i] = e.bones[i]; got[i] = e.got[i]; }
        return true;
    }

    inline bool TryGetHeadBoneWorldPos(SDK::ATgPawn* pawn, PlainVec& outPos) {
        if (!pawn) return false;
        ULONGLONG now = GetTickCount64();

        int slot = -1;
        for (int i = 0; i < 32; i++) {
            if (g_HeadCache[i].pawn == pawn) { slot = i; break; }
        }
        if (slot == -1) {
            ULONGLONG oldest = (ULONGLONG)-1;
            for (int i = 0; i < 32; i++) {
                if (!g_HeadCache[i].pawn) { slot = i; break; }
                if (g_HeadCache[i].lastUpdateMs < oldest) { oldest = g_HeadCache[i].lastUpdateMs; slot = i; }
            }
        }

        HeadCacheEntry& entry = g_HeadCache[slot];
        // ACCURACY FIX: the cached bone position is up to 50ms old, and on a
        // moving target 50ms of lag is a visible offset — that's the "close but
        // not quite the real head" behaviour. GetBoneLocation is a scripted call
        // so we can't just resolve it every frame; instead, extrapolate the
        // stale position forward using the pawn's own velocity. A player moving
        // ~400uu/s drifts ~20uu in 50ms, which is roughly a head-width, so this
        // correction is the difference between hitting and missing.
        if (entry.pawn == pawn && entry.valid && (now - entry.lastUpdateMs) < 50) {
            float ageSec = (float)(now - entry.lastUpdateMs) / 1000.0f;
            outPos = entry.headPos;
            __try {
                outPos.x += pawn->Velocity.X * ageSec;
                outPos.y += pawn->Velocity.Y * ageSec;
                outPos.z += pawn->Velocity.Z * ageSec;
            }
            __except (EXCEPTION_EXECUTE_HANDLER) { /* keep un-extrapolated */ }
            return true;
        }

        bool ok = false;
        __try {
            if (pawn->m_HeadMesh) {
                // m_HeadShotBoneName is the game's OWN dedicated field for this —
                // the exact bone its own headshot detection uses. Falls back to
                // the general head bone list, then a plain guess, if it's unset.
                SDK::FName boneName = pawn->m_HeadShotBoneName;
                if (boneName.Index == 0 && pawn->HeadBoneNames.Num() > 0) boneName = pawn->HeadBoneNames[0];
                SDK::FVector loc = pawn->m_HeadMesh->GetBoneLocation(boneName, 0);
                entry.headPos = { loc.X, loc.Y, loc.Z };
                entry.pawn = pawn;
                entry.lastUpdateMs = now;
                entry.valid = true;
                outPos = entry.headPos;
                ok = true;
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            entry.valid = false;
            ok = false;
        }

        return ok;
    }

    // Cached result, written from the safe thread (ProcessEvent dispatch),
    // read from the render thread purely for drawing. See GatherAndCache().
    inline GatherResult g_CachedGather = {};

    // THREADING FIX: this used to run inline inside RenderBoxes(), called
    // from hkPresent (the DX11 Present hook) — likely a separate render
    // thread from the game's own logic thread. TryGetHeadBoneWorldPos calls
    // GetBoneLocation, a SCRIPTED function (ProcessEvent), so doing that from
    // the render thread was a genuine cross-thread race against the game's
    // own script activity — worse during combat, which is exactly when users
    // reported crashes. Fixed by moving ALL data gathering (including head
    // bone lookups) here, called from inside HookedProcessEvent — the SAME
    // thread as the game's own script dispatch, not the render thread.
    // RenderBoxes() now only reads the cached result and draws; it makes no
    // scripted calls at all anymore.
    // NOT gated on the boxes "enabled" toggle — Silhouette reuses this same
    // cache and is supposed to work independently of boxes being shown. Only
    // the head-bone lookup (the one actually-scripted, throttled part) is
    // gated on boxes+headbox actually needing it.
    inline void GatherAndCache() {
        GatherResult result = SafeGatherBoxes();
        // Head bone positions are also needed by the target reticle's headshot
        // detection — previously only resolved when the head BOX was on, so the
        // reticle could never report a head hit even once LOS was fixed.
        // Advance the round-robin cursor once per frame so a different enemy's
        // bones get refreshed each time.
        g_BoneRefreshCursor++;
        if (result.ok && ((enabled && showHeadBox) || (reticleEnabled && reticleHeadDistinct)
                          || (enabled && showSkeleton) || g_ExternalWantsHeadPos)) {

            // ONE head-bone read per frame, round-robin. See the head cache
            // above for why - this used to read every enemy every frame from the
            // render thread and it crashed inside AntiCheatArray.
            g_HeadRefreshCursor++;
            int headTurn = (result.count > 0)
                         ? (g_HeadRefreshCursor % result.count)
                         : 0;

            for (int i = 0; i < result.count; i++) {
                BoxEntry& e = result.entries[i];

                if (e.kind != BoxKind::Enemy) {
                    e.hasHeadWorldPos = false;
                } else {
                    int slot = HeadCacheSlot(e.pawnPtr);
                    if (slot >= 0) {
                        // Only the enemy whose turn it is actually calls into
                        // the engine this frame.
                        if (i == headTurn) {
                            PlainVec hp{};
                            bool got = TryGetHeadBoneWorldPos(e.pawnPtr, hp);
                            g_HeadCacheOk[slot]  = got;
                            if (got) g_HeadCachePos[slot] = hp;
                        }
                        e.hasHeadWorldPos = g_HeadCacheOk[slot];
                        if (e.hasHeadWorldPos) e.headWorldPos = g_HeadCachePos[slot];
                    } else {
                        e.hasHeadWorldPos = false;
                    }
                }
                // Skeleton: only ONE enemy is allowed to actually re-read its
                // bones per frame (round-robin via g_BoneRefreshCursor). Everyone
                // else draws from cache. 19 scripted calls/frame is affordable;
                // 19 x every enemy is not.
                // CRASH FIX. GetBoneLocation is a SCRIPTED ProcessEvent call, and
                // GatherAndCache runs on the RENDER thread (hkPresent). Reading
                // up to 50 bones per frame from there is exactly the cross-thread
                // corruption that crashed at ProcessEventOriginal.
                //
                // So NOTHING is read here — allowRefresh is false, we only copy
                // whatever the safe thread has already cached. The actual reads
                // happen in ResolveBonesOnSafeThread(), driven from
                // HookedProcessEvent. (That path only became usable once the
                // PostRender anchor bug was fixed — previously it never ran,
                // which is why "move it to the safe thread" looked broken.)
                e.hasBones = false;
                if (showSkeleton &&
                    (e.kind == BoxKind::Enemy || (skeletonAllies && e.kind == BoxKind::Ally))) {
                    // Read from cache first (filled by the safe thread — correct
                    // and crash-free).
                    e.hasBones = TryGetBones(e.pawnPtr, e.bones, e.boneGot, false);

                    // FALLBACK, and the reason bones worked originally: the very
                    // first version refreshed from HERE, on the render thread.
                    // That's technically the wrong thread for a scripted call,
                    // but it WORKED (just jittery). My "fix" made this path
                    // read-only and thereby removed the only thing filling the
                    // cache in practice — so the feature stopped rendering.
                    //
                    // So: if the safe thread hasn't produced bones for this pawn,
                    // fall back to reading them here, throttled to ONE pawn per
                    // frame (round-robin) to keep the call count near what the
                    // original did. Toggleable, since it carries the known risk.
                    if (!e.hasBones && boneRenderThreadFallback) {
                        bool myTurn = (i == (g_BoneRefreshCursor % (result.count > 0 ? result.count : 1)));
                        if (myTurn) {
                            e.hasBones = TryGetBones(e.pawnPtr, e.bones, e.boneGot, true);
                            g_BoneFallbackReads++;
                        }
                    }
                }
            }
        }
        g_CachedGather = result;
    }

    // ---- Runs on the PROCESSEVENT THREAD (from HookedProcessEvent) ----
    // This is the only place bones are actually read. One pawn per call,
    // round-robin, so the scripted-call budget stays bounded. The render thread
    // never touches GetBoneLocation.
    inline int g_BoneSafeResolveCount = 0;
    inline void ResolveBonesOnSafeThread() {
        if (!showSkeleton || !enabled) return;
        if (!g_CachedGather.ok) return;
        ResolveBoneNames();
        if (g_BoneValidCount == 0) return;

        int count = g_CachedGather.count;
        if (count <= 0) return;

        // Pick the next ENEMY in rotation and refresh only that one.
        for (int attempt = 0; attempt < count; attempt++) {
            int idx = (g_BoneRefreshCursor + attempt) % count;
            const BoxEntry& e = g_CachedGather.entries[idx];
            if (e.kind != BoxKind::Enemy || !e.pawnPtr) continue;
            // allowRefresh = true: this is the safe thread, reads are legal here.
            PlainVec tmp[64]; bool got[64];
            TryGetBones(e.pawnPtr, tmp, got, true);
            g_BoneRefreshCursor = idx + 1;
            g_BoneSafeResolveCount++;
            // Count how many slots actually hold usable bones — distinguishes
            // "reads happening" from "reads succeeding".
            int filled = 0;
            for (int s = 0; s < 32; s++) if (g_BoneCache[s].pawn && g_BoneCache[s].valid) filled++;
            g_BoneCacheFilled = filled;
            return;
        }
        g_BoneRefreshCursor++;
    }

    // ---- "Boxes - No Through Walls" (test feature, kept separate from the
    // main boxes so it can't break the already-working ones) ----
    // Last attempt at this crashed: LineOfSightTo was called per-enemy every
    // frame from the render thread, the same scripted-call-from-the-wrong-
    // thread pattern that caused every other crash this session. Fixed the
    // same way as the head-bone lookup and outline recoloring: the actual
    // call runs from the SAFE thread (HookedProcessEvent), throttled to
    // 500ms per pawn AND capped at one real call per frame total. The render
    // thread only ever reads the cached result.
    inline bool noWallsBoxesEnabled = false;

    struct LosCacheEntry {
        SDK::ATgPawn* pawn;
        bool visible;
        ULONGLONG lastCheckMs;
    };
    inline LosCacheEntry g_LosCache[32] = {};

    // Called from hkPresent — see the note on GatherAndCache for why (a
    // ProcessEvent-thread version of this specifically returned no results
    // at all, not a crash, just permanently false for everyone).
    // Runs if EITHER the separate "no through walls" test boxes OR the main
    // boxes' wall-indicator style needs the data.
    inline void UpdateLosCacheOnePerFrame() {
        // RETICLE FIX: this used to return unless a BOX feature wanted LOS. The
        // target reticle also depends on it (it's LOS-gated by default), so with
        // only the reticle enabled the cache never updated, GetCachedLos() always
        // answered "not visible", and the dot stayed grey forever. That was the
        // whole bug — it wasn't the hit-detection maths.
        if (!noWallsBoxesEnabled && !showWallIndicator && !(reticleEnabled && reticleRequireLos)) return;
        if (!Globals::LocalController) return;
        if (!g_CachedGather.ok) return;

        SDK::ATgPlayerController* myController = (SDK::ATgPlayerController*)Globals::LocalController;
        ULONGLONG now = GetTickCount64();

        for (int i = 0; i < g_CachedGather.count; i++) {
            const BoxEntry& e = g_CachedGather.entries[i];
            if (e.kind != BoxKind::Enemy) continue;

            int slot = -1;
            for (int s = 0; s < 32; s++) {
                if (g_LosCache[s].pawn == e.pawnPtr) { slot = s; break; }
            }
            if (slot == -1) {
                for (int s = 0; s < 32; s++) {
                    if (!g_LosCache[s].pawn) { slot = s; break; }
                }
                if (slot == -1) slot = 0;
                g_LosCache[slot].pawn = e.pawnPtr;
                g_LosCache[slot].visible = false;
                g_LosCache[slot].lastCheckMs = 0;
            }

            LosCacheEntry& entry = g_LosCache[slot];
            if (now - entry.lastCheckMs < 500) continue; // not due yet

            bool visible = false;
            __try {
                SDK::FVector zeroVec = {};
                visible = myController->LineOfSightTo((SDK::AActor*)e.pawnPtr, zeroVec, false);
            }
            __except (EXCEPTION_EXECUTE_HANDLER) {
                visible = false;
            }
            entry.visible = visible;
            entry.lastCheckMs = now;
            break; // one real call this frame, stop
        }
    }

    // ========================================================================
    // TARGET RETICLE — a crosshair that changes colour when an enemy is under
    // it (body vs head). Deliberately DISPLAY ONLY: it never moves your view
    // and never clicks for you. You aim, you shoot; this just tells you what
    // you're pointed at, the same class of information the boxes already show.
    //
    // LOS-gated on purpose: it only reacts to enemies the real LineOfSightTo
    // check says you can actually see, so it doesn't become a through-wall
    // indicator. Same cache the "no through walls" boxes use.
    //
    // Useful for Kasumi specifically, whose kit is target-marking rather than
    // projectile aiming, so "am I actually on them" is the whole question.
    // ========================================================================
    inline bool GetCachedLos(SDK::ATgPawn* pawn); // fwd decl, defined just below

    // FALLBACK SCREEN SIZE — for callers with no ImGui context at all (PHAROAH
    // LITE, which never creates one: see main_lite.cpp). ImGui::GetIO() itself
    // asserts/crashes with no context ("No current context..."), which is
    // exactly what happened the first time LITE called into this function -
    // it has no D3D11/ImGui of its own, but still needs this reticle logic for
    // its trigger bot. A caller with real canvas dimensions and no ImGui
    // context (LiteMenu::Tick) writes them here every frame; a caller WITH a
    // context (the full PHAROAH build) is completely unaffected, since the
    // branch below only ever reaches this fallback when GetCurrentContext()
    // is null - never the case in that build.
    inline float g_FallbackScreenW = 1920.0f, g_FallbackScreenH = 1080.0f;

    inline void RenderTargetReticle() {
        g_ReticleOnEnemy = false;
        g_ReticleOnHead = false;
        g_ReticleOnPredictionBox = false;
        g_ReticleTargetName[0] = 0;
        g_ReticleTargetPawn = nullptr;

        // Always detect reticle state (needed for trigger bot even if visual is off)
        // Only skip rendering if reticleEnabled is false
        const GatherResult& gathered = g_CachedGather;
        if (!gathered.ok) return;

        PlainVec fwd, right, up;
        RotatorToVectors(gathered.camPitch, gathered.camYaw, fwd, right, up);

        ImVec2 screenSize = ImGui::GetCurrentContext()
            ? ImGui::GetIO().DisplaySize
            : ImVec2(g_FallbackScreenW, g_FallbackScreenH);
        float ccx = screenSize.x * 0.5f;
        float ccy = screenSize.y * 0.5f;

        // Find whether the screen centre falls inside any visible enemy's
        // projected capsule, and whether it's in the head region.
        for (int i = 0; i < gathered.count; i++) {
            const BoxEntry& e = gathered.entries[i];
            if (e.kind != BoxKind::Enemy) continue;
            if (reticleRequireLos && !GetCachedLos(e.pawnPtr)) continue;
            // Wall check (see wallCheckEnabled) - independent of the LOS gate
            // above, which is off by default. This is what keeps the reticle
            // (and everything downstream of it: trigger bot, sticky-target
            // aim lock) from reacting to an enemy hidden behind a wall.
            if (wallCheckEnabled && !e.isVisible) continue;

            PlainVec topWorld{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight };
            PlainVec botWorld{ e.worldPos.x, e.worldPos.y, e.worldPos.z - e.collisionHeight };
            ImVec2 topScreen, botScreen;
            if (!WorldToScreen(topWorld, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, topScreen)) continue;
            if (!WorldToScreen(botWorld, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, botScreen)) continue;

            float boxHeight = botScreen.y - topScreen.y;
            if (boxHeight < 4.0f) continue;
            float boxWidth = (e.collisionHeight > 0.1f) ? boxHeight * (e.collisionRadius / e.collisionHeight) : boxHeight * 0.5f;
            float cx = (topScreen.x + botScreen.x) * 0.5f;
            float left = cx - boxWidth * 0.5f, rightEdge = cx + boxWidth * 0.5f;

            if (ccx < left || ccx > rightEdge || ccy < topScreen.y || ccy > botScreen.y) continue;

            g_ReticleOnEnemy = true;
            g_ReticleTargetPawn = e.pawnPtr;
            strncpy_s(g_ReticleTargetName, sizeof(g_ReticleTargetName), e.championName, _TRUNCATE);

            // Head check uses the real head bone position when we have it,
            // falling back to the top ~12% of the capsule otherwise. Tighter radius for accuracy.
            if (reticleHeadDistinct) {
                if (e.hasHeadWorldPos) {
                    ImVec2 headScreen;
                    if (WorldToScreen(e.headWorldPos, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, headScreen)) {
                        float headR = boxWidth * 0.20f;
                        float dx = ccx - headScreen.x, dy = ccy - headScreen.y;
                        if ((dx * dx + dy * dy) <= headR * headR) g_ReticleOnHead = true;
                    }
                } else if (ccy <= topScreen.y + boxHeight * 0.12f) {
                    g_ReticleOnHead = true;
                }
            }
            break;
        }

        // Check for white prediction boxes (PURPLE reticle) - ALWAYS CHECK, regardless of
        // visual toggle AND regardless of whether we already found a red/head hit above.
        // Purple must win whenever the cursor is on the white box AT ALL, even if it's
        // simultaneously within the red box's bounds too — never let red silently win a
        // tie. The colour-priority check below (purple > yellow > red) is what actually
        // enforces that ordering, but only if this block is allowed to run every time.
        {
            float myProjSpeed = g_MyTableSpeed;
            if (myProjSpeed > 0.0f) {  // Only projectile characters have prediction boxes
                for (int i = 0; i < gathered.count; i++) {
                    const BoxEntry& e = gathered.entries[i];
                    if (e.kind != BoxKind::Enemy) continue;
                    if (wallCheckEnabled && !e.isVisible) continue;

                    float lead = LeadSecondsForSpeed(myProjSpeed);
                    if (lead <= 0.0f || lead >= 3.0f) continue;

                    PlainVec relVel = e.velocity;
                    if (predictIgnoreVertical) relVel.z = 0.0f;

                    PlainVec predTop{ e.worldPos.x + relVel.x * lead,
                                    e.worldPos.y + relVel.y * lead,
                                    e.worldPos.z + relVel.z * lead + e.collisionHeight };
                    PlainVec predBot{ e.worldPos.x + relVel.x * lead,
                                    e.worldPos.y + relVel.y * lead,
                                    e.worldPos.z + relVel.z * lead - e.collisionHeight };

                    ImVec2 pTop, pBot;
                    if (!WorldToScreen(predTop, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, pTop)) continue;
                    if (!WorldToScreen(predBot, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, pBot)) continue;

                    float ph = pBot.y - pTop.y;
                    if (ph < 3.0f) continue;

                    float pw = ph * (e.collisionRadius / e.collisionHeight);
                    float pcx = (pTop.x + pBot.x) * 0.5f;
                    float pcy = (pTop.y + pBot.y) * 0.5f;

                    float dx = ccx - pcx;
                    float dy = ccy - pcy;
                    float boxR = (pw + ph) * 0.25f;

                    if ((dx * dx + dy * dy) <= boxR * boxR) {
                        g_ReticleOnPredictionBox = true;
                        break;
                    }
                }
            }
        }

        // Only render visual if reticle is enabled (detection always runs for trigger bot)
        if (!reticleEnabled) return;
        // SECOND no-context guard in this same function - see
        // g_FallbackScreenW above. ImGui::GetBackgroundDrawList() asserts
        // exactly like GetIO() does with no context; this is what actually
        // crashed PHAROAH LITE (the screenSize fetch above was fixed first,
        // but this later draw call in the SAME function was missed the first
        // time). PHAROAH LITE draws its own visual feedback (boxes, names),
        // so it has no need for this crosshair anyway - it also sets
        // reticleEnabled = false at init, but that flag is a feature choice,
        // not a safety mechanism, so this function must not depend on it for
        // crash-safety by itself.
        if (!ImGui::GetCurrentContext()) return;

        // Colour: grey=nothing, red=body, yellow=head, PURPLE=prediction box
        ImU32 col = IM_COL32(200, 200, 200, 190);
        if (g_ReticleOnPredictionBox) col = IM_COL32(180, 80, 255, 255);  // PURPLE for prediction box
        else if (g_ReticleOnHead)     col = IM_COL32(255, 220, 40, 255);  // Yellow for head
        else if (g_ReticleOnEnemy)    col = IM_COL32(255, 60, 60, 255);   // Red for body

        ImDrawList* draw = ImGui::GetBackgroundDrawList();
        float s = reticleSize;
        if (reticleStyle == 0) {
            draw->AddCircleFilled(ImVec2(ccx, ccy), s, col, 16);
        } else if (reticleStyle == 1) {
            draw->AddCircle(ImVec2(ccx, ccy), s * 1.6f, col, 24, 2.0f);
        } else {
            float gap = s * 0.6f, len = s * 2.2f;
            draw->AddLine(ImVec2(ccx - gap - len, ccy), ImVec2(ccx - gap, ccy), col, 2.0f);
            draw->AddLine(ImVec2(ccx + gap, ccy), ImVec2(ccx + gap + len, ccy), col, 2.0f);
            draw->AddLine(ImVec2(ccx, ccy - gap - len), ImVec2(ccx, ccy - gap), col, 2.0f);
            draw->AddLine(ImVec2(ccx, ccy + gap), ImVec2(ccx, ccy + gap + len), col, 2.0f);
        }
    }

    inline bool GetCachedLos(SDK::ATgPawn* pawn) {
        for (int s = 0; s < 32; s++) {
            if (g_LosCache[s].pawn == pawn) return g_LosCache[s].visible;
        }
        return false; // unknown yet — default to "not visible" rather than flash a box before it's verified
    }

    // Render thread — only reads the cache above, no scripted calls at all.
    inline void RenderBoxesNoWalls() {
        if (!noWallsBoxesEnabled) return;
        const GatherResult& gathered = g_CachedGather;
        if (!gathered.ok) return;

        PlainVec fwd, right, up;
        RotatorToVectors(gathered.camPitch, gathered.camYaw, fwd, right, up);
        ImVec2 screenSize = ImGui::GetIO().DisplaySize;
        ImDrawList* draw = ImGui::GetBackgroundDrawList();

        for (int i = 0; i < gathered.count; i++) {
            const BoxEntry& e = gathered.entries[i];
            if (e.kind != BoxKind::Enemy) continue;
            if (!GetCachedLos(e.pawnPtr)) continue;

            PlainVec topWorld{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight };
            PlainVec botWorld{ e.worldPos.x, e.worldPos.y, e.worldPos.z - e.collisionHeight };
            ImVec2 topScreen, botScreen;
            if (!WorldToScreen(topWorld, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, topScreen)) continue;
            if (!WorldToScreen(botWorld, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, botScreen)) continue;

            float boxHeight = botScreen.y - topScreen.y;
            if (boxHeight < 4.0f) continue;
            float boxWidth = (e.collisionHeight > 0.1f) ? boxHeight * (e.collisionRadius / e.collisionHeight) : boxHeight * 0.5f;
            float cx = (topScreen.x + botScreen.x) * 0.5f;

            // Distinct green so it's obviously a different feature from the main boxes.
            ImU32 color = ImGui::ColorConvertFloat4ToU32(ImVec4(0.25f, 1.0f, 0.4f, 1.0f));
            draw->AddRect(ImVec2(cx - boxWidth * 0.5f, topScreen.y),
                          ImVec2(cx + boxWidth * 0.5f, botScreen.y), color, 0.0f, 0, 2.0f);
        }
    }

    inline void DrawNoWallsControls(bool inMatch) {
        ImGui::TextWrapped("TEST feature, separate from the boxes below — only draws a box on "
            "enemies verified visible via the real LineOfSightTo check (green). Kept apart so "
            "it can't affect the already-working boxes if this misbehaves.");
        ImGui::Checkbox("Enable boxes - no through walls (test)", &noWallsBoxesEnabled);
        if (!inMatch) {
            ImGui::TextDisabled("Join a match to test.");
        }
    }

    // Enemies: red (close) -> hot pink -> purple (far). Hot palette.
    inline ImU32 ColorByDistanceEnemy(float dist, float maxDist) {
        float t = dist / maxDist;
        if (t < 0.0f) t = 0.0f;
        if (t > 1.0f) t = 1.0f;
        float r, g, b;
        if (t < 0.5f) {
            float k = t / 0.5f; // red -> hot pink
            r = 1.0f;
            g = 0.1f + (0.2f - 0.1f) * k;
            b = 0.1f + (0.55f - 0.1f) * k;
        } else {
            float k = (t - 0.5f) / 0.5f; // hot pink -> purple
            r = 1.0f - (1.0f - 0.55f) * k;
            g = 0.2f - (0.2f - 0.0f) * k;
            b = 0.55f + (0.85f - 0.55f) * k;
        }
        return ImGui::ColorConvertFloat4ToU32(ImVec4(r, g, b, 1.0f));
    }

    // Allies: soft green (close) -> cool blue (far). Cold palette, deliberately
    // far from the enemy hot palette. Close-range toned down from the original
    // neon green — too harsh to look at up close, now closer to the mid tone.
    inline ImU32 ColorByDistanceAlly(float dist, float maxDist) {
        float t = dist / maxDist;
        if (t < 0.0f) t = 0.0f;
        if (t > 1.0f) t = 1.0f;
        float r = 0.15f;
        float g = 0.65f - (0.65f - 0.35f) * t; // soft green fading toward blue
        float b = 0.35f + (0.85f - 0.35f) * t; // rises toward cool blue
        return ImGui::ColorConvertFloat4ToU32(ImVec4(r, g, b, 1.0f));
    }

    // Role lookup for name-label coloring, keyed on the INTERNAL class name
    // (what championName actually contains, e.g. "Gauntlet" not "Torvald" —
    // matches the SDK's TgPawn_ class name, not the live display name).
    // ONLY includes entries confirmed via this project's own reference data
    // (02_REFERENCE_DATA) or well-established champions I'm confident about.
    // Everything else defaults to plain white rather than guessing a role —
    // wrong is worse than unlabeled. Tell me if you spot a mislabeled/missing
    // one in-game and I'll add it.
    // Internal class name -> real display name. Only confirmed swaps go
    // here; anything not listed displays as-is (its raw internal name).
    struct NameSwap { const char* internalName; const char* realName; };
    static const NameSwap g_NameSwaps[] = {
        { "Longbow", "Sha Lin" },
        { "Gauntlet", "Torvald" },
        { "Blades", "Maeve" },
        { "Vampire", "Lillith" },
        { "Fairy", "Willo" },
        // "Demon" -> Talus. Previously mapped to Androxus, which was WRONG (it
        // showed "Androxus" on Talus). Now confirmed by the user in-game: the
        // pawn class ATgPawn_Demon IS Talus. Its kit fields match — teleport,
        // TELEPUNCH (Overcharge/Blitz Upper) and blood-sense.
        { "Demon", "Talus" },      // confirmed by user
        { "Flak",  "Ash" },        // confirmed by user
        { "Darklord", "Zhin" },    // confirmed by user
        { "Astro", "Jenos" },
        { "Corrupter", "Vora" },
        { "Churchill", "Vivian" }, // confirmed by user — old dev codename history
        { "Vanguard", "Khan" },    // confirmed by user
        { "Owl", "Strix" },
        { "Seven", "VII" },
        { "Oracle", "Seris" },
        { "VoodooTotem", "Totem" },   // not a full champion — Grohk's totem deployable
        // CORRECTED — these two were backwards. ATgPawn_Druid owns
        // m_CachedSpawnFox and r_ActiveFox (typed ATgPawn_DruidGuardian), so
        // Druid is the CHAMPION (Io) and DruidGuardian is her fox pet (Luna).
        { "Druid", "Io" },
        { "DruidGuardian", "Luna" },  // not a full champion — Io's fox pet
        // ATgPawn_BarrierTank has UpdateWallPlacementInfos + Start/EndGaeBolg
        // (Gae Bolg = the mythological spear) — wall placement plus a spear
        // weapon is Inara: Stone Spear, Warder's Field, Impasse.
        { "BarrierTank", "Inara" },
        { "BombQueen", "Betty la Bomba" }, // confirmed by user
        { "Shadow", "Vatu" },              // confirmed by user — matches the already-known ShadowTeleport device naming for Vatu's Ambush
        { "Princess", "Lian" },            // confirmed by user
        { "Bunny", "Rei" },                // confirmed by user
        { "Commander", "Octavia" },        // confirmed via her own class fields (jump/air-scope kit matches) AND the talent DB ("Commander Talent (Leap)" under Octavia's own section)
    };
    inline const char* TranslateToRealName(const char* internalName) {
        for (const auto& s : g_NameSwaps) {
            if (_stricmp(internalName, s.internalName) == 0) return s.realName;
        }
        return internalName;
    }

    enum class ChampionRole { DamageOrFlank, Tank, Healer };
    inline ChampionRole GetChampionRole(const char* champName) {
        // Vanguard=Khan confirmed too — Khan is Tank.
        static const char* tanks[]   = { "Atlas", "Barik", "Fernando", "Makoa", "Ruckus", "Azaan", "Gauntlet", "Vanguard", "BarrierTank" };
        // Astro=Jenos confirmed by user testing — added.
        // Oracle=Seris confirmed too — Seris is Support.
        // Bunny=Rei confirmed too — Rei is Support.
        static const char* healers[] = { "Grohk", "Grover", "Pip", "Ying", "Corvus", "Furia", "MalDamba", "Astro", "Oracle", "Bunny" };
        // Corrupter=Vora confirmed too — Vora is Damage, which is already the
        // default fallback, so no list entry needed for it.
        for (const char* n : tanks)   if (_stricmp(champName, n) == 0) return ChampionRole::Tank;
        for (const char* n : healers) if (_stricmp(champName, n) == 0) return ChampionRole::Healer;
        return ChampionRole::DamageOrFlank;
    }

    // Detects "just used ultimate" generically (no per-champion class needed):
    // watches each enemy's ultReady state, and when it flips from true to
    // false, that's the charge being spent — starts a rainbow-border window.
    // Pure cache/logic, no scripted calls, safe to run on the render thread.
    struct UltUseCacheEntry {
        SDK::ATgPawn* pawn;
        bool lastReady;
        ULONGLONG rainbowUntilMs;
    };
    inline UltUseCacheEntry g_UltUseCache[32] = {};

    inline bool UpdateAndCheckJustUlted(SDK::ATgPawn* pawn, bool currentlyReady) {
        if (!pawn) return false;
        ULONGLONG now = GetTickCount64();

        int slot = -1;
        for (int i = 0; i < 32; i++) {
            if (g_UltUseCache[i].pawn == pawn) { slot = i; break; }
        }
        if (slot == -1) {
            for (int i = 0; i < 32; i++) {
                if (!g_UltUseCache[i].pawn) { slot = i; break; }
            }
            if (slot == -1) slot = 0; // cache full, just reuse the first slot
            g_UltUseCache[slot].pawn = pawn;
            g_UltUseCache[slot].lastReady = currentlyReady;
            g_UltUseCache[slot].rainbowUntilMs = 0;
        }

        UltUseCacheEntry& entry = g_UltUseCache[slot];
        if (entry.lastReady && !currentlyReady) {
            entry.rainbowUntilMs = now + 3500; // ready -> not ready = they just used it
        }
        entry.lastReady = currentlyReady;
        return now < entry.rainbowUntilMs;
    }

    // Dashed rect border — used to mark an enemy as "behind a wall" without
    // hiding the box (the box itself keeps drawing through walls exactly like
    // it always has, per request — this is purely a style difference, not a
    // visibility gate). Reads GetCachedLos(), which is already safely
    // populated by UpdateLosCacheOnePerFrame() elsewhere.
    inline void DrawDashedRect(ImDrawList* draw, ImVec2 topLeft, ImVec2 botRight, ImU32 color, float thickness) {
        float dashLen = 6.0f, gapLen = 4.0f;
        float w = botRight.x - topLeft.x, h = botRight.y - topLeft.y;

        auto dashLine = [&](ImVec2 a, ImVec2 b) {
            float len = sqrtf((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y));
            if (len < 0.01f) return;
            ImVec2 dir{ (b.x - a.x) / len, (b.y - a.y) / len };
            float t = 0.0f;
            bool draw_on = true;
            while (t < len) {
                float seg = draw_on ? dashLen : gapLen;
                float segEnd = t + seg < len ? t + seg : len;
                if (draw_on) {
                    draw->AddLine(ImVec2(a.x + dir.x * t, a.y + dir.y * t),
                                  ImVec2(a.x + dir.x * segEnd, a.y + dir.y * segEnd), color, thickness);
                }
                t = segEnd;
                draw_on = !draw_on;
            }
        };

        dashLine(topLeft, ImVec2(topLeft.x + w, topLeft.y));
        dashLine(ImVec2(topLeft.x + w, topLeft.y), botRight);
        dashLine(botRight, ImVec2(topLeft.x, topLeft.y + h));
        dashLine(ImVec2(topLeft.x, topLeft.y + h), topLeft);
    }

    // Drawing only — no scripted calls, no gathering. Reads the cache that
    // GatherAndCache() (called from HookedProcessEvent, the safe thread)
    // already filled in. Safe to call from the render thread (hkPresent).
    // ================= 3D BOX =================
    // The flat box is derived purely from the capsule's top and bottom points.
    // Looking straight down at someone collapses those two to nearly the same
    // screen position, so the box shrinks to nothing and gets culled by the
    // minimum-height check — that's the "fly over an enemy and their box
    // vanishes" problem.
    //
    // A real 3D box projects all EIGHT corners of the bounding volume and draws
    // the twelve connecting edges. Corners spread out horizontally regardless of
    // view angle, so it stays readable from above, below, or any side, and it
    // reads as a solid volume rather than a flat rectangle.
    inline bool Draw3DBox(ImDrawList* draw, const GatherResult& g,
                          const PlainVec& fwd, const PlainVec& right, const PlainVec& up,
                          const PlainVec& center, float radius, float height,
                          ImU32 color, float thickness, float screenW, float screenH) {
        PlainVec corners[8] = {
            { center.x - radius, center.y - radius, center.z - height },
            { center.x + radius, center.y - radius, center.z - height },
            { center.x + radius, center.y + radius, center.z - height },
            { center.x - radius, center.y + radius, center.z - height },
            { center.x - radius, center.y - radius, center.z + height },
            { center.x + radius, center.y - radius, center.z + height },
            { center.x + radius, center.y + radius, center.z + height },
            { center.x - radius, center.y + radius, center.z + height },
        };
        ImVec2 pts[8];
        for (int i = 0; i < 8; i++) {
            if (!WorldToScreen(corners[i], g.camLoc, fwd, right, up, g.fov, screenW, screenH, pts[i]))
                return false; // any corner behind the camera -> skip, avoids smearing
        }
        // 4 bottom edges, 4 top edges, 4 verticals
        static const int edges[12][2] = {
            {0,1},{1,2},{2,3},{3,0},
            {4,5},{5,6},{6,7},{7,4},
            {0,4},{1,5},{2,6},{3,7}
        };
        for (auto& e : edges) draw->AddLine(pts[e[0]], pts[e[1]], color, thickness);
        return true;
    }

    // ================= BILLBOARD (camera-facing flat) BOX =================
    // Same root problem as the 3D box above (top/bottom points collapsing when
    // you're directly overhead), fixed a different way for people who want to
    // stay in flat 2D rather than switch to the 3D volume: instead of deriving
    // the box from two WORLD points that can go nearly coincident on screen,
    // size it directly from distance using the same depth/FOV relationship
    // WorldToScreen already uses for every point (screenSize = worldSize/depth
    // * screenScale). A flat rectangle, always facing the camera, sized purely
    // by how far away the target is — never by viewing angle — so it cannot
    // shrink from flying overhead, exactly like a billboard sprite.
    inline bool DrawBillboardBox(ImDrawList* draw, const GatherResult& g,
                                  const PlainVec& fwd, const PlainVec& right, const PlainVec& up,
                                  const PlainVec& worldCenter, float collisionRadius, float collisionHeight,
                                  ImU32 color, float thickness, float screenW, float screenH) {
        PlainVec delta{ worldCenter.x - g.camLoc.x, worldCenter.y - g.camLoc.y, worldCenter.z - g.camLoc.z };
        float depth = delta.x * fwd.x + delta.y * fwd.y + delta.z * fwd.z;
        if (depth < 10.0f) return false; // behind camera / degenerate, same guard as WorldToScreen

        ImVec2 centerScreen;
        if (!WorldToScreen(worldCenter, g.camLoc, fwd, right, up, g.fov, screenW, screenH, centerScreen)) return false;

        float fovRad = g.fov * (3.14159265f / 180.0f);
        float screenScale = (screenW / 2.0f) / tanf(fovRad / 2.0f);
        float halfWidth  = (collisionRadius / depth) * screenScale;
        float halfHeight = (collisionHeight / depth) * screenScale;
        if ((halfHeight * 2.0f) < 3.0f) return false; // too small to be worth drawing

        draw->AddRect(ImVec2(centerScreen.x - halfWidth, centerScreen.y - halfHeight),
                      ImVec2(centerScreen.x + halfWidth, centerScreen.y + halfHeight),
                      color, 0.0f, 0, thickness);
        return true;
    }

    inline void RenderBoxes() {
        if (!enabled) return;

        // FIX: this used to be called ONLY from DrawControls (the Highlights
        // tab UI), so switching champion while that tab was closed left
        // g_MyTableSpeed stale — you'd swap Maeve -> Lex and still get Maeve's
        // prediction box until you toggled the feature off and on. Refreshing
        // here means it tracks the pawn regardless of which tab is open. It
        // early-outs on an unchanged pawn pointer, so it costs nothing.
        UpdateMyChampionSpeed();

        const GatherResult& gathered = g_CachedGather;
        if (!gathered.ok) return;

        PlainVec fwd, right, up;
        RotatorToVectors(gathered.camPitch, gathered.camYaw, fwd, right, up);

        ImVec2 screenSize = ImGui::GetIO().DisplaySize;
        ImDrawList* draw = ImGui::GetBackgroundDrawList();

        // Computed once per frame (not per-entity — it's about OUR weapon, not
        // theirs) so both the red-box-hiding decision below and the white-box
        // section further down agree on the same values.
        float myProjSpeedForFrame = predictManualOverride ? 0.0f : g_MyTableSpeed;
        bool amHitscanForFrame = (!predictManualOverride && myProjSpeedForFrame == 0.0f);
        bool haveSpeedForFrame = predictManualOverride || myProjSpeedForFrame > 1.0f;
        // Only actually hides anything once the white box feature itself is on
        // AND our own weapon can produce one — an enemy on a hitscan champion
        // (of ours) always keeps their red box regardless of this setting.
        bool hidingRedForPredictOnly = predictBoxOnlyMode && showPredictBox && !amHitscanForFrame && haveSpeedForFrame;

        for (int i = 0; i < gathered.count; i++) {
            const BoxEntry& e = gathered.entries[i];

            PlainVec delta{ e.worldPos.x - gathered.camLoc.x, e.worldPos.y - gathered.camLoc.y, e.worldPos.z - gathered.camLoc.z };
            float dist = sqrtf(delta.x * delta.x + delta.y * delta.y + delta.z * delta.z);

            // Project the pawn's actual top/bottom (world-space capsule) instead
            // of a fixed pixel box, so size tracks real distance automatically.
            PlainVec topWorld{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight };
            PlainVec botWorld{ e.worldPos.x, e.worldPos.y, e.worldPos.z - e.collisionHeight };

            ImVec2 topScreen, botScreen;
            if (!WorldToScreen(topWorld, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, topScreen)) continue;
            if (!WorldToScreen(botWorld, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, botScreen)) continue;

            float boxHeight = botScreen.y - topScreen.y;
            if (boxHeight < 4.0f) continue;
            float boxWidth = (e.collisionHeight > 0.1f) ? boxHeight * (e.collisionRadius / e.collisionHeight) : boxHeight * 0.5f;
            float cx = (topScreen.x + botScreen.x) * 0.5f;

            // Deployables/turrets/pets/structures aren't real targets — flagged
            // a distinct milky-white so they read as "ignore this" at a glance.
            // Enemies use a hot (red->purple) palette, allies a cold (green->blue)
            // one — deliberately far apart so the two never get confused.
            ImU32 color;
            bool justUlted = (e.kind == BoxKind::Enemy) && UpdateAndCheckJustUlted(e.pawnPtr, e.ultReady);
            if (justUlted) {
                // Rainbow border for ~3.5s after their ult charge gets spent —
                // makes it obvious at a glance WHO just ulted.
                static float ultBorderHue = 0.0f;
                ultBorderHue += 0.01f;
                if (ultBorderHue > 1.0f) ultBorderHue -= 1.0f;
                float hr, hg, hb;
                ImGui::ColorConvertHSVtoRGB(ultBorderHue, 0.9f, 1.0f, hr, hg, hb);
                color = ImGui::ColorConvertFloat4ToU32(ImVec4(hr, hg, hb, 1.0f));
            } else if (e.kind == BoxKind::Other) {
                color = ImGui::ColorConvertFloat4ToU32(ImVec4(0.92f, 0.92f, 0.88f, 0.85f));
            } else if (e.kind == BoxKind::Ally) {
                color = ColorByDistanceAlly(dist, 6000.0f);
                // Cauterised teammate: swap the whole box to DARK BLUE so it
                // reads instantly as "healing them is reduced right now".
                // Deliberately a hue nowhere near the enemy palette.
                if (showAllyCauterize && e.healMitigatorCount > 0) {
                    color = ImGui::ColorConvertFloat4ToU32(
                        ImVec4(cautBoxColor[0], cautBoxColor[1], cautBoxColor[2], 1.0f));
                }
            } else {
                color = ColorByDistanceEnemy(dist, 6000.0f); // ~6000 units is a long Paladins sightline
            }
            // Behind a wall? Dashed border instead of solid — box still draws
            // exactly like it always has (position/color unchanged), this is
            // purely a style cue. Only meaningful once the throttled LOS
            // cache has actually checked this pawn at least once.
            bool behindWall = (e.kind == BoxKind::Enemy) && showWallIndicator && !GetCachedLos(e.pawnPtr);
            ImVec2 boxTL(cx - boxWidth * 0.5f, topScreen.y), boxBR(cx + boxWidth * 0.5f, botScreen.y);
            // "White box only" mode: this enemy will get a predicted (white)
            // box drawn later in this same iteration, so skip the normal
            // red/current-position outline entirely — never draw both.
            bool skipRedOutline = hidingRedForPredictOnly && e.kind == BoxKind::Enemy;
            bool drew3D = false;
            bool drewBillboard = false;
            if (!skipRedOutline) {
            if (use3DBoxes && !behindWall) {
                // Real volume — stays readable when viewed from above/below,
                // where the flat box collapses to nothing.
                drew3D = Draw3DBox(draw, gathered, fwd, right, up, e.worldPos,
                                   e.collisionRadius, e.collisionHeight,
                                   color, 1.6f, screenSize.x, screenSize.y);
            }
            // Staying flat but still don't want the overhead-collapse problem:
            // billboard sizes from distance alone, so it can't shrink from angle.
            if (!drew3D && !behindWall && billboardBoxes2D) {
                drewBillboard = DrawBillboardBox(draw, gathered, fwd, right, up, e.worldPos,
                                                 e.collisionRadius, e.collisionHeight,
                                                 color, 2.0f, screenSize.x, screenSize.y);
            }
            if (!drew3D && !drewBillboard) {
                if (behindWall) {
                    DrawDashedRect(draw, boxTL, boxBR, color, 2.0f);
                } else {
                    draw->AddRect(boxTL, boxBR, color, 0.0f, 0, 2.0f);
                }
            }
            } // !skipRedOutline

            // Stack order above the box, closest-to-box first: health bar,
            // then name label above that.
            float aboveY = topScreen.y;

            // Health bars: ENEMIES ONLY (allies already show this on the game's
            // own HUD). Darker red (high health) -> hot pink (low) — vivid
            // color signals "go hunt them now."
            // FIXED an aspect-ratio bug: barH used to be a FIXED pixel value
            // while barW shrank with distance — at long range the box got
            // narrower than the bar was tall, so it looked like a vertical
            // rectangle instead of a thin horizontal bar. barH now scales down
            // with the box too (clamped), so width always stays well ahead of
            // height regardless of distance.
            // Health bars. Enemies use showHealthBars; ALLIES have their own
            // separate toggle (showAllyHealthBars) so you can run one without the
            // other. The health value itself was always gathered for allies too —
            // it was only the drawing that excluded them — so this needed no new
            // data, just its own gate and its own colour ramp.
            //
            // BEHIND-WALL ONLY, per explicit request: the game's own HUD/model
            // already shows health when you can actually see someone, so the
            // custom bar is redundant (and clutter) there — it should only
            // appear for the one case the native UI can't help with: someone
            // hidden behind a wall. Same e.isVisible/wallCheckEnabled signal
            // the wall-check trigger-bot gate already uses. If wallCheckEnabled
            // itself is off there's no reliable "behind a wall" signal to act
            // on, so no bar draws — that's the same fail-safe direction as
            // everything else wallCheckEnabled gates.
            bool hiddenBehindWall = wallCheckEnabled && !e.isVisible;
            bool wantHealthBar =
                ((e.kind == BoxKind::Enemy && showHealthBars) ||
                 (e.kind == BoxKind::Ally  && showAllyHealthBars)) && hiddenBehindWall;
            if (wantHealthBar && e.healthPct >= 0.0f) {
                float barW = boxWidth;
                // Thickness: found a middle ground between "way too thick" and
                // "too thin to notice" — bigger floor/ceiling than last time.
                float barH = boxWidth * 0.16f;
                if (barH < 3.0f) barH = 3.0f;
                if (barH > 6.0f) barH = 6.0f;
                float barRounding = barH * 0.4f; // rounded corners — ONLY the health bar, boxes stay sharp
                float barY = aboveY - barH - 1.0f;
                ImU32 bg = ImGui::ColorConvertFloat4ToU32(ImVec4(0.1f, 0.1f, 0.1f, 0.85f));
                draw->AddRectFilled(ImVec2(cx - barW * 0.5f, barY), ImVec2(cx + barW * 0.5f, barY + barH), bg, barRounding);
                float fillW = barW * e.healthPct;
                float lowFactor = 1.0f - e.healthPct; // 0 at full, 1 at empty
                float hr, hg, hb;
                if (e.kind == BoxKind::Ally) {
                    // Allies read the opposite way round: a hurt TEAMMATE is
                    // something to help, not hunt. Healthy green -> urgent amber
                    // -> red as they drop, so a low ally is obvious at a glance
                    // without looking like an enemy bar.
                    hr = 0.20f + (0.95f - 0.20f) * lowFactor;
                    hg = 0.85f - (0.85f - 0.25f) * lowFactor;
                    hb = 0.35f - (0.35f - 0.15f) * lowFactor;
                } else {
                    // INVERTED per feedback: darker red (#7A1C42, full/high health,
                    // muted/calm) -> hot pink (#CC1672, low health, vibrant) — the
                    // more vivid the color, the more it reads as "go hunt them now."
                    hr = 0.478f + (0.800f - 0.478f) * lowFactor;
                    hg = 0.110f + (0.086f - 0.110f) * lowFactor;
                    hb = 0.259f + (0.447f - 0.259f) * lowFactor;
                }
                ImU32 fill = ImGui::ColorConvertFloat4ToU32(ImVec4(hr, hg, hb, 1.0f));
                draw->AddRectFilled(ImVec2(cx - barW * 0.5f, barY), ImVec2(cx - barW * 0.5f + fillW, barY + barH), fill, barRounding);
                aboveY = barY - 1.0f;

                // Optional exact numbers, allies only — useful for healers who
                // want to know how much healing is actually needed.
                if (e.kind == BoxKind::Ally && showAllyHealthNumbers) {
                    char hpTxt[24];
                    snprintf(hpTxt, sizeof(hpTxt), "%d%%", (int)(e.healthPct * 100.0f + 0.5f));
                    float fs = boxWidth * 0.18f;
                    if (fs < 9.0f) fs = 9.0f;
                    if (fs > 13.0f) fs = 13.0f;
                    ImVec2 ts = ImGui::GetFont()->CalcTextSizeA(fs, FLT_MAX, 0.0f, hpTxt);
                    draw->AddText(ImGui::GetFont(), fs, ImVec2(cx - ts.x * 0.5f, barY - ts.y - 1.0f),
                                  IM_COL32(230, 245, 235, 235), hpTxt);
                    aboveY = barY - ts.y - 2.0f;
                }
            }

            // Name label — ENEMIES ONLY, colored by role: Healer = slow
            // rainbow, Tank = deep off-white + extra-bold, Damage/Flank
            // (and anything unmapped) = the original light off-white bold.
            // All caps, scales down with distance so it doesn't look
            // oversized far away, no dark shadow in any case.
            if (showNameLabels && e.kind == BoxKind::Enemy && e.championName[0] != 0) {
                const char* realName = TranslateToRealName(e.championName);
                char label[32];
                size_t i = 0;
                for (; i < sizeof(label) - 1 && realName[i] != 0; i++) {
                    label[i] = (char)toupper((unsigned char)realName[i]);
                }
                label[i] = 0;
                float fontSize = boxWidth * 0.22f;
                if (fontSize < 10.0f) fontSize = 10.0f;
                if (fontSize > 15.0f) fontSize = 15.0f;
                ImVec2 textSize = ImGui::GetFont()->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, label);
                ImVec2 textPos(cx - textSize.x * 0.5f, aboveY - textSize.y - 2.0f);

                ChampionRole role = GetChampionRole(e.championName);
                ImU32 nameColor;
                int extraBoldPasses = 1; // damage/flank default: light double-draw
                if (role == ChampionRole::Healer) {
                    // No longer rainbow, per feedback — fixed soft green instead.
                    nameColor = ImGui::ColorConvertFloat4ToU32(ImVec4(0.45f, 0.95f, 0.55f, 1.0f));
                } else if (role == ChampionRole::Tank) {
                    nameColor = ImGui::ColorConvertFloat4ToU32(ImVec4(0.80f, 0.79f, 0.75f, 1.0f)); // deep off-white
                    extraBoldPasses = 3; // way thicker/bolder
                } else {
                    nameColor = ImGui::ColorConvertFloat4ToU32(ImVec4(0.94f, 0.95f, 0.97f, 1.0f));
                }

                draw->AddText(ImGui::GetFont(), fontSize, textPos, nameColor, label);
                for (int pass = 1; pass <= extraBoldPasses; pass++) {
                    float off = pass * 0.6f;
                    draw->AddText(ImGui::GetFont(), fontSize, ImVec2(textPos.x + off, textPos.y), nameColor, label);
                }

                // Ult ready — small rainbow-cycling circle next to the name,
                // only appears at 100%. Scales with the name's own font size.
                if (showUltIcon && e.ultReady) {
                    float dotR = fontSize * 0.28f;
                    static float ultHue = 0.0f;
                    ultHue += 0.0008f; // was 0.01f — way too fast, now slow like the RGB theme
                    if (ultHue > 1.0f) ultHue -= 1.0f;
                    float hr, hg, hb;
                    ImGui::ColorConvertHSVtoRGB(ultHue, 0.85f, 1.0f, hr, hg, hb);
                    ImU32 rainbow = ImGui::ColorConvertFloat4ToU32(ImVec4(hr, hg, hb, 1.0f));
                    draw->AddCircleFilled(ImVec2(textPos.x + textSize.x + dotR + 4.0f, textPos.y + textSize.y * 0.5f), dotR, rainbow);
                }
            }

            // Head box only for enemies — allies don't need one. Uses the
            // head position already resolved during GatherAndCache() (safe
            // thread) — no scripted call happens here on the render thread.
            if (showHeadBox && e.kind == BoxKind::Enemy) {
                ImVec2 headCenter;
                bool haveRealHead = false;
                if (e.hasHeadWorldPos) {
                    haveRealHead = WorldToScreen(e.headWorldPos, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, headCenter);
                }
                if (!haveRealHead) {
                    // Fallback: approximate as the top slice of the body box.
                    headCenter = ImVec2(cx, topScreen.y + boxHeight * 0.11f);
                }

                float headSize = boxWidth * 0.316f; // half size, then +15% per feedback
                ImU32 headColor = ImGui::ColorConvertFloat4ToU32(ImVec4(1.0f, 0.92f, 0.1f, 1.0f)); // always yellow

                // 3D head marker: a small cube around the real head bone. Same
                // benefit as the body version — it stays readable looking down
                // from above, where a flat square degenerates.
                bool head3D = false;
                if (use3DHeadBox && e.hasHeadWorldPos) {
                    float headHalf = e.collisionRadius * 0.45f; // roughly head-sized
                    head3D = Draw3DBox(draw, gathered, fwd, right, up, e.headWorldPos,
                                       headHalf, headHalf, headColor, 1.3f,
                                       screenSize.x, screenSize.y);
                }
                if (!head3D) {
                    draw->AddRect(ImVec2(headCenter.x - headSize * 0.5f, headCenter.y - headSize * 0.5f),
                                  ImVec2(headCenter.x + headSize * 0.5f, headCenter.y + headSize * 0.5f), headColor, 0.0f, 0, 1.5f);
                }
            }

            // Cauterise marker for ALLIES. The colour swap already signals it,
            // but a small label makes it unambiguous, and the reason code is how
            // we confirm which eReason value cauterize actually is.
            if (e.kind == BoxKind::Ally && showAllyCauterize && e.healMitigatorCount > 0) {
                char ct[32];
                if (showCautDebugReason)
                    snprintf(ct, sizeof(ct), "CAUT r=%d n=%d", e.healMitigatorReason, e.healMitigatorCount);
                else
                    snprintf(ct, sizeof(ct), "CAUT");
                float fs = boxWidth * 0.20f;
                if (fs < 9.0f) fs = 9.0f;
                if (fs > 14.0f) fs = 14.0f;
                ImVec2 ts = ImGui::GetFont()->CalcTextSizeA(fs, FLT_MAX, 0.0f, ct);
                draw->AddText(ImGui::GetFont(), fs, ImVec2(cx - ts.x * 0.5f, botScreen.y + 2.0f),
                              IM_COL32(120, 170, 255, 240), ct);
            }

            // ================= SKELETON =================
            // Every joint is a real world-space bone position projected through
            // the same WorldToScreen path as the boxes, so the skeleton is
            // genuinely 3D — it foreshortens and rotates correctly rather than
            // being a flat overlay pinned to the box.
            if (showSkeleton && e.hasBones &&
                (e.kind == BoxKind::Enemy || (skeletonAllies && e.kind == BoxKind::Ally))) {
                ImVec2 jp[64];
                bool ok[64];

                // STRAY LINES TO THE MIDDLE OF THE MAP - fixed here.
                //
                // A bone read that silently fails leaves a zero or stale vector
                // in the array. Zero is the world ORIGIN, which projects to
                // roughly the centre of the map - so the skeleton grew a long
                // line running off to nowhere. The bone flag said 'got it', so
                // nothing downstream could tell.
                //
                // A real bone is always within arm's reach of its own pawn, so
                // any joint further than a few body-heights from the pawn's own
                // position is a bad read and gets dropped. The rest of the
                // skeleton still draws.
                float maxBoneDist = e.collisionHeight * 5.0f;
                if (maxBoneDist < 400.0f) maxBoneDist = 400.0f;
                const float maxBoneDistSq = maxBoneDist * maxBoneDist;

                for (int b = 0; b < kBoneCount && b < 64; b++) {
                    ok[b] = false;
                    if (!e.boneGot[b]) continue;

                    float bx = e.bones[b].x - e.worldPos.x;
                    float by = e.bones[b].y - e.worldPos.y;
                    float bz = e.bones[b].z - e.worldPos.z;
                    if (bx * bx + by * by + bz * bz > maxBoneDistSq) continue;  // bad read

                    ok[b] = WorldToScreen(e.bones[b], gathered.camLoc, fwd, right, up,
                                          gathered.fov, screenSize.x, screenSize.y, jp[b]);
                }

                const int linkCount = (int)(sizeof(kBoneLinks) / sizeof(kBoneLinks[0]));

                if (skeletonOutlineMode) {
                    // ---- FAKE OUTLINE: hollow limbs, one continuous border ----
                    ImU32 ocol = skeletonOutlineUseOwnColor
                        ? ImGui::ColorConvertFloat4ToU32(ImVec4(skeletonOutlineColor[0],
                                                               skeletonOutlineColor[1],
                                                               skeletonOutlineColor[2],
                                                               skeletonOutlineColor[3]))
                        : color;

                    // Width scales with the box so it stays proportional at any
                    // range instead of swallowing distant enemies.
                    float halfW = skeletonOutlineWidth * 0.5f * (boxWidth / 60.0f);
                    if (halfW < 1.5f)  halfW = 1.5f;
                    if (halfW > 26.0f) halfW = 26.0f;
                    float lw = skeletonOutlineLine;

                    for (int L = 0; L < linkCount; L++) {
                        int a = kBoneLinks[L][0], b2 = kBoneLinks[L][1];
                        if (a >= kBoneCount || b2 >= kBoneCount) continue;
                        if (!ok[a] || !ok[b2]) continue;
                        DrawHollowLimb(draw, jp[a], jp[b2], halfW, ocol, lw);
                    }
                    // The joint circles close every limb's open ends, so the
                    // whole thing reads as ONE border with no visible segments.
                    for (int b = 0; b < kBoneCount && b < 64; b++) {
                        if (ok[b]) draw->AddCircle(jp[b], halfW, ocol, 14, lw);
                    }
                } else {
                    // ---- classic bone lines ----
                    // Thickness scales with the box so distant skeletons thin out
                    // instead of turning into a solid blob.
                    float thick = skeletonThickness;
                    if (skeletonThick) thick = boxWidth * 0.10f;
                    if (thick < 1.0f) thick = 1.0f;
                    if (thick > 14.0f) thick = 14.0f;

                    for (int L = 0; L < linkCount; L++) {
                        int a = kBoneLinks[L][0], b2 = kBoneLinks[L][1];
                        if (a >= kBoneCount || b2 >= kBoneCount) continue; // bounds guard
                        if (!ok[a] || !ok[b2]) continue;
                        draw->AddLine(jp[a], jp[b2], color, thick);
                    }
                    if (skeletonJoints) {
                        float jr = skeletonThick ? thick * 0.55f : skeletonJointRadius;
                        for (int b = 0; b < kBoneCount && b < 64; b++) {
                            if (ok[b]) draw->AddCircleFilled(jp[b], jr, color, 10);
                        }
                    }
                }
            }

            // ================= MOVEMENT TELEMETRY =================
            // Distance / speed / 3D direction. All derived from raw fields
            // already gathered (Location + Velocity), so nothing scripted runs
            // here. The direction arrow is the real velocity vector projected
            // into screen space — i.e. it points where they're ACTUALLY going
            // in 3D, including vertically, not just a 2D screen guess.
            if (e.kind == BoxKind::Enemy) {
                float speedUU = sqrtf(e.velocity.x * e.velocity.x +
                                      e.velocity.y * e.velocity.y +
                                      e.velocity.z * e.velocity.z);

                // Text block under the box
                if (showDistance || showSpeed || showVerticalState) {
                    char info[64]; info[0] = 0;
                    int len = 0;
                    if (showDistance) {
                        len += snprintf(info + len, sizeof(info) - len, "%.0fm", UnitsToMetres(dist));
                    }
                    if (showSpeed) {
                        len += snprintf(info + len, sizeof(info) - len, "%s%.0fm/s",
                                        len ? "  " : "", UnitsToMetres(speedUU));
                    }
                    if (showVerticalState) {
                        const char* vs = (e.velocity.z > 80.0f) ? "RISING"
                                       : (e.velocity.z < -80.0f) ? "FALLING" : "";
                        if (vs[0]) len += snprintf(info + len, sizeof(info) - len, "%s%s", len ? "  " : "", vs);
                    }
                    if (showCautDebugReason && e.healMitigatorCount > 0) {
                        len += snprintf(info + len, sizeof(info) - len, "%sCAUT r=%d n=%d",
                                        len ? "  " : "", e.healMitigatorReason, e.healMitigatorCount);
                    }
                    if (info[0]) {
                        float fs = boxWidth * 0.18f;
                        if (fs < 9.0f) fs = 9.0f;
                        if (fs > 13.0f) fs = 13.0f;
                        ImVec2 ts = ImGui::GetFont()->CalcTextSizeA(fs, FLT_MAX, 0.0f, info);
                        ImVec2 tp(cx - ts.x * 0.5f, botScreen.y + 3.0f);
                        // rising/falling tints the readout so it reads at a glance
                        ImU32 infoCol = (e.velocity.z > 80.0f) ? IM_COL32(120, 220, 255, 235)
                                      : (e.velocity.z < -80.0f) ? IM_COL32(255, 170, 90, 235)
                                      : IM_COL32(225, 230, 240, 225);
                        draw->AddText(ImGui::GetFont(), fs, tp, infoCol, info);
                    }
                }

                // 3D velocity arrow: project where they'll be in N seconds and
                // draw a line to it. Length/angle on screen therefore encode
                // real speed and real 3D heading, including up/down.
                if (showDirectionArrow && speedUU > 40.0f) {
                    PlainVec future{
                        e.worldPos.x + e.velocity.x * velocityArrowScale,
                        e.worldPos.y + e.velocity.y * velocityArrowScale,
                        e.worldPos.z + e.velocity.z * velocityArrowScale
                    };
                    ImVec2 fromS, toS;
                    if (WorldToScreen(e.worldPos, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, fromS) &&
                        WorldToScreen(future,     gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, toS)) {
                        ImU32 arrowCol = (e.velocity.z > 80.0f) ? IM_COL32(120, 220, 255, 240)
                                       : (e.velocity.z < -80.0f) ? IM_COL32(255, 170, 90, 240)
                                       : IM_COL32(120, 255, 160, 240);
                        draw->AddLine(fromS, toS, arrowCol, 2.0f);
                        // arrowhead
                        float ax = toS.x - fromS.x, ay = toS.y - fromS.y;
                        float alen = sqrtf(ax * ax + ay * ay);
                        if (alen > 6.0f) {
                            ax /= alen; ay /= alen;
                            float hs = 7.0f;
                            ImVec2 p1(toS.x - ax * hs - ay * hs * 0.5f, toS.y - ay * hs + ax * hs * 0.5f);
                            ImVec2 p2(toS.x - ax * hs + ay * hs * 0.5f, toS.y - ay * hs - ax * hs * 0.5f);
                            draw->AddTriangleFilled(toS, p1, p2, arrowCol);
                        }
                    }
                }

                // PREDICTED-POSITION BOX (white). Where they'll be once your shot
                // arrives: lead time = distance / projectile speed, using the real
                // GetProjectileSpeed() value. Hitscan weapons get no box (nothing
                // to lead). Purely a visual aid — no aim assistance, you place the
                // shot yourself.
                // HITSCAN GATE: if our champion is hitscan (table speed 0) there
                // is nothing to lead, so no box at all. This is the Lex bug —
                // previously a hitscan weapon fell through to predictManualLead
                // and drew a box anyway.
                // myProjSpeed/amHitscan/haveSpeed computed once per frame above
                // the loop now (myProjSpeedForFrame etc.) — reused here instead
                // of recomputing, so this section and the red-box-hiding
                // decision above can never disagree.
                float myProjSpeed = myProjSpeedForFrame;
                bool amHitscan = amHitscanForFrame;
                bool haveSpeed = haveSpeedForFrame;

                // Normally a white box only appears once the target is actually
                // moving (>40 u/s) so standing targets aren't cluttered with a
                // duplicate box. But if "white box only" mode just hid this
                // entity's red box entirely, a standing target would otherwise
                // render NOTHING — so drop that movement requirement in that
                // case; the white box just sits in place instead (still correct,
                // simply not "leading" anything).
                bool predictWouldNormallyShow = speedUU > 40.0f;
                bool showThisPredictBox = showPredictBox && !amHitscan && haveSpeed
                    && (predictWouldNormallyShow || skipRedOutline);

                if (showThisPredictBox) {
                    PlainVec relVel = e.velocity;
                    // Off by default — this was making the box leap around,
                    // worst of all while jumping (our own Z velocity subtracted).
                    if (predictAccountForOwnVelocity && Globals::LocalPawn) {
                        __try {
                            SDK::FVector mv = ((SDK::ATgPawn*)Globals::LocalPawn)->Velocity;
                            relVel.x -= mv.X; relVel.y -= mv.Y; relVel.z -= mv.Z;
                        }
                        __except (EXCEPTION_EXECUTE_HANDLER) { }
                    }
                    // A jumping/falling target otherwise throws the box well
                    // above or below them, which is never the useful aim point.
                    if (predictIgnoreVertical) relVel.z = 0.0f;

                    // Calibrated constant lead — see LeadSecondsForSpeed. The old
                    // distance-based intercept solve was the source of the wildly
                    // over-projected box.
                    float lead = predictManualOverride
                        ? predictManualLead
                        : LeadSecondsForSpeed(myProjSpeed);

                    if (lead > 0.0f && lead < 3.0f) {
                        // Predict using the SAME relative velocity the solve used,
                        // or the box won't match the time it computed.
                        PlainVec futTop{ e.worldPos.x + relVel.x * lead,
                                         e.worldPos.y + relVel.y * lead,
                                         e.worldPos.z + relVel.z * lead + e.collisionHeight };
                        PlainVec futBot{ e.worldPos.x + relVel.x * lead,
                                         e.worldPos.y + relVel.y * lead,
                                         e.worldPos.z + relVel.z * lead - e.collisionHeight };
                        ImVec2 pTop, pBot;
                        if (WorldToScreen(futTop, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, pTop) &&
                            WorldToScreen(futBot, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, pBot)) {
                            float ph = pBot.y - pTop.y;
                            if (ph > 3.0f) {
                                float pw = ph * (e.collisionRadius / e.collisionHeight);
                                float pcx = (pTop.x + pBot.x) * 0.5f;
                                ImU32 white = IM_COL32(255, 255, 255, 210);
                                bool pred3D = false;
                                PlainVec pc{ e.worldPos.x + relVel.x * lead,
                                             e.worldPos.y + relVel.y * lead,
                                             e.worldPos.z + relVel.z * lead };
                                if (predictBoxUse3D) {
                                    pred3D = Draw3DBox(draw, gathered, fwd, right, up, pc,
                                                       e.collisionRadius, e.collisionHeight,
                                                       white, 1.4f, screenSize.x, screenSize.y);
                                }
                                bool predBillboard = false;
                                if (!pred3D && billboardBoxes2D) {
                                    predBillboard = DrawBillboardBox(draw, gathered, fwd, right, up, pc,
                                                                     e.collisionRadius, e.collisionHeight,
                                                                     white, 1.6f, screenSize.x, screenSize.y);
                                }
                                if (!pred3D && !predBillboard)
                                draw->AddRect(ImVec2(pcx - pw * 0.5f, pTop.y),
                                              ImVec2(pcx + pw * 0.5f, pBot.y), white, 0.0f, 0, 1.6f);
                                // faint link so it's obvious which enemy it belongs to
                                draw->AddLine(ImVec2(cx, botScreen.y), ImVec2(pcx, pBot.y),
                                              IM_COL32(255, 255, 255, 70), 1.0f);
                            }
                        }
                    }
                }

                // Tracer: line from the bottom-centre of the screen to them.
                if (showTracers) {
                    draw->AddLine(ImVec2(screenSize.x * 0.5f, screenSize.y),
                                  ImVec2(cx, botScreen.y), IM_COL32(255, 80, 120, 140), 1.2f);
                }
            }
        }
    }

    inline void DrawControls(bool inMatch) {
        ImGui::TextWrapped("Detects real player pawns, draws a box sized to their actual "
            "collision cylinder (shrinks with distance). Enemies: red->pink->purple by "
            "distance, with a yellow head box (game's own headshot bone). Allies: "
            "green->blue by distance, no head box. Deployables/turrets/pets/structures "
            "show as milky white instead so you know to ignore them.");
        ImGui::Separator();
        // Enable boxes and the predicted-position box sit together at the very
        // top: the skeleton only draws when boxes are on, so this is the switch
        // everything else depends on. Both default ON now.
        ImGui::Checkbox(Tm("Enable boxes", "Activar cajas"), &enabled);
        ImGui::Checkbox(Tm("Predicted-position box (white)", "Caja de posicion prevista (blanca)"), &showPredictBox);
        ImGui::TextDisabled("White box shows where a moving enemy will be when your shot lands.");
        ImGui::TextDisabled("Its settings are further down under Movement telemetry.");
        ImGui::Separator();
        ImGui::Checkbox(Tm("Show head box (cosmetic only)", "Mostrar caja de cabeza (solo cosmetico)"), &showHeadBox);
        ImGui::Checkbox(Tm("Show enemy name labels (off-white, bold, all caps)", "Mostrar nombres de enemigos"), &showNameLabels);
        ImGui::Checkbox(Tm("Show ult-ready icon (gold dot, only at 100%)", "Mostrar icono de ultimate lista (punto dorado, solo al 100%)"), &showUltIcon);
        ImGui::Checkbox(Tm("Show health bars (enemies)", "Mostrar barras de vida (enemigos)"), &showHealthBars);
        // BORDER COLOUR VIA RANGE TRICK — REMOVED.
        // 'Range checks intercepted' sat at 0 in every test: the function is not
        // called under that name on this build, so the two force-range switches
        // could never colour a border. Recolouring outlines remains unsolved and
        // is written up in the Feature Ideas tab instead of faked here.
        //
        // 'Show ALLY health bars (through walls)' — REMOVED as a choice, not as
        // behaviour: ally bars already draw through walls unconditionally, so
        // the checkbox implied a mode that does not exist.
        //
        // 'Dashed border when behind a wall' — REMOVED. The wall test never
        // resolved, so the border never went dashed.
        //
        // The cauterise colour swap is kept but folded away: it is niche, and it
        // was cluttering the top of a tab whose main job is boxes.
        ImGui::Checkbox(Tm("Show ALLY health bars", "Mostrar barras de vida de ALIADOS"), &showAllyHealthBars);
        if (showAllyHealthBars) {
            ImGui::Indent();
            ImGui::Checkbox("Also show exact ally HP %", &showAllyHealthNumbers);
            ImGui::Unindent();
        }
        ImGui::TextDisabled("Ally bars run green -> amber -> red as they get hurt, so a low");
        ImGui::TextDisabled("teammate reads as 'help them' rather than looking like an enemy.");
        ImGui::TextDisabled("These already draw through walls - there is nothing to switch on.");

        ImGui::Spacing();
        if (ImGui::CollapsingHeader("Cauterise marker")) {
            ImGui::Checkbox("Ally box turns DARK BLUE when cauterised", &showAllyCauterize);
            if (showAllyCauterize) {
                ImGui::Indent();
                ImGui::ColorEdit3("Cauterised colour", cautBoxColor, ImGuiColorEditFlags_NoInputs);
                ImGui::Checkbox("Show raw reason code (debug)", &showCautDebugReason);
                ImGui::TextDisabled("Detected via ATgPawn::s_PawnHealMitigators — a non-empty array");
                ImGui::TextDisabled("means something is suppressing heals. Cauterize is the usual");
                ImGui::TextDisabled("cause but not the only one; see CautSensingExplained.txt.");
                ImGui::Unindent();
            }
        }
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.9f, 1.0f)), "SKELETON (bone ESP)");
        ImGui::TextWrapped("Real bone positions from the character rig, projected in 3D. Joints "
            "foreshorten and rotate correctly with the model rather than sitting flat on the box.");
        ImGui::Checkbox(Tm("Show skeleton", "Mostrar esqueleto"), &showSkeleton);
        if (showSkeleton) {
            ResolveBoneNames();
            ImGui::Text("Bones validated: %d / %d", g_BoneValidCount, kBoneCount);
            if (g_BoneValidCount == 0) {
                ImGui::TextColored(Ink(ImVec4(1.0f, 0.3f, 0.3f, 1.0f)),
                    "NONE validated - the dumped bone indices don't match this build.");
            }
            ImGui::Text("Detail:");
            ImGui::Checkbox("Arms", &boneGroupArms);
            ImGui::SameLine();
            ImGui::Checkbox("Hands", &boneGroupHands);
            ImGui::SameLine();
            ImGui::Checkbox("Legs", &boneGroupLegs);
            ImGui::Checkbox("Fingers (30 extra bones)", &boneGroupFingers);
            ImGui::SameLine();
            ImGui::Checkbox("Weapon/prop", &boneGroupProps);
            ImGui::TextDisabled("Spine/neck/head are always on. Each group adds scripted calls.");

            ImGui::Text("Safe-thread bone reads: %d", g_BoneSafeResolveCount);
            ImGui::Text("Render-thread fallback: %d", g_BoneFallbackReads);
            ImGui::Text("Cache slots filled    : %d", g_BoneCacheFilled);
            ImGui::Text("Bones read last pass  : %d", g_BoneLastReadCount);
            ImGui::Checkbox("Render-thread fallback (needed to make it render)", &boneRenderThreadFallback);
            ImGui::TextDisabled("The original working version read bones from the render thread.");
            ImGui::TextDisabled("Moving them off it is 'correct' but stopped them appearing, so this");
            ImGui::TextDisabled("fallback is ON. Untick only if bones cause crashes again.");
            ImGui::TextDisabled("If this stays 0, bones can never appear — check the Respawn tab's");
            ImGui::TextDisabled("heartbeat, since bone reads now run on that same thread.");
            ImGui::SliderInt("Refresh rate (Hz)", &boneRefreshHz, 5, 60);
            ImGui::TextDisabled("Higher = smoother but more scripted calls per second. If it gets");
            ImGui::TextDisabled("jittery or heavy, lower this first.");

            ImGui::Checkbox("Also draw skeleton on ALLIES", &skeletonAllies);
            ImGui::Separator();

            // ---- the fake outline ----
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)), "BONE OUTLINE (fake recolour)");
            ImGui::TextWrapped("The game outlines enemies in a colour we cannot change. This draws "
                "our own outline instead: every limb becomes a hollow tube and the joints are "
                "stroked as circles, so the whole skeleton reads as ONE continuous border with no "
                "visible segment ends - and it is any colour you like.");
            ImGui::Checkbox("Bone outline mode (hollow limbs)", &skeletonOutlineMode);
            if (skeletonOutlineMode) {
                ImGui::Indent();
                ImGui::SliderFloat("Outline width", &skeletonOutlineWidth, 2.0f, 40.0f, "%.1f");
                ImGui::TextDisabled("How far the border sits from the bone. Scales with distance.");
                ImGui::SliderFloat("Border weight", &skeletonOutlineLine, 0.5f, 6.0f, "%.1f");
                ImGui::TextDisabled("How thick the border LINE itself is drawn.");
                ImGui::Checkbox("Use my own colour", &skeletonOutlineUseOwnColor);
                if (skeletonOutlineUseOwnColor) {
                    ImGui::ColorEdit4("Outline colour", skeletonOutlineColor,
                                      ImGuiColorEditFlags_AlphaBar);
                } else {
                    ImGui::TextDisabled("Using the distance-graded box colour instead.");
                }
                ImGui::TextDisabled("Joint dots and thick limbs are ignored in this mode - they");
                ImGui::TextDisabled("would break the continuous-border look.");
                ImGui::Unindent();
            } else {
                ImGui::Checkbox("Thick limbs (toward silhouette)", &skeletonThick);
                if (skeletonThick) {
                    ImGui::TextDisabled("Thickness scales with distance so it doesn't blob up close.");
                } else {
                    ImGui::SliderFloat("Line thickness", &skeletonThickness, 1.0f, 8.0f);
                }
                ImGui::Checkbox("Joint dots", &skeletonJoints);
                if (skeletonJoints && !skeletonThick) {
                    ImGui::SliderFloat("Joint radius", &skeletonJointRadius, 1.0f, 8.0f);
                }
            }
            ImGui::TextDisabled("Bones that read as garbage are now dropped instead of drawn, which");
            ImGui::TextDisabled("is what caused the stray line running off to the middle of the map.");
            ImGui::TextDisabled("Uses the same colour as the box (distance-graded).");
            ImGui::TextDisabled("Bones refresh one enemy per frame to keep scripted calls bounded,");
            ImGui::TextDisabled("so a fast-moving skeleton can trail very slightly.");
        }
        ImGui::Separator();

        ImGui::Checkbox("3D boxes (8-corner volume)", &use3DBoxes);
        ImGui::SameLine();
        ImGui::Checkbox("3D head box", &use3DHeadBox);
        ImGui::TextDisabled("Both ON by default. Applies to enemy/ally boxes and the head marker.");
        ImGui::TextDisabled("The white prediction box has its own separate 2D/3D setting below.");
        if (!use3DBoxes) {
            ImGui::Checkbox("Billboard boxes (always face camera, no shrink from above)", &billboardBoxes2D);
            ImGui::TextDisabled("Only matters with 3D boxes OFF. A flat box sized purely by distance instead");
            ImGui::TextDisabled("of by two world points that can collapse when you're directly overhead —");
            ImGui::TextDisabled("stays a real, correctly-sized rectangle from any angle. ON by default.");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.5f, 1.0f, 0.8f, 1.0f)), "Movement telemetry");
        ImGui::TextWrapped("Distance and velocity read from the pawn's real Location/Velocity "
            "fields. The direction arrow is the actual 3D velocity vector projected to screen — "
            "its length is their speed and its angle is their true heading, including vertical. "
            "This is also the groundwork for proper 3D/skeleton overlays later.");
        ImGui::Checkbox(Tm("Show distance (metres)", "Mostrar distancia (metros)"), &showDistance);
        ImGui::Checkbox(Tm("Show speed (m/s)", "Mostrar velocidad (m/s)"), &showSpeed);
        ImGui::Checkbox(Tm("Show RISING / FALLING state", "Mostrar estado SUBIENDO / CAYENDO"), &showVerticalState);
        ImGui::Checkbox(Tm("Show 3D direction arrow", "Mostrar flecha de direccion 3D"), &showDirectionArrow);
        if (showDirectionArrow) {
            ImGui::SliderFloat("Arrow lead (seconds)", &velocityArrowScale, 0.1f, 2.0f);
            ImGui::TextDisabled("Higher = arrow projects further ahead of them.");
        }
        ImGui::Checkbox("Tracer lines from bottom of screen", &showTracers);

        ImGui::Spacing();
        // The ON/OFF switch for this lives at the TOP of the tab next to Enable
        // boxes; what follows is only its tuning.
        ImGui::TextColored(Ink(ImVec4(0.9f, 0.9f, 0.9f, 1.0f)), "Predicted-position box settings");
        if (showPredictBox) {
            UpdateMyChampionSpeed();
            ImGui::TextWrapped("White box showing where the enemy will be when your shot lands. "
                "Aim at it to lead a moving target. Display only — it never moves your aim.");

            ImGui::Checkbox("3D white box (independent of the 3D setting above)", &predictBoxUse3D);
            ImGui::TextDisabled("OFF by default — flat 2D rectangle. The prediction MATH is identical");
            ImGui::TextDisabled("either way; this only changes how the result is drawn.");

            ImGui::Checkbox("Hide red box, show white box only", &predictBoxOnlyMode);
            ImGui::TextDisabled("For projectile champions: never draw both at once — only the white,");
            ImGui::TextDisabled("predicted box appears for them. Hitscan enemies are unaffected (they");
            ImGui::TextDisabled("have no white box to switch to, so they keep their red box).");

            ImGui::Text("Your champion: %s", g_MyChampInternal[0] ? g_MyChampInternal : "(unknown)");
            ImGui::SameLine();
            if (g_MyTableSpeed < 0.0f) {
                ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)), "- not in table, no box");
            } else if (g_MyTableSpeed == 0.0f) {
                ImGui::TextColored(Ink(ImVec4(0.6f, 0.9f, 1.0f, 1.0f)), "- HITSCAN, no box needed");
            } else {
                ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), "- projectile %.1f u/s", g_MyTableSpeed);
            }

            if (!predictManualOverride && g_MyTableSpeed > 1.0f) {
                ImGui::Text("Auto lead: %.3fs", LeadSecondsForSpeed(g_MyTableSpeed));
                ImGui::SameLine();
                ImGui::TextDisabled("(= %.0f / %.0f)", predictLeadConstant, g_MyTableSpeed);
            }
            ImGui::SliderFloat("Lead constant", &predictLeadConstant, 5.0f, 120.0f, "%.0f");
            ImGui::TextDisabled("Calibrated from Maeve: 400 speed -> 0.10s. Raise/lower to taste;");
            ImGui::TextDisabled("every champion rescales automatically from this one number.");

            // Koga-specific controls, only shown when actually on him.
            if (_stricmp(g_MyChampInternal, "Koga") == 0) {
                ImGui::Separator();
                ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), "KOGA - claws are projectile, SMGs are hitscan");
                ImGui::Text("m_bUseSecondWeapon = %s",
                    g_KogaSecondWeaponFlag < 0 ? "unreadable" : (g_KogaSecondWeaponFlag ? "1" : "0"));
                ImGui::TextDisabled("Swap weapons in game and watch this flip. Tell me which value");
                ImGui::TextDisabled("is claws and I can hard-code it.");
                ImGui::Checkbox("Always assume claws (safest)", &kogaAssumeClaws);
                if (!kogaAssumeClaws) {
                    ImGui::Checkbox("Invert stance detection", &kogaInvertStance);
                    ImGui::TextDisabled("Tick this if the box appears on SMGs instead of claws.");
                }
                ImGui::SliderFloat("Claw projectile speed", &kogaClawSpeed, 200.0f, 700.0f, "%.0f");
                ImGui::Separator();
            }

            ImGui::Checkbox("Ignore vertical movement", &predictIgnoreVertical);
            ImGui::TextDisabled("Stops the box flying off when a target jumps. Recommended ON.");
            ImGui::Checkbox("Account for your own velocity", &predictAccountForOwnVelocity);
            ImGui::TextDisabled("OFF by default - this was making the box jump around.");

            ImGui::Checkbox("Manual lead override (debug)", &predictManualOverride);
            if (predictManualOverride) {
                ImGui::SliderFloat("Manual lead (seconds)", &predictManualLead, 0.02f, 0.6f, "%.3f");
                ImGui::TextColored(Ink(ImVec4(1.0f, 0.7f, 0.4f, 1.0f)), "Override ignores hitscan detection.");
            }
        }
        ImGui::TextDisabled("Blue tint = rising, orange = falling, green = level movement.");

        ImGui::Spacing();
        ImGui::Text("Your weapon's projectile speed:");
        UpdateProjectileSpeedThrottled();
        if (g_MyProjectileSpeed < 0.0f) {
            ImGui::TextDisabled("  unknown (not in a match, or couldn't read)");
        } else if (g_MyProjectileSpeed < 1.0f) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.9f, 0.5f, 1.0f)), "  HITSCAN (no projectile - instant hit)");
        } else {
            ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), "  %.0f uu/s   (%.1f m/s)",
                g_MyProjectileSpeed, UnitsToMetres(g_MyProjectileSpeed));
            // Handy derived number: how long the projectile takes to reach a
            // target at a given range, which is what actually matters for leading.
            ImGui::TextDisabled("  travel time: %.0fm = %.2fs   |   %.0fm = %.2fs",
                10.0f, (10.0f * 52.5f) / g_MyProjectileSpeed,
                30.0f, (30.0f * 52.5f) / g_MyProjectileSpeed);
        }
        ImGui::TextDisabled("Read from UTgDeviceFire::GetProjectileSpeed() for your CURRENT fire mode.");
        ImGui::TextDisabled("Switch fire modes and this updates - useful for comparing modes.");
        if (!inMatch) {
            ImGui::TextDisabled("Join a match to test.");
        }
    }

    // ============================================================================
    // CANVAS-DRAWN ENEMY BOXES — a second, independent drawing path
    // ============================================================================
    // WHY THIS EXISTS: the boxes above draw through ImGui, inside hkPresent -
    // which depends on the D3D11 render hook actually firing. On some real
    // machines (confirmed: NVIDIA driver doing its own D3D11 presentation
    // interception) that hook never fires at all, through no fault of the
    // hook-installation code itself - kiero's whole premise (any throwaway
    // device resolves the same Present the real game uses) can simply be
    // false there. No amount of fixing HOW the hook installs changes that.
    //
    // This draws through a completely different path that has NOTHING to do
    // with D3D11 or kiero at all: UE3's own PostRender(UCanvas* Canvas), the
    // same call two other, unrelated Paladins tools ("Magic"/CardsExploit,
    // confirmed via reverse-engineering its binary) use for their own overlay
    // drawing - Canvas->Draw2DLine/DrawText are real, native, SDK-confirmed
    // UCanvas functions (see PL_Engine_classes.hpp), called the exact same
    // way any other scripted function in this project already is. PostRender
    // is dispatched through ProcessEvent - the SAME hook that already reaches
    // 100% of the time on every machine that's ever been tested, including
    // the ones where the D3D11 hook fails completely. If this works, boxes
    // work regardless of whether the render hook ever fires.
    //
    // IMPORTANT, LEARNED THE HARD WAY: an EARLIER attempt to move the ImGui
    // box system's OWN camera read (PlayerCamera->CameraCache.POV) onto the
    // ProcessEvent thread broke boxes entirely, because that state isn't
    // finalized yet at the point PostRender fires in the frame. This is a
    // different technique, not that one: it calls Canvas->Project() on the
    // ACTUAL Canvas object the engine itself handed to PostRender for this
    // exact frame, using whatever view state the engine already set up on it
    // - not a manually-read camera snapshot. Untested against the real game
    // (this project has no way to run Paladins itself) - kept entirely
    // separate from and additive to the existing ImGui box system above, so
    // it cannot break what already works. Gated on the same `enabled` flag,
    // which defaults ON, specifically so it needs no menu interaction to
    // show something - the whole reason it exists is for machines where the
    // menu that WOULD let you turn it on can never appear in the first place.
    inline ULONGLONG g_LastCanvasBoxDrawMs = 0;
    inline int g_CanvasBoxDrawCount = 0;

    // DIAGNOSTIC LOGGING - added specifically because the first "it works!"
    // report was untrustworthy: on a machine where the OLD ImGui/D3D11 box
    // system ALSO works (which is most machines - it's only broken on some),
    // seeing boxes on screen proves NOTHING about whether THIS Canvas path
    // did anything at all, since both would be drawing at once. Every stage
    // below logs explicitly and unambiguously, tagged [CanvasBox], so a log
    // file alone (no need to trust what appeared on screen) proves whether
    // this mechanism is really the one doing the drawing.
    inline bool g_LoggedCanvasFirstCall = false;
    inline bool g_LoggedCanvasFirstDraw = false;
    inline bool g_LoggedCanvasException = false;
    inline bool g_LoggedCanvasSuppressed = false;
    inline bool g_LoggedCanvasActivated = false;
    inline ULONGLONG g_LastCanvasHeartbeatMs = 0;
    inline ULONGLONG g_CanvasCallCount = 0;
    inline ULONGLONG g_CanvasFirstCallMs = 0;

    // AUTO-FALLBACK GATE. Confirmed live: on a machine where the real D3D11
    // render hook already works, drawing Canvas boxes unconditionally too
    // produces a SECOND, visually different set of boxes on top of the real
    // ones at the same time - reported directly as "alien boxes... my actual
    // cheat isn't being rendered." Two inject buttons for two separate DLLs
    // does not fix this (picking the wrong one, or both, reproduces the same
    // overlap) - the actual fix is for the fallback to know when it isn't
    // needed. hkPresent firing at all, even once, sets
    // g_D3D11RenderHookConfirmedWorking permanently true - on every machine
    // that's ever been tested where the render hook works, that happens
    // within a couple hundred milliseconds of injection. GRACE_MS below is
    // a wide margin past that, so real machines never draw a single Canvas
    // box; only ones where hkPresent stays silent past that window - i.e.
    // genuinely broken - fall through to the Canvas path at all.
    static const ULONGLONG kCanvasGraceMs = 5000;

    inline void RenderBoxesViaCanvas(SDK::UCanvas* canvas) {
        g_CanvasCallCount++;
        if (g_CanvasFirstCallMs == 0) g_CanvasFirstCallMs = GetTickCount64();
        if (!g_LoggedCanvasFirstCall) {
            g_LoggedCanvasFirstCall = true;
            InitLog("[CanvasBox] RenderBoxesViaCanvas CALLED for the first time - PostRender detection "
                    "and Canvas parameter extraction both work, independent of the D3D11 render hook. "
                    "canvas=%p enabled=%d", (void*)canvas, enabled ? 1 : 0);
        }

        // g_SimulateFallbackMode (F6, main.cpp) forces this ON even on a
        // machine where the real hook works fine, so a working machine can
        // preview what a genuinely broken one sees without a second build or
        // a second person's PC - see the big comment on g_SimulateFallbackMode.
        if (g_D3D11RenderHookConfirmedWorking && !g_SimulateFallbackMode) {
            if (!g_LoggedCanvasSuppressed) {
                g_LoggedCanvasSuppressed = true;
                InitLog("[CanvasBox] D3D11 render hook confirmed working - Canvas fallback staying OFF "
                        "permanently for this session, so only the real wall system draws. No duplicate boxes.");
            }
            return;
        }
        if (GetTickCount64() - g_CanvasFirstCallMs < kCanvasGraceMs) return; // still inside the grace window - give the real hook a chance first
        if (!g_LoggedCanvasActivated) {
            g_LoggedCanvasActivated = true;
            InitLog("[CanvasBox] D3D11 render hook has NOT fired after %llu ms - activating the Canvas "
                    "fallback for the rest of this session. This is the ONLY box system that will draw now.",
                    (unsigned long long)kCanvasGraceMs);
        }

        if (!enabled || !canvas) return;
        if (!Globals::LocalController || !Globals::LocalPawn) return;

        __try {
            SDK::ATgPawn* myPawn = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!myPawn->WorldInfo) return;
            int myTeam = GetTeamIndexRaw(myPawn);

            SDK::UClass* tgPawnClass = SDK::ATgPawn::StaticClass();
            SDK::UClass* tgCharacterClass = SDK::ATgPawn_Character::StaticClass();
            if (!tgPawnClass || !tgCharacterClass) return;

            SDK::APawn* pawn = myPawn->WorldInfo->PawnList;
            int safety = 0;
            int drawn = 0;
            while (pawn && safety < 100) {
                safety++;
                SDK::APawn* next = pawn->NextPawn;

                if (pawn == Globals::LocalPawn || pawn->bDeleteMe || pawn->bPendingDelete || pawn->bTearOff) { pawn = next; continue; }
                if (!pawn->IsA(tgPawnClass)) { pawn = next; continue; }
                SDK::ATgPawn* tgPawn = (SDK::ATgPawn*)pawn;

                bool isRealCharacter = pawn->IsA(tgCharacterClass) && tgPawn->PlayerReplicationInfo;
                if (!isRealCharacter) { pawn = next; continue; }
                SDK::ATgRepInfo_Player* pri = (SDK::ATgRepInfo_Player*)tgPawn->PlayerReplicationInfo;
                if (pri->r_nHealthCurrent <= 0) { pawn = next; continue; }

                int theirTeam = GetTeamIndexRaw(tgPawn);
                bool isEnemy = (theirTeam != myTeam);
                if (!isEnemy) { pawn = next; continue; } // allies covered by the normal healthbar recolour path already

                // BUG FIX (confirmed live: boxes rendering floating above the
                // enemy, not around them). Location is the CENTER of the
                // pawn's collision cylinder in UE3, not its feet, and
                // CollisionHeight is already the HALF-height from that center
                // - not the full height. The original math treated Location
                // as the feet and added a doubled height on top of it, which
                // put the whole box roughly a body-height too high. Fixed:
                // top = center + halfHeight, bottom = center - halfHeight.
                float halfHeight = 44.0f, radius = 22.0f;
                if (pawn->CylinderComponent) {
                    halfHeight = pawn->CylinderComponent->CollisionHeight;
                    radius = pawn->CylinderComponent->CollisionRadius;
                }
                float height = halfHeight * 2.0f;

                SDK::FVector center = pawn->Location;
                SDK::FVector top = center; top.Z += halfHeight;
                SDK::FVector base = center; base.Z -= halfHeight;

                SDK::FVector screenTop = canvas->Project(top);
                SDK::FVector screenBottom = canvas->Project(base);
                // Project()'s Z here is a behind-camera indicator (UE3 convention:
                // <= 0 means it's not actually in front of the camera at all -
                // drawing it would put a box in the wrong place or off in space).
                if (screenTop.Z <= 0.0f || screenBottom.Z <= 0.0f) { pawn = next; continue; }

                float boxHeight = screenBottom.Y - screenTop.Y;
                if (boxHeight < 4.0f || boxHeight > 2000.0f) { pawn = next; continue; } // sanity bounds, not a real feature gate
                float boxWidth = boxHeight * (radius / (height * 0.5f)); // keep box aspect roughly matching the real cylinder's
                float left = screenTop.X - boxWidth * 0.5f;
                float right = screenTop.X + boxWidth * 0.5f;
                float top_y = screenTop.Y;
                float bottom_y = screenBottom.Y;

                SDK::FColor color;
                color.R = 255; color.G = 40; color.B = 40; color.A = 255; // enemy red, matches the ImGui box system's own convention

                canvas->Draw2DLine(left, top_y, right, top_y, color);
                canvas->Draw2DLine(right, top_y, right, bottom_y, color);
                canvas->Draw2DLine(right, bottom_y, left, bottom_y, color);
                canvas->Draw2DLine(left, bottom_y, left, top_y, color);

                if (!g_LoggedCanvasFirstDraw) {
                    g_LoggedCanvasFirstDraw = true;
                    InitLog("[CanvasBox] First real Draw2DLine call issued (enemy at screen %.0f,%.0f - %.0f,%.0f) - "
                            "Canvas->Project() and Canvas->Draw2DLine() both genuinely executed, not just resolved.",
                            left, top_y, right, bottom_y);
                }

                drawn++;
                pawn = next;
            }
            g_CanvasBoxDrawCount = drawn;
            g_LastCanvasBoxDrawMs = GetTickCount64();

            // Ongoing heartbeat, same idea as hkPresent's - proves this keeps
            // running over time rather than firing once then going quiet, and
            // reports how many enemies it actually found each tick so "zero
            // enemies in range" is distinguishable from "found some but didn't
            // draw them" in the log alone.
            ULONGLONG nowMs = GetTickCount64();
            if (nowMs - g_LastCanvasHeartbeatMs > 10000) {
                g_LastCanvasHeartbeatMs = nowMs;
                InitLog("[CanvasBox] heartbeat - %llu calls so far, %d enemy box(es) drawn this frame.",
                        (unsigned long long)g_CanvasCallCount, drawn);
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            if (!g_LoggedCanvasException) {
                g_LoggedCanvasException = true;
                InitLog("[CanvasBox] EXCEPTION caught inside the drawing block (code 0x%08lX) - something in "
                        "Project()/Draw2DLine() or the pawn walk faulted. Logged once so this isn't silently "
                        "invisible; the block is skipped for this frame and retried next frame as normal.",
                        GetExceptionCode());
            }
            // Never let a bad frame's worth of drawing take the game down -
            // same defensive posture as every other safe-thread block in this
            // project. Miss a frame of boxes rather than crash.
        }
    }
}
