// ============================================================================
// PHAROAH INJECTOR
//
// Minimal, self-contained DLL injector. Built from scratch rather than
// rebranding Sastasha, because that folder only ships the compiled .exe — there
// is no source to modify, despite the readme saying it's open source.
//
// Method: classic LoadLibrary injection.
//   1. OpenProcess on the target
//   2. VirtualAllocEx a buffer inside it
//   3. WriteProcessMemory the DLL PATH into that buffer
//   4. CreateRemoteThread pointed at LoadLibraryW with that path as the arg
//
// kernel32.dll is loaded at the same base address in every process on a given
// boot, so the LoadLibraryW pointer we resolve locally is valid in the target.
// That's what makes this short.
//
// Build (from a Developer Command Prompt, no project file needed):
//   cl /EHsc /std:c++17 /O2 main.cpp /link user32.lib gdi32.lib comdlg32.lib
//      /SUBSYSTEM:WINDOWS
// ============================================================================

// UNICODE must be defined BEFORE windows.h. Without it, macros like
// IDI_APPLICATION / IDC_ARROW expand to MAKEINTRESOURCEA (an LPSTR), which won't
// pass to the wide LoadIconW / LoadCursorW we call — that's the C2664 build
// error. The build script also passes /DUNICODE, so this is belt and braces.
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <commdlg.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cwctype>   // towlower, used by the "paladins" name match
#include <cstdio>    // _wfopen_s/fgetws/fputws - PHAROAH_lang.txt read/write
#include <cwchar>

// ---------- branding ----------
static const wchar_t* kAppTitle   = L"PHAROAH";
static const wchar_t* kAppSub     = L"Paladins Mod Loader";
static const wchar_t* kDefaultProc = L"Paladins.exe";

// Palette sampled from blue.png (the PHAROAH mask logo) so the app and its icon
// read as one piece: deep navy ground, teal nemes stripes, pale limestone face.
// The in-game menu uses the sand theme; this uses the LOGO's colours instead,
// because a sand-coloured window around a navy logo looks like two products.
//
// Theme swap later: red.png / brown.png / green.png are the same artwork in
// other colourways, so a theme picker can change both palette and icon together.
// SOFTENED from the first pass, which read as corporate/enterprise: the hard
// near-black header, sharp gold rule and serif title all pushed it that way.
// Now: lifted slate-blue instead of near-black navy, muted teal instead of
// saturated, no hard rules, and a single friendly sans typeface throughout.
static const COLORREF COL_BG         = RGB( 38,  56,  74);  // soft slate blue
static const COLORREF COL_PANEL      = RGB( 50,  71,  92);  // gently raised panel
static const COLORREF COL_HEADER     = RGB( 31,  47,  63);  // only slightly deeper
static const COLORREF COL_TEAL       = RGB( 92, 178, 174);  // muted, less neon
static const COLORREF COL_LIMESTONE  = RGB(226, 236, 240);  // headline text
static const COLORREF COL_INK        = RGB(206, 220, 228);  // body text
static const COLORREF COL_GOLD       = RGB(226, 190, 108);  // softened accent
static const COLORREF COL_OK         = RGB(126, 220, 176);
static const COLORREF COL_ERR        = RGB(240, 138, 128);

// Aliases so the painting code below reads naturally.
static const COLORREF COL_SAND_BG    = COL_BG;
static const COLORREF COL_SAND_PANEL = COL_PANEL;
static const COLORREF COL_SAND_DEEP  = COL_HEADER;
static const COLORREF COL_LAPIS      = COL_TEAL;

// ---------- control ids ----------
#define ID_COMBO_PROC   1001
#define ID_BTN_REFRESH  1002
#define ID_BTN_BROWSE   1003
#define ID_BTN_INJECT   1004
#define ID_EDIT_DLL     1005
#define ID_BTN_INJECT_LITE 1007
#define ID_BTN_LANG_EN  1008
#define ID_BTN_LANG_ES  1009
#define ID_BTN_TUTORIAL 1010
#define ID_TIMER_SCAN   2001

// Auto-rescan interval. The list was previously built ONCE at startup, so
// launching the injector before Paladins meant it never appeared — you had to
// close and reopen the app, which is exactly what happened.
static const UINT kScanIntervalMs = 1500;

static HWND g_hCombo, g_hDllEdit, g_hStatus;
static std::wstring g_StatusText = L"Ready.";
static bool g_StatusIsError = false;
static HBRUSH g_BgBrush, g_PanelBrush;
static HFONT  g_FontTitle, g_FontBody, g_FontSmall;
static HICON  g_Icon = nullptr;
// The icon's TRUE pixel dimensions, so it can be drawn scaled-to-fit instead of
// forced into a square. See MeasureIcon and the logo draw in the paint handler.
static int    g_IconW = 0;
static int    g_IconH = 0;

// Reads an icon's real size out of its bitmap. GetIconInfo hands back GDI bitmap
// handles that the caller owns, so both are deleted here — leaking them on every
// call would matter in a repainting window.
static void MeasureIcon(HICON icon, int* outW, int* outH) {
    *outW = 0; *outH = 0;
    if (!icon) return;
    ICONINFO ii{};
    if (!GetIconInfo(icon, &ii)) return;

    BITMAP bm{};
    // Prefer the colour bitmap; monochrome icons only have a mask, whose height
    // is doubled (image stacked over mask), hence the halving below.
    if (ii.hbmColor && GetObject(ii.hbmColor, sizeof(bm), &bm)) {
        *outW = bm.bmWidth;
        *outH = bm.bmHeight;
    } else if (ii.hbmMask && GetObject(ii.hbmMask, sizeof(bm), &bm)) {
        *outW = bm.bmWidth;
        *outH = bm.bmHeight / 2;
    }

    if (ii.hbmColor) DeleteObject(ii.hbmColor);
    if (ii.hbmMask)  DeleteObject(ii.hbmMask);
}

struct ProcEntry { DWORD pid; std::wstring name; };
static std::vector<ProcEntry> g_Procs;

// ---------- helpers ----------

static bool IsRunningAsAdmin() {
    BOOL isAdmin = FALSE;
    HANDLE token = nullptr;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) {
        TOKEN_ELEVATION elev{};
        DWORD sz = sizeof(elev);
        if (GetTokenInformation(token, TokenElevation, &elev, sizeof(elev), &sz))
            isAdmin = elev.TokenIsElevated;
        CloseHandle(token);
    }
    return isAdmin == TRUE;
}

// SeDebugPrivilege is NOT the same thing as "being an elevated admin process".
// Administrators normally HOLD this privilege in their token, but Windows
// keeps it DISABLED by default even for admins - it has to be explicitly
// turned on via AdjustTokenPrivileges before it does anything. Without it,
// OpenProcess/VirtualAllocEx can still be refused against a process in some
// configurations even though the caller is genuinely elevated (the manifest
// already forces elevation via requireAdministrator - this is a separate,
// additional gap). Enabling it costs nothing and only ever widens what we can
// reach, so it's called unconditionally before every injection attempt.
static void TryEnableDebugPrivilege() {
    HANDLE token = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token))
        return;
    LUID luid{};
    if (LookupPrivilegeValueW(nullptr, SE_DEBUG_NAME, &luid)) {
        TOKEN_PRIVILEGES tp{};
        tp.PrivilegeCount = 1;
        tp.Privileges[0].Luid = luid;
        tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        AdjustTokenPrivileges(token, FALSE, &tp, sizeof(tp), nullptr, nullptr);
        // AdjustTokenPrivileges can return TRUE while still not actually
        // granting the privilege (e.g. it wasn't present in the token at
        // all) - GetLastError() would say ERROR_NOT_ALL_ASSIGNED in that
        // case. Nothing to do about that here either way, so not checked;
        // this is a best-effort widening, not a requirement.
    }
    CloseHandle(token);
}

// Human-readable reason instead of a bare error code — the whole point is that
// a failed injection should say WHY.
static std::wstring ExplainLastError(DWORD err) {
    switch (err) {
        case ERROR_ACCESS_DENIED:
            return L"Access denied. Run PHAROAH as Administrator.";
        case ERROR_INVALID_PARAMETER:
            return L"Invalid parameter - is the process still running?";
        case ERROR_NOT_ENOUGH_MEMORY:
        case ERROR_OUTOFMEMORY:
            return L"Could not allocate memory inside the target process.";
        case ERROR_PARTIAL_COPY:
            return L"Partial copy - the target is likely 32-bit while this DLL is 64-bit (or vice versa).";
        case ERROR_FILE_NOT_FOUND:
            return L"File not found.";
        default: {
            wchar_t buf[256]{};
            FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                           nullptr, err, 0, buf, 255, nullptr);
            std::wstring s(buf);
            while (!s.empty() && (s.back() == L'\n' || s.back() == L'\r')) s.pop_back();
            if (s.empty()) s = L"Unknown error";
            return s + L" (code " + std::to_wstring(err) + L")";
        }
    }
}

static void SetStatus(const std::wstring& text, bool isError) {
    g_StatusText = text;
    g_StatusIsError = isError;
    if (g_hStatus) InvalidateRect(GetParent(g_hStatus), nullptr, TRUE);
}

// Only processes that own a VISIBLE TOP-LEVEL WINDOW are real "programs" from a
// user's point of view. That single test removes every service, driver host and
// background worker, and it's also what collapses the twelve Firefox content
// processes down to the one that actually has the browser window.
static bool ProcessHasVisibleWindow(DWORD pid) {
    struct Ctx { DWORD pid; bool found; } ctx{ pid, false };
    EnumWindows([](HWND hwnd, LPARAM lp) -> BOOL {
        Ctx* c = (Ctx*)lp;
        if (!IsWindowVisible(hwnd)) return TRUE;
        if (GetWindow(hwnd, GW_OWNER) != nullptr) return TRUE; // tool/child window
        int len = GetWindowTextLengthW(hwnd);
        if (len == 0) return TRUE;                             // untitled = not a real UI
        DWORD wpid = 0;
        GetWindowThreadProcessId(hwnd, &wpid);
        if (wpid == c->pid) { c->found = true; return FALSE; }
        return TRUE;
    }, (LPARAM)&ctx);
    return ctx.found;
}

// Matches "paladins" anywhere in the exe name, case-insensitively, rather than
// requiring an exact "Paladins.exe". Tempest and other launchers can name the
// binary differently, and an exact match would silently miss those.
static bool LooksLikePaladins(const std::wstring& name) {
    std::wstring lower = name;
    for (auto& ch : lower) ch = (wchar_t)towlower(ch);
    return lower.find(L"paladins") != std::wstring::npos;
}

static void RefreshProcessList() {
    // Preserve what the user had picked, so an auto-refresh can't yank the
    // selection out from under them mid-click.
    std::wstring prevSelName;
    int prevSel = (int)SendMessageW(g_hCombo, CB_GETCURSEL, 0, 0);
    if (prevSel >= 0 && prevSel < (int)g_Procs.size()) prevSelName = g_Procs[prevSel].name;

    // Don't rebuild while the dropdown is open — it would collapse the list
    // as you're reading it.
    if (SendMessageW(g_hCombo, CB_GETDROPPEDSTATE, 0, 0)) return;

    g_Procs.clear();
    SendMessageW(g_hCombo, CB_RESETCONTENT, 0, 0);

    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) {
        SetStatus(L"Could not enumerate processes.", true);
        return;
    }

    std::vector<ProcEntry> all;
    PROCESSENTRY32W pe{}; pe.dwSize = sizeof(pe);
    if (Process32FirstW(snap, &pe)) {
        do {
            all.push_back({ pe.th32ProcessID, pe.szExeFile });
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);

    // Keep only windowed programs, and only ONE entry per executable name —
    // previously every Firefox content process got its own line, which is exactly
    // the noise complained about. Paladins is force-kept even if the window check
    // is momentarily false (fullscreen/borderless transitions can hide it).
    for (const auto& p : all) {
        bool isTarget = LooksLikePaladins(p.name);
        if (!isTarget && !ProcessHasVisibleWindow(p.pid)) continue;

        bool dupe = false;
        for (const auto& kept : g_Procs) {
            if (_wcsicmp(kept.name.c_str(), p.name.c_str()) == 0) { dupe = true; break; }
        }
        if (!dupe) g_Procs.push_back(p);
    }

    // Anything matching "paladins" goes to the very top, then alphabetical.
    std::sort(g_Procs.begin(), g_Procs.end(), [](const ProcEntry& a, const ProcEntry& b) {
        bool aT = LooksLikePaladins(a.name);
        bool bT = LooksLikePaladins(b.name);
        if (aT != bT) return aT;
        return _wcsicmp(a.name.c_str(), b.name.c_str()) < 0;
    });

    int paladinsIdx = -1, restoreIdx = -1;
    for (size_t i = 0; i < g_Procs.size(); i++) {
        std::wstring label = g_Procs[i].name + L"   (" + std::to_wstring(g_Procs[i].pid) + L")";
        SendMessageW(g_hCombo, CB_ADDSTRING, 0, (LPARAM)label.c_str());
        if (paladinsIdx < 0 && LooksLikePaladins(g_Procs[i].name)) paladinsIdx = (int)i;
        if (!prevSelName.empty() && _wcsicmp(g_Procs[i].name.c_str(), prevSelName.c_str()) == 0)
            restoreIdx = (int)i;
    }

    // Keep the user's own choice if it still exists; otherwise auto-pick Paladins.
    int useIdx = (restoreIdx >= 0) ? restoreIdx : paladinsIdx;
    if (useIdx >= 0) SendMessageW(g_hCombo, CB_SETCURSEL, useIdx, 0);

    // Only touch the status line when the found/not-found state actually FLIPS.
    // Rewriting it every 1.5s would stomp on an injection result the moment you
    // finished reading it.
    static int lastFoundState = -1;
    int foundState = (paladinsIdx >= 0) ? 1 : 0;
    if (foundState != lastFoundState) {
        lastFoundState = foundState;
        if (foundState) SetStatus(L"Paladins detected - ready to inject.", false);
        else            SetStatus(L"Waiting for Paladins to start... (scanning automatically)", true);
    }
}

// ============================================================================
// FINDING THE DLL
// ============================================================================
// The path used to be hardcoded to the machine this was built on, which is fine
// for me and useless for everyone else - a downloaded ZIP would open with a path
// that does not exist on their PC.
//
// So: look next to the injector first. The release ZIP ships the exe and the DLL
// in the same folder, which means the box is already filled in correctly the
// moment someone unzips it and there is nothing to browse for.
//
// The old hardcoded path is kept as the LAST resort so my own dev build still
// finds the freshly compiled DLL without me retyping it.
static std::wstring FindDllPath() {
    wchar_t exePath[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, exePath, MAX_PATH);

    std::wstring dir(exePath);
    size_t slash = dir.find_last_of(L"\\/");
    if (slash != std::wstring::npos) dir = dir.substr(0, slash + 1);
    else                             dir = L"";

    // Names in order of preference. PHAROAH.dll is what the release ZIP calls
    // it; Talents.dll is the raw build output name.
    static const wchar_t* kNames[] = {
        L"PHAROAH.dll",
        L"Talents.dll",
        L"bin\\Talents.dll",
        L"dll\\PHAROAH.dll",
    };

    for (const wchar_t* nm : kNames) {
        std::wstring cand = dir + nm;
        if (GetFileAttributesW(cand.c_str()) != INVALID_FILE_ATTRIBUTES)
            return cand;
    }

    // A developer fallback pointing at the original build tree used to be here.
    // Removed: it was an absolute path on one specific machine, so for everyone
    // else it was dead weight that also leaked a username. The names above cover
    // both the release layout and a normal build output.

    // Nothing found - hand back the folder so the message is useful.
    return dir + L"PHAROAH.dll";
}

// Same idea, for the separate LITE build - see PHAROAH LITE below. Its own
// function rather than a parameter on FindDllPath because the two have
// different name lists and, unlike the main DLL, LITE has no user-editable
// path box to fall back on if this comes up empty - it's this or nothing.
static std::wstring FindLiteDllPath() {
    wchar_t exePath[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, exePath, MAX_PATH);
    std::wstring dir(exePath);
    size_t slash = dir.find_last_of(L"\\/");
    if (slash != std::wstring::npos) dir = dir.substr(0, slash + 1);
    else                             dir = L"";

    static const wchar_t* kNames[] = {
        L"PHAROAH_LITE.dll",
        L"TalentsLite.dll",
        L"bin\\TalentsLite.dll",
    };
    for (const wchar_t* nm : kNames) {
        std::wstring cand = dir + nm;
        if (GetFileAttributesW(cand.c_str()) != INVALID_FILE_ATTRIBUTES)
            return cand;
    }
    return dir + L"PHAROAH_LITE.dll";
}
static std::wstring g_LiteDllPath;

// ============================================================================
// LANGUAGE - writes PHAROAH_lang.txt next to the injector (and next to
// whichever DLL gets injected, since both live in the same release folder).
// Both DLLs read it at startup to set their initial language ("EN"/"ES");
// their own in-menu language controls (LITE's EN/ES header button, the full
// build's ESPANOL toggle next to POTATO MODE) still change it any time
// afterwards regardless of what this file said - this is just a sensible
// starting point picked before injecting, not a hard requirement.
// ============================================================================
static bool g_UseSpanish = false;

static std::wstring LangFilePath() {
    wchar_t exePath[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, exePath, MAX_PATH);
    std::wstring dir(exePath);
    size_t slash = dir.find_last_of(L"\\/");
    dir = (slash != std::wstring::npos) ? dir.substr(0, slash + 1) : L"";
    return dir + L"PHAROAH_lang.txt";
}
static void LoadLangChoice() {
    FILE* f = nullptr;
    if (_wfopen_s(&f, LangFilePath().c_str(), L"r") == 0 && f) {
        wchar_t buf[8] = {};
        fgetws(buf, 8, f);
        fclose(f);
        g_UseSpanish = (_wcsnicmp(buf, L"ES", 2) == 0);
    }
}
static void SaveLangChoice() {
    FILE* f = nullptr;
    if (_wfopen_s(&f, LangFilePath().c_str(), L"w") == 0 && f) {
        fputws(g_UseSpanish ? L"ES" : L"EN", f);
        fclose(f);
    }
}

static bool InjectDll(DWORD pid, const std::wstring& dllPath, std::wstring& errOut) {
    if (GetFileAttributesW(dllPath.c_str()) == INVALID_FILE_ATTRIBUTES) {
        errOut = L"DLL not found at that path.";
        return false;
    }

    TryEnableDebugPrivilege();

    HANDLE proc = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION |
                              PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ,
                              FALSE, pid);
    if (!proc) {
        errOut = L"OpenProcess failed. " + ExplainLastError(GetLastError());
        return false;
    }

    // Architecture check up front — a 32/64-bit mismatch otherwise fails much
    // later with a confusing ERROR_PARTIAL_COPY.
    BOOL targetIsWow64 = FALSE, selfIsWow64 = FALSE;
    IsWow64Process(proc, &targetIsWow64);
    IsWow64Process(GetCurrentProcess(), &selfIsWow64);
    if (targetIsWow64 != selfIsWow64) {
        CloseHandle(proc);
        errOut = L"Architecture mismatch: the target process is a different bitness than this injector.";
        return false;
    }

    SIZE_T bytes = (dllPath.size() + 1) * sizeof(wchar_t);
    LPVOID remote = VirtualAllocEx(proc, nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote) {
        DWORD e = GetLastError();
        CloseHandle(proc);
        // OpenProcess (just above) already succeeded with PROCESS_VM_OPERATION
        // in its access mask - so if THIS still comes back ACCESS_DENIED, the
        // handle's rights were fine at open time and something is intercepting
        // the actual memory operation instead. "Run as admin" (which is already
        // forced by this injector's own manifest, so it's essentially always
        // true here) is very unlikely to be the real fix for this specific
        // failure. The known real cause in the wild is a security product's
        // kernel driver silently stripping handle rights on this exact class of
        // call - and the most commonly OVERLOOKED source of that is Windows'
        // own Tamper Protection, which stays active even when the main
        // Defender real-time-protection toggle is switched off (it's a
        // separate setting). Say so explicitly instead of repeating advice
        // that's already been tried and confirmed not to work.
        if (e == ERROR_ACCESS_DENIED) {
            errOut = L"VirtualAllocEx failed: Access denied - even though this already has an "
                     L"elevated handle. This is NOT the usual \"run as admin\" problem (you're "
                     L"already elevated by this point). Something is blocking memory access to "
                     L"the game process specifically. Most likely causes:\n\n"
                     L"1. Windows Tamper Protection - a SEPARATE setting from the main Defender "
                     L"on/off toggle, and it stays active even when that's off. Windows Security "
                     L"-> Virus & threat protection -> Manage settings -> turn OFF Tamper Protection.\n\n"
                     L"2. A different antivirus/endpoint-security product (not Windows Defender) "
                     L"running alongside it - check for anything else installed, including ones "
                     L"that run silently in the background.\n\n"
                     L"3. Windows Exploit Protection app-specific settings for Paladins.exe - "
                     L"Windows Security -> App & browser control -> Exploit protection -> "
                     L"Program settings -> check if Paladins.exe has an override there.";
        } else {
            errOut = L"VirtualAllocEx failed. " + ExplainLastError(e);
        }
        return false;
    }

    if (!WriteProcessMemory(proc, remote, dllPath.c_str(), bytes, nullptr)) {
        DWORD e = GetLastError();
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        CloseHandle(proc);
        errOut = L"WriteProcessMemory failed. " + ExplainLastError(e);
        return false;
    }

    // kernel32 sits at the same base in every process this boot, so our local
    // LoadLibraryW address is valid inside the target.
    HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
    LPTHREAD_START_ROUTINE loadLib =
        (LPTHREAD_START_ROUTINE)GetProcAddress(k32, "LoadLibraryW");
    if (!loadLib) {
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        CloseHandle(proc);
        errOut = L"Could not resolve LoadLibraryW.";
        return false;
    }

    HANDLE thread = CreateRemoteThread(proc, nullptr, 0, loadLib, remote, 0, nullptr);
    if (!thread) {
        DWORD e = GetLastError();
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        CloseHandle(proc);
        errOut = L"CreateRemoteThread failed. " + ExplainLastError(e);
        return false;
    }

    WaitForSingleObject(thread, 5000);

    // LoadLibrary returns the module handle; 0 means the DLL itself failed to
    // load inside the target (bad dependency, wrong bitness, DllMain returned
    // FALSE). Distinguishing that from "injection failed" matters.
    DWORD exitCode = 0;
    GetExitCodeThread(thread, &exitCode);

    CloseHandle(thread);
    VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
    CloseHandle(proc);

    if (exitCode == 0) {
        errOut = L"Injected, but LoadLibrary failed inside the game. "
                 L"Usually a missing dependency, a bitness mismatch, or DllMain returning FALSE.";
        return false;
    }
    return true;
}

// ============================================================================
// AUTOMATIC LOADING SETUP - REMOVED per explicit request ("I dont want it,
// I say remove totally"). Was the proxy-DLL method (rename d3d11.dll aside,
// drop PHAROAH.dll in as d3d11.dll). The two-button layout below (INJECT
// PHAROAH / INJECT PHAROAH LITE, with the LITE button explicitly framed as
// "if the first one fails, use this instead") replaces it as the guidance
// for what to try next when injection doesn't work.
// ============================================================================

// ---------- owner-drawn buttons ----------
// Plain BS_PUSHBUTTON draws as a default system-grey button regardless of
// any brush WM_CTLCOLORBTN returns - Windows never asks the app to paint a
// standard push button's face. Real colour needs BS_OWNERDRAW + WM_DRAWITEM.
// Used for the three injection buttons specifically, per PRIMAL_MONKE: make
// INJECT read as the clearly-primary, recommended action (gold, matching
// the site's own DOWNLOAD PHAROAH button) and the other two as real but
// secondary options (muted / teal) - not three equally-weighted buttons a
// new user has to guess between.
static void DrawOwnerButton(LPDRAWITEMSTRUCT dis, const wchar_t* label,
                             COLORREF fill, COLORREF fillHot, COLORREF border, COLORREF text, HFONT font) {
    bool hot = (dis->itemState & ODS_SELECTED) != 0;
    HBRUSH b = CreateSolidBrush(hot ? fillHot : fill);
    FillRect(dis->hDC, &dis->rcItem, b);
    DeleteObject(b);
    HPEN pen = CreatePen(PS_SOLID, 1, border);
    HGDIOBJ oldPen = SelectObject(dis->hDC, pen);
    HGDIOBJ oldBrush = SelectObject(dis->hDC, GetStockObject(NULL_BRUSH));
    Rectangle(dis->hDC, dis->rcItem.left, dis->rcItem.top, dis->rcItem.right, dis->rcItem.bottom);
    SelectObject(dis->hDC, oldBrush);
    SelectObject(dis->hDC, oldPen);
    DeleteObject(pen);

    SetBkMode(dis->hDC, TRANSPARENT);
    SetTextColor(dis->hDC, text);
    HGDIOBJ oldFont = SelectObject(dis->hDC, font);
    DrawTextW(dis->hDC, label, -1, &dis->rcItem, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    SelectObject(dis->hDC, oldFont);
}

// ---------- painting ----------

static void PaintWindow(HWND hwnd) {
    PAINTSTRUCT ps;
    HDC dc = BeginPaint(hwnd, &ps);
    RECT rc; GetClientRect(hwnd, &rc);

    FillRect(dc, &rc, g_BgBrush);

    // Header band — rounded bottom corners and NO hard divider rule. The sharp
    // full-width gold line was the main thing making this feel like a business
    // app rather than a mod.
    HBRUSH deep = CreateSolidBrush(COL_HEADER);
    HRGN hdr = CreateRoundRectRgn(-12, -12, rc.right + 12, 96, 22, 22);
    FillRgn(dc, hdr, deep);
    DeleteObject(hdr);
    DeleteObject(deep);

    // Soft teal underline that stops short of the edges, instead of a rule
    // spanning the whole window.
    HBRUSH accent = CreateSolidBrush(COL_TEAL);
    RECT underline = { 96, 84, 96 + 150, 86 };
    FillRect(dc, &underline, accent);
    DeleteObject(accent);

    // LOGO — scaled to fit its box with the aspect ratio preserved, and centred
    // in that box. Previously this drew at a hardcoded 64x64 regardless of the
    // icon's real dimensions, which is what made it look cropped: if the .ico has
    // no 64px frame, Windows substitutes the nearest one and forcing it into a
    // square box stretches or clips it. g_IconW/g_IconH are the icon's TRUE size,
    // measured at load time.
    if (g_Icon) {
        const int boxX = 18, boxY = 14, boxSize = 64;
        int dw = boxSize, dh = boxSize;
        if (g_IconW > 0 && g_IconH > 0) {
            // Fit to the box on the longer side, so nothing is ever cut off.
            if (g_IconW >= g_IconH) {
                dw = boxSize;
                dh = (int)((float)boxSize * (float)g_IconH / (float)g_IconW);
            } else {
                dh = boxSize;
                dw = (int)((float)boxSize * (float)g_IconW / (float)g_IconH);
            }
        }
        if (dw < 1) dw = 1;
        if (dh < 1) dh = 1;
        int ox = boxX + (boxSize - dw) / 2;
        int oy = boxY + (boxSize - dh) / 2;
        DrawIconEx(dc, ox, oy, g_Icon, dw, dh, 0, nullptr, DI_NORMAL);
    }

    SetBkMode(dc, TRANSPARENT);
    SetTextColor(dc, COL_LIMESTONE);
    SelectObject(dc, g_FontTitle);
    // Letter-spaced wordmark — reads as branding rather than a form label.
    {
        int x = 96;
        for (const wchar_t* p = kAppTitle; *p; ++p) {
            TextOutW(dc, x, 20, p, 1);
            SIZE sz; GetTextExtentPoint32W(dc, p, 1, &sz);
            x += sz.cx + 4;
        }
    }

    SetTextColor(dc, COL_TEAL);
    SelectObject(dc, g_FontSmall);
    TextOutW(dc, 98, 60, kAppSub, (int)wcslen(kAppSub));

    // Field labels
    SelectObject(dc, g_FontBody);
    SetTextColor(dc, COL_INK);
    TextOutW(dc, 20, 112, L"Target process", 14);
    TextOutW(dc, 20, 180, L"DLL to inject", 13);

    // Status strip
    RECT status = { 0, rc.bottom - 34, rc.right, rc.bottom };
    HBRUSH sb = CreateSolidBrush(COL_SAND_PANEL);
    FillRect(dc, &status, sb);
    DeleteObject(sb);

    SetTextColor(dc, g_StatusIsError ? COL_ERR : COL_OK);
    SelectObject(dc, g_FontSmall);
    RECT textRc = { 14, rc.bottom - 27, rc.right - 14, rc.bottom - 6 };
    DrawTextW(dc, g_StatusText.c_str(), -1, &textRc, DT_LEFT | DT_END_ELLIPSIS | DT_SINGLELINE);

    EndPaint(hwnd, &ps);
}

// ============================================================================
// TUTORIAL - "not a regular README with BS... just make it normal, tells you
// what this is, what it can do, most important info at the top." A real
// in-app window with a scrollable, read-only text box - not a popup, not a
// .txt file. Content follows g_UseSpanish.
// ============================================================================
static const wchar_t* kTutorialEN =
L"WHAT PHAROAH IS\r\n"
L"PHAROAH is a client-side mod for Paladins: wallhack-style boxes on players, a trigger bot, "
L"a card/ability spam helper, aim assist, and cosmetic unlocking - injected into the game while "
L"it's running. Two versions ship together:\r\n\r\n"
L"  - PHAROAH (the full menu) - everything, in a full in-game window.\r\n"
L"  - PHAROAH LITE - a smaller, simpler build for machines where the full menu's render hook "
L"doesn't work. Fewer features, but far more likely to actually show up and run smoothly.\r\n\r\n"
L"------------------------------------------------------------\r\n"
L"HOW TO USE THIS INJECTOR\r\n"
L"1. Start Paladins first (or start this injector first - it will find the game automatically "
L"once it launches).\r\n"
L"2. Pick your language below if you haven't already (English/Espanol).\r\n"
L"3. Click INJECT PHAROAH. Try that first.\r\n"
L"4. If nothing appears, the game does nothing different, or it gets laggy: close the game, "
L"reopen it, and click INJECT PHAROAH LITE instead.\r\n"
L"5. In game: press F3 to show/hide the full PHAROAH menu, or F3 for PHAROAH LITE's own panel.\r\n\r\n"
L"------------------------------------------------------------\r\n"
L"IF INJECTION FAILS\r\n"
L"The status bar at the bottom of this window explains why. The most common cause is Windows "
L"Tamper Protection (a SEPARATE setting from the main Windows Defender on/off switch) - go to "
L"Windows Security > Virus & threat protection > Manage settings > turn OFF Tamper Protection. "
L"Also check for any other antivirus/security software running in the background.\r\n\r\n"
L"------------------------------------------------------------\r\n"
L"WHAT EACH MAIN FEATURE DOES\r\n"
L"  - Boxes/walls - see enemies and allies through walls.\r\n"
L"  - Trigger bot - fires automatically when your crosshair is on an enemy. Off by default.\r\n"
L"  - Cards/abilities - detects your loadout and can spam cards or cycle ability fire modes.\r\n"
L"  - Aim assist / magnet aim - gently pulls your aim toward a target while you fire.\r\n"
L"  - Unlocker - unlocks cosmetics in the menu (outside of a live match).\r\n"
L"  - Health bar recolour - makes the game's own health bars easier to read at a glance.\r\n\r\n"
L"This tool is provided free and open source. Use it however your own conscience and your "
L"game's rules allow.";

static const wchar_t* kTutorialES =
L"QUE ES PHAROAH\r\n"
L"PHAROAH es un mod del lado del cliente para Paladins: cajas tipo wallhack sobre los "
L"jugadores, disparo automatico, ayuda para usar cartas/habilidades, asistencia de punteria "
L"y desbloqueo de cosmeticos - se inyecta en el juego mientras esta corriendo. Se incluyen dos "
L"versiones:\r\n\r\n"
L"  - PHAROAH (menu completo) - todo, en una ventana completa dentro del juego.\r\n"
L"  - PHAROAH LITE - una version mas simple para equipos donde el menu completo no funciona "
L"bien. Menos funciones, pero mucho mas probable que funcione sin problemas.\r\n\r\n"
L"------------------------------------------------------------\r\n"
L"COMO USAR ESTE INYECTOR\r\n"
L"1. Abre Paladins primero (o abre este inyector primero - detectara el juego automaticamente).\r\n"
L"2. Elige tu idioma abajo si no lo has hecho (English/Espanol).\r\n"
L"3. Haz clic en INJECT PHAROAH. Prueba esto primero.\r\n"
L"4. Si no aparece nada, el juego no cambia, o se pone lento: cierra el juego, abrelo de nuevo, "
L"y haz clic en INJECT PHAROAH LITE.\r\n"
L"5. En el juego: pulsa F3 para mostrar/ocultar el menu de PHAROAH, o F3 para el panel de "
L"PHAROAH LITE.\r\n\r\n"
L"------------------------------------------------------------\r\n"
L"SI LA INYECCION FALLA\r\n"
L"La barra de estado abajo en esta ventana explica por que. La causa mas comun es la "
L"Proteccion contra alteraciones de Windows (una opcion SEPARADA del interruptor principal de "
L"Windows Defender) - ve a Seguridad de Windows > Proteccion contra virus y amenazas > "
L"Administrar configuracion > desactiva la Proteccion contra alteraciones. Revisa tambien si "
L"tienes otro antivirus corriendo en segundo plano.\r\n\r\n"
L"------------------------------------------------------------\r\n"
L"QUE HACE CADA FUNCION PRINCIPAL\r\n"
L"  - Cajas/muros - ver enemigos y aliados a traves de muros.\r\n"
L"  - Disparo automatico - dispara solo cuando tu mira esta sobre un enemigo. Apagado por "
L"defecto.\r\n"
L"  - Cartas/habilidades - detecta tu mazo y puede usar cartas repetidamente o cambiar modos "
L"de disparo.\r\n"
L"  - Asistencia de punteria / iman - atrae tu punteria hacia un objetivo mientras disparas.\r\n"
L"  - Desbloqueador - desbloquea cosmeticos en el menu (fuera de una partida en vivo).\r\n"
L"  - Recolor de barra de vida - hace las barras de vida del juego mas faciles de leer.\r\n\r\n"
L"Esta herramienta se ofrece gratis y de codigo abierto. Usala segun tu propia conciencia y "
L"las reglas de tu juego.";

static LRESULT CALLBACK TutorialWndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    static HWND s_edit = nullptr;
    switch (msg) {
    case WM_CREATE: {
        s_edit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", g_UseSpanish ? kTutorialES : kTutorialEN,
            WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL,
            0, 0, 0, 0, hwnd, nullptr, nullptr, nullptr);
        SendMessageW(s_edit, WM_SETFONT, (WPARAM)g_FontSmall, TRUE);
        return 0;
    }
    case WM_SIZE: {
        RECT rc; GetClientRect(hwnd, &rc);
        if (s_edit) MoveWindow(s_edit, 8, 8, rc.right - 16, rc.bottom - 16, TRUE);
        return 0;
    }
    case WM_CLOSE:
        DestroyWindow(hwnd);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

static void ShowTutorialWindow(HWND owner) {
    static bool s_classRegistered = false;
    HINSTANCE inst = (HINSTANCE)GetWindowLongPtrW(owner, GWLP_HINSTANCE);
    if (!s_classRegistered) {
        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.lpfnWndProc = TutorialWndProc;
        wc.hInstance = inst;
        wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
        wc.lpszClassName = L"PharoahTutorialWnd";
        RegisterClassExW(&wc);
        s_classRegistered = true;
    }
    HWND existing = FindWindowW(L"PharoahTutorialWnd", nullptr);
    if (existing) { SetForegroundWindow(existing); return; }

    HWND tw = CreateWindowExW(0, L"PharoahTutorialWnd",
        g_UseSpanish ? L"PHAROAH - Tutorial" : L"PHAROAH - Tutorial",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 560, 560,
        owner, nullptr, inst, nullptr);
    if (tw) ShowWindow(tw, SW_SHOW);
}

// ---------- window ----------

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE: {
        // Segoe UI Light for the wordmark, not Georgia — the serif read as
        // corporate. Wide letter-spacing gives it a logo feel instead.
        g_FontTitle = CreateFontW(36, 0, 0, 0, FW_LIGHT, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
            OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FF_DONTCARE, L"Segoe UI Light");
        g_FontBody = CreateFontW(17, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
            OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FF_DONTCARE, L"Segoe UI");
        g_FontSmall = CreateFontW(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
            OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FF_DONTCARE, L"Segoe UI");

        g_hCombo = CreateWindowExW(0, L"COMBOBOX", nullptr,
            WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_VSCROLL,
            20, 134, 380, 320, hwnd, (HMENU)ID_COMBO_PROC, nullptr, nullptr);
        SendMessageW(g_hCombo, WM_SETFONT, (WPARAM)g_FontBody, TRUE);

        CreateWindowExW(0, L"BUTTON", L"Refresh",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            410, 133, 90, 30, hwnd, (HMENU)ID_BTN_REFRESH, nullptr, nullptr);

        g_hDllEdit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
            WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
            20, 202, 380, 28, hwnd, (HMENU)ID_EDIT_DLL, nullptr, nullptr);
        SendMessageW(g_hDllEdit, WM_SETFONT, (WPARAM)g_FontSmall, TRUE);

        CreateWindowExW(0, L"BUTTON", L"Browse",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            410, 201, 90, 30, hwnd, (HMENU)ID_BTN_BROWSE, nullptr, nullptr);

        // Owner-drawn (BS_OWNERDRAW) so each can actually be coloured - see
        // DrawOwnerButton/WM_DRAWITEM. INJECT is gold: the recommended,
        // primary action, same colour language as the website's own
        // DOWNLOAD PHAROAH button. The other two are real, working options,
        // just visually secondary so a new user isn't left guessing which
        // of three equal-looking buttons to press.
        // v8 REDESIGN - two buttons, not three. "Set up automatic loading"
        // removed entirely per explicit request. TRY THIS FIRST over the
        // main button; the LITE button's own label now IS the guidance for
        // when to use it, replacing the separate explainer line that used
        // to sit above "Set up automatic loading".
        {
            HWND lblTry = CreateWindowExW(0, L"STATIC", L"TRY THIS FIRST",
                WS_CHILD | WS_VISIBLE, 20, 236, 480, 16, hwnd, nullptr, nullptr, nullptr);
            SendMessageW(lblTry, WM_SETFONT, (WPARAM)g_FontSmall, TRUE);
        }
        CreateWindowExW(0, L"BUTTON", L"INJECT PHAROAH",
            WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
            20, 254, 480, 44, hwnd, (HMENU)ID_BTN_INJECT, nullptr, nullptr);

        {
            HWND lbl2 = CreateWindowExW(0, L"STATIC",
                L"If regular PHAROAH injection fails to appear, does nothing, or is too laggy,\n"
                L"close the game and inject PHAROAH LITE instead:",
                WS_CHILD | WS_VISIBLE, 20, 306, 480, 32, hwnd, nullptr, nullptr, nullptr);
            SendMessageW(lbl2, WM_SETFONT, (WPARAM)g_FontSmall, TRUE);
        }
        CreateWindowExW(0, L"BUTTON", L"INJECT PHAROAH LITE",
            WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
            20, 342, 480, 38, hwnd, (HMENU)ID_BTN_INJECT_LITE, nullptr, nullptr);

        // Language + tutorial row.
        {
            HWND lblLang = CreateWindowExW(0, L"STATIC", L"PLEASE SELECT LANGUAGE",
                WS_CHILD | WS_VISIBLE, 20, 394, 300, 16, hwnd, nullptr, nullptr, nullptr);
            SendMessageW(lblLang, WM_SETFONT, (WPARAM)g_FontSmall, TRUE);
        }
        CreateWindowExW(0, L"BUTTON", L"ENGLISH",
            WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
            20, 412, 110, 30, hwnd, (HMENU)ID_BTN_LANG_EN, nullptr, nullptr);
        CreateWindowExW(0, L"BUTTON", L"ESPANOL",
            WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
            136, 412, 110, 30, hwnd, (HMENU)ID_BTN_LANG_ES, nullptr, nullptr);
        CreateWindowExW(0, L"BUTTON", L"TUTORIAL",
            WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
            390, 412, 110, 30, hwnd, (HMENU)ID_BTN_TUTORIAL, nullptr, nullptr);

        // Auto-detected: next to this exe first, dev build tree last.
        // Someone who unzips the release never has to touch this box.
        {
            std::wstring found = FindDllPath();
            SetWindowTextW(g_hDllEdit, found.c_str());
            if (GetFileAttributesW(found.c_str()) == INVALID_FILE_ATTRIBUTES) {
                SetStatus(L"PHAROAH.dll not found next to this program - use Browse to locate it.", true);
            }
        }
        g_LiteDllPath = FindLiteDllPath();
        LoadLangChoice();

        RefreshProcessList();

        // Rescan on a timer so launching the injector BEFORE the game just works.
        // Previously the list was built once at startup, which is why you had to
        // close and reopen the app after starting Paladins.
        SetTimer(hwnd, ID_TIMER_SCAN, kScanIntervalMs, nullptr);

        if (!IsRunningAsAdmin()) {
            SetStatus(L"NOT running as Administrator - injection will likely fail. Restart as admin.", true);
            MessageBoxW(hwnd,
                L"PHAROAH is not running as Administrator.\n\n"
                L"Injection needs elevated rights to obtain a handle to the game process.\n"
                L"Close this and right-click > Run as administrator.",
                L"PHAROAH - Administrator required", MB_OK | MB_ICONWARNING);
        }

        // The startup Memory Integrity warning that used to live here was
        // REMOVED after live testing: PRIMAL_MONKE tested with Memory
        // Integrity deliberately left ON, rejected the alternate-loading
        // prompt, injected normally anyway - and the regular INJECT method
        // worked perfectly. So HVCI is not, on its own, a reliable predictor
        // of the "menu doesn't fully load" failure. The guidance now is
        // simpler and doesn't require a diagnosis at all: if PHAROAH
        // (INJECT PHAROAH) doesn't work, use PHAROAH LITE instead.
        return 0;
    }

    case WM_CTLCOLORSTATIC:
    case WM_CTLCOLORBTN:
        SetBkMode((HDC)wp, TRANSPARENT);
        SetTextColor((HDC)wp, COL_INK);
        return (LRESULT)g_BgBrush;

    case WM_CTLCOLOREDIT:
    case WM_CTLCOLORLISTBOX:
        SetBkColor((HDC)wp, COL_SAND_PANEL);
        SetTextColor((HDC)wp, COL_INK);
        return (LRESULT)g_PanelBrush;

    case WM_TIMER:
        if (wp == ID_TIMER_SCAN) {
            RefreshProcessList();
            InvalidateRect(hwnd, nullptr, TRUE);
        }
        return 0;

    case WM_PAINT:
        PaintWindow(hwnd);
        return 0;

    case WM_COMMAND: {
        int id = LOWORD(wp);
        if (id == ID_BTN_REFRESH) {
            RefreshProcessList();
            InvalidateRect(hwnd, nullptr, TRUE);
        }
        else if (id == ID_BTN_BROWSE) {
            wchar_t path[MAX_PATH]{};
            OPENFILENAMEW ofn{};
            ofn.lStructSize = sizeof(ofn);
            ofn.hwndOwner = hwnd;
            ofn.lpstrFilter = L"DLL files\0*.dll\0All files\0*.*\0";
            ofn.lpstrFile = path;
            ofn.nMaxFile = MAX_PATH;
            ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
            if (GetOpenFileNameW(&ofn)) SetWindowTextW(g_hDllEdit, path);
        }
        else if (id == ID_BTN_INJECT) {
            int sel = (int)SendMessageW(g_hCombo, CB_GETCURSEL, 0, 0);
            if (sel < 0 || sel >= (int)g_Procs.size()) {
                SetStatus(L"Select a target process first.", true);
                InvalidateRect(hwnd, nullptr, TRUE);
                return 0;
            }
            wchar_t dll[MAX_PATH * 2]{};
            GetWindowTextW(g_hDllEdit, dll, MAX_PATH * 2);
            if (!dll[0]) {
                SetStatus(L"Choose a DLL to inject.", true);
                InvalidateRect(hwnd, nullptr, TRUE);
                return 0;
            }

            std::wstring err;
            if (InjectDll(g_Procs[sel].pid, dll, err)) {
                SetStatus(L"SUCCESS - injected into " + g_Procs[sel].name +
                          L". Press F3 / INSERT in game.", false);
            } else {
                SetStatus(L"FAILED - " + err, true);
            }
            InvalidateRect(hwnd, nullptr, TRUE);
        }
        else if (id == ID_BTN_LANG_EN) {
            g_UseSpanish = false;
            SaveLangChoice();
            SetStatus(L"Language set to English.", false);
            InvalidateRect(hwnd, nullptr, TRUE);
        }
        else if (id == ID_BTN_LANG_ES) {
            g_UseSpanish = true;
            SaveLangChoice();
            SetStatus(L"Idioma configurado en Espanol.", false);
            InvalidateRect(hwnd, nullptr, TRUE);
        }
        else if (id == ID_BTN_TUTORIAL) {
            ShowTutorialWindow(hwnd);
        }
        else if (id == ID_BTN_INJECT_LITE) {
            int sel = (int)SendMessageW(g_hCombo, CB_GETCURSEL, 0, 0);
            if (sel < 0 || sel >= (int)g_Procs.size()) {
                SetStatus(L"Select a target process first.", true);
                InvalidateRect(hwnd, nullptr, TRUE);
                return 0;
            }
            if (g_LiteDllPath.empty() || GetFileAttributesW(g_LiteDllPath.c_str()) == INVALID_FILE_ATTRIBUTES) {
                SetStatus(L"PHAROAH_LITE.dll not found next to this program.", true);
                InvalidateRect(hwnd, nullptr, TRUE);
                return 0;
            }
            std::wstring err;
            if (InjectDll(g_Procs[sel].pid, g_LiteDllPath, err)) {
                SetStatus(L"SUCCESS - PHAROAH LITE injected into " + g_Procs[sel].name +
                          L". Press INSERT in game.", false);
            } else {
                SetStatus(L"FAILED - " + err, true);
            }
            InvalidateRect(hwnd, nullptr, TRUE);
        }
        return 0;
    }

    case WM_DRAWITEM: {
        LPDRAWITEMSTRUCT dis = (LPDRAWITEMSTRUCT)lp;
        // v8 REDESIGN: "make both color WHITE background, and INJECT
        // PHAROAH LITE is purple button with cyan text." INJECT PHAROAH:
        // white fill, dark text (the "TRY THIS FIRST" primary action).
        // INJECT PHAROAH LITE: purple fill, cyan text - matches PHAROAH
        // LITE's own in-game COLD theme (#2d0049/#00abc9), so the button
        // reads as "this is the same product" before you've even injected.
        if (dis->CtlID == ID_BTN_INJECT) {
            DrawOwnerButton(dis, L"INJECT PHAROAH", RGB(255, 255, 255), RGB(230, 230, 235),
                             RGB(150, 118, 50), RGB(20, 20, 24), g_FontBody);
            return TRUE;
        }
        if (dis->CtlID == ID_BTN_INJECT_LITE) {
            DrawOwnerButton(dis, L"INJECT PHAROAH LITE", RGB(0x2d, 0x00, 0x49), RGB(0x42, 0x10, 0x66),
                             RGB(0x00, 0xab, 0xc9), RGB(0x00, 0xab, 0xc9), g_FontBody);
            return TRUE;
        }
        if (dis->CtlID == ID_BTN_LANG_EN) {
            bool active = !g_UseSpanish;
            DrawOwnerButton(dis, L"ENGLISH", active ? COL_TEAL : COL_PANEL, RGB(78, 138, 133),
                             COL_TEAL, active ? RGB(20, 30, 30) : COL_INK, g_FontSmall);
            return TRUE;
        }
        if (dis->CtlID == ID_BTN_LANG_ES) {
            bool active = g_UseSpanish;
            DrawOwnerButton(dis, L"ESPANOL", active ? COL_TEAL : COL_PANEL, RGB(78, 138, 133),
                             COL_TEAL, active ? RGB(20, 30, 30) : COL_INK, g_FontSmall);
            return TRUE;
        }
        if (dis->CtlID == ID_BTN_TUTORIAL) {
            DrawOwnerButton(dis, L"TUTORIAL", COL_PANEL, RGB(70, 92, 112), COL_GOLD, COL_GOLD, g_FontSmall);
            return TRUE;
        }
        return FALSE;
    }

    case WM_DESTROY:
        KillTimer(hwnd, ID_TIMER_SCAN);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, int nCmdShow) {
    g_BgBrush = CreateSolidBrush(COL_SAND_BG);
    g_PanelBrush = CreateSolidBrush(COL_SAND_PANEL);

    // Icon: pharoah.ico next to the exe if present, else the default app icon.
    //
    // Passing 0,0 with LR_DEFAULTSIZE=off loads the icon at its OWN native size
    // rather than forcing a 64x64 frame that may not exist in the file. Forcing a
    // size was the cropping bug: Windows substitutes the nearest available frame,
    // and drawing that into a fixed square distorts or clips it. Load native,
    // measure, then scale to fit at draw time.
    // EMBEDDED FIRST. The icon is compiled into the exe as resource 1, so a
    // downloaded ZIP shows the PHAROAH icon in Explorer and on the taskbar even
    // if pharoah.ico is not sitting beside it. The loose file is still tried
    // afterwards so swapping the art needs no rebuild.
    // TWO ICONS, TWO JOBS.
    //
    //   resource 1 (pharoah.ico) = the APP icon: taskbar, Explorer, window tab.
    //   resource 2 (logo.ico)    = the logo we DRAW ourselves, top-left inside
    //                              the window.
    //
    // They were the same file and it looked wrong in one place or the other.
    //
    // Both are loaded at 256x256 on purpose. An .ico holds several frames and
    // LoadImage with size 0,0 hands back the FIRST one - which is 16x16 - so
    // drawing that at ~72px is what made the header look like a stretched
    // thumbnail. Asking for a size makes Windows pick the matching frame.
    const int kBigIcon = 256;
    HMODULE selfMod = GetModuleHandleW(nullptr);

    // The header logo.
    g_Icon = (HICON)LoadImageW(selfMod, MAKEINTRESOURCEW(2),
                               IMAGE_ICON, kBigIcon, kBigIcon, 0);
    if (!g_Icon)
        g_Icon = (HICON)LoadImageW(nullptr, L"logo.ico", IMAGE_ICON,
                                   kBigIcon, kBigIcon, LR_LOADFROMFILE);
    if (!g_Icon) g_Icon = LoadIconW(selfMod, MAKEINTRESOURCEW(2));
    // Last resort: the app icon is better than no logo at all.
    if (!g_Icon) g_Icon = LoadIconW(selfMod, MAKEINTRESOURCEW(1));
    if (!g_Icon) g_Icon = LoadIconW(nullptr, MAKEINTRESOURCEW(32512));
    MeasureIcon(g_Icon, &g_IconW, &g_IconH);

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
    wc.hbrBackground = g_BgBrush;
    wc.lpszClassName = L"PharoahInjectorWnd";
    // The WINDOW icon is the APP icon (resource 1), not the header logo - this
    // is what shows in the taskbar and the Alt-Tab switcher.
    //
    // Each is loaded at the size it will actually be shown at: 32px for the big
    // one, 16px for the title bar. Handing Windows a 256px icon for a 16px slot
    // makes it downscale on the fly and the result looks soft.
    HICON appBig   = (HICON)LoadImageW(selfMod, MAKEINTRESOURCEW(1), IMAGE_ICON, 32, 32, 0);
    HICON appSmall = (HICON)LoadImageW(selfMod, MAKEINTRESOURCEW(1), IMAGE_ICON, 16, 16, 0);
    if (!appBig)   appBig   = LoadIconW(selfMod, MAKEINTRESOURCEW(1));
    if (!appSmall) appSmall = appBig;
    wc.hIcon   = appBig   ? appBig   : g_Icon;
    wc.hIconSm = appSmall ? appSmall : g_Icon;
    RegisterClassExW(&wc);

    // Grew from 464 - the language row + TUTORIAL button added below the two
    // inject buttons need the extra height.
    RECT want = { 0, 0, 524, 510 };
    AdjustWindowRect(&want, WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX, FALSE);

    HWND hwnd = CreateWindowExW(0, wc.lpszClassName, kAppTitle,
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT,
        want.right - want.left, want.bottom - want.top,
        nullptr, nullptr, hInst, nullptr);
    if (!hwnd) return 1;

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return 0;
}
