#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "menus/Perf.h"   // POTATO MODE
#include "menus/DeviceNames.h"
#include "menus/KnownExploits.h"
#include "menus/Language.h" // Tm() - see that file's header comment
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include <Windows.h>
#include <cstdarg>

using Language::Tm;

// ============================================================================
// DIRECT FIRE  —  a device-fire mechanism, reimplemented from independent analysis
// ============================================================================
// Source: internal reverse-engineering notes (not shipped).
//
// Of the 38 game functions a third-party tool of this kind resolves and
// calls, 36 are cosmetic (Engine.Canvas.* drawing, TgClient UI). Exactly two
// are gameplay:
//
//     Function TgGame.TgDevice.StartFire
//     Function TgGame.TgDevice.StopFire
//
// Both invoked bare: ATgDevice as the object, empty params. It never writes a
// cooldown field — an exhaustive search of that binary for writes to
// ATgDevice's timer block (0x43C-0x458) came back empty. It simply calls the
// game's own fire function, bypassing the input path.
//
// THE FIVE CARD SLOTS
//     EQP_CARD = 5, EQP_CARD01 = 19, EQP_CARD02 = 20,
//     EQP_CARD03 = 21, EQP_CARD04 = 22
// A card IS an ATgDevice, so firing it runs its effect WITHOUT the condition
// that normally gates it.
//
// ---------------------------------------------------------------------------
// THREADING — read this before changing anything here
// ---------------------------------------------------------------------------
// StartFire, StopFire and GetInventoryByEquipPoint are ALL scripted: they go
// through ProcessEvent. Calling them from the render thread is what crashed
// the first version of this file — DrawControls was resolving eleven devices
// per frame just to draw "ready" indicators.
//
// So nothing here calls into the game from the draw path or from Tick():
//     Tick(), TickCards()  render thread — poll keys, set pending flags ONLY
//     DrawControls()       render thread — read cached state, set flags ONLY
//     ProcessPending()     SAFE thread   — the only place the game is touched
// ============================================================================

namespace DirectFire {

    struct CardSlot { const char* label; int equipPoint; };
    static const CardSlot kCards[5] = {
        { "CARD 1", 5  }, { "CARD 2", 19 }, { "CARD 3", 20 },
        { "CARD 4", 21 }, { "CARD 5", 22 },
    };
    static const CardSlot kBurn[5] = {
        { "BURN 1", 8  }, { "BURN 2", 9  }, { "BURN 3", 10 },
        { "BURN 4", 11 }, { "BURN 5", 28 },
    };

    // Talents and combos are devices too - a community report says the same
    // numpad trick works on both, which fits: everything here is an ATgDevice.
    static const CardSlot kExtra[4] = {
        { "TALENT",  26 },   // EQP_TALENT
        { "COMBO",   24 },   // EQP_COMBO
        { "OFFHAND",  2 },   // EQP_OFFHAND
        { "ULT",     15 },   // EQP_ULT_CHARGE
    };
    inline bool g_ExtraReady[4]  = { false, false, false, false };
    inline bool g_PendingExtra[4]= { false, false, false, false };
    inline int  g_ExtraShots[4]  = { 0, 0, 0, 0 };
    inline bool g_ExtraSpam[4]   = { false, false, false, false };

    // ---- FULL SLOT SCANNER -------------------------------------------------
    // Every card button reading "no device" means the equip-point / item-type
    // guess is wrong, and guessing again is not a plan. This sweeps the whole
    // space and reports what actually exists, so the real numbers can be read
    // off rather than assumed.
    // ---- DEVICE SWEEP  (the one that works in a real match) ----------------
    //
    // The inventory sweep reads UTgInventoryObject_Device::s_Device at +0xA8.
    // Look at the prefix: in this SDK "s_" means SERVER-local, and sure enough
    // it is populated in the shooting range (NetMode 0, where you ARE the
    // server) and NULL on a client in a real match. That is the same authority
    // split that has blocked every other server-side thing in this project.
    //
    // ATgDevice itself has no such problem. It is an actor, and everything we
    // need on it is replicated:
    //
    //     AActor::Owner            0x00C4  (Net)
    //     AActor::Instigator       0x0118  (Net)
    //     ATgDevice::r_nDeviceId   0x0304  (Net)
    //     ATgDevice::r_nInstanceCount 0x030C (Net)   <- card level
    //     ATgDevice::r_nInventoryId 0x0438 (Net)
    //
    // So we find the devices themselves in GObjects and keep the ones owned by
    // our pawn. No server-side field anywhere in the path.
    struct DevRow {
        SDK::ATgDevice* dev;
        int  deviceId;
        int  instanceCount;
        int  points;          // r_nPointsAllocated - THIS is the card level
        int  deviceType;
        int  inventoryId;
        bool isCard;          // matched an inventory object, and not an ability
        char name[72];        // the device's own name, often just "TgDevice"
        char label[72];       // the inventory object's class name - the useful one
    };
    static const int kMaxDevRows = 96;
    inline DevRow g_Dev[kMaxDevRows];
    inline int    g_DevCount = 0;
    inline bool   g_PendingDevSweep = false;
    inline int    g_PendingFireDev  = -1;
    inline bool   g_DevSpam[kMaxDevRows] = {};
    inline char   g_DevStatus[220] = "Not swept yet.";
    inline bool   g_PendingCopyDev = false;

    // ========================================================================
    // CARD MAXXING  —  what this actually is
    // ========================================================================
    // Cards are NOT fireable devices. Look at what the inventory objects are
    // actually called:
    //
    //     TgInventoryObject_Listen_ReloadCard
    //     TgInventoryObject_Listen_AbilityStart
    //     TgInventoryObject_Listen_HitWithDeviceInhand
    //     TgInventoryObject_Listen_FireOnElimination
    //
    // They are LISTENERS. Each one watches for a thing you do and applies its
    // effect when that thing happens. That is why cards never show up in the
    // device sweep, and why firing them does nothing - there is nothing to fire.
    //
    // So you do not spam the card. You spam THE THING THE CARD LISTENS FOR:
    //
    //     Listen_ReloadCard      -> spam TgDevice_<champ>Reload
    //     Listen_AbilityStart    -> spam an ability device (Q / F / RMB)
    //     Listen_HitWithDevice   -> spam the in-hand weapon
    //     Listen_FireOnElimination -> not spammable, needs a real kill
    //
    // This is exactly the behaviour already observed: Dredge and Damba reloads
    // can be spammed because their reload device has no internal cooldown. Every
    // spam fires the reload listener again, and the card's effect stacks.
    enum TrigKind { TRIG_NONE = 0, TRIG_RELOAD, TRIG_ABILITY, TRIG_INHAND, TRIG_EVENT };

    inline TrigKind ClassifyListener(const char* n) {
        if (!n || !n[0]) return TRIG_NONE;
        auto has = [](const char* h, const char* nd) {
            for (int i = 0; h[i]; ++i) {
                int j = 0;
                while (nd[j] && h[i + j] && ((h[i + j] | 32) == (nd[j] | 32))) ++j;
                if (!nd[j]) return true;
            }
            return false;
        };
        if (has(n, "Reload"))                                    return TRIG_RELOAD;
        if (has(n, "Ability") || has(n, "Combo"))                return TRIG_ABILITY;
        if (has(n, "Inhand") || has(n, "HitWithDevice"))         return TRIG_INHAND;
        if (has(n, "Elimination") || has(n, "LowHealth")
            || has(n, "Died") || has(n, "Kill"))                 return TRIG_EVENT;
        return TRIG_NONE;
    }

    inline const char* TrigName(TrigKind k) {
        switch (k) {
            case TRIG_RELOAD:  return "RELOAD";
            case TRIG_ABILITY: return "ABILITY";
            case TRIG_INHAND:  return "WEAPON";
            case TRIG_EVENT:   return "event";
            default:           return "?";
        }
    }

    // Which device in the sweep triggers this kind of listener?
    inline int FindTriggerDevice(TrigKind k);

    // ---- DIRECT OBJECT SWEEP ----------------------------------------------
    // GetInventoryByEquipPoint returned NULL for all 186 equip-point/item-type
    // combinations even though InvManager was non-null, so that route is not
    // usable here. Fortunately it is not the only one: inventory objects live in
    // GObjects like everything else, and each one carries its own identity.
    //
    //   UTgInventoryObject
    //       m_InventoryData          +0x60   FInventoryData
    //           .nItemId             +0x68  (abs)
    //           .nLevel              +0x70  (abs)
    //           .nEquipSlotValueId   +0x80  (abs)   <- the REAL equip slot
    //       m_nRefData               +0x84
    //       m_InvManager             +0x88          <- whose inventory this is
    //   UTgInventoryObject_Device
    //       s_Device                 +0xA8          <- the ATgDevice to fire
    //
    // So we walk GObjects, keep UTgInventoryObject instances belonging to OUR
    // manager, and read the equip slot off the object rather than guessing it.
    struct ObjRow {
        void* obj;
        SDK::ATgDevice* dev;
        int  equipSlot;
        int  level;
        int  itemId;
        bool mine;
        char name[72];
    };
    static const int kMaxObjRows = 96;
    inline ObjRow g_Obj[kMaxObjRows];
    inline int    g_ObjCount     = 0;
    inline bool   g_PendingSweep = false;
    inline bool   g_OnlyMine     = true;
    inline int    g_PendingFireObj = -1;
    inline bool   g_ObjSpam[kMaxObjRows] = {};
    inline char   g_SweepStatus[220] = "Not swept yet.";

    // THE SWEEP IS ONLY VALID FOR THE PAWN IT WAS TAKEN FROM.
    //
    // g_Obj holds raw UObject*/ATgDevice* pointers. Change champion, enter the
    // shooting range, or requeue, and every one of those objects is destroyed -
    // but the list still holds their addresses. Firing one then writes through a
    // freed pointer, which is exactly the "worked, then crashed when I switched"
    // behaviour. Same class of bug as the material GC crash earlier in this
    // project, and the same fix: tie the cache to its owner and drop it the
    // instant the owner changes.
    inline void* g_SweptPawn = nullptr;
    inline void* g_SweptMgr  = nullptr;

    // Objects exist before they are populated. In a fresh match the sweep can
    // land early and see 19 objects with lvl=0 and no device attached, which is
    // not a failure - it is just too soon. So re-sweep on a timer until the
    // deck actually shows up, instead of making you press the button again.
    inline bool  g_AutoSweep     = true;
    inline float g_AutoSweepTimer = 0.0f;
    inline int   g_DeckFound     = 0;   // rows with a level AND a device

    // Pick the device in the sweep whose name matches the trigger kind.
    inline int FindTriggerDevice(TrigKind k) {
        auto has = [](const char* h, const char* nd) {
            for (int i = 0; h[i]; ++i) {
                int j = 0;
                while (nd[j] && h[i + j] && ((h[i + j] | 32) == (nd[j] | 32))) ++j;
                if (!nd[j]) return true;
            }
            return false;
        };
        for (int i = 0; i < g_DevCount; ++i) {
            const char* n = g_Dev[i].name;
            if (k == TRIG_RELOAD && has(n, "Reload")) return i;
            if (k == TRIG_INHAND && has(n, "Inhand")) return i;
            if (k == TRIG_ABILITY &&
                (has(n, "RMB") || has(n, "_Q") || has(n, "_F") || has(n, "Ult"))) return i;
        }
        return -1;
    }

    // ========================================================================
    // THE FIVE CARDS
    // ========================================================================
    // A loadout is five cards, and the shooting-range dump showed them sitting
    // in fixed inventory slots with levels that total 15:
    //
    //     slot=201  lvl=5   Listen_ReloadCard
    //     slot=999  lvl=2   Listen_HitWithDevice
    //     slot=1000 lvl=2   Device
    //     slot=1001 lvl=3   Listen_ActiveDuringAbility
    //     slot=1002 lvl=3   Listen_AbilityEnd
    //
    // The same five slots exist in a real match. What is NOT there is
    // s_Device - that field is server-local, so it reads null on a client.
    //
    // But the card's DEVICE is still in memory: it is an ATgDevice whose
    // r_nDeviceId equals the inventory object's nItemId. So we resolve each of
    // the five slots to its device by matching ids across the two sweeps, and
    // end up with five numbered buttons that work on a client.
    static const int kCardSlots[5] = { 201, 999, 1000, 1001, 1002 };

    struct FiveCard {
        SDK::ATgDevice* dev;
        int  slot;
        int  itemId;
        int  level;
        bool spam;
        int  shots;
        char label[72];
    };
    inline FiveCard g_Five[5] = {};
    inline int  g_FiveFound = 0;
    inline bool g_PendingFive[5] = { false, false, false, false, false };
    inline char g_FiveStatus[220] = "Not resolved yet - run SWEEP DEVICES.";
    // CARD MAXXING spam rate. This spam had NO rate limit at all - it fired all
    // five slots on EVERY safe-thread pass (i.e. every frame), which is the same
    // flood that crashed the game from the other card path. Now throttled, with
    // its own slider, and floored at kMinSafeFireRate like everything else.
    // Manual CARD button clicks are NOT throttled - only continuous spam is.
    inline float      g_FiveRate       = 0.10f;
    inline ULONGLONG  g_LastFiveFireMs = 0;

    // ========================================================================
    // DEEP DIAGNOSTIC
    // ========================================================================
    // The facts that need explaining:
    //   shooting range : 19 objects, 5 with levels, s_Device set on all 19
    //   real match     : 19 objects, 0 with levels, s_Device NULL on all 19
    //
    // Same slots, same count. If this were purely "s_Device is server-side" the
    // LEVEL would still be populated - nLevel lives in a plain struct, not
    // behind an s_ prefix. Both being empty together says we are looking at a
    // DIFFERENT SET of objects in a match: almost certainly archetypes or
    // templates rather than the live per-match instances.
    //
    // This dumps every UTgInventoryObject with NO manager filter at all, groups
    // them by which manager they belong to, and reports which manager owns the
    // populated ones. If the live objects exist under a different manager than
    // pawn+0x4DC, that is the whole bug and this will show it.
    static const int kMaxMgrs = 16;
    inline void* g_MgrPtr[kMaxMgrs];
    inline int   g_MgrObjs[kMaxMgrs];
    inline int   g_MgrLevelled[kMaxMgrs];
    inline int   g_MgrWithDev[kMaxMgrs];
    inline int   g_MgrCount = 0;
    inline bool  g_PendingDiag = false;
    inline bool  g_PendingCopyDiag = false;
    inline char  g_DiagText[24][200];
    inline int   g_DiagLines = 0;

    inline void DiagLine(const char* fmt, ...) {
        if (g_DiagLines >= 24) return;
        va_list ap; va_start(ap, fmt);
        wvsprintfA(g_DiagText[g_DiagLines], fmt, ap);
        va_end(ap);
        g_DiagLines++;
    }

    // ========================================================================
    // EQ-POINT SWEEP  —  the one that works on a client
    // ========================================================================
    // Two dead ends before this:
    //   InvManager -> GetInventoryByEquipPoint   returns null in a real match
    //   UTgInventoryObject_Device::s_Device      is server-local, null on a client
    //
    // The working route was in the Call Log tab the entire time:
    //
    //     ATgPawn::GetDeviceByEqPoint(int)
    //
    // A method on the PAWN, not the inventory manager. It reads every card in a
    // real match - the recorder has been logging device ids and card points
    // through it for weeks. Both fields it returns are replicated:
    //
    //     ATgDevice::r_nDeviceId        0x0304  (Net)
    //     ATgDevice::r_nPointsAllocated 0x0320  (Net)   <- card level
    //
    // So: sweep eq points 0-20, keep whatever answers, and fire it. No guessing
    // at which constant is a card - the pawn is asked directly.
    struct EqRow {
        SDK::ATgDevice* dev;
        int  eq;
        int  deviceId;
        int  points;
        bool spam;
        int  shots;
    };
    static const int kMaxEq = 24;
    inline EqRow g_Eq[kMaxEq];
    inline int   g_EqCount = 0;
    inline bool  g_PendingEqSweep = true;     // sweep on first safe-thread pass
    inline int   g_PendingFireEq  = -1;
    inline float g_EqSpamRate     = 0.06f;
    inline float g_EqSpamTimer    = 0.0f;
    inline char  g_EqStatus[200]  = "Not swept yet.";
    inline bool  g_PendingCopyEq  = false;
    inline void* g_EqSweptPawn    = nullptr;

    // ---- AUTO RE-SWEEP -----------------------------------------------------
    // The pawn-change trigger below catches a champion swap, but it is not
    // enough on its own: at the moment the pawn appears the devices are often
    // not populated yet, so the sweep lands early, finds nothing, and you have
    // to press RE-SWEEP by hand. That is exactly the "click scan, then it
    // works" dance.
    //
    // So: re-sweep on a timer as well. It costs 21 GetDeviceByEqPoint calls,
    // all on the SAFE thread, which is nothing next to what the box gather
    // already does every frame. Retries come fast while the list is empty and
    // slow down once it has filled in.
    inline bool  g_EqAutoSweep      = true;
    inline float g_EqAutoSweepTimer = 0.0f;
    inline float g_EqAutoSweepSec   = 3.0f;   // once populated
    static const float kEqRetrySec  = 0.75f;  // while still empty

    inline void InvalidateSweep(const char* why) {
        g_DevCount = 0;
        for (int i = 0; i < kMaxDevRows; ++i) g_DevSpam[i] = false;
        g_PendingFireDev = -1;
        g_PendingDevSweep = true;      // rebuild immediately under the new pawn
        g_ObjCount = 0;
        g_DeckFound = 0;
        for (int i = 0; i < kMaxObjRows; ++i) g_ObjSpam[i] = false;
        g_PendingFireObj = -1;
        lstrcpynA(g_SweepStatus, why, 210);
    }

    static const int kScanMaxRows = 128;
    inline bool g_PendingScan = false;
    inline int  g_ScanRows    = 0;
    inline char g_ScanText[kScanMaxRows][160];
    inline char g_ScanSummary[220] = "Not scanned yet.";
    inline bool g_PendingCopyScan = false;

    // ---- manual single-device controls ----
    inline int   g_EquipPoint = 5;
    inline int   g_ItemType   = 0;
    inline bool  g_Spam       = false;
    inline float g_SpamRate   = 0.05f;
    inline float g_SpamTimer  = 0.0f;

    // SAFE MINIMUM interval between card/device fires. Cards fire via
    // DeviceStartFire (a scripted ProcessEvent), and the card timer is GLOBAL -
    // all 5 slots fire together each tick - so a rate of 0.0 meant ~5 scripted
    // ability-fires EVERY FRAME (~700/sec). That flooded the game's own
    // ability-fire path and produced a repeatable crash inside ProcessEvent
    // (identical stack twice). Nothing legitimate needs to re-fire a card
    // faster than this, so it's floored here no matter what the slider says.
    inline constexpr float kMinSafeFireRate = 0.04f;

    // ---- card / burn state ----
    inline bool  g_CardSpam[5]  = { false, false, false, false, false };
    inline bool  g_BurnSpam[5]  = { false, false, false, false, false };
    inline float g_CardRate     = 0.05f;
    inline float g_CardTimer    = 0.0f;
    inline int   g_CardShots[5] = { 0, 0, 0, 0, 0 };
    inline int   g_BurnShots[5] = { 0, 0, 0, 0, 0 };

    // ---- hotkeys (polling is render-thread safe; firing is not) ----
    inline bool g_HotkeysOn  = false;
    inline bool g_HotkeyHold = true;
    inline int  g_CardKey[5] = { '1', '2', '3', '4', '5' };
    inline int  g_BurnKey[5] = { 0, 0, 0, 0, 0 };
    inline bool g_CardKeyWasDown[5] = { false, false, false, false, false };
    inline bool g_BurnKeyWasDown[5] = { false, false, false, false, false };

    // ---- CROSS-THREAD HANDOFF ----
    // Set on the render thread, consumed on the safe thread. Plain bools; a
    // missed edge just means one dropped shot, which is harmless.
    inline bool g_PendingCard[5] = { false, false, false, false, false };
    inline bool g_PendingBurn[5] = { false, false, false, false, false };
    inline bool g_PendingManualStart = false;
    inline bool g_PendingManualStop  = false;
    inline bool g_PendingAllFive     = false;

    // ---- cached readiness, refreshed on the SAFE thread only ----
    inline bool  g_CardReady[5] = { false, false, false, false, false };
    inline bool  g_BurnReady[5] = { false, false, false, false, false };
    inline bool  g_ManualReady  = false;
    inline float g_ProbeTimer   = 0.0f;
    inline char  g_Status[220]  = "Nothing fired yet.";

    // ================= SAFE THREAD ONLY from here down =================

    inline bool FireSlotSafe(const CardSlot* set, int i, int* counter) {
        if (i < 0 || i > 4) return false;
        SDK::ATgDevice* d = SafeCalls::GetDeviceByEquipPoint(set[i].equipPoint, 0);
        if (!d) return false;
        if (!SafeCalls::DeviceStartFire(d)) return false;
        SafeCalls::DeviceStopFire(d);
        if (counter) counter[i]++;
        return true;
    }

    // Re-read UTgInventoryObject_Device::s_Device (+0xA8) from the object, and
    // refresh the cached level while we are there. Guarded, because if the
    // object HAS been freed this is where we find out.
    inline SDK::ATgDevice* FreshDevice(int i) {
        if (i < 0 || i >= g_ObjCount || !g_Obj[i].obj) return nullptr;
        // A sweep taken under a different pawn is not ours to fire.
        if (Globals::LocalPawn != g_SweptPawn) return nullptr;
        __try {
            unsigned char* b = (unsigned char*)g_Obj[i].obj;
            g_Obj[i].level = *(int*)(b + 0x70);
            SDK::ATgDevice* d = *(SDK::ATgDevice**)(b + 0xA8);
            g_Obj[i].dev = d;
            return d;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            g_Obj[i].dev = nullptr;
            return nullptr;
        }
    }

    // Called from RecoverySuite::RunSafeThreadSubsystems. This is the only
    // function in this file permitted to touch the game.
    inline void ProcessPending() {
        // Pawn gone (dead, loading, menu) - the whole cache is dead with it.
        if (!Globals::LocalPawn) {
            if (g_ObjCount) InvalidateSweep("Pawn gone - sweep dropped. Will re-sweep automatically.");
            g_SweptPawn = nullptr;
            g_SweptMgr  = nullptr;
            return;
        }

        // Different pawn than the one we swept: champion change, new match,
        // shooting range. Every cached pointer is now dangling.
        void* mgrNow = SafeCalls::GetInvManager();
        if (g_ObjCount && (Globals::LocalPawn != g_SweptPawn || mgrNow != g_SweptMgr)) {
            InvalidateSweep("Pawn or inventory changed - sweep dropped, re-sweeping.");
            g_PendingSweep = true;
        }

        // Auto re-sweep until the deck is actually populated. Objects can exist
        // before they have levels or devices, so an early sweep looks empty.
        if (g_AutoSweep) {
            g_AutoSweepTimer += 0.016f;
            if (g_AutoSweepTimer >= 1.0f) {
                g_AutoSweepTimer = 0.0f;
                if (g_DeckFound == 0) g_PendingSweep = true;
                if (g_DevCount == 0)  g_PendingDevSweep = true;
            }
        }

        // Refresh the "is there a device here" indicators about twice a second,
        // not every frame. Eleven scripted lookups per frame is what crashed.
        g_ProbeTimer += 0.016f;
        if (g_ProbeTimer >= 0.5f) {
            g_ProbeTimer = 0.0f;
            for (int i = 0; i < 5; i++) {
                g_CardReady[i] = SafeCalls::GetDeviceByEquipPoint(kCards[i].equipPoint, 0) != nullptr;
                g_BurnReady[i] = SafeCalls::GetDeviceByEquipPoint(kBurn[i].equipPoint, 0) != nullptr;
            }
            g_ManualReady = SafeCalls::GetDeviceByEquipPoint(g_EquipPoint, g_ItemType) != nullptr;
            for (int i = 0; i < 4; i++)
                g_ExtraReady[i] = SafeCalls::GetDeviceByEquipPoint(kExtra[i].equipPoint, 0) != nullptr;
        }

        // THE INVENTORY SWEEP MUST RUN FIRST.
        // The device sweep joins device ids against these objects to work out
        // which devices are cards. It used to run BEFORE this block, so the join
        // always saw an empty list and reported "0 matched a card" no matter what.

        if (g_PendingDiag) {
            g_PendingDiag = false;
            g_DiagLines = 0;
            g_MgrCount = 0;

            void* pawn = (void*)Globals::LocalPawn;
            void* mgrField = SafeCalls::GetInvManager();
            DiagLine("pawn            = %p", pawn);
            DiagLine("pawn+0x4DC      = %p   (what GetInvManager returns)", mgrField);

            // What class is that pointer actually? If it is not a
            // TgInventoryManager, the whole equip-point route was doomed.
            if (mgrField) {
                char cls[96] = {};
                __try {
                    SDK::UObject* mo = (SDK::UObject*)mgrField;
                    SDK::UClass* c = mo->Class;
                    if (c) {
                        auto& names = SDK::FName::GetGlobalNames();
                        if (c->Name.Index && names.IsValidIndex((size_t)c->Name.Index)) {
                            SDK::FNameEntry* e = names[c->Name.Index];
                            if (e) lstrcpynA(cls, e->GetAnsiName(), 95);
                        }
                    }
                }
                __except (EXCEPTION_EXECUTE_HANDLER) { lstrcpynA(cls, "<faulted>", 95); }
                DiagLine("  its class     = %s", cls[0] ? cls : "<unreadable>");
            }

            SDK::UClass* icls = nullptr;
            __try { icls = SDK::UTgInventoryObject::StaticClass(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { icls = nullptr; }

            if (icls && SDK::UObject::GObjects) {
                auto& arr = *SDK::UObject::GObjects;
                size_t count = 0;
                __try { count = arr.Num(); } __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
                int total = 0, levelled = 0, withDev = 0;

                for (size_t i = 0; i < count && count < 4000000; ++i) {
                    SDK::UObject* o = nullptr;
                    __try { if (arr.IsValidIndex(i)) o = arr[i]; }
                    __except (EXCEPTION_EXECUTE_HANDLER) { o = nullptr; }
                    if (!o) continue;
                    bool isInv = false;
                    __try { isInv = o->IsA(icls); }
                    __except (EXCEPTION_EXECUTE_HANDLER) { isInv = false; }
                    if (!isInv) continue;

                    int lvl = 0; void* mgr = nullptr; void* dev = nullptr;
                    __try {
                        unsigned char* b = (unsigned char*)o;
                        lvl = *(int*)(b + 0x70);
                        mgr = *(void**)(b + 0x88);
                        dev = *(void**)(b + 0xA8);
                    }
                    __except (EXCEPTION_EXECUTE_HANDLER) { continue; }

                    total++;
                    if (lvl > 0) levelled++;
                    if (dev)     withDev++;

                    int m = -1;
                    for (int k = 0; k < g_MgrCount; ++k) if (g_MgrPtr[k] == mgr) { m = k; break; }
                    if (m < 0 && g_MgrCount < kMaxMgrs) {
                        m = g_MgrCount++;
                        g_MgrPtr[m] = mgr; g_MgrObjs[m] = 0;
                        g_MgrLevelled[m] = 0; g_MgrWithDev[m] = 0;
                    }
                    if (m >= 0) {
                        g_MgrObjs[m]++;
                        if (lvl > 0) g_MgrLevelled[m]++;
                        if (dev)     g_MgrWithDev[m]++;
                    }
                }

                DiagLine("");
                DiagLine("ALL TgInventoryObject, no filter:");
                DiagLine("  total=%d  with a LEVEL=%d  with s_Device=%d", total, levelled, withDev);
                DiagLine("");
                DiagLine("grouped by m_InvManager (+0x88):");
                for (int k = 0; k < g_MgrCount; ++k) {
                    DiagLine("  mgr=%p  objs=%-3d levelled=%-3d withDev=%-3d %s",
                             g_MgrPtr[k], g_MgrObjs[k], g_MgrLevelled[k], g_MgrWithDev[k],
                             (g_MgrPtr[k] == mgrField) ? "  <-- pawn+0x4DC" : "");
                }
                DiagLine("");
                if (levelled == 0)
                    DiagLine("VERDICT: no inventory object anywhere has a level. The live");
                else if (g_MgrCount > 1)
                    DiagLine("VERDICT: more than one manager. If the levelled rows sit under a");
                else
                    DiagLine("VERDICT: single manager holds everything.");
                DiagLine("         objects are either not built yet, or not UTgInventoryObject.");
            } else {
                DiagLine("Could not resolve TgInventoryObject or GObjects.");
            }
        }

        if (g_PendingCopyDiag) {
            g_PendingCopyDiag = false;
            static char big[8000];
            int n = wsprintfA(big, "===== DEEP DIAGNOSTIC =====\r\n");
            for (int i = 0; i < g_DiagLines && n < 7000; ++i)
                n += wsprintfA(big + n, "%s\r\n", g_DiagText[i]);
            lstrcatA(big, "===== END =====\r\n");
            ImGui::SetClipboardText(big);
        }

        if (g_PendingSweep) {
            g_PendingSweep = false;
            g_ObjCount = 0;
            void* myMgr = SafeCalls::GetInvManager();

            SDK::UClass* cls = nullptr;
            __try { cls = SDK::UTgInventoryObject::StaticClass(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { cls = nullptr; }

            if (!cls || !SDK::UObject::GObjects) {
                lstrcpynA(g_SweepStatus, "Could not resolve TgInventoryObject or GObjects.", 210);
            } else {
                auto& arr = *SDK::UObject::GObjects;
                size_t count = 0;
                __try { count = arr.Num(); } __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
                int seen = 0, mine = 0;
                for (size_t i = 0; i < count && count < 4000000; ++i) {
                    SDK::UObject* o = nullptr;
                    __try { if (arr.IsValidIndex(i)) o = arr[i]; }
                    __except (EXCEPTION_EXECUTE_HANDLER) { o = nullptr; }
                    if (!o) continue;
                    bool isInv = false;
                    __try { isInv = o->IsA(cls); }
                    __except (EXCEPTION_EXECUTE_HANDLER) { isInv = false; }
                    if (!isInv) continue;
                    seen++;

                    ObjRow r{};
                    r.obj = o;
                    __try {
                        unsigned char* b = (unsigned char*)o;
                        r.itemId    = *(int*)(b + 0x68);
                        r.level     = *(int*)(b + 0x70);
                        r.equipSlot = *(int*)(b + 0x80);
                        void* mgr   = *(void**)(b + 0x88);
                        r.mine      = (myMgr && mgr == myMgr);
                        r.dev       = *(SDK::ATgDevice**)(b + 0xA8);
                    }
                    __except (EXCEPTION_EXECUTE_HANDLER) { continue; }
                    if (r.mine) mine++;
                    if (g_OnlyMine && !r.mine) continue;

                    char nm[72] = {};
                    __try {
                        auto& names = SDK::FName::GetGlobalNames();
                        if (o->Name.Index && names.IsValidIndex((size_t)o->Name.Index)) {
                            SDK::FNameEntry* e = names[o->Name.Index];
                            if (e) lstrcpynA(nm, e->GetAnsiName(), 71);
                        }
                    }
                    __except (EXCEPTION_EXECUTE_HANDLER) { nm[0] = 0; }
                    lstrcpynA(r.name, nm[0] ? nm : "(unnamed)", 71);

                    if (g_ObjCount < kMaxObjRows) g_Obj[g_ObjCount++] = r;
                }
                // Sort by LEVEL, highest first. A Paladins deck is five cards whose
                // levels total 15, so the levelled rows ARE your deck - everything at
                // level 0 is some other device that happens to live in the same list.
                // Putting them on top means the five that matter are the five you see.
                for (int a2 = 1; a2 < g_ObjCount; ++a2) {
                    ObjRow key = g_Obj[a2];
                    int b2 = a2 - 1;
                    while (b2 >= 0 && g_Obj[b2].level < key.level) { g_Obj[b2 + 1] = g_Obj[b2]; b2--; }
                    g_Obj[b2 + 1] = key;
                }
                g_SweptPawn = Globals::LocalPawn;
                g_SweptMgr  = myMgr;
                int levelled = 0, total = 0;
                g_DeckFound = 0;
                for (int i = 0; i < g_ObjCount; ++i) {
                    if (g_Obj[i].level > 0) { levelled++; total += g_Obj[i].level; }
                    if (g_Obj[i].level > 0 && g_Obj[i].dev) g_DeckFound++;
                }
                wsprintfA(g_SweepStatus,
                    "%d in memory, %d yours, %d listed. %d have a LEVEL (total %d) - those are "
                    "your deck, shown first.", seen, mine, g_ObjCount, levelled, total);
            }
        }

        // Re-sweep whenever the pawn changes; the device pointers belong to it.
        if (Globals::LocalPawn != g_EqSweptPawn) {
            g_EqSweptPawn = (void*)Globals::LocalPawn;
            g_EqCount = 0;
            g_PendingEqSweep = true;
            g_EqAutoSweepTimer = 0.0f;
        }

        // Timed re-sweep. Fast while the list is empty (the devices usually are
        // not ready the instant the pawn spawns), slow once it has filled in.
        if (g_EqAutoSweep && Globals::LocalPawn) {
            g_EqAutoSweepTimer += 0.016f;   // safe thread runs ~per frame
            float want = ((g_EqCount == 0) ? kEqRetrySec : g_EqAutoSweepSec)
                         * Perf::IntervalScale();
            if (g_EqAutoSweepTimer >= want) {
                g_EqAutoSweepTimer = 0.0f;
                g_PendingEqSweep = true;
            }
        }

        if (g_PendingEqSweep) {
            g_PendingEqSweep = false;

            // SPAM TURNING ITSELF OFF - fixed here.
            //
            // The sweep rebuilt g_Eq IN PLACE and then looked up the old spam
            // flag inside that same array. By the time it reached eq12 the low
            // slots already held NEW rows, so the lookup matched a freshly
            // written row with spam=false and the toggle was lost. With the
            // auto re-sweep running every few seconds, a spam you ticked would
            // silently switch itself off moments later.
            //
            // Snapshot first, and key it on DEVICE ID rather than equip point -
            // ids are stable, equip points have shifted between builds.
            struct PrevSpam { int deviceId; bool spam; int shots; };
            PrevSpam prevRows[kMaxEq];
            int prevCount = g_EqCount;
            for (int k = 0; k < prevCount && k < kMaxEq; ++k) {
                prevRows[k].deviceId = g_Eq[k].deviceId;
                prevRows[k].spam     = g_Eq[k].spam;
                prevRows[k].shots    = g_Eq[k].shots;
            }

            g_EqCount = 0;
            int withPoints = 0;
            for (int eq = 0; eq <= 20 && g_EqCount < kMaxEq; ++eq) {
                SDK::ATgDevice* d = SafeCalls::GetDeviceByEqPointPawn(eq);
                if (!d) continue;
                int id = 0, pts = 0;
                if (!SafeCalls::ReadDeviceIdAndPoints(d, &id, &pts)) continue;

                EqRow r{};
                r.dev = d; r.eq = eq; r.deviceId = id; r.points = pts;
                // Carry the user's spam toggle across the re-sweep, from the
                // SNAPSHOT - never from the array being rebuilt.
                for (int k = 0; k < prevCount && k < kMaxEq; ++k) {
                    if (prevRows[k].deviceId == id) {
                        r.spam  = prevRows[k].spam;
                        r.shots = prevRows[k].shots;
                        break;
                    }
                }
                if (pts > 0) withPoints++;
                g_Eq[g_EqCount++] = r;
            }
            wsprintfA(g_EqStatus, "%d devices across eq 0-20, %d with card points.",
                      g_EqCount, withPoints);

            // ---- CARD MAXXING gets its cards from HERE now -------------------
            //
            // It used to resolve the five slots out of the INVENTORY sweep
            // (g_Obj). On a client that sweep comes back with no levels and no
            // s_Device, so every slot reported "no device resolved" - even
            // though the eq sweep sitting right above it had the same cards and
            // could fire them.
            //
            // So the five card slots are filled from the eq sweep instead: rows
            // the device table says are real deck cards (rarity is not
            // "Default"), preferring the ones with points allocated.
            {
                int prev[5];
                bool prevSpam[5];
                int  prevShots[5];
                for (int s = 0; s < 5; ++s) {
                    prev[s]      = g_Five[s].itemId;
                    prevSpam[s]  = g_Five[s].spam;
                    prevShots[s] = g_Five[s].shots;
                }

                g_FiveFound = 0;
                int slot = 0;

                // Pass 1: real deck cards WITH points. Pass 2: deck cards
                // without. Two passes so a levelled card never loses its slot to
                // an unlevelled one just for sweeping earlier.
                for (int pass = 0; pass < 2 && slot < 5; ++pass) {
                    for (int i = 0; i < g_EqCount && slot < 5; ++i) {
                        if (!DeviceNames::IsDeckCard(g_Eq[i].deviceId)) continue;
                        bool hasPts = (g_Eq[i].points > 0);
                        if (pass == 0 && !hasPts) continue;
                        if (pass == 1 &&  hasPts) continue;

                        // no duplicates across the two passes
                        bool already = false;
                        for (int k = 0; k < slot; ++k)
                            if (g_Five[k].itemId == g_Eq[i].deviceId) { already = true; break; }
                        if (already) continue;

                        FiveCard fc{};
                        fc.dev    = g_Eq[i].dev;
                        fc.slot   = g_Eq[i].eq;      // the eq point, which is what fires it
                        fc.itemId = g_Eq[i].deviceId;
                        fc.level  = g_Eq[i].points;
                        lstrcpynA(fc.label, DeviceNames::NameOf(g_Eq[i].deviceId), 71);

                        // Carry the spam toggle across a re-sweep by device id,
                        // not by slot - slots shuffle, device ids do not.
                        for (int k = 0; k < 5; ++k) {
                            if (prev[k] == fc.itemId) {
                                fc.spam  = prevSpam[k];
                                fc.shots = prevShots[k];
                                break;
                            }
                        }

                        g_Five[slot++] = fc;
                        g_FiveFound++;
                    }
                }
                for (int s = slot; s < 5; ++s) {
                    FiveCard empty{};
                    empty.slot = -1;
                    lstrcpynA(empty.label, "(empty)", 71);
                    g_Five[s] = empty;
                }

                if (g_FiveFound > 0)
                    wsprintfA(g_FiveStatus, "%d card(s) resolved from the eq sweep.", g_FiveFound);
                else
                    lstrcpynA(g_FiveStatus,
                        "No deck cards in this sweep - this champion's rows are all abilities, "
                        "or the sweep has not run yet.", 210);
            }
        }

        if (g_PendingCopyEq) {
            g_PendingCopyEq = false;
            static char big[8000];
            int c = wsprintfA(big, "===== EQ-POINT SWEEP =====\r\n%s\r\n\r\n", g_EqStatus);
            for (int i = 0; i < g_EqCount && c < 7000; ++i)
                c += wsprintfA(big + c, "eq%-3d device=%-7d points=%d\r\n",
                               g_Eq[i].eq, g_Eq[i].deviceId, g_Eq[i].points);
            lstrcatA(big, "===== END =====\r\n");
            ImGui::SetClipboardText(big);
        }

        if (g_PendingFireEq >= 0) {
            int i = g_PendingFireEq;
            g_PendingFireEq = -1;
            if (i < g_EqCount) {
                // Re-fetch rather than trust a cached pointer.
                SDK::ATgDevice* d = SafeCalls::GetDeviceByEqPointPawn(g_Eq[i].eq);
                if (d && SafeCalls::DeviceStartFire(d)) {
                    SafeCalls::DeviceStopFire(d);
                    g_Eq[i].shots++;
                    wsprintfA(g_Status, "eq%d (device %d) FIRED x%d",
                              g_Eq[i].eq, g_Eq[i].deviceId, g_Eq[i].shots);
                } else {
                    wsprintfA(g_Status, "eq%d: no live device right now.", g_Eq[i].eq);
                }
            }
        }

        // eq spam, on its own timer
        {
            bool any = false;
            for (int i = 0; i < g_EqCount; ++i) if (g_Eq[i].spam) { any = true; break; }
            if (any) {
                g_EqSpamTimer += 0.016f;
                if (g_EqSpamTimer >= (g_EqSpamRate < 0.0f ? 0.0f : g_EqSpamRate)) {
                    g_EqSpamTimer = 0.0f;
                    for (int i = 0; i < g_EqCount; ++i) {
                        if (!g_Eq[i].spam) continue;
                        SDK::ATgDevice* d = SafeCalls::GetDeviceByEqPointPawn(g_Eq[i].eq);
                        if (d && SafeCalls::DeviceStartFire(d)) {
                            SafeCalls::DeviceStopFire(d);
                            g_Eq[i].shots++;
                        }
                    }
                }
            }
        }

        if (g_PendingDevSweep) {
            g_PendingDevSweep = false;
            // The join below needs the inventory list, which carries the useful
            // names. If it is empty, build it first - it is cheap and it is the
            // only source of a readable label.
            if (g_ObjCount == 0) { g_PendingSweep = true; g_PendingDevSweep = true; }
        }
        if (g_PendingDevSweep) {
            g_PendingDevSweep = false;
            g_DevCount = 0;
            SDK::UClass* dcls = nullptr;
            __try { dcls = SDK::ATgDevice::StaticClass(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { dcls = nullptr; }

            if (!dcls || !SDK::UObject::GObjects) {
                lstrcpynA(g_DevStatus, "Could not resolve ATgDevice or GObjects.", 210);
            } else {
                auto& arr = *SDK::UObject::GObjects;
                size_t count = 0;
                __try { count = arr.Num(); } __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
                int seen = 0;
                void* myPawn = (void*)Globals::LocalPawn;
                for (size_t i = 0; i < count && count < 4000000; ++i) {
                    SDK::UObject* o = nullptr;
                    __try { if (arr.IsValidIndex(i)) o = arr[i]; }
                    __except (EXCEPTION_EXECUTE_HANDLER) { o = nullptr; }
                    if (!o) continue;
                    bool isDev = false;
                    __try { isDev = o->IsA(dcls); }
                    __except (EXCEPTION_EXECUTE_HANDLER) { isDev = false; }
                    if (!isDev) continue;
                    seen++;

                    DevRow r{};
                    bool ours = false;
                    __try {
                        unsigned char* b = (unsigned char*)o;
                        void* owner = *(void**)(b + 0x00C4);
                        void* instg = *(void**)(b + 0x0118);
                        ours = (myPawn && (owner == myPawn || instg == myPawn));
                        r.dev           = (SDK::ATgDevice*)o;
                        r.deviceId      = *(int*)(b + 0x0304);
                        r.instanceCount = *(int*)(b + 0x030C);
                        // r_nInstanceCount came back 1 for everything. The card's
                        // LEVEL is the points spent on it, which is a separate
                        // replicated field.
                        r.points        = *(int*)(b + 0x0320);
                        r.deviceType    = *(int*)(b + 0x0424);
                        r.inventoryId   = *(int*)(b + 0x0438);
                    }
                    __except (EXCEPTION_EXECUTE_HANDLER) { continue; }
                    if (g_OnlyMine && !ours) continue;

                    char nm[72] = {};
                    __try {
                        auto& names = SDK::FName::GetGlobalNames();
                        if (o->Name.Index && names.IsValidIndex((size_t)o->Name.Index)) {
                            SDK::FNameEntry* e = names[o->Name.Index];
                            if (e) lstrcpynA(nm, e->GetAnsiName(), 71);
                        }
                    }
                    __except (EXCEPTION_EXECUTE_HANDLER) { nm[0] = 0; }
                    lstrcpynA(r.name, nm[0] ? nm : "(unnamed)", 71);

                    if (g_DevCount < kMaxDevRows) g_Dev[g_DevCount++] = r;
                }
                g_SweptPawn = Globals::LocalPawn;

                // NAME THE DEVICES.
                //
                // Most card devices are literally called "TgDevice", which tells
                // you nothing. But the inventory objects ARE named usefully
                // (TgInventoryObject_Listen_FireOnLowHealth and so on), and the
                // two sides share an id: the device's r_nDeviceId equals the
                // inventory object's m_InventoryData.nItemId. So join them and
                // borrow the good name.
                //
                // A negative r_nInventoryId also turns out to be the tell for a
                // card - abilities and cosmetics carry small negative ids in a
                // different range, while the loadout cards sit around -180.
                for (int i = 0; i < g_DevCount; ++i) {
                    lstrcpynA(g_Dev[i].label, g_Dev[i].name, 71);
                    g_Dev[i].isCard = false;
                    for (int j = 0; j < g_ObjCount; ++j) {
                        if (g_Obj[j].itemId != g_Dev[i].deviceId) continue;
                        const char* n = g_Obj[j].name;
                        // strip the boilerplate prefix so the list reads cleanly
                        const char* p = n;
                        if (_strnicmp(p, "TgInventoryObject_Listen_", 25) == 0) p += 25;
                        else if (_strnicmp(p, "TgInventoryObject_", 18) == 0)   p += 18;
                        else if (_strnicmp(p, "TgInvListener_", 14) == 0)       p += 14;
                        lstrcpynA(g_Dev[i].label, p, 71);
                        g_Dev[i].isCard = true;
                        break;
                    }
                }

                // Cards first, then by points.
                for (int a2 = 1; a2 < g_DevCount; ++a2) {
                    DevRow key = g_Dev[a2];
                    int rank = (key.isCard ? 1000 : 0) + key.points;
                    int b2 = a2 - 1;
                    while (b2 >= 0 &&
                           ((g_Dev[b2].isCard ? 1000 : 0) + g_Dev[b2].points) < rank) {
                        g_Dev[b2 + 1] = g_Dev[b2]; b2--;
                    }
                    g_Dev[b2 + 1] = key;
                }

                int cards = 0, pts = 0;
                for (int i = 0; i < g_DevCount; ++i)
                    if (g_Dev[i].isCard) { cards++; pts += g_Dev[i].points; }

                wsprintfA(g_DevStatus,
                    "%d devices in memory, %d yours. %d matched a card (%d points total). "
                    "Cards listed first.", seen, g_DevCount, cards, pts);

                // ---- resolve the five numbered cards ----
                g_FiveFound = 0;
                for (int s = 0; s < 5; ++s) {
                    FiveCard fc{};
                    fc.slot = kCardSlots[s];
                    fc.spam = g_Five[s].spam;      // keep the user's spam toggles
                    fc.shots = g_Five[s].shots;
                    lstrcpynA(fc.label, "(empty)", 71);

                    // find the inventory object sitting in this card slot
                    int oj = -1;
                    for (int j = 0; j < g_ObjCount; ++j)
                        if (g_Obj[j].equipSlot == kCardSlots[s]) { oj = j; break; }

                    if (oj >= 0) {
                        fc.itemId = g_Obj[oj].itemId;
                        fc.level  = g_Obj[oj].level;
                        const char* n = g_Obj[oj].name;
                        const char* p = n;
                        if (_strnicmp(p, "TgInventoryObject_Listen_", 25) == 0) p += 25;
                        else if (_strnicmp(p, "TgInventoryObject_", 18) == 0)   p += 18;
                        else if (_strnicmp(p, "TgInvListener_", 14) == 0)       p += 14;
                        lstrcpynA(fc.label, p, 71);

                        // s_Device is server-side, so find the device by ID instead
                        for (int d2 = 0; d2 < g_DevCount; ++d2) {
                            if (g_Dev[d2].deviceId != fc.itemId) continue;
                            fc.dev = g_Dev[d2].dev;
                            if (fc.level <= 0) fc.level = g_Dev[d2].points;
                            break;
                        }
                        if (fc.dev) g_FiveFound++;
                    }
                    g_Five[s] = fc;
                }
                wsprintfA(g_FiveStatus,
                    "%d of 5 card slots resolved to a live device.", g_FiveFound);
            }
        }

        if (g_PendingCopyDev) {
            g_PendingCopyDev = false;
            static char big[16000];
            int n = wsprintfA(big, "===== DEVICE SWEEP =====\r\n%s\r\n\r\n", g_DevStatus);
            for (int i = 0; i < g_DevCount && n < 15000; ++i)
                n += wsprintfA(big + n, "%s devId=%-7d pts=%-3d cnt=%-3d type=%-4d invId=%-6d  %s\r\n",
                               g_Dev[i].isCard ? "CARD" : "    ",
                               g_Dev[i].deviceId, g_Dev[i].points, g_Dev[i].instanceCount,
                               g_Dev[i].deviceType, g_Dev[i].inventoryId, g_Dev[i].label);
            lstrcatA(big, "===== END =====\r\n");
            ImGui::SetClipboardText(big);
        }

        // Is a SPAM tick due? Manual CARD clicks ignore this and fire instantly;
        // only the continuous "spam" checkboxes are rate-limited. Without this
        // the five slots re-fired every single frame with no limit.
        bool fiveSpamDue = false;
        {
            ULONGLONG nowFive = GetTickCount64();
            float fr = g_FiveRate < kMinSafeFireRate ? kMinSafeFireRate : g_FiveRate;
            if (nowFive - g_LastFiveFireMs >= (ULONGLONG)(fr * 1000.0f)) {
                g_LastFiveFireMs = nowFive;
                fiveSpamDue = true;
            }
        }
        for (int s = 0; s < 5; ++s) {
            bool want = g_PendingFive[s];              // manual click - always honoured
            g_PendingFive[s] = false;
            if (g_Five[s].spam && fiveSpamDue) want = true;
            if (!want || !g_Five[s].dev) continue;
            if (Globals::LocalPawn != g_SweptPawn) break;
            if (SafeCalls::DeviceStartFire(g_Five[s].dev)) {
                SafeCalls::DeviceStopFire(g_Five[s].dev);
                g_Five[s].shots++;
            }
        }

        if (g_PendingFireDev >= 0) {
            int i = g_PendingFireDev;
            g_PendingFireDev = -1;
            if (i < g_DevCount && g_Dev[i].dev && Globals::LocalPawn == g_SweptPawn) {
                bool ok = SafeCalls::DeviceStartFire(g_Dev[i].dev);
                if (ok) SafeCalls::DeviceStopFire(g_Dev[i].dev);
                wsprintfA(g_Status, "%s: %s", g_Dev[i].name, ok ? "FIRED" : "faulted");
            } else {
                lstrcpynA(g_Status, "Device row is stale - re-sweep.", 210);
            }
        }
        for (int i = 0; i < g_DevCount && i < kMaxDevRows; ++i) {
            if (!g_DevSpam[i] || !g_Dev[i].dev) continue;
            if (Globals::LocalPawn != g_SweptPawn) break;
            if (SafeCalls::DeviceStartFire(g_Dev[i].dev))
                SafeCalls::DeviceStopFire(g_Dev[i].dev);
        }


        // Re-read s_Device from the object at fire time rather than trusting a
        // pointer cached seconds ago. The device can be swapped or released
        // while the inventory object itself is still alive.
        if (g_PendingFireObj >= 0) {
            int i = g_PendingFireObj;
            g_PendingFireObj = -1;
            SDK::ATgDevice* d = (i >= 0 && i < g_ObjCount) ? FreshDevice(i) : nullptr;
            if (d) {
                bool ok = SafeCalls::DeviceStartFire(d);
                if (ok) SafeCalls::DeviceStopFire(d);
                wsprintfA(g_Status, "%s (slot %d): %s",
                          g_Obj[i].name, g_Obj[i].equipSlot, ok ? "FIRED" : "faulted");
            } else {
                lstrcpynA(g_Status, "No live device on that row right now.", 210);
            }
        }
        for (int i = 0; i < g_ObjCount && i < kMaxObjRows; ++i) {
            if (!g_ObjSpam[i]) continue;
            SDK::ATgDevice* d = FreshDevice(i);
            if (d && SafeCalls::DeviceStartFire(d)) SafeCalls::DeviceStopFire(d);
        }

        if (g_PendingScan) {
            g_PendingScan = false;
            g_ScanRows = 0;
            int found = 0;
            void* mgr = SafeCalls::GetInvManager();
            if (!mgr) {
                lstrcpynA(g_ScanSummary, "InvManager is NULL - the pawn has no inventory manager "
                                         "reachable at APawn+0x4DC. Nothing else can work.", 210);
            } else {
                for (int ep = 0; ep <= 30; ++ep) {
                    for (int it = 0; it <= 5; ++it) {
                        SDK::UTgInventoryObject* io = SafeCalls::GetInvByEquipPoint(ep, it);
                        if (!io) continue;
                        found++;
                        SafeCalls::InvRow row{};
                        SafeCalls::ReadInvObject(io, &row);
                        SDK::ATgDevice* dev = SafeCalls::GetDeviceFromInvObject(io);
                        if (g_ScanRows < kScanMaxRows) {
                            wsprintfA(g_ScanText[g_ScanRows],
                                "eqp=%-2d type=%d  dev=%s  id=%-6d lvl=%-3d  %s",
                                ep, it, dev ? "YES" : "no ", row.refData, row.stackCount, row.name);
                            g_ScanRows++;
                        }
                    }
                }
                wsprintfA(g_ScanSummary,
                    "InvManager OK. %d inventory objects across equip points 0-30, item types 0-5. "
                    "%d rows listed.", found, g_ScanRows);
            }
        }

        if (g_PendingCopyScan) {
            g_PendingCopyScan = false;
            static char big[24000];
            int n = wsprintfA(big, "===== SLOT SCAN =====\r\n%s\r\n\r\n", g_ScanSummary);
            for (int i = 0; i < g_ScanRows && n < 23000; ++i)
                n += wsprintfA(big + n, "%s\r\n", g_ScanText[i]);
            if (g_ScanRows == 0) lstrcatA(big, "(no inventory objects found at all)\r\n");
            lstrcatA(big, "===== END =====\r\n");
            ImGui::SetClipboardText(big);
        }

        for (int i = 0; i < 4; i++) {
            if (g_PendingExtra[i]) {
                g_PendingExtra[i] = false;
                if (FireSlotSafe(kExtra, i, g_ExtraShots))
                    wsprintfA(g_Status, "%s fired (eqp %d) x%d",
                              kExtra[i].label, kExtra[i].equipPoint, g_ExtraShots[i]);
                else
                    wsprintfA(g_Status, "%s: no device at eqp %d",
                              kExtra[i].label, kExtra[i].equipPoint);
            }
        }

        if (g_PendingAllFive) {
            g_PendingAllFive = false;
            int n = 0;
            for (int i = 0; i < 5; i++) if (FireSlotSafe(kCards, i, g_CardShots)) n++;
            wsprintfA(g_Status, "Fired %d of 5 cards.", n);
        }

        for (int i = 0; i < 5; i++) {
            if (g_PendingCard[i]) {
                g_PendingCard[i] = false;
                if (FireSlotSafe(kCards, i, g_CardShots))
                    wsprintfA(g_Status, "%s fired (eqp %d) x%d",
                              kCards[i].label, kCards[i].equipPoint, g_CardShots[i]);
                else
                    wsprintfA(g_Status, "%s: no device at eqp %d",
                              kCards[i].label, kCards[i].equipPoint);
            }
            if (g_PendingBurn[i]) {
                g_PendingBurn[i] = false;
                if (FireSlotSafe(kBurn, i, g_BurnShots))
                    wsprintfA(g_Status, "%s fired (eqp %d) x%d",
                              kBurn[i].label, kBurn[i].equipPoint, g_BurnShots[i]);
                else
                    wsprintfA(g_Status, "%s: no device at eqp %d",
                              kBurn[i].label, kBurn[i].equipPoint);
            }
        }

        if (g_PendingManualStart) {
            g_PendingManualStart = false;
            SDK::ATgDevice* d = SafeCalls::GetDeviceByEquipPoint(g_EquipPoint, g_ItemType);
            if (!d) lstrcpynA(g_Status, "No device at that equip point / item type.", 210);
            else wsprintfA(g_Status, "StartFire: %s",
                           SafeCalls::DeviceStartFire(d) ? "sent" : "FAULTED");
        }
        if (g_PendingManualStop) {
            g_PendingManualStop = false;
            SDK::ATgDevice* d = SafeCalls::GetDeviceByEquipPoint(g_EquipPoint, g_ItemType);
            if (!d) lstrcpynA(g_Status, "No device at that equip point / item type.", 210);
            else wsprintfA(g_Status, "StopFire: %s",
                           SafeCalls::DeviceStopFire(d) ? "sent" : "FAULTED");
        }
    }

    // ================= RENDER THREAD from here down =================
    // Flags only. Nothing below may call into the game.

    inline void Tick() {
        if (!g_Spam) return;
        g_SpamTimer += 0.016f;
        float rate = g_SpamRate < kMinSafeFireRate ? kMinSafeFireRate : g_SpamRate;
        if (g_SpamTimer >= rate) { g_SpamTimer = 0.0f; g_PendingManualStart = true; }
    }

    inline void TickCards() {
        // Never fire a card because the user typed a number into a text box.
        // Same class of bug as the grayscale hotkey: raw key state does not know
        // an ImGui field has focus.
        const bool typing = ImGui::GetCurrentContext() && ImGui::GetIO().WantTextInput;
        if (g_HotkeysOn && !typing) {
            for (int i = 0; i < 5; i++) {
                if (g_CardKey[i]) {
                    bool down = (GetAsyncKeyState(g_CardKey[i]) & 0x8000) != 0;
                    if (down && !g_CardKeyWasDown[i]) g_PendingCard[i] = true;   // edge
                    g_CardKeyWasDown[i] = down;
                }
                if (g_BurnKey[i]) {
                    bool down = (GetAsyncKeyState(g_BurnKey[i]) & 0x8000) != 0;
                    if (down && !g_BurnKeyWasDown[i]) g_PendingBurn[i] = true;
                    g_BurnKeyWasDown[i] = down;
                }
            }
        }

        g_CardTimer += 0.016f;
        // Floored at kMinSafeFireRate - a 0.0 rate here used to fire all 5 card
        // slots every single frame and crash the game inside ProcessEvent.
        float cardRate = g_CardRate < kMinSafeFireRate ? kMinSafeFireRate : g_CardRate;
        if (g_CardTimer < cardRate) return;
        g_CardTimer = 0.0f;

        for (int i = 0; i < 5; i++) {
            bool held = g_HotkeysOn && g_HotkeyHold && g_CardKey[i] &&
                        (GetAsyncKeyState(g_CardKey[i]) & 0x8000) != 0;
            if (g_CardSpam[i] || held) g_PendingCard[i] = true;

            bool bheld = g_HotkeysOn && g_HotkeyHold && g_BurnKey[i] &&
                         (GetAsyncKeyState(g_BurnKey[i]) & 0x8000) != 0;
            if (g_BurnSpam[i] || bheld) g_PendingBurn[i] = true;
        }
        for (int i = 0; i < 4; i++) if (g_ExtraSpam[i]) g_PendingExtra[i] = true;
    }

    inline void DrawSlotRow(const CardSlot* set, int i, bool ready, bool* spam,
                            int* shots, bool* pending, const char* tag) {
        char lbl[64]; wsprintfA(lbl, "%s##%s%d", set[i].label, tag, i);
        if (!ready) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.24f, 0.24f, 1.0f));
        if (ImGui::Button(lbl, ImVec2(110, 28))) pending[i] = true;
        if (!ready) ImGui::PopStyleColor();
        ImGui::SameLine();
        char sp[40]; wsprintfA(sp, "spam##%s%d", tag, i);
        ImGui::Checkbox(sp, &spam[i]);
        ImGui::SameLine();
        if (ready) ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)),
                                      "eqp %-2d ready  x%d", set[i].equipPoint, shots[i]);
        else       ImGui::TextDisabled("eqp %-2d no device", set[i].equipPoint);
    }

    inline void DrawControls(bool inMatch) {
        // CARD MAXXING at the very TOP, per PRIMAL_MONKE - it's the thing people
        // actually open this tab for, so it shouldn't be buried under the
        // scanners/diagnostics. (Moved up from further down; the diagnostics
        // still live below it.)
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted(Tm("CARD MAXXING  -  start here", "CARTAS AL MAXIMO  -  empieza aqui"));
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Cards are LISTENERS, not devices - firing them does nothing and they "
            "never appear in the device list. Each card watches for something you do; to stack a "
            "card, spam the thing it listens for.");
        ImGui::TextWrapped("%s", g_FiveStatus);
        for (int s = 0; s < 5; ++s) {
            char lbl[48]; wsprintfA(lbl, "CARD %d##five%d", s + 1, s);
            bool live = (g_Five[s].dev != nullptr);
            if (!live) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.24f, 0.24f, 1.0f));
            if (ImGui::Button(lbl, ImVec2(90, 28))) g_PendingFive[s] = true;
            if (!live) ImGui::PopStyleColor();
            ImGui::SameLine();
            char sp[40]; wsprintfA(sp, "spam##five%d", s);
            ImGui::Checkbox(sp, &g_Five[s].spam);
            ImGui::SameLine();
            if (live)
                ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)),
                    "eq%-3d  pts %-2d  %-28s x%d",
                    g_Five[s].slot, g_Five[s].level, g_Five[s].label, g_Five[s].shots);
            else
                ImGui::TextDisabled("(empty)");
        }
        ImGui::SetNextItemWidth(240);
        ImGui::SliderFloat("spam rate##five", &g_FiveRate, kMinSafeFireRate, 3.0f, "%.2f s");
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "How long to wait between each spam re-fire.\n"
            "LEFT  = fast (%.2fs, the safe minimum)\n"
            "RIGHT = slow (up to 3s between fires)\n"
            "Only affects the 'spam' checkboxes - clicking a CARD button\n"
            "always fires immediately.", kMinSafeFireRate);
        ImGui::TextDisabled("Spam repeats on the safe thread and keeps running with the menu closed.");
        ImGui::Spacing();
        ImGui::Separator();

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.5f, 1.0f, 0.6f, 1.0f)));
        ImGui::TextUnformatted("DIRECT FIRE  -  TgDevice.StartFire / StopFire");
        ImGui::PopStyleColor();
        ImGui::Separator();

        if (!inMatch) ImGui::TextDisabled("Not in a match - devices only exist once you have a pawn.");

        ImGui::TextWrapped("Calls the game's own fire function on a device directly instead of "
            "going through the input path. Does NOT touch cooldown fields.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.55f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("SLOT SCANNER  -  run this FIRST if buttons say 'no device'");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Sweeps every equip point 0-30 against item types 0-5 and reports what "
            "actually exists. The card buttons assume equip points 5/19/20/21/22 with item type 0 - "
            "if that is wrong, this tells us the right numbers instead of guessing again.");
        // "SCAN ALL SLOTS" removed - it walked the inventory manager, which is
        // empty on a client. RE-SWEEP below is the route that works.
        ImGui::SameLine();
        if (ImGui::Button("COPY RESULT", ImVec2(150, 30))) g_PendingCopyScan = true;
        ImGui::SameLine();
        ImGui::TextDisabled("(paste it back to me)");
        ImGui::TextWrapped("%s", g_ScanSummary);
        if (g_ScanRows > 0) {
            ImGui::BeginChild("slotscan", ImVec2(0, 160), true,
                              ImGuiWindowFlags_HorizontalScrollbar);
            for (int i = 0; i < g_ScanRows; i++) ImGui::TextUnformatted(g_ScanText[i]);
            ImGui::EndChild();
        }

        // ================= CARD MAXXING =================
        // ================= CARDS, VIA THE PAWN =================
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)));
        ImGui::TextUnformatted("CARDS  -  THIS IS THE ONE THAT WORKS IN REAL MATCHES");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Asks the PAWN for each equip point directly "
            "(ATgPawn::GetDeviceByEqPoint). The inventory-manager route below returns nothing on "
            "a client - this one does not. Rows with points are your cards.");

        if (ImGui::Button("RE-SWEEP", ImVec2(140, 28))) g_PendingEqSweep = true;
        ImGui::SameLine();
        ImGui::Checkbox("auto", &g_EqAutoSweep);
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Re-sweeps on champion change and every %.0fs after.\n"
                              "Retries fast while the list is empty, which is what\n"
                              "used to make you press RE-SWEEP by hand.", g_EqAutoSweepSec);
        ImGui::SameLine();
        if (ImGui::Button("COPY##eq", ImVec2(90, 28))) g_PendingCopyEq = true;
        ImGui::SameLine();
        ImGui::SetNextItemWidth(150);
        ImGui::SliderFloat("spam rate##eq", &g_EqSpamRate, 0.0f, 0.5f, "%.3f s");
        ImGui::TextWrapped("%s", g_EqStatus);

        if (g_EqCount > 0) {
            // ORDER: confirmed exploits first, then everything else.
            //
            // The sweep returns equip points in numeric order, which buries the
            // one row you actually came for - Octavia's eq18 sat halfway down a
            // list of twenty. Known exploits are hoisted to the top so they are
            // the first thing on screen after a re-sweep.
            int order[kMaxEq]; int nOrder = 0;
            for (int i = 0; i < g_EqCount; ++i)
                if (KnownExploits::Match(g_Eq[i].eq, g_Eq[i].deviceId)) order[nOrder++] = i;
            for (int i = 0; i < g_EqCount; ++i)
                if (!KnownExploits::Match(g_Eq[i].eq, g_Eq[i].deviceId)) order[nOrder++] = i;

            ImGui::BeginChild("eqlist", ImVec2(0, 260), true);
            bool wroteDivider = false;
            for (int o = 0; o < nOrder; ++o) {
                int i = order[o];
                const KnownExploits::Exploit* ex =
                    KnownExploits::Match(g_Eq[i].eq, g_Eq[i].deviceId);

                if (!ex && !wroteDivider && o > 0) {
                    ImGui::Separator();
                    ImGui::TextDisabled("everything else on this champion");
                    wroteDivider = true;
                }

                char lbl[48]; wsprintfA(lbl, "FIRE##eq%d", i);
                if (ImGui::Button(lbl, ImVec2(64, 22))) g_PendingFireEq = i;
                ImGui::SameLine();
                char sp[40]; wsprintfA(sp, "spam##eq%d", i);
                ImGui::Checkbox(sp, &g_Eq[i].spam);
                ImGui::SameLine();

                // KIND comes from the device table, not from whether points are
                // allocated. Points > 0 does NOT mean "card" - abilities carry
                // points too, which is why Turret and Rocket Boots used to be
                // listed as cards. DeviceNames keys off the rarity field: only
                // Default-rarity devices are abilities.
                const char* nm   = DeviceNames::NameOf(g_Eq[i].deviceId);
                const char* kind = DeviceNames::KindLabel(g_Eq[i].deviceId);

                if (ex) {
                    ImGui::TextColored(Ink(ImVec4(1.0f, 0.80f, 0.25f, 1.0f)),
                        "eq%-3d  %-9s  %-28s  << %s",
                        g_Eq[i].eq, kind, nm, ex->label);
                    ImGui::SameLine();
                    ImGui::TextDisabled("dev %d  x%d", g_Eq[i].deviceId, g_Eq[i].shots);
                    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", ex->note);
                } else if (g_Eq[i].points > 0) {
                    ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)),
                        "eq%-3d  %-9s  %-28s  pts %-2d  dev %-6d  x%d",
                        g_Eq[i].eq, kind, nm, g_Eq[i].points, g_Eq[i].deviceId, g_Eq[i].shots);
                } else {
                    ImGui::TextDisabled("eq%-3d  %-9s  %-28s  pts 0   dev %-6d  x%d",
                        g_Eq[i].eq, kind, nm, g_Eq[i].deviceId, g_Eq[i].shots);
                }
            }
            ImGui::EndChild();
            ImGui::TextDisabled("Spam keeps running with the menu closed.");

            // ---- write what you find straight to disk ----
            if (ImGui::Button("LOG THIS SWEEP", ImVec2(170, 26))) {
                const char* champ = DeviceNames::ChampOf(g_EqCount > 0 ? g_Eq[0].deviceId : 0);
                KnownExploits::AppendFinding("");
                KnownExploits::AppendFinding("===== SWEEP =====");
                for (int i = 0; i < g_EqCount; ++i) {
                    const char* c = DeviceNames::ChampOf(g_Eq[i].deviceId);
                    KnownExploits::LogSweepRow((c && c[0]) ? c : champ,
                                               g_Eq[i].eq, g_Eq[i].deviceId, g_Eq[i].points);
                }
            }
            ImGui::SameLine();
            if (ImGui::Button("LOG CONFIRMED TABLE", ImVec2(210, 26)))
                KnownExploits::LogKnownTable();
            ImGui::TextDisabled("%s", KnownExploits::g_LogStatus);
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.55f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("DEEP DIAGNOSTIC  -  run this in a REAL MATCH");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Dumps every inventory object with NO manager filter, grouped by which "
            "manager owns it. If the live cards exist under a different manager than pawn+0x4DC, "
            "this shows it - and that is the whole bug.");
        if (ImGui::Button("RUN DIAGNOSTIC", ImVec2(170, 28))) g_PendingDiag = true;
        ImGui::SameLine();
        if (ImGui::Button("COPY##diag", ImVec2(100, 28))) g_PendingCopyDiag = true;
        if (g_DiagLines > 0) {
            ImGui::BeginChild("diagbox", ImVec2(0, 190), true,
                              ImGuiWindowFlags_HorizontalScrollbar);
            for (int i = 0; i < g_DiagLines; ++i) ImGui::TextUnformatted(g_DiagText[i]);
            ImGui::EndChild();
        }

        // (CARD MAXXING moved to the TOP of this page - see the top of
        // DrawControls. The reload-spam note that used to sit here: cards are
        // listeners with no internal cooldown, so spamming their trigger device
        // - e.g. reload on Dredge/Damba - re-fires the card each time.)

        ImGui::Spacing();
        if (ImGui::CollapsingHeader("Trigger reference - what each card listens for")) {
        if (g_ObjCount == 0) {
            ImGui::TextDisabled("Press SWEEP DEVICES below - it builds this list too.");
        } else {
            int spammable = 0;
            ImGui::BeginChild("cardmaxx", ImVec2(0, 170), true,
                              ImGuiWindowFlags_HorizontalScrollbar);
            for (int j = 0; j < g_ObjCount; ++j) {
                TrigKind k = ClassifyListener(g_Obj[j].name);
                if (k == TRIG_NONE) continue;

                const char* n = g_Obj[j].name;
                const char* p = n;
                if (_strnicmp(p, "TgInventoryObject_Listen_", 25) == 0) p += 25;
                else if (_strnicmp(p, "TgInventoryObject_", 18) == 0)   p += 18;
                else if (_strnicmp(p, "TgInvListener_", 14) == 0)       p += 14;

                int devIdx = (k == TRIG_EVENT) ? -1 : FindTriggerDevice(k);
                if (devIdx >= 0) {
                    spammable++;
                    char lbl[64]; wsprintfA(lbl, "SPAM##cm%d", j);
                    bool on = g_DevSpam[devIdx];
                    if (on) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.25f, 0.55f, 0.30f, 1.0f));
                    if (ImGui::Button(lbl, ImVec2(70, 22))) g_DevSpam[devIdx] = !g_DevSpam[devIdx];
                    if (on) ImGui::PopStyleColor();
                    ImGui::SameLine();
                    ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)),
                        "%-26s on %-7s -> %s%s", p, TrigName(k),
                        g_Dev[devIdx].name, on ? "   [SPAMMING]" : "");
                } else {
                    ImGui::Dummy(ImVec2(70, 22));
                    ImGui::SameLine();
                    if (k == TRIG_EVENT)
                        ImGui::TextDisabled("%-26s on %-7s -> needs a real kill/death, cannot spam",
                                            p, TrigName(k));
                    else
                        ImGui::TextDisabled("%-26s on %-7s -> no matching device found",
                                            p, TrigName(k));
                }
            }
            ImGui::EndChild();
            if (spammable == 0)
                ImGui::TextDisabled("No spammable trigger found for this champion's cards. "
                                    "Reload-trigger champions (Dredge, Damba) work best.");
        }
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)));
        ImGui::TextUnformatted("DEVICES  -  the things you can spam");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("The inventory list below reads s_Device, and the 's_' prefix means "
            "SERVER-local: it is filled in the shooting range (where you are the server) and NULL "
            "on a client in a real match. That is why it worked in the range and not in a match. "
            "This list finds the devices themselves instead - every field it uses is replicated.");
        // THE OLDER SWEEPS, FOLDED AWAY.
        //
        // SWEEP DEVICES, SWEEP INVENTORY, the fixed-equip-point CARD DECK and the
        // hotkey macro all predate the eq-point sweep at the top of this tab.
        // They are the same idea reached three earlier ways, and on a client the
        // inventory-based ones come back empty - which is why this tab looked
        // like it had duplicate, half-working copies of itself.
        //
        // Kept because they are the record of how the working route was found.
        if (!ImGui::CollapsingHeader("Older sweeps (superseded by RE-SWEEP above)"))
            return;

        if (ImGui::Button("SWEEP DEVICES", ImVec2(170, 30))) g_PendingDevSweep = true;
        ImGui::SameLine();
        if (ImGui::Button("COPY##dev", ImVec2(90, 30))) g_PendingCopyDev = true;
        ImGui::SameLine();
        ImGui::TextDisabled("count = card level");
        ImGui::TextWrapped("%s", g_DevStatus);

        if (g_DevCount > 0) {
            ImGui::BeginChild("slotdev", ImVec2(0, 210), true,
                              ImGuiWindowFlags_HorizontalScrollbar);
            for (int i = 0; i < g_DevCount; ++i) {
                char lbl[64]; wsprintfA(lbl, "FIRE##dv%d", i);
                if (ImGui::Button(lbl, ImVec2(64, 22))) g_PendingFireDev = i;
                ImGui::SameLine();
                char sp[32]; wsprintfA(sp, "spam##dv%d", i);
                ImGui::Checkbox(sp, &g_DevSpam[i]);
                ImGui::SameLine();
                if (g_Dev[i].isCard)
                    ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)),
                        "CARD  pts %-2d  id=%-6d  %s", g_Dev[i].points,
                        g_Dev[i].deviceId, g_Dev[i].label);
                else
                    ImGui::TextDisabled("      pts %-2d  id=%-6d  %s", g_Dev[i].points,
                        g_Dev[i].deviceId, g_Dev[i].label);
            }
            ImGui::EndChild();
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.6f, 0.8f, 0.9f, 1.0f)));
        ImGui::TextUnformatted("INVENTORY OBJECTS  -  shooting range only (s_Device is server-side)");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("GetInventoryByEquipPoint returned nothing for all 186 combinations, so "
            "this finds the inventory objects directly in memory instead and reads each one's REAL "
            "equip slot off the object. No guessing.");
        if (ImGui::Button("SWEEP INVENTORY", ImVec2(180, 30))) g_PendingSweep = true;
        ImGui::SameLine();
        ImGui::Checkbox("auto", &g_AutoSweep);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Re-sweeps once a second until your deck actually appears, and drops\n"
            "the whole list the moment your pawn changes. Leave this ON - it is\n"
            "what stops a stale list from firing through freed pointers.");
        ImGui::SameLine();
        ImGui::Checkbox("only mine", &g_OnlyMine);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Keeps only objects whose m_InvManager matches yours, so you are not\n"
            "looking at - or firing - another player's cards.");
        ImGui::SameLine();
        if (ImGui::Button("COPY##sweep", ImVec2(90, 30))) {
            static char big[16000];
            int n = wsprintfA(big, "===== INVENTORY SWEEP =====\r\n%s\r\n\r\n", g_SweepStatus);
            for (int i = 0; i < g_ObjCount && n < 15000; ++i)
                n += wsprintfA(big + n, "slot=%-4d lvl=%-3d id=%-7d dev=%s  %s\r\n",
                               g_Obj[i].equipSlot, g_Obj[i].level, g_Obj[i].itemId,
                               g_Obj[i].dev ? "YES" : "no ", g_Obj[i].name);
            lstrcatA(big, "===== END =====\r\n");
            ImGui::SetClipboardText(big);
        }
        ImGui::TextWrapped("%s", g_SweepStatus);

        if (g_ObjCount > 0) {
            ImGui::BeginChild("slotobj", ImVec2(0, 200), true,
                              ImGuiWindowFlags_HorizontalScrollbar);
            for (int i = 0; i < g_ObjCount; ++i) {
                char lbl[160];
                wsprintfA(lbl, "FIRE##ob%d", i);
                bool has = (g_Obj[i].dev != nullptr);
                if (!has) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.24f, 0.24f, 1.0f));
                if (ImGui::Button(lbl, ImVec2(64, 22))) g_PendingFireObj = i;
                if (!has) ImGui::PopStyleColor();
                ImGui::SameLine();
                char sp[32]; wsprintfA(sp, "spam##ob%d", i);
                ImGui::Checkbox(sp, &g_ObjSpam[i]);
                ImGui::SameLine();
                if (g_Obj[i].level > 0)
                    ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)),
                        "slot=%-4d LVL %-2d  %s%s", g_Obj[i].equipSlot, g_Obj[i].level,
                        g_Obj[i].name, has ? "" : "   (no device)");
                else
                    ImGui::TextDisabled("slot=%-4d lvl 0   %s%s", g_Obj[i].equipSlot,
                        g_Obj[i].name, has ? "" : "   (no device)");
            }
            ImGui::EndChild();
            ImGui::TextDisabled("Spam repeats every safe-thread pass. Untick to stop.");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("CARD DECK  (fixed equip points - only works if the sweep agrees)");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Five cards, five equip points. Firing a card runs its effect WITHOUT "
            "the condition that normally gates it.");
        ImGui::Spacing();

        for (int i = 0; i < 5; i++)
            DrawSlotRow(kCards, i, g_CardReady[i], g_CardSpam, g_CardShots, g_PendingCard, "cd");

        ImGui::Spacing();
        ImGui::TextDisabled("Talents / combos - reported to work the same way:");
        for (int i = 0; i < 4; i++)
            DrawSlotRow(kExtra, i, g_ExtraReady[i], g_ExtraSpam, g_ExtraShots, g_PendingExtra, "ex");

        ImGui::Spacing();
        if (ImGui::CollapsingHeader("Burn cards")) {
            for (int i = 0; i < 5; i++)
                DrawSlotRow(kBurn, i, g_BurnReady[i], g_BurnSpam, g_BurnShots, g_PendingBurn, "bn");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("HOTKEYS  -  the actual macro");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Buttons in a menu are not a macro. Bind a key per slot and it works "
            "with the menu closed.");
        ImGui::Checkbox("ENABLE HOTKEYS", &g_HotkeysOn);
        ImGui::SameLine();
        ImGui::Checkbox("repeat while held", &g_HotkeyHold);

        if (g_HotkeysOn) {
            ImGui::TextDisabled("VK codes - number row is 0x31..0x35. 0 disables a slot.");
            for (int i = 0; i < 5; i++) {
                ImGui::SetNextItemWidth(70);
                char id[32]; wsprintfA(id, "card %d##ck%d", i + 1, i);
                ImGui::InputInt(id, &g_CardKey[i]);
                ImGui::SameLine();
                bool down = g_CardKey[i] && (GetAsyncKeyState(g_CardKey[i]) & 0x8000) != 0;
                if (down) ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), "HELD");
                else      ImGui::TextDisabled("up");
                ImGui::SameLine();
                ImGui::SetNextItemWidth(70);
                char id2[32]; wsprintfA(id2, "burn %d##bk%d", i + 1, i);
                ImGui::InputInt(id2, &g_BurnKey[i]);
            }
        }

        ImGui::Spacing();
        ImGui::SetNextItemWidth(200);
        // Min is the safe floor, not 0 - firing every frame crashed the game.
        // Max raised 0.5 -> 3.0 so you can deliberately spam SLOWLY too.
        ImGui::SliderFloat("repeat interval", &g_CardRate, kMinSafeFireRate, 3.0f, "%.2f s");
        ImGui::SameLine();
        if (ImGui::Button("ALL 5 ONCE", ImVec2(110, 24))) g_PendingAllFive = true;
        ImGui::SameLine();
        if (ImGui::Button("stop all spam", ImVec2(110, 24)))
            for (int i = 0; i < 5; i++) { g_CardSpam[i] = false; g_BurnSpam[i] = false; }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextDisabled("Manual - any equip point / item type:");
        ImGui::SetNextItemWidth(80);
        ImGui::InputInt("equip point", &g_EquipPoint);
        ImGui::SameLine();
        ImGui::SetNextItemWidth(80);
        ImGui::InputInt("item type", &g_ItemType);
        ImGui::SameLine();
        if (g_ManualReady) ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), "device found");
        else               ImGui::TextDisabled("no device");

        if (ImGui::Button("START FIRE", ImVec2(150, 28))) g_PendingManualStart = true;
        ImGui::SameLine();
        if (ImGui::Button("STOP FIRE", ImVec2(130, 28)))  g_PendingManualStop = true;
        ImGui::SameLine();
        ImGui::Checkbox("spam##manual", &g_Spam);

        ImGui::Spacing();
        ImGui::TextWrapped("%s", g_Status);
    }
}
