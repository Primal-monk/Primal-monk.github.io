#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include <Windows.h>

// ============================================================================
// CLIENT VALUES  —  the console-command features
// ============================================================================
// Source: CardsStuffAim.txt, a community Input.ini full of key bindings that
// drive ATgPlayerController::SetClientValue against CLASS DEFAULT OBJECTS.
//
// Setting a value on a CDO (Default__TgPawn_Androxus and friends) changes the
// class default, so it applies to every instance of that class - which is how
// one keypress turns a feature on for every champion at once.
//
// Three features live in that file, and all three are things PHAROAH either
// lacked or did worse:
//
//   ATgPawn::r_bIsWallHacking          0x0688  -> see enemies through walls
//   ATgDevice::m_fForce3PPersistTimer  0x062C  -> third person that holds
//   ATgDevice::m_AimAssistMagnetScale  0x07B4  -> aim magnetism (FVector2D)
//
// All three verified present in our own SDK dump before anything here was
// written.
//
// THREADING: SetClientValue is scripted (ProcessEvent), so every call happens
// in ProcessPending() on the safe thread. The draw path only sets flags. This
// is the same rule that fixed the card-suite crash.
// ============================================================================

namespace ClientValues {

    // Every pawn CDO named in the community Input.ini bindings (CardsStuffAim.txt).
    static const wchar_t* kPawnCDOs[] = {
        L"Default__TgPawn",
        L"Default__TgPawn_Androxus",
        L"Default__TgPawn_Astro",
        L"Default__TgPawn_Atlas",
        L"Default__TgPawn_Azaan",
        L"Default__TgPawn_Barik",
        L"Default__TgPawn_BarrierTank",
        L"Default__TgPawn_Biped",
        L"Default__TgPawn_Blades",
        L"Default__TgPawn_BombKing",
        L"Default__TgPawn_BombQueen",
        L"Default__TgPawn_Buck",
        L"Default__TgPawn_Bunny",
        L"Default__TgPawn_Caspian",
        L"Default__TgPawn_Cassie",
        L"Default__TgPawn_Character",
        L"Default__TgPawn_Churchill",
        L"Default__TgPawn_Commander",
        L"Default__TgPawn_Corrupter",
        L"Default__TgPawn_Corvus",
        L"Default__TgPawn_Darklord",
        L"Default__TgPawn_Demon",
        L"Default__TgPawn_Dredge",
        L"Default__TgPawn_Drogoz",
        L"Default__TgPawn_Druid",
        L"Default__TgPawn_DruidGuardian",
        L"Default__TgPawn_Evie",
        L"Default__TgPawn_Fairy",
        L"Default__TgPawn_Fernando",
        L"Default__TgPawn_Flak",
        L"Default__TgPawn_Furia",
        L"Default__TgPawn_Gauntlet",
        L"Default__TgPawn_Grohk",
        L"Default__TgPawn_Grover",
        L"Default__TgPawn_HHGate",
        L"Default__TgPawn_Halloween_Vivian",
        L"Default__TgPawn_Illusion",
        L"Default__TgPawn_Imani",
        L"Default__TgPawn_ImaniAvatar",
        L"Default__TgPawn_Juggernaut",
        L"Default__TgPawn_Kasumi",
        L"Default__TgPawn_KasumiBody",
        L"Default__TgPawn_KasumiEthereal",
        L"Default__TgPawn_Kinessa",
        L"Default__TgPawn_Koga",
        L"Default__TgPawn_LanePusher",
        L"Default__TgPawn_LanePusherBase",
        L"Default__TgPawn_LanePusherRace",
        L"Default__TgPawn_Lazarus",
        L"Default__TgPawn_Lex",
        L"Default__TgPawn_Longbow",
        L"Default__TgPawn_Makoa",
        L"Default__TgPawn_MalDamba",
        L"Default__TgPawn_Nyx",
        L"Default__TgPawn_Omen",
        L"Default__TgPawn_Oracle",
        L"Default__TgPawn_Owl",
        L"Default__TgPawn_Pet",
        L"Default__TgPawn_Pip",
        L"Default__TgPawn_Princess",
        L"Default__TgPawn_Raum",
        L"Default__TgPawn_Rider",
        L"Default__TgPawn_Ruckus",
        L"Default__TgPawn_Saati",
        L"Default__TgPawn_SaatiDecoy",
        L"Default__TgPawn_Seven",
        L"Default__TgPawn_Shadow",
        L"Default__TgPawn_SiegeBeyond_Payload",
        L"Default__TgPawn_SiegeEngine_CaptureAndPayload",
        L"Default__TgPawn_SiegeEngine_ImmuneWhileTraveling",
        L"Default__TgPawn_SiegeEngine_Payload",
        L"Default__TgPawn_SiegeEngine_Payload_Crusade",
        L"Default__TgPawn_SiegeEngine_Wedge",
        L"Default__TgPawn_SiegeWall",
        L"Default__TgPawn_SiegeWall_Base",
        L"Default__TgPawn_SiegeWall_Inner",
        L"Default__TgPawn_SiegeWall_Outer",
        L"Default__TgPawn_Skye",
        L"Default__TgPawn_Stoker",
        L"Default__TgPawn_Structure",
        L"Default__TgPawn_Tiberius",
        L"Default__TgPawn_Tower",
        L"Default__TgPawn_TowerBase",
        L"Default__TgPawn_Tower_FA",
        L"Default__TgPawn_Tower_Inner",
        L"Default__TgPawn_Tower_Outer",
        L"Default__TgPawn_Tower_Upper",
        L"Default__TgPawn_Turret",
        L"Default__TgPawn_Turret_DefaultCone",
        L"Default__TgPawn_Turret_Flamethrower",
        L"Default__TgPawn_Turret_Flamethrower_Mini",
        L"Default__TgPawn_Turret_Mega",
        L"Default__TgPawn_Tyra",
        L"Default__TgPawn_Vampire",
        L"Default__TgPawn_Vanguard",
        L"Default__TgPawn_Viktor",
        L"Default__TgPawn_VoodooTotem",
        L"Default__TgPawn_Yagorath",
        L"Default__TgPawn_Ying",
    };
    static const int kPawnCDOCount = 99;

    // Every in-hand device CDO from the same source.
    static const wchar_t* kDeviceCDOs[] = {
        L"Default__TgDevice_AndroxusInhand",
        L"Default__TgDevice_ArcaneMissilesInhand",
        L"Default__TgDevice_AstroInhand",
        L"Default__TgDevice_AtlasInhand",
        L"Default__TgDevice_AtlasRMBInhand",
        L"Default__TgDevice_AzaanInhand",
        L"Default__TgDevice_BarikInhand",
        L"Default__TgDevice_BarrierTankInhand",
        L"Default__TgDevice_BarriertankInhand",
        L"Default__TgDevice_BladesInhand",
        L"Default__TgDevice_BombKingInhand",
        L"Default__TgDevice_BombQueenInhand",
        L"Default__TgDevice_BuckInhand",
        L"Default__TgDevice_BunnyInhand",
        L"Default__TgDevice_CaspianInhand",
        L"Default__TgDevice_CassieInhand",
        L"Default__TgDevice_ChurchillInhand",
        L"Default__TgDevice_CommanderInhand",
        L"Default__TgDevice_CorrupterInhand",
        L"Default__TgDevice_CorvusInhand",
        L"Default__TgDevice_DarklordInhand",
        L"Default__TgDevice_DemonInhand",
        L"Default__TgDevice_DredgeInhand",
        L"Default__TgDevice_DrogozInhand",
        L"Default__TgDevice_DruidInhand",
        L"Default__TgDevice_EvieInhand",
        L"Default__TgDevice_FairyInhand",
        L"Default__TgDevice_FernandoInhand",
        L"Default__TgDevice_FlakInhand",
        L"Default__TgDevice_FuriaInhand",
        L"Default__TgDevice_GauntletInhand",
        L"Default__TgDevice_GrohkInhand",
        L"Default__TgDevice_GroverInhand",
        L"Default__TgDevice_ImaniDragonInhand",
        L"Default__TgDevice_KasumiInhand",
        L"Default__TgDevice_KinessaInhand",
        L"Default__TgDevice_LazarusInhand",
        L"Default__TgDevice_LexInhand",
        L"Default__TgDevice_LongbowInhand",
        L"Default__TgDevice_MakoaInhand",
        L"Default__TgDevice_MalDambaInhand",
        L"Default__TgDevice_NAMEInhand",
        L"Default__TgDevice_NinjaAltInhand",
        L"Default__TgDevice_NinjaInhand",
        L"Default__TgDevice_NyxInhand",
        L"Default__TgDevice_OmenInhand",
        L"Default__TgDevice_OracleInhand",
        L"Default__TgDevice_OwlInhand",
        L"Default__TgDevice_PipInhand",
        L"Default__TgDevice_PrincessInhand",
        L"Default__TgDevice_RiderInhand",
        L"Default__TgDevice_RuckusInhand",
        L"Default__TgDevice_SaatiDecoyInhand",
        L"Default__TgDevice_SaatiInhand",
        L"Default__TgDevice_SevenInhand",
        L"Default__TgDevice_SkyeInhand",
        L"Default__TgDevice_TiberiusInhand",
        L"Default__TgDevice_ToggleInhand",
        L"Default__TgDevice_TyraInhand",
        L"Default__TgDevice_VampireInhand",
        L"Default__TgDevice_VanguardInhand",
        L"Default__TgDevice_ViktorInhand",
        L"Default__TgDevice_YingInhand",
        L"Default__TgDevice_bladesInhand",
        L"Default__TgDevice_bombkingInhand",
        L"Default__TgDevice_bombqueenInhand",
        L"Default__TgDevice_bunnyInhand",
        L"Default__TgDevice_caspianInhand",
        L"Default__TgDevice_cassieInhand",
        L"Default__TgDevice_corrupterInhand",
        L"Default__TgDevice_corvusInhand",
        L"Default__TgDevice_darklordInhand",
        L"Default__TgDevice_dredgeInhand",
        L"Default__TgDevice_drogozInhand",
        L"Default__TgDevice_druidInhand",
        L"Default__TgDevice_furiaInhand",
        L"Default__TgDevice_grohkInhand",
        L"Default__TgDevice_groverInhand",
        L"Default__TgDevice_imaniInhand",
        L"Default__TgDevice_kasumiInhand",
        L"Default__TgDevice_kunaiInhand",
        L"Default__TgDevice_maldambaInhand",
        L"Default__TgDevice_oracleInhand",
        L"Default__TgDevice_riderInhand",
        L"Default__TgDevice_tiberiusInhand",
        L"Default__TgDevice_vampireInhand",
        L"Default__TgDevice_yingInhand",
    };
    static const int kDeviceCDOCount = 87;

    // ---- pending flags (set on the render thread, consumed on the safe one) --
    inline bool g_PendingWallhack   = false;
    inline bool g_PendingWallhackOff= false;
    inline bool g_Pending3P         = false;
    inline bool g_Pending3POff      = false;
    inline bool g_PendingMagnet     = false;
    inline bool g_PendingMagnetOff  = false;

    inline float g_MagnetScale = 1.0f;
    inline float g_ThirdPerson = 99999.0f;
    inline char  g_Status[256] = "Nothing applied yet.";
    inline int   g_LastOk = 0, g_LastFail = 0;

    // ================= SAFE THREAD ONLY =================

    inline void ApplyToPawns(const wchar_t* var, const wchar_t* val) {
        g_LastOk = g_LastFail = 0;
        for (int i = 0; i < kPawnCDOCount; ++i) {
            if (SafeCalls::SetClientValue(kPawnCDOs[i], var, val)) g_LastOk++;
            else g_LastFail++;
        }
    }
    inline void ApplyToDevices(const wchar_t* var, const wchar_t* val) {
        g_LastOk = g_LastFail = 0;
        for (int i = 0; i < kDeviceCDOCount; ++i) {
            if (SafeCalls::SetClientValue(kDeviceCDOs[i], var, val)) g_LastOk++;
            else g_LastFail++;
        }
    }

    inline void ProcessPending() {
        if (!Globals::LocalController) return;

        if (g_PendingWallhack || g_PendingWallhackOff) {
            bool on = g_PendingWallhack;
            g_PendingWallhack = g_PendingWallhackOff = false;
            ApplyToPawns(L"r_bIsWallHacking", on ? L"1" : L"0");
            wsprintfA(g_Status, "Wallhack %s on %d pawn classes (%d refused).",
                      on ? "ON" : "OFF", g_LastOk, g_LastFail);
        }

        if (g_Pending3P || g_Pending3POff) {
            bool on = g_Pending3P;
            g_Pending3P = g_Pending3POff = false;
            wchar_t val[32];
            wsprintfW(val, L"%d", on ? (int)g_ThirdPerson : 0);
            ApplyToDevices(L"m_fForce3PPersistTimer", val);
            wsprintfA(g_Status, "Third person %s on %d device classes (%d refused).",
                      on ? "ON" : "OFF", g_LastOk, g_LastFail);
        }

        if (g_PendingMagnet || g_PendingMagnetOff) {
            bool on = g_PendingMagnet;
            g_PendingMagnet = g_PendingMagnetOff = false;
            // FVector2D is written in the game's own literal form.
            wchar_t val[64];
            int whole = (int)g_MagnetScale;
            int frac  = (int)((g_MagnetScale - (float)whole) * 100.0f + 0.5f);
            if (on) wsprintfW(val, L"(X=%d.%02d,Y=%d.%02d)", whole, frac, whole, frac);
            else    lstrcpyW(val, L"(X=0.0,Y=0.0)");
            ApplyToDevices(L"m_AimAssistMagnetScale", val);
            wsprintfA(g_Status, "Aim magnet %s on %d device classes (%d refused).",
                      on ? "ON" : "OFF", g_LastOk, g_LastFail);
        }
    }

    // ================= RENDER THREAD =================

    inline void DrawControls(bool inMatch) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("CLIENT VALUES  -  SetClientValue on class defaults");
        ImGui::PopStyleColor();
        ImGui::Separator();
        ImGui::TextWrapped("These come from a community Input.ini (CardsStuffAim.txt). Each writes "
            "a variable onto every champion's CLASS DEFAULT OBJECT, so one press covers all of "
            "them. All three fields were verified in our SDK before this was built.");

        if (!inMatch) ImGui::TextDisabled("Join a match - these need a player controller.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.5f, 1.0f, 0.6f, 1.0f)));
        ImGui::TextUnformatted("SEE THROUGH WALLS   (ATgPawn::r_bIsWallHacking)");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("The real thing - the game's own wallhack flag, not our boxes. Applied "
            "to all %d pawn classes.", kPawnCDOCount);
        if (ImGui::Button(">>> WALLHACK ON <<<", ImVec2(200, 32))) g_PendingWallhack = true;
        ImGui::SameLine();
        if (ImGui::Button("wallhack off", ImVec2(140, 32))) g_PendingWallhackOff = true;

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.5f, 1.0f, 0.6f, 1.0f)));
        ImGui::TextUnformatted("THIRD PERSON   (ATgDevice::m_fForce3PPersistTimer)");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("A persist timer, so it holds instead of snapping back. The bindings "
            "file uses 99999. Applied to all %d in-hand device classes.", kDeviceCDOCount);
        ImGui::SetNextItemWidth(180);
        ImGui::InputFloat("persist seconds", &g_ThirdPerson);
        if (ImGui::Button(">>> THIRD PERSON ON <<<", ImVec2(220, 32))) g_Pending3P = true;
        ImGui::SameLine();
        if (ImGui::Button("back to 1st person", ImVec2(180, 32))) g_Pending3POff = true;

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.5f, 1.0f, 0.6f, 1.0f)));
        ImGui::TextUnformatted("AIM MAGNET   (ATgDevice::m_AimAssistMagnetScale)");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("The game's own aim-assist magnetism, turned up. The bindings file uses "
            "1.0 for most champions and 0.45 for Skye.");
        ImGui::SetNextItemWidth(200);
        ImGui::SliderFloat("magnet scale", &g_MagnetScale, 0.0f, 3.0f, "%.2f");
        if (ImGui::Button(">>> AIM MAGNET ON <<<", ImVec2(200, 32))) g_PendingMagnet = true;
        ImGui::SameLine();
        if (ImGui::Button("magnet off", ImVec2(140, 32))) g_PendingMagnetOff = true;

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextWrapped("%s", g_Status);
        ImGui::TextDisabled("A high 'refused' count means SetClientValue is rejecting the object "
                            "names - tell me and I will dump which ones failed.");
    }
}
