#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include <Windows.h>
#include <cstring>
#include <cstdio>

// ============================================================================
// CHARITY GATE
// ============================================================================
// PHAROAH stays free. EVERYTHING works in the SHOOTING RANGE with no code and
// no payment — that is where people learn the tool. The gate only applies in a
// REAL MATCH, where the same features affect other players.
//
// The flow, as decided:
//   1. User donates to a charity of their choice.
//   2. User posts a screenshot in the community they got this from.
//   3. User is given the code, types it in here, and the whole tool unlocks.
//
// There is also an honour-system shortcut: "I already donated" reveals the code
// in-tool. That is deliberate. This cannot be enforced from a DLL and pretending
// otherwise would only punish honest people while stopping nobody — the code is
// plain text in the binary either way.
//
// UNLOCK PERSISTS across sessions and across versions. It is written next to
// the DLL so a rebuild does not re-lock a user who already donated. Deleting
// that file re-locks.
//
// WHAT IS GATED (in real matches only):
//   - full-rate behaviour for everything. Locked users still get the tool, but
//     the aggressive parts run on a throttle (see kLockedThrottle) instead of
//     being outright removed, so the free version is genuinely usable.
// ============================================================================

namespace Gating {

    // ========================================================================
    // MASTER KILL SWITCH — the gate is currently DISABLED.
    // ========================================================================
    // false = nothing is ever gated. The whole tool works everywhere, out of the
    //         gate, with no code. The tab stays visible so the flow can still be
    //         seen and tested, and the MENU / RANGE / MATCH detector keeps
    //         running because it is useful on its own.
    // true  = the gate is live again.
    //
    // Flip this ONE line to re-enable. Nothing else needs to change: every
    // enforcement point already routes through Allowed() / IsBlocking() /
    // RepeatInterval() below.
    // BACK ON FOR RELEASE.
    //
    // This was switched off during development so testing did not need a code
    // every session. Shipping with it off would mean shipping with no charity
    // gate at all, which is the one thing the licence says must stay.
    // ========================================================================
    // THE GATE IS OFF. NOTHING IS LOCKED. THIS IS DELIBERATE.
    // ========================================================================
    // Locking features behind a donation was the original idea and it did not
    // work out:
    //
    //   - people route around a client-side lock in minutes; it only ever
    //     inconvenienced the honest ones
    //   - it made the tool feel broken - you press a button, nothing happens,
    //     and nothing tells you why
    //   - it drew accusations of running a scam, which is the opposite of the
    //     point
    //
    // So the charity tab stays, the donation links stay, and the ask stays -
    // but it is an ASK, not a toll. Give if you want to give.
    //
    // Everything below (Allowed / IsBlocking / the per-group flags) is left in
    // place and simply always answers "allowed". It costs nothing to keep and
    // means the decision is one line, not a rewrite, if it ever changes back.
    inline constexpr bool kGateEnabled = false;

    // ---- The unlock code -------------------------------------------------
    inline const char* kCode = "SingleUse-01AA";

    // NO EXTERNAL URLS AND NO SHELL-API LINK OPENING, ANYWHERE IN THIS FILE.
    // A modding-site review rejected an earlier build over exactly this:
    // "External Linking and forcing webpage loading using Shell API is
    // against UCD rules." The donate/community buttons that used to live here
    // (and called ShellExecuteA to open a browser) are removed outright - the
    // charity ask stays, but as plain, non-clickable text with no address in
    // it, so there is nothing to open and nothing to link to.

    // While LOCKED and in a real match, repeat-fire effects run at this interval
    // instead of their real one. Octavia shields being the worked example: 1.2s
    // locked vs 0.06s unlocked.
    inline const float kLockedThrottle = 1.2f;
    inline const float kUnlockedRate   = 0.06f;

    // ---- Where are we? ---------------------------------------------------
    enum class State {
        Unknown,        // no controller yet, or the read faulted
        Menu,           // no pawn — lobby, loading, main menu
        ShootingRange,  // NM_Standalone: we are the server. Never gated.
        RealMatch       // NM_Client: a real server owns replication. Gated.
    };

    inline State  g_State         = State::Unknown;
    inline int    g_LastNetMode   = -1;
    inline bool   g_Unlocked      = false;   // false = gated. This is the default.
    inline bool   g_Loaded        = false;
    inline bool   g_ShowCode      = false;   // "I already donated" was clicked
    inline char   g_CodeInput[64] = { 0 };
    inline char   g_LastMessage[192] = { 0 };
    inline bool   g_LastAttemptFailed = false;

    // ---- Persistence -----------------------------------------------------
    // Stored next to the DLL rather than in the game folder, so it survives a
    // game update. A rebuild of the DLL does NOT clear it — that is the point.
    inline const char* UnlockFilePath() {
        static char path[MAX_PATH] = { 0 };
        if (path[0]) return path;
        HMODULE self = nullptr;
        GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)&UnlockFilePath, &self);
        if (self && GetModuleFileNameA(self, path, MAX_PATH)) {
            char* slash = std::strrchr(path, '\\');
            if (slash) { slash[1] = 0; std::strcat(path, "pharoah_gate.dat"); return path; }
        }
        std::strcpy(path, "pharoah_gate.dat");
        return path;
    }

    inline void SaveUnlock() {
        FILE* f = nullptr;
        if (fopen_s(&f, UnlockFilePath(), "wb") == 0 && f) {
            std::fputs("PHAROAH_GATE_UNLOCKED_V1", f);
            std::fclose(f);
        }
    }

    inline void ClearUnlock() {
        DeleteFileA(UnlockFilePath());
    }

    inline void LoadUnlockOnce() {
        if (g_Loaded) return;
        g_Loaded = true;
        FILE* f = nullptr;
        if (fopen_s(&f, UnlockFilePath(), "rb") == 0 && f) {
            char buf[64] = { 0 };
            size_t n = std::fread(buf, 1, sizeof(buf) - 1, f);
            std::fclose(f);
            if (n > 0 && std::strstr(buf, "PHAROAH_GATE_UNLOCKED_V1")) g_Unlocked = true;
        }
    }

    // Called once per frame from the main render path, before anything draws.
    inline void Poll(bool inMatch) {
        LoadUnlockOnce();

        int mode = -1;
        if (!SafeCalls::TryReadNetMode(&mode)) {
            g_State = State::Unknown;
            g_LastNetMode = -1;
            return;
        }
        g_LastNetMode = mode;

        // No pawn means we are not in a playable world yet, whatever the net
        // mode claims. inMatch is the caller's existing pawn-based check.
        if (!inMatch || !Globals::LocalPawn) {
            g_State = State::Menu;
            return;
        }

        switch (mode) {
            case 0:  g_State = State::ShootingRange; break;  // NM_Standalone
            case 2:  g_State = State::ShootingRange; break;  // NM_ListenServer — still our authority
            case 3:  g_State = State::RealMatch;     break;  // NM_Client
            default: g_State = State::Unknown;       break;
        }
    }

    inline const char* StateName() {
        switch (g_State) {
            case State::Menu:          return "MENU";
            case State::ShootingRange: return "SHOOTING RANGE";
            case State::RealMatch:     return "REAL MATCH";
            default:                   return "UNKNOWN";
        }
    }

    inline ImVec4 StateColor() {
        switch (g_State) {
            case State::Menu:          return ImVec4(0.65f, 0.68f, 0.72f, 1.0f);
            case State::ShootingRange: return ImVec4(0.40f, 1.00f, 0.50f, 1.0f);
            case State::RealMatch:     return ImVec4(1.00f, 0.72f, 0.30f, 1.0f);
            default:                   return ImVec4(0.85f, 0.55f, 0.55f, 1.0f);
        }
    }

    // ---- THE ONE QUESTION EVERY GATED FEATURE ASKS -----------------------
    // "Am I allowed to run at full strength right now?"
    // Range and menu: always yes. Real match: only once unlocked.
    inline bool Allowed() {
        if (!kGateEnabled) return true;          // gate disabled — nothing is held back
        if (g_State == State::RealMatch) return g_Unlocked;
        return true;
    }

    // ------------------------------------------------------------------------
    // PER-TAB GATING
    // ------------------------------------------------------------------------
    // The gate used to be all-or-nothing: locked meant Fire Modes and Leave were
    // held back and nothing else was. That was never the intent - some tabs are
    // pure overlay (boxes, reticle, themes) and gating them is pointless, while
    // others genuinely are the payoff.
    //
    // So gating is now per FEATURE GROUP, and the GATING tab shows exactly which
    // groups are covered. Anything not listed is free, always. Keeping the list
    // visible in the UI matters: a charity gate that quietly grows to cover
    // everything is just a paywall with extra steps.
    enum class Gated {
        FireModes,     // fire-mode switching and the confirmed exploits
        Cards,         // the device sweep / card firing
        Skins,         // mesh swapping
        Octavia,       // shield stacking
        Leave,         // leave-match
        COUNT
    };

    inline bool g_GateGroup[(int)Gated::COUNT] = {
        true,    // FireModes - the flagship
        true,    // Cards     - the thing that took longest to crack
        false,   // Skins     - cosmetic, and half-working; not worth gating
        true,    // Octavia   - shield stacking is strong
        false,   // Leave     - never gate the way out of a match
    };

    inline const char* GatedName(Gated g) {
        switch (g) {
            case Gated::FireModes: return "Fire Modes + exploits";
            case Gated::Cards:     return "Cards (device sweep)";
            case Gated::Skins:     return "Skins";
            case Gated::Octavia:   return "OCTAVIA shield stack";
            case Gated::Leave:     return "Leave match";
            default:               return "?";
        }
    }

    // True when the gate is actively holding something back.
    inline bool IsBlocking() {
        if (!kGateEnabled) return false;
        return (g_State == State::RealMatch) && !g_Unlocked;
    }

    // Is THIS group being held back right now?
    inline bool IsBlockingGroup(Gated g) {
        if ((int)g < 0 || (int)g >= (int)Gated::COUNT) return false;
        return IsBlocking() && g_GateGroup[(int)g];
    }

    inline bool AllowedGroup(Gated g) { return !IsBlockingGroup(g); }

    // For repeat-fire features (Octavia shields, heal trigger): how often may
    // this fire right now, in seconds. Locked real matches get the slow rate;
    // everywhere else gets the real one.
    inline float RepeatInterval() {
        return IsBlocking() ? kLockedThrottle : kUnlockedRate;   // full rate while disabled
    }

    inline bool VerifyCode(const char* entered) {
        return entered && std::strcmp(entered, kCode) == 0;
    }

    inline void TryUnlock() {
        if (VerifyCode(g_CodeInput)) {
            g_Unlocked = true;
            g_LastAttemptFailed = false;
            SaveUnlock();
            std::strcpy(g_LastMessage, "Unlocked, and saved. This stays unlocked on future versions.");
            std::memset(g_CodeInput, 0, sizeof(g_CodeInput));
        } else {
            g_LastAttemptFailed = true;
            std::strcpy(g_LastMessage, "That code was not accepted. Check for stray spaces.");
        }
    }

    // OpenUrl() / ShellExecuteA removed entirely - see the note above kCode.

    // ---- Compact status line, drawn in the window header -----------------
    inline void DrawStatusLine() {
        ImGui::TextUnformatted("STATE:");
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Text, StateColor());
        ImGui::TextUnformatted(StateName());
        ImGui::PopStyleColor();

        ImGui::SameLine();
        ImGui::TextUnformatted("   GATE:");
        ImGui::SameLine();
        if (g_Unlocked) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.40f, 1.00f, 0.50f, 1.0f)));
            ImGui::TextUnformatted("UNLOCKED");
        } else if (g_State == State::RealMatch) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.00f, 0.55f, 0.45f, 1.0f)));
            ImGui::TextUnformatted("LOCKED (real match)");
        } else if (!kGateEnabled) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.70f, 0.80f, 0.90f, 1.0f)));
            ImGui::TextUnformatted("DISABLED");
        } else {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.70f, 0.80f, 0.90f, 1.0f)));
            ImGui::TextUnformatted("not required here");
        }
        ImGui::PopStyleColor();

        if (g_LastNetMode >= 0) {
            ImGui::SameLine();
            ImGui::TextDisabled("   (NetMode %d)", g_LastNetMode);
        }
    }

    // A banner for gated tabs to drop at the top of themselves.
    // Group-aware banner. The old all-or-nothing DrawBlockedBanner() below is
    // kept and now simply forwards, so existing callers keep working.
    // Set true when a banner button below is clicked. RecoverySuite.h's
    // central render loop (the only place that actually owns activeSection)
    // checks this once per frame and jumps to the GATING tab, then clears
    // it. A shared flag rather than a bool return because these banners are
    // called from three unrelated files/namespaces (here, LeaveMatch.h,
    // OdinSuite.h), none of which can see RecoverySuite::Section — Gating.h
    // is included before that enum even exists in the translation unit.
    inline bool g_JumpToGatingRequested = false;

    // ROADMAP asked for "a big GATED button that jumps to the GATING tab" —
    // used to be plain coloured text explaining the lock but requiring you
    // to find the tab yourself. Now a real button that does it for you.
    inline void DrawBlockedBannerFor(Gated g) {
        if (!IsBlockingGroup(g)) return;
        char label[160];
        snprintf(label, sizeof(label), "%s is LOCKED in real matches (free in the shooting range) - click to unlock in GATING >>", GatedName(g));
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.85f, 0.35f, 0.10f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.00f, 0.45f, 0.12f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.70f, 0.28f, 0.08f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
        if (ImGui::Button(label, ImVec2(-1, 0))) g_JumpToGatingRequested = true;
        ImGui::PopStyleColor(4);
        ImGui::Separator();
        ImGui::Spacing();
    }

    inline void DrawBlockedBanner() {
        if (!IsBlocking()) return;
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.85f, 0.35f, 0.10f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.00f, 0.45f, 0.12f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.70f, 0.28f, 0.08f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
        if (ImGui::Button("LOCKED IN REAL MATCHES (free in the shooting range) - click to unlock in GATING >>", ImVec2(-1, 0)))
            g_JumpToGatingRequested = true;
        ImGui::PopStyleColor(4);
        ImGui::Separator();
        ImGui::Spacing();
    }

    // ---- The tab ---------------------------------------------------------
    // Kept deliberately SIMPLE per PRIMAL_MONKE: PHAROAH is free, this is just
    // an optional charity ask. NO buttons open a browser and NO addresses are
    // printed anywhere in here - see the note above kCode for why. All the old
    // gate/lock/code machinery below is only shown if the gate is ever
    // switched back on (kGateEnabled) - which it isn't - so a normal user
    // just sees the ask.
    inline void DrawControls(bool /*inMatch*/) {
        LoadUnlockOnce();

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("CHARITY");
        ImGui::PopStyleColor();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::TextWrapped("PHAROAH is free - all of it, everywhere, no code and no payment. "
            "If you'd like to give something back: give to any UN charity, then screenshot it "
            "and send it to me. The goal is to raise $200 for charity with PHAROAH, an "
            "open-source mod. Totally optional - PHAROAH does not open, link to, or point you "
            "at anywhere specific to do this.");
        ImGui::Spacing();
        ImGui::TextDisabled("Thanks for using PHAROAH.");

        // If the charity gate is ever re-enabled, the full donate->code->unlock
        // flow appears here. While it's off (the ship default) this whole block
        // is skipped and the tab stays a clean, simple ask.
        if (kGateEnabled) {
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();
            ImGui::TextUnformatted("Current state:");
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Text, StateColor());
            ImGui::TextUnformatted(StateName());
            ImGui::PopStyleColor();

            if (g_Unlocked) {
                ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.40f, 1.00f, 0.50f, 1.0f)));
                ImGui::TextUnformatted("GATE OPEN  -  FULL TOOL");
                ImGui::PopStyleColor();
                if (ImGui::Button("Re-lock (for testing)", ImVec2(240, 28))) {
                    g_Unlocked = false; g_ShowCode = false; g_LastAttemptFailed = false;
                    ClearUnlock();
                    std::strcpy(g_LastMessage, "Re-locked and the saved unlock was deleted.");
                }
            } else {
                if (!g_ShowCode) {
                    if (ImGui::Button("I already donated", ImVec2(280, 30))) g_ShowCode = true;
                } else {
                    ImGui::TextUnformatted("Your code:");
                    ImGui::SameLine();
                    ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
                    ImGui::TextUnformatted(kCode);
                    ImGui::PopStyleColor();
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Copy")) ImGui::SetClipboardText(kCode);
                }
                ImGui::SetNextItemWidth(300);
                bool submitted = ImGui::InputText("##GateCode", g_CodeInput, sizeof(g_CodeInput),
                                                  ImGuiInputTextFlags_EnterReturnsTrue);
                ImGui::SameLine();
                if (ImGui::Button("Unlock", ImVec2(110, 0)) || submitted) TryUnlock();
            }
            if (g_LastMessage[0]) {
                ImGui::PushStyleColor(ImGuiCol_Text, Ink(g_LastAttemptFailed
                                                         ? ImVec4(1.00f, 0.55f, 0.45f, 1.0f)
                                                         : ImVec4(0.40f, 1.00f, 0.50f, 1.0f)));
                ImGui::TextWrapped("%s", g_LastMessage);
                ImGui::PopStyleColor();
            }
        }
    }
}
