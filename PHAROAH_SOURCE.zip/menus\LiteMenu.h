#pragma once
// ============================================================================
//  PHAROAH LITE  —  minimal standalone build for PaladinsSDK-master's PHAROAH
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
//
// The panel for PHAROAH LITE. Deliberately a SIBLING of CanvasMenu.h, not an
// edit to it - LITE is a genuinely separate build, and touching the file the
// full PHAROAH build already depends on risks breaking something proven, for
// zero benefit.
//
// Same drawing rule as CanvasMenu.h and RenderBoxesViaCanvas: Draw2DLine is
// the ONLY primitive used anywhere in this file - see the big comment at the
// top of CanvasMenu.h for why (DrawTile/DrawText crashed a real match twice).
//
// UI MODEL, v4. Fixes from live testing of v3:
//   - MOUSE CLICKS DID NOTHING. Root cause: ToggleRow/ActionRow only ever
//     drew - neither one ever called HitTestRect or checked clickedEdge.
//     The key-press path worked but was never actually verified by testing
//     before v3 shipped, and the click path was simply never wired at all.
//     Fixed: every row now does its own hit-test and returns whether it was
//     clicked, same shape as the old Checkbox()/Button() widgets.
//   - FONT WAS ILLEGIBLE. Every stroke is now drawn TWICE with a 1px
//     perpendicular offset (a bolded stroke), and the base scale is bigger.
//     Still Draw2DLine only - this is just two line calls instead of one
//     per segment.
//   - CURSOR REMOVED. The magenta crosshair was unwanted - gone entirely.
//   - HIDE/SHOW moved to F3, matching the full build's own F3-hides-menu
//     convention exactly (this one instance of an F-key is intentional -
//     it isn't a random function key, it's memory-compatible with the tool
//     people already know).
//   - CARDS REBUILT per explicit description: ONE key ('1') cycles a
//     spam-count 0->1->2->3->4->5->0..., filling that many boxes left to
//     right (plain colour fill, no digits drawn in the boxes). Clicking a
//     box individually still toggles just that slot, as a bonus - the key
//     is the primary/expected way to use it.
//   - WALLS REBUILT as LITE's own function (DrawWalls, below) instead of
//     calling VisibilityBoxes::RenderBoxesViaCanvas - needed real distance-
//     based colour (red close -> pink mid -> purple far) and a thicker
//     stroke, neither of which the shared function does or should be
//     changed to do (it's shared with the full build's fallback). Reuses
//     the SAME gather cache (g_CachedGather) enemy names already read, so
//     this costs nothing extra to compute.
//   - Enemy name colour changed to white.
//
// v5. Fixes from live testing of v4:
//   - CARDS WERE WIRED TO THE WRONG ARRAY. DirectFire::g_CardSpam[]/kCards
//     is the OLD fixed-equip-point path the file's own comments say does not
//     work on a real card ("Cards are NOT fireable devices... firing them
//     does nothing - there is nothing to fire"). The full build's actual
//     "CARD MAXXING" UI drives DirectFire::g_Five[].spam instead - real
//     devices resolved off the eq-point sweep. v4's card cycle/click code
//     toggled g_CardSpam, which is why cards never did anything. Now targets
//     g_Five[].spam/g_PendingFive[] - the same array the full build's own
//     working card UI uses.
//   - TRIGGER BOT HAD NO VISUAL AND WAS MISSING A REQUIRED CALL. The full
//     build's crosshair (VisibilityBoxes::RenderTargetReticle's draw half)
//     is ImGui-only and can never draw in LITE - LITE never had ANY visual
//     reticle. Fixed with LiteMenu's own DrawReticleDot(), Draw2DLine only,
//     reading the exact same g_ReticleOnEnemy/g_ReticleOnHead/
//     g_ReticleOnPredictionBox globals the full build's dot and the trigger
//     bot both already key off. Also: VisibilityBoxes::UpdateMyChampionSpeed()
//     was never called anywhere in LITE's path (the full build only calls it
//     from its own ImGui Highlights tab and RenderBoxes(), neither of which
//     LITE has) - g_MyTableSpeed sat at its -1 default forever, so a
//     projectile champion's purple predicted-box reticle state could never
//     be reached. Now called once per frame from main_lite.cpp.
//   - FONT WAS "DOUBLE" / GHOSTED. v4's bold trick offset every segment
//     perpendicular to ITS OWN direction, so two segments that share a
//     corner got pushed apart in different directions - the corner visibly
//     split into two, reading as doubled/ghosted text. Fixed: bold is now a
//     single constant-direction copy of the WHOLE glyph (draw at (x,y) and
//     again at (x+1,y+1)) - every segment shifts by the exact same vector,
//     so shared corners stay shared. Uniformly bolder, no ghosting.
//   - ENEMY NAMES WERE TOO BIG. Own kNameScale now, well under kSmallScale.
//   - KEYS MOVED FROM NUMPAD TO F-KEYS, again, per explicit request ("use
//     normal numbers or F, make it say F"). F3 stays hide/show (unchanged -
//     matches the full build). F4 stays avoided (Alt+F4, and collides with
//     the full build's own F4 reset hotkey). F12 is also avoided (Steam's
//     default screenshot bind). Everything else moved to F1/F2/F5-F11 - see
//     the keybind table in PHAROAH_LITE_NOTES.md.
//   - BOXES/NAMES/RETICLE FROZE AFTER LEAVING A MATCH. main_lite.cpp only
//     called GatherAndCache/RenderTargetReticle/UpdateAutoFire inside
//     `if (Globals::initObjects())` - the instant that went false (leaving
//     the match), those three simply stopped being called at all, so
//     g_CachedGather kept its LAST live frame forever and boxes/names hung
//     in place on the post-match screen. All three are now called every
//     frame unconditionally - each already self-gates safely on
//     LocalPawn/LocalController being null (SafeGatherBoxes returns
//     ok=false, RenderTargetReticle returns on !gathered.ok, UpdateAutoFire
//     returns and releases any held trigger on !LocalPawn), so calling them
//     with no pawn is exactly what makes the cache clear itself.
//
// v6. Fixes from live testing of v5:
//   - CARDS STILL SHOWED "LEFT CLICK SPAM" ENTRIES. The eq sweep (0-20)
//     sometimes resolves a card slot straight onto the equipped WEAPON's own
//     device - firing that is functionally identical to mashing left click,
//     not a real card effect. IsRealCardSlot() now excludes any g_Five[]
//     entry whose dev == Globals::LocalWeapon from ever being ready/spammable.
//   - FIRE MODES DIDN'T DETECT ANYTHING. Was reading DirectFire::g_Dev[] -
//     the GObjects device sweep built for CARDS. The full build's own
//     PROVEN fire-mode scanner (FireModeMenu.h's ScanEquipPoints) never
//     used that sweep - it calls GetDeviceByEqPoint(i) for eq 0-20 directly.
//     That's exactly what DirectFire::g_Eq[] already caches. Retargeted to
//     read g_Eq instead of g_Dev - same device-discovery path the full
//     build's working scanner uses.
//   - FONT WAS STILL "DOUBLE" ON BOTH THE MENU AND, WORSE, ENEMY NAMES. v5's
//     "fix" (a second glyph offset by a constant vector) was still visibly
//     two strokes at this scale. There is no second font available
//     (Draw2DLine-only, see file header) so v6 goes back to a SINGLE draw,
//     everywhere, no exceptions - legibility now comes from scale/spacing/
//     contrast, not a synthetic bold.
//   - "CRT LINES" ON THE MENU BACKGROUND. FillRectLines stepped 2px between
//     solid rows, leaving a 1px gap of raw game image between every line -
//     that's what read as scanlines. Now steps 1px, genuinely solid, and the
//     panel itself is a darker, flatter monochrome for real contrast.
//   - CHECKBOXES WERE A THIN CHECKMARK. Per explicit request: the key-badge
//     box is now FULLY FILLED - solid green when ON, solid red when OFF -
//     not an outline with a slim checkmark. Every row's LABEL TEXT also now
//     gets its own accent colour (heal trigger bot green, trigger bot
//     orange-red, etc.) so different features are visually distinct, while
//     the box itself stays strictly green=ON/red=OFF everywhere, always.
//   - NO WAY TO CLOSE OR RESIZE THE MENU. Added an X button (same effect as
//     F3) and "-"/"+" buttons (NudgeUiScale) in the header - see g_UiScale.
//   - ALLIES HAD NO VISUAL AT ALL. DrawWalls now also draws a flat blue box
//     on BoxKind::Ally entries alongside the existing enemy boxes (F1 WALLS
//     is the one toggle for both).
//   - HEALTH BARS DREW REGARDLESS OF VISIBILITY (both here and in the full
//     build). Added DrawHealthBarIfHidden(), gated on the SAME
//     wallCheckEnabled/e.isVisible signal the wall-check trigger-bot gate
//     already used - a bar only appears for someone actually hidden behind
//     a wall; when you can see them normally, the game's own HUD/model is
//     enough. VisibilityBoxes.h's RenderBoxes() (the full build's own health
//     bars) got the identical gate added, so both builds agree.
//   - NO ULT-READY INDICATOR. Copied the full build's own ult icon (a small
//     circle next to the name, slowly cycling the colour wheel while
//     e.ultReady is true) - same ImGui::ColorConvertHSVtoRGB call, just
//     filled via FillCircle's Draw2DLine scanlines instead of an ImGui
//     draw-list, since LITE has no ImGui context.
//   - Trigger bot correctly refusing to fire through a wall (wallCheckEnabled
//     gating VisibilityBoxes::RenderTargetReticle's detection) was CONFIRMED
//     WORKING AS INTENDED by live testing - not a bug, no change needed.
//
// KEYS: F1/F2/F5-F11 for the toggle rows (see PollToggleKeys/DrawHud), F3
// for HUD show/hide (or the header's X button), '1' for the card cycle,
// '6'-'9' for fire modes, header "-"/"+" to resize the panel.
//
// WHAT THIS FILE DOES NOT DO: install a D3D11/kiero hook, create an ImGui
// context, or call into any of PHAROAH's periodic background subsystems
// (HealthBarColor, MeshSkin, DevSkin, skin scanning, the bone/skeleton
// system, RunSafeThreadSubsystems as a whole, Speeden::Update as a whole).
//
// *** EVERY NEW FUNCTION ADDED HERE MUST BE CHECKED FOR ImGui::GetIO() /
// ImGui::GetTime() / ImGui::GetBackgroundDrawList() BEFORE IT SHIPS. ***
// LITE has no ImGui context, ever. Those calls assert/crash with none, and
// it is NOT an SEH exception - __try/__except does not catch it. Grep any
// shared function you're about to call for "ImGui::Get" before wiring it
// in, every single time - this has already shipped broken twice.

#include "globals.h"
#include "ext/kiero/kiero.h"
#include "menus/VisibilityBoxes.h"
#include "menus/DirectFire.h"
#include "menus/RecoverySuite.h"
#include "menus/FireModeMenu.h"
#include "menus/Unlocker.h"
#include "menus/Speeden.h"
#include "Utils/SafeCalls.h"
#include <Windows.h>
#include <cctype>
#include <cmath>

namespace LiteMenu {

    // ---------------------------------------------------------------------
    // INPUT - polled directly against the real game window, independent of
    // any render hook. Works while the game is paused/in a menu, same as
    // any other foreground-independent GetAsyncKeyState/GetCursorPos call.
    // ---------------------------------------------------------------------
    struct InputState {
        float mouseX = 0.0f, mouseY = 0.0f;
        bool mouseDown = false;
        bool clickedEdge = false;
    };
    inline InputState g_Input;

    inline void PollInput() {
        static bool wasDown = false;
        HWND wnd = (HWND)kiero::findRealGameWindow();
        if (!wnd) { g_Input = InputState(); wasDown = false; return; }
        POINT p{};
        GetCursorPos(&p);
        ScreenToClient(wnd, &p);
        g_Input.mouseX = (float)p.x;
        g_Input.mouseY = (float)p.y;
        bool down = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        g_Input.mouseDown = down;
        g_Input.clickedEdge = down && !wasDown;
        wasDown = down;
    }
    inline bool HitTestRect(float x, float y, float w, float h) {
        return g_Input.mouseX >= x && g_Input.mouseX <= x + w &&
               g_Input.mouseY >= y && g_Input.mouseY <= y + h;
    }

    // ---------------------------------------------------------------------
    // DRAWING PRIMITIVES - Draw2DLine only.
    // ---------------------------------------------------------------------
    inline void Line(SDK::UCanvas* canvas, float x0, float y0, float x1, float y1,
                      unsigned char r, unsigned char g, unsigned char b, unsigned char a = 255) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = a;
        canvas->Draw2DLine(x0, y0, x1, y1, c);
    }

    inline void Outline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                         unsigned char r, unsigned char g, unsigned char b) {
        Line(canvas, x,     y,     x + w, y,     r, g, b);
        Line(canvas, x + w, y,     x + w, y + h, r, g, b);
        Line(canvas, x + w, y + h, x,     y + h, r, g, b);
        Line(canvas, x,     y + h, x,     y,     r, g, b);
    }

    // Nested outlines growing outward - the only way to get a "thick" border
    // out of a primitive with no width parameter.
    inline void ThickOutline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                              unsigned char r, unsigned char g, unsigned char b, int thickness) {
        for (int o = 0; o < thickness; o++) {
            Outline(canvas, x - o, y - o, w + o * 2.0f, h + o * 2.0f, r, g, b);
        }
    }

    // v6: row step was 2.0f, leaving a visible 1px gap of raw game image
    // between every filled row - that gap is exactly what read as "CRT scan
    // lines" on the menu background. Every row now, for a genuinely solid fill.
    inline void FillRectLines(SDK::UCanvas* canvas, float x, float y, float w, float h,
                               unsigned char r, unsigned char g, unsigned char b) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = 255;
        for (float row = y; row < y + h; row += 1.0f) {
            canvas->Draw2DLine(x, row, x + w, row, c);
        }
    }

    // Scanline-filled circle (same solid-fill technique as FillRectLines,
    // just circular chords instead of a rectangle) - for the ult-ready icon.
    inline void FillCircle(SDK::UCanvas* canvas, float cx, float cy, float radius,
                            unsigned char r, unsigned char g, unsigned char b) {
        if (!canvas || radius <= 0.0f) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = 255;
        for (float dy = -radius; dy <= radius; dy += 1.0f) {
            float halfW = sqrtf(radius * radius - dy * dy);
            if (halfW <= 0.0f) continue;
            canvas->Draw2DLine(cx - halfW, cy + dy, cx + halfW, cy + dy, c);
        }
    }

    namespace Font {
        struct Seg { float x0, y0, x1, y1; };
        inline int Glyph(char ch, Seg* out) {
            switch (ch) {
            case 'A': out[0]={0,4,0,1}; out[1]={0,1,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,4}; out[4]={0,2,2,2}; return 5;
            case 'B': out[0]={0,0,0,4}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={2,2,2,4}; out[5]={2,4,0,4}; return 6;
            case 'C': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; return 3;
            case 'D': out[0]={0,0,0,4}; out[1]={0,0,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,3}; out[4]={2,3,1,4}; out[5]={1,4,0,4}; return 6;
            case 'E': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={0,2,2,2}; return 4;
            case 'F': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,2,2,2}; return 3;
            case 'G': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,1,2}; return 5;
            case 'H': out[0]={0,0,0,4}; out[1]={2,0,2,4}; out[2]={0,2,2,2}; return 3;
            case 'I': out[0]={0,0,2,0}; out[1]={1,0,1,4}; out[2]={0,4,2,4}; return 3;
            case 'J': out[0]={2,0,2,3}; out[1]={2,3,1,4}; out[2]={1,4,0,3}; return 3;
            case 'K': out[0]={0,0,0,4}; out[1]={2,0,0,2}; out[2]={0,2,2,4}; return 3;
            case 'L': out[0]={0,0,0,4}; out[1]={0,4,2,4}; return 2;
            case 'M': out[0]={0,4,0,0}; out[1]={0,0,1,2}; out[2]={1,2,2,0}; out[3]={2,0,2,4}; return 4;
            case 'N': out[0]={0,4,0,0}; out[1]={0,0,2,4}; out[2]={2,4,2,0}; return 3;
            case 'O': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case 'P': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; return 4;
            case 'Q': out[0]={0,0,2,0}; out[1]={2,0,2,3}; out[2]={2,3,0,3}; out[3]={0,3,0,0}; out[4]={1,3,2,4}; return 5;
            case 'R': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={0,2,2,4}; return 5;
            case 'S': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case 'T': out[0]={0,0,2,0}; out[1]={1,0,1,4}; return 2;
            case 'U': out[0]={0,0,0,4}; out[1]={0,4,2,4}; out[2]={2,4,2,0}; return 3;
            case 'V': out[0]={0,0,1,4}; out[1]={2,0,1,4}; return 2;
            case 'W': out[0]={0,0,0,4}; out[1]={0,4,1,2}; out[2]={1,2,2,4}; out[3]={2,4,2,0}; return 4;
            case 'X': out[0]={0,0,2,4}; out[1]={2,0,0,4}; return 2;
            case 'Y': out[0]={0,0,1,2}; out[1]={2,0,1,2}; out[2]={1,2,1,4}; return 3;
            case 'Z': out[0]={0,0,2,0}; out[1]={2,0,0,4}; out[2]={0,4,2,4}; return 3;
            case '0': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case '1': out[0]={1,0,1,4}; return 1;
            case '2': out[0]={0,0,2,0}; out[1]={2,0,2,2}; out[2]={2,2,0,2}; out[3]={0,2,0,4}; out[4]={0,4,2,4}; return 5;
            case '3': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,2,2,2}; return 4;
            case '4': out[0]={0,0,0,2}; out[1]={0,2,2,2}; out[2]={2,0,2,4}; return 3;
            case '5': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case '6': out[0]={1,0,0,1}; out[1]={0,1,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,0,2}; return 5;
            case '7': out[0]={0,0,2,0}; out[1]={2,0,1,4}; return 2;
            case '8': out[0]={0,0,2,0}; out[1]={0,0,0,4}; out[2]={2,0,2,4}; out[3]={0,4,2,4}; out[4]={0,2,2,2}; return 5;
            case '9': out[0]={0,0,2,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,0,2,4}; return 4;
            case '-': out[0]={0,2,2,2}; return 1;
            case '/': out[0]={0,4,2,0}; return 1;
            case '?': out[0]={0,1,1,0}; out[1]={1,0,2,1}; out[2]={2,1,1,2}; out[3]={1,3,1,3}; return 4;
            default: return 0;
            }
        }
    }

    // v6: back to a SINGLE draw, no bold duplicate at all. v5's "fix" (a
    // second glyph offset by a constant vector) was still visibly two
    // separate strokes at this font's scale/weight - reported as "double
    // text" on both the menu and, worse, doubled enemy names. There is no
    // real second font available to swap to (Draw2DLine-only, see the file
    // header), so legibility now comes entirely from scale/spacing/contrast,
    // not a synthetic bold. One name over one enemy, one line of text in the
    // menu - what you write is what draws.
    inline void DrawGlyphAt(SDK::UCanvas* canvas, char ch, float x, float y, float scale,
                             unsigned char r, unsigned char g, unsigned char b) {
        Font::Seg segs[8];
        int n = Font::Glyph((char)toupper((unsigned char)ch), segs);
        for (int i = 0; i < n; i++) {
            Line(canvas, x + segs[i].x0 * scale, y + segs[i].y0 * scale,
                         x + segs[i].x1 * scale, y + segs[i].y1 * scale, r, g, b);
        }
    }
    inline void DrawChar(SDK::UCanvas* canvas, char ch, float x, float y, float scale,
                          unsigned char r, unsigned char g, unsigned char b) {
        DrawGlyphAt(canvas, ch, x, y, scale, r, g, b);
    }

    inline float DrawString(SDK::UCanvas* canvas, float x, float y, const char* text, float scale,
                             unsigned char r, unsigned char g, unsigned char b) {
        float cursor = x;
        for (const char* p = text; *p; p++) {
            DrawChar(canvas, *p, cursor, y, scale, r, g, b);
            cursor += 4.6f * scale;
        }
        return cursor - x;
    }
    inline float StringWidth(const char* text, float scale) {
        float n = 0; for (const char* p = text; *p; p++) n += 1.0f;
        return n * 4.6f * scale;
    }

    const float kFontScale = 4.2f;
    const float kSmallScale = 3.2f; // the smallest anything is ever drawn at now
    // Enemy names were reported 2.5x too big at kSmallScale - own, smaller
    // scale just for the name text drawn over enemies' heads. NOT affected by
    // g_UiScale below - that's the top-left MENU panel's own size, enemy
    // overlays are a separate, world-space concern the resize buttons don't
    // touch.
    const float kNameScale = kSmallScale / 2.5f;

    // ---------------------------------------------------------------------
    // MENU SIZE - the "-"/"+" buttons in the header scale the whole top-left
    // panel (fonts, box sizes, row spacing) by this factor. Only the panel -
    // world-space drawing (walls, names, the reticle dot) is untouched.
    // ---------------------------------------------------------------------
    inline float g_UiScale = 1.0f;
    inline void NudgeUiScale(float delta) {
        g_UiScale += delta;
        if (g_UiScale < 0.7f) g_UiScale = 0.7f;
        if (g_UiScale > 1.6f) g_UiScale = 1.6f;
    }

    // "[KEY] LABEL ............. ON/OFF" - key badge, label, state, all in
    // one fixed-format row. BOTH the key AND clicking the row toggle it.
    //
    // v6: the key badge box is now FULLY FILLED green (ON) or red (OFF) -
    // "the entire box is fully green [or] full red", not a thin checkmark on
    // an outline, per explicit request: state must be readable at a glance,
    // not squinted at. labelR/G/B lets every row get its own category colour
    // (heal trigger bot green, trigger bot red-orange, etc.) instead of one
    // flat white for every line. Every metric scales with g_UiScale.
    // Returns true the frame it was clicked.
    inline bool ToggleRow(SDK::UCanvas* canvas, float x, float y, float w, const char* keyLabel,
                           const char* label, bool value,
                           unsigned char labelR, unsigned char labelG, unsigned char labelB) {
        const float rowH = 26.0f * g_UiScale, boxSz = 22.0f * g_UiScale;
        const float fs = kSmallScale * g_UiScale;
        bool hovered = HitTestRect(x, y, w, rowH);
        bool clicked = hovered && g_Input.clickedEdge;

        // Full state fill: solid green ON, solid red OFF - unambiguous even
        // at a glance, no squinting at a slim checkmark.
        if (value) FillRectLines(canvas, x, y, boxSz, boxSz, 30, 180, 70);
        else       FillRectLines(canvas, x, y, boxSz, boxSz, 170, 35, 45);
        Outline(canvas, x, y, boxSz, boxSz, 235, 235, 240);
        DrawString(canvas, x + 3 * g_UiScale, y + 3 * g_UiScale, keyLabel, fs * 0.6f, 15, 15, 18);
        DrawString(canvas, x + 32 * g_UiScale, y + 3 * g_UiScale, label, fs, labelR, labelG, labelB);
        const char* state = value ? "ON" : "OFF";
        float sw = StringWidth(state, fs);
        DrawString(canvas, x + w - sw, y + 3 * g_UiScale, state, fs,
                   value ? 90 : 230, value ? 230 : 90, value ? 120 : 95);
        if (hovered) ThickOutline(canvas, x - 2, y - 2, w + 4, rowH, 90, 160, 230, 1);
        return clicked;
    }

    // Same shape, no ON/OFF - for one-shot actions (LEAVE MATCH).
    inline bool ActionRow(SDK::UCanvas* canvas, float x, float y, float w, const char* keyLabel,
                           const char* label, unsigned char labelR, unsigned char labelG, unsigned char labelB) {
        const float rowH = 26.0f * g_UiScale, boxSz = 22.0f * g_UiScale;
        const float fs = kSmallScale * g_UiScale;
        bool hovered = HitTestRect(x, y, w, rowH);
        bool clicked = hovered && g_Input.clickedEdge;
        FillRectLines(canvas, x, y, boxSz, boxSz, 150, 90, 40);
        Outline(canvas, x, y, boxSz, boxSz, 235, 235, 240);
        DrawString(canvas, x + 3 * g_UiScale, y + 3 * g_UiScale, keyLabel, fs * 0.6f, 15, 15, 18);
        DrawString(canvas, x + 32 * g_UiScale, y + 3 * g_UiScale, label, fs, labelR, labelG, labelB);
        if (hovered) ThickOutline(canvas, x - 2, y - 2, w + 4, rowH, 230, 120, 100, 1);
        return clicked;
    }

    // A small square icon button - "-"/"+"/"X" in the header. Same full-fill
    // language as the toggle rows, neutral grey since it has no on/off state.
    inline bool IconButton(SDK::UCanvas* canvas, float x, float y, float sz, const char* glyph) {
        bool hovered = HitTestRect(x, y, sz, sz);
        bool clicked = hovered && g_Input.clickedEdge;
        FillRectLines(canvas, x, y, sz, sz, hovered ? 70 : 45, hovered ? 74 : 48, hovered ? 82 : 54);
        Outline(canvas, x, y, sz, sz, 200, 200, 210);
        float gw = StringWidth(glyph, kSmallScale * g_UiScale * 0.6f);
        float gh = sz * 0.5f;
        DrawString(canvas, x + (sz - gw) * 0.5f, y + (sz - gh) * 0.5f, glyph,
                   kSmallScale * g_UiScale * 0.6f, 230, 230, 235);
        return clicked;
    }

    // ========================================================================
    // CARDS, v5 - RETARGETED TO THE WORKING ARRAY.
    //
    // v4 drove DirectFire::g_CardSpam[]/g_PendingCard[], which fires through
    // the fixed-equip-point kCards table (5/19/20/21/22). DirectFire.h's own
    // extensive comments say that table does not work on a real card - cards
    // are listener objects, not fireable devices, so firing "the card" does
    // nothing. That's why v4's cards never did anything no matter how they
    // were clicked. The full build's actual "CARD MAXXING" UI (the one that
    // works) drives DirectFire::g_Five[].spam / g_PendingFive[] instead -
    // real ATgDevice pointers resolved off the eq-point sweep
    // (DirectFire::ProcessPending's g_PendingEqSweep block), which is what
    // auto-detects the equipped deck and stays correct across a re-sweep.
    // This now targets that array. Detection itself needed no changes - the
    // eq sweep already runs on its own auto-refresh timer
    // (g_EqAutoSweep/g_AutoSweep, both left on by InitThreadLite).
    //
    // Still ONE key ('1') cycling a spam-count 0..5, filling that many boxes
    // left to right. Clicking a box individually still toggles just that
    // slot as a bonus.
    // ========================================================================
    inline int  g_CardSpamCount = 0;
    inline bool g_CardCycleKeyWasDown = false;

    // v6: filter out the weapon's own fire device. The eq sweep (0-20)
    // sometimes resolves a "card" slot straight onto Globals::LocalWeapon
    // itself - firing that via DeviceStartFire/StopFire is functionally
    // indistinguishable from just mashing left click, not a real card
    // effect, and was reported as exactly that ("many of the cards it
    // detects is just left click spam method"). A slot pointing at the
    // equipped weapon is never treated as ready/spammable here.
    inline bool IsRealCardSlot(int i) {
        if (i < 0 || i >= 5) return false;
        SDK::ATgDevice* d = DirectFire::g_Five[i].dev;
        if (!d) return false;
        if (d == Globals::LocalWeapon) return false;
        return true;
    }

    inline void PollCardCycleKey() {
        bool down = (GetAsyncKeyState('1') & 0x8000) != 0;
        if (down && !g_CardCycleKeyWasDown) {
            g_CardSpamCount = (g_CardSpamCount + 1) % 6; // 0,1,2,3,4,5,0,...
            for (int i = 0; i < 5; i++)
                DirectFire::g_Five[i].spam = IsRealCardSlot(i) && (i < g_CardSpamCount);
        }
        g_CardCycleKeyWasDown = down;
    }

    inline void DrawCardRow(SDK::UCanvas* canvas, float x, float y) {
        const float boxSize = 34.0f * g_UiScale, gap = 8.0f * g_UiScale;
        bool anyReady = false;
        for (int i = 0; i < 5; i++) {
            float bx = x + i * (boxSize + gap);
            bool ready = IsRealCardSlot(i);
            if (ready) anyReady = true;
            bool spamming = ready && DirectFire::g_Five[i].spam;

            if (ready && HitTestRect(bx, y, boxSize, boxSize) && g_Input.clickedEdge) {
                DirectFire::g_Five[i].spam = !DirectFire::g_Five[i].spam;
                // Resync the counter to match, so the '1' key picks up from
                // here rather than fighting a manual click on the next press.
                int n = 0; for (int k = 0; k < 5; k++) if (IsRealCardSlot(k) && DirectFire::g_Five[k].spam) n++;
                g_CardSpamCount = n;
            }

            unsigned char r = ready ? 70 : 50, g = ready ? 70 : 50, b = ready ? 75 : 50;
            if (spamming) { r = 30; g = 180; b = 70; }
            FillRectLines(canvas, bx, y, boxSize, boxSize, spamming ? r : r / 4, spamming ? g : g / 4, spamming ? b : b / 4);
            ThickOutline(canvas, bx, y, boxSize, boxSize, r, g, b, spamming ? 2 : 1);

            // What was actually detected in this slot, so it's a real list to
            // pick through rather than five mystery boxes.
            if (ready) {
                DrawString(canvas, bx + 2, y + boxSize + 3, DirectFire::g_Five[i].label,
                           kNameScale * g_UiScale, 190, 190, 200);
            }
        }
        if (!anyReady) {
            DrawString(canvas, x, y + boxSize + 3, "DETECTING YOUR DECK...", kNameScale * g_UiScale, 200, 170, 130);
        }
    }

    // ========================================================================
    // FIRE MODES, v6 - RETARGETED, same class of bug as cards.
    //
    // Was reading DirectFire::g_Dev[] - the raw GObjects device sweep built
    // for CARDS specifically (kMaxDevRows=96, walks every ATgDevice in
    // memory filtering owner==pawn). The full build's own PROVEN fire-mode
    // scanner (FireModeMenu.h's ScanEquipPoints) never uses that sweep at
    // all - it calls pawn->GetDeviceByEqPoint(i) directly for eq 0-20. That
    // is exactly what DirectFire::g_Eq[] already caches (populated by
    // SafeCalls::GetDeviceByEqPointPawn(eq) in DirectFire::ProcessPending's
    // g_PendingEqSweep block - the very same call, just safe-thread-cached
    // with its own auto-refresh timer instead of a render-thread button
    // press). Reading g_Eq instead of g_Dev means fire-mode detection now
    // uses the SAME device-discovery path the full build's working scanner
    // does, not a different one built for a different purpose.
    // ========================================================================
    struct FireModeSlot {
        SDK::ATgDevice* dev = nullptr;
        int modeCount = 0;
        int key = 0;
        char label[32] = {};
    };
    static const int kMaxFireModeSlots = 4;
    inline FireModeSlot g_FireModeSlots[kMaxFireModeSlots];
    inline int  g_FireModeSlotCount = 0;
    inline bool g_FireModeKeyWasDown[kMaxFireModeSlots] = {};

    inline void RebuildFireModeSlots() {
        g_FireModeSlotCount = 0;
        for (int i = 0; i < DirectFire::g_EqCount && g_FireModeSlotCount < kMaxFireModeSlots; i++) {
            const DirectFire::EqRow& row = DirectFire::g_Eq[i];
            if (!row.dev) continue;
            int count = 0;
            __try { count = (int)row.dev->m_FireMode.Num(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
            if (count <= 1) continue;

            FireModeSlot& slot = g_FireModeSlots[g_FireModeSlotCount];
            slot.dev = row.dev;
            slot.modeCount = count;
            slot.key = '6' + g_FireModeSlotCount;
            lstrcpynA(slot.label, DeviceNames::NameOf(row.deviceId), sizeof(slot.label));
            g_FireModeSlotCount++;
        }
    }

    // g_Eq self-refreshes on pawn change and on its own auto-sweep timer
    // (DirectFire::ProcessPending, g_EqAutoSweep - already on by default) -
    // nothing to trigger here, just re-filter the always-current list every
    // frame. Kept as its own function/name for DrawHud's call site to stay
    // unchanged.
    inline void TickFireModesSafe() {
        RebuildFireModeSlots();
    }

    inline void PollFireModeKeys() {
        for (int i = 0; i < g_FireModeSlotCount; i++) {
            bool down = (GetAsyncKeyState(g_FireModeSlots[i].key) & 0x8000) != 0;
            if (down && !g_FireModeKeyWasDown[i]) {
                SDK::ATgDevice* d = g_FireModeSlots[i].dev;
                if (d) {
                    int cur = 0;
                    __try { cur = (int)d->CurrentFireMode; } __except (EXCEPTION_EXECUTE_HANDLER) { cur = 0; }
                    int next = (cur + 1) % g_FireModeSlots[i].modeCount;
                    ApplyFireModeRaw(d, next);
                }
            }
            g_FireModeKeyWasDown[i] = down;
        }
    }

    inline void DrawFireModes(SDK::UCanvas* canvas, float x, float y) {
        const float fs = kSmallScale * g_UiScale, boxSz = 22.0f * g_UiScale;
        if (g_FireModeSlotCount == 0) {
            DrawString(canvas, x, y, "SCANNING FOR ABILITIES...", fs, 200, 170, 130);
            return;
        }
        float cy = y;
        for (int i = 0; i < g_FireModeSlotCount; i++) {
            const FireModeSlot& slot = g_FireModeSlots[i];
            Outline(canvas, x, cy, boxSz, boxSz, 210, 210, 215);
            char keyCh[2] = { (char)slot.key, 0 };
            DrawString(canvas, x + 5 * g_UiScale, cy + 3 * g_UiScale, keyCh, fs, 255, 210, 110);
            DrawString(canvas, x + 30 * g_UiScale, cy + 3 * g_UiScale, slot.label, fs * 0.85f, 225, 225, 230);
            cy += 26.0f * g_UiScale;

            int cur = 0;
            __try { cur = slot.dev ? (int)slot.dev->CurrentFireMode : 0; } __except (EXCEPTION_EXECUTE_HANDLER) { cur = 0; }
            for (int m = 0; m < slot.modeCount && m < 8; m++) {
                float px = x + m * 28.0f * g_UiScale;
                bool active = (m == cur);
                if (HitTestRect(px, cy, boxSz, boxSz) && g_Input.clickedEdge) ApplyFireModeRaw(slot.dev, m);
                if (active) FillRectLines(canvas, px, cy, boxSz, boxSz, 20, 60, 25);
                ThickOutline(canvas, px, cy, boxSz, boxSz, active ? 90 : 170, active ? 230 : 170, active ? 120 : 175, active ? 2 : 1);
            }
            cy += 28.0f * g_UiScale;
        }
    }

    // ========================================================================
    // WALLS - LITE's OWN drawing (not VisibilityBoxes::RenderBoxesViaCanvas -
    // that function is shared with the full build's fallback and deliberately
    // untouched; this needed real distance colour + thickness neither has).
    // Reuses g_CachedGather (already populated every frame for the trigger
    // bot / enemy names) instead of doing its own separate pawn walk.
    // Colour: red up close, through pink, to purple far away. Distances are
    // in Unreal units (~52.5 per metre, same conversion VisibilityBoxes.h
    // uses elsewhere) - tune kCloseUnits/kFarUnits if the bands feel off in
    // practice.
    // ========================================================================
    inline void DistanceColor(float dist, unsigned char& r, unsigned char& g, unsigned char& b) {
        const float kCloseUnits = 800.0f;   // ~15m - full red at or inside this
        const float kMidUnits   = 2200.0f;  // ~42m - pink
        const float kFarUnits   = 4500.0f;  // ~86m and beyond - full purple
        if (dist <= kMidUnits) {
            float t = (dist - kCloseUnits) / (kMidUnits - kCloseUnits);
            if (t < 0.0f) t = 0.0f; if (t > 1.0f) t = 1.0f;
            r = 255;
            g = (unsigned char)(40.0f  + (80.0f  - 40.0f)  * t);
            b = (unsigned char)(40.0f  + (180.0f - 40.0f)  * t);
        } else {
            float t = (dist - kMidUnits) / (kFarUnits - kMidUnits);
            if (t < 0.0f) t = 0.0f; if (t > 1.0f) t = 1.0f;
            r = (unsigned char)(255.0f + (150.0f - 255.0f) * t);
            g = (unsigned char)(80.0f  + (60.0f  - 80.0f)  * t);
            b = (unsigned char)(180.0f + (220.0f - 180.0f) * t);
        }
    }

    // v6: draws an ALLY box too (blue, flat colour - no distance gradient,
    // per "draw blue squares on allies like you do enemies") alongside the
    // existing enemy box. Also draws a health bar above EITHER kind, but
    // ONLY when they're actually hidden behind a wall - see
    // DrawHealthBarIfHidden below. Mirrors the identical
    // wallCheckEnabled/e.isVisible gate just added to the full build's own
    // RenderBoxes() health bars in VisibilityBoxes.h, so both builds agree:
    // a bar you can see the person normally is redundant with the game's
    // own HUD/model and clutter; a bar for someone behind a wall is the one
    // case the native UI can't help with.
    inline void DrawHealthBarIfHidden(SDK::UCanvas* canvas, const VisibilityBoxes::BoxEntry& e,
                                       float left, float topY, float boxWidth) {
        if (e.healthPct < 0.0f) return;
        if (!(VisibilityBoxes::wallCheckEnabled && !e.isVisible)) return;

        float barW = boxWidth;
        float barH = boxWidth * 0.16f;
        if (barH < 3.0f) barH = 3.0f;
        if (barH > 6.0f) barH = 6.0f;
        float barY = topY - barH - 3.0f;

        FillRectLines(canvas, left, barY, barW, barH, 25, 25, 28);
        float lowFactor = 1.0f - e.healthPct;
        unsigned char r, g, b;
        if (e.kind == VisibilityBoxes::BoxKind::Ally) {
            // healthy green -> urgent red as an ally drops, same direction as
            // the full build's ally bar.
            r = (unsigned char)(50.0f  + (230.0f - 50.0f)  * lowFactor);
            g = (unsigned char)(210.0f - (210.0f - 60.0f)  * lowFactor);
            b = (unsigned char)(90.0f  - (90.0f  - 55.0f)  * lowFactor);
        } else {
            // enemies: calm red (full) -> hot pink (low) - matches the full
            // build's "the more vivid, the more it reads as go hunt them now."
            r = (unsigned char)(190.0f + (215.0f - 190.0f) * lowFactor);
            g = (unsigned char)(30.0f  + (25.0f  - 30.0f)  * lowFactor);
            b = (unsigned char)(60.0f  + (120.0f - 60.0f)  * lowFactor);
        }
        float fillW = barW * e.healthPct;
        FillRectLines(canvas, left, barY, fillW, barH, r, g, b);
        Outline(canvas, left, barY, barW, barH, 15, 15, 17);
    }

    inline void DrawWalls(SDK::UCanvas* canvas) {
        if (!canvas || !VisibilityBoxes::enabled) return;
        const VisibilityBoxes::GatherResult& g = VisibilityBoxes::g_CachedGather;
        if (!g.ok) return;

        VisibilityBoxes::PlainVec fwd, right, up;
        VisibilityBoxes::RotatorToVectors(g.camPitch, g.camYaw, fwd, right, up);
        ImVec2 screenSize = { (float)canvas->SizeX, (float)canvas->SizeY };

        for (int i = 0; i < g.count; i++) {
            const VisibilityBoxes::BoxEntry& e = g.entries[i];
            bool isEnemy = e.kind == VisibilityBoxes::BoxKind::Enemy;
            bool isAlly  = e.kind == VisibilityBoxes::BoxKind::Ally;
            if (!isEnemy && !isAlly) continue;

            VisibilityBoxes::PlainVec top{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight };
            VisibilityBoxes::PlainVec bot{ e.worldPos.x, e.worldPos.y, e.worldPos.z - e.collisionHeight };
            ImVec2 screenTop, screenBot;
            if (!VisibilityBoxes::WorldToScreen(top, g.camLoc, fwd, right, up, g.fov, screenSize.x, screenSize.y, screenTop)) continue;
            if (!VisibilityBoxes::WorldToScreen(bot, g.camLoc, fwd, right, up, g.fov, screenSize.x, screenSize.y, screenBot)) continue;

            float boxHeight = screenBot.y - screenTop.y;
            if (boxHeight < 4.0f || boxHeight > 2000.0f) continue;
            float boxWidth = (e.collisionHeight > 0.1f) ? boxHeight * (e.collisionRadius / e.collisionHeight) : boxHeight * 0.5f;
            float left = screenTop.x - boxWidth * 0.5f;

            unsigned char r, gg, b;
            if (isEnemy) {
                float dx = e.worldPos.x - g.camLoc.x, dy = e.worldPos.y - g.camLoc.y, dz = e.worldPos.z - g.camLoc.z;
                float dist = sqrtf(dx * dx + dy * dy + dz * dz);
                DistanceColor(dist, r, gg, b);
            } else {
                r = 60; gg = 160; b = 255; // flat blue - allies, no distance gradient
            }

            ThickOutline(canvas, left, screenTop.y, boxWidth, boxHeight, r, gg, b, 2);
            DrawHealthBarIfHidden(canvas, e, left, screenTop.y, boxWidth);
        }
    }

    // ========================================================================
    // ENEMY NAMES - white per explicit request, drawn at kNameScale (reported
    // 2.5x too big at kSmallScale), single draw only (v6 - see DrawChar).
    // Ult-ready icon: a small filled circle next to the name, cycling
    // through the colour wheel, copied from the full build's own ult icon
    // (VisibilityBoxes.h's RenderBoxes - AddCircleFilled + ColorConvertHSVtoRGB
    // on a slow-incrementing hue) - only the fill technique differs
    // (FillCircle's Draw2DLine scanlines instead of ImGui's AddCircleFilled).
    // ========================================================================
    inline bool g_ShowNames = true;

    inline void DrawEnemyNames(SDK::UCanvas* canvas) {
        if (!canvas || !g_ShowNames) return;
        const VisibilityBoxes::GatherResult& g = VisibilityBoxes::g_CachedGather;
        if (!g.ok) return;

        VisibilityBoxes::PlainVec fwd, right, up;
        VisibilityBoxes::RotatorToVectors(g.camPitch, g.camYaw, fwd, right, up);
        ImVec2 screenSize = { (float)canvas->SizeX, (float)canvas->SizeY };

        static float s_UltHue = 0.0f;
        s_UltHue += 0.0008f; // same slow rate as the full build's icon
        if (s_UltHue > 1.0f) s_UltHue -= 1.0f;

        for (int i = 0; i < g.count; i++) {
            const VisibilityBoxes::BoxEntry& e = g.entries[i];
            if (e.kind != VisibilityBoxes::BoxKind::Enemy) continue;
            if (!e.championName[0]) continue;

            VisibilityBoxes::PlainVec top{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight + 16.0f };
            ImVec2 screen;
            if (!VisibilityBoxes::WorldToScreen(top, g.camLoc, fwd, right, up, g.fov, screenSize.x, screenSize.y, screen))
                continue;

            float w = StringWidth(e.championName, kNameScale);
            DrawString(canvas, screen.x - w / 2.0f, screen.y, e.championName, kNameScale, 255, 255, 255);

            if (e.ultReady) {
                float dotR = kNameScale * 2.2f;
                float hr, hgf, hb;
                ImGui::ColorConvertHSVtoRGB(s_UltHue, 0.85f, 1.0f, hr, hgf, hb);
                FillCircle(canvas, screen.x + w / 2.0f + dotR + 4.0f, screen.y + kNameScale * 2.0f, dotR,
                           (unsigned char)(hr * 255.0f), (unsigned char)(hgf * 255.0f), (unsigned char)(hb * 255.0f));
            }
        }
    }

    // ========================================================================
    // TARGET RETICLE DOT, v5 - LITE never had ANY visual reticle before this.
    // The full build's own crosshair (VisibilityBoxes::RenderTargetReticle's
    // draw half) is ImGui-only (GetBackgroundDrawList) and can never run in
    // LITE - it self-guards and returns with no context, by design (see the
    // comment on VisibilityBoxes::g_FallbackScreenW). But the DETECTION half
    // of that same function runs unconditionally and already sets
    // g_ReticleOnEnemy/g_ReticleOnHead/g_ReticleOnPredictionBox every frame -
    // this just draws LITE's own small crosshair off those same globals,
    // Draw2DLine only. Colour priority matches the full build's own dot
    // exactly: purple (prediction box) > yellow (head) > red (body) > grey
    // (nothing). Always drawn - it's a display-only aim reference; whether it
    // actually FIRES is the separate TRIGGER BOT toggle (off by default).
    // ========================================================================
    inline void DrawReticleDot(SDK::UCanvas* canvas) {
        if (!canvas) return;
        float ccx = (float)canvas->SizeX * 0.5f;
        float ccy = (float)canvas->SizeY * 0.5f;

        unsigned char r = 210, g = 210, b = 215;
        if (VisibilityBoxes::g_ReticleOnPredictionBox)   { r = 180; g = 80;  b = 255; }
        else if (VisibilityBoxes::g_ReticleOnHead)       { r = 255; g = 220; b = 40;  }
        else if (VisibilityBoxes::g_ReticleOnEnemy)      { r = 255; g = 60;  b = 60;  }

        const float gap = 5.0f, len = 6.0f;
        Line(canvas, ccx - gap - len, ccy, ccx - gap, ccy, r, g, b);
        Line(canvas, ccx + gap, ccy, ccx + gap + len, ccy, r, g, b);
        Line(canvas, ccx, ccy - gap - len, ccx, ccy - gap, r, g, b);
        Line(canvas, ccx, ccy + gap, ccx, ccy + gap + len, r, g, b);
    }

    // ---------------------------------------------------------------------
    // NO-SPREAD / NO-RECOIL - unchanged from before. Six raw struct-field
    // writes (m_AccuracySettings/m_RecoilSettings), zero ImGui, zero
    // scripted calls - see Speeden.h. Combined into one toggle.
    // ---------------------------------------------------------------------
    inline bool g_NoSpreadRecoilEnabled = true;
    inline SDK::ATgDevice* g_SpreadRecoilDevice = nullptr;
    inline bool g_HaveSpreadRecoilBase = false;

    inline void TickNoSpreadRecoil() {
        SDK::ATgDevice* wep = Globals::LocalWeapon;
        if (!wep) { g_HaveSpreadRecoilBase = false; g_SpreadRecoilDevice = nullptr; return; }
        if (wep != g_SpreadRecoilDevice || !g_HaveSpreadRecoilBase) {
            g_SpreadRecoilDevice = wep;
            g_HaveSpreadRecoilBase = Speeden::TryCaptureAccuracy(wep) && Speeden::TryCaptureRecoil(wep);
        }
        if (!g_HaveSpreadRecoilBase) return;
        if (g_NoSpreadRecoilEnabled) {
            Speeden::TryApplyNoSpread(wep);
            Speeden::TryApplyNoRecoil(wep);
        } else {
            Speeden::TryRestoreAccuracy(wep);
            Speeden::TryRestoreRecoil(wep);
        }
    }

    // ---------------------------------------------------------------------
    // RESPAWN - unchanged. LITE's own small tracker, not
    // RecoverySuite::ProcessPendingSafeResets (drags in the subsystem sweep
    // LITE exists to avoid).
    // ---------------------------------------------------------------------
    inline bool g_AutoRespawn = true;
    inline bool g_PendingRespawnNow = false;
    inline ULONGLONG g_LastRespawnTryMs = 0;

    inline void TickRespawnSafe() {
        if (g_PendingRespawnNow) {
            g_PendingRespawnNow = false;
            SafeCalls::ServerSetReadyToPlay();
        }
        if (!g_AutoRespawn || !Globals::LocalPawn) return;
        ULONGLONG now = GetTickCount64();
        if (now - g_LastRespawnTryMs < 500) return;
        g_LastRespawnTryMs = now;
        int cur = 0, mx = 0;
        if (SafeCalls::GetPawnHealth(&cur, &mx) && cur <= 0) {
            SafeCalls::ServerSetReadyToPlay();
        }
    }

    // ---------------------------------------------------------------------
    // UNLOCKER - unchanged. Calls Unlocker::RunPass() directly, NOT
    // Unlocker::Tick() (Tick() calls ImGui::GetTime() unconditionally).
    // ---------------------------------------------------------------------
    inline bool g_UnlockerEnabled = true;
    inline ULONGLONG g_LastUnlockRunMs = 0;

    inline void TickUnlockerSafe() {
        if (!g_UnlockerEnabled) return;
        if (Globals::LocalPawn) return;
        ULONGLONG now = GetTickCount64();
        if (now - g_LastUnlockRunMs < 1000) return;
        g_LastUnlockRunMs = now;
        Unlocker::RunPass(false, false, false);
    }

    // ---------------------------------------------------------------------
    // GRAYSCALE - F10, v5 (was NUMPAD8; keys moved to F-keys, see file header).
    // ---------------------------------------------------------------------
    inline bool g_GrayscaleKeyWasDown = false;
    inline void PollGrayscaleKey() {
        bool down = (GetAsyncKeyState(VK_F10) & 0x8000) != 0;
        if (down && !g_GrayscaleKeyWasDown) {
            RecoverySuite::ApplyGrayscale(!RecoverySuite::grayscaleOn);
        }
        g_GrayscaleKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // LEAVE MATCH - F11, v5 (was NUMPAD9).
    // ---------------------------------------------------------------------
    inline bool g_LeaveKeyWasDown = false;
    inline void PollLeaveMatchKey() {
        bool down = (GetAsyncKeyState(VK_F11) & 0x8000) != 0;
        if (down && !g_LeaveKeyWasDown) {
            SafeCalls::RunConsoleCommand(L"disconnect");
        }
        g_LeaveKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // SHOW/HIDE - moved to F3 per explicit request, matching the full
    // build's own F3-hides-menu convention. The collapsed hint is itself
    // clickable too (not just a key), same click-fix as everything else.
    // ---------------------------------------------------------------------
    inline bool g_HudVisible = true;
    inline bool g_HudKeyWasDown = false;
    inline void PollHudKey() {
        bool down = (GetAsyncKeyState(VK_F3) & 0x8000) != 0;
        if (down && !g_HudKeyWasDown) g_HudVisible = !g_HudVisible;
        g_HudKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // Toggle key polling - F1/F2/F5-F9, v5 (was NUMPAD1-7). F3 is HUD show/
    // hide (above), F4 stays avoided entirely, F10/F11 are grayscale/leave
    // match (above), F12 stays avoided (Steam's default screenshot bind).
    // ---------------------------------------------------------------------
    inline bool g_ToggleKeyWasDown[7] = {};
    inline void PollToggleKeys() {
        const int keys[7] = { VK_F1, VK_F2, VK_F5, VK_F6, VK_F7, VK_F8, VK_F9 };
        for (int i = 0; i < 7; i++) {
            bool down = (GetAsyncKeyState(keys[i]) & 0x8000) != 0;
            if (down && !g_ToggleKeyWasDown[i]) {
                switch (i) {
                    case 0: VisibilityBoxes::enabled = !VisibilityBoxes::enabled; break;
                    case 1: g_ShowNames = !g_ShowNames; break;
                    case 2: RecoverySuite::triggerBotEnabled = !RecoverySuite::triggerBotEnabled; break;
                    case 3: RecoverySuite::autoHealEnabled = !RecoverySuite::autoHealEnabled; break;
                    case 4: g_UnlockerEnabled = !g_UnlockerEnabled; break;
                    case 5: g_AutoRespawn = !g_AutoRespawn; break;
                    case 6: g_NoSpreadRecoilEnabled = !g_NoSpreadRecoilEnabled; break;
                }
            }
            g_ToggleKeyWasDown[i] = down;
        }
    }

    // ---------------------------------------------------------------------
    // THE HUD - always drawn (unless collapsed via F3/the X button, which
    // still leaves a clickable one-line reminder). Every row below both a
    // key AND a click.
    //
    // v6: darker, flatter monochrome background (was a lighter grey the
    // scanline fill made look striped/CRT - see FillRectLines' fix). Each
    // row gets its own accent colour on the LABEL TEXT so different
    // features are visually distinct at a glance, while the little key-box
    // itself stays strictly green=ON/red=OFF, never anything else - state
    // must always read the same way everywhere. X/+/- buttons in the header:
    // X does the same thing as F3, +/- call NudgeUiScale to resize the whole
    // panel.
    // ---------------------------------------------------------------------
    inline void DrawHud(SDK::UCanvas* canvas) {
        if (!canvas) return;
        PollInput();

        if (!g_HudVisible) {
            const float hw = 210.0f, hh = 26.0f;
            FillRectLines(canvas, 16, 16, hw, hh, 10, 10, 12);
            Outline(canvas, 16, 16, hw, hh, 130, 130, 140);
            DrawString(canvas, 22, 20, "[F3] SHOW LITE", kSmallScale, 255, 215, 120);
            if (HitTestRect(16, 16, hw, hh) && g_Input.clickedEdge) g_HudVisible = true;
            return;
        }

        const float scale = g_UiScale;
        const float x = 18.0f, y = 18.0f, w = 260.0f * scale;
        float cy = y + 10.0f * scale;
        const float rowH = 30.0f * scale;

        float unscaledH = 58.0f + 8 * 30.0f + 20.0f + 62.0f + 20.0f +
                           (g_FireModeSlotCount > 0 ? g_FireModeSlotCount * 56.0f + 14.0f : 26.0f);
        float h = unscaledH * scale;
        // Darker, flatter monochrome - "real contrast", not the lighter grey
        // the CRT-line bug used to disguise.
        FillRectLines(canvas, x - 10, y - 10, w + 20, h, 8, 8, 10);
        ThickOutline(canvas, x - 10, y - 10, w + 20, h, 120, 120, 130, 1);

        // Header: title + close/resize buttons, all on the panel's top edge.
        const float btnSz = 18.0f * scale, btnGap = 4.0f * scale;
        float bx = x + w - btnSz;
        if (IconButton(canvas, bx, y, btnSz, "X")) g_HudVisible = false;
        bx -= (btnSz + btnGap);
        if (IconButton(canvas, bx, y, btnSz, "+")) NudgeUiScale(0.1f);
        bx -= (btnSz + btnGap);
        if (IconButton(canvas, bx, y, btnSz, "-")) NudgeUiScale(-0.1f);

        DrawString(canvas, x, cy, "PHAROAH LITE", kFontScale * scale, 255, 215, 120);
        cy += 22.0f * scale;
        DrawString(canvas, x, cy, "PRESS F3 TO HIDE", kNameScale * scale, 170, 170, 180);
        cy += 26.0f * scale;

        if (ToggleRow(canvas, x, cy, w, "F1", "WALLS", VisibilityBoxes::enabled, 120, 205, 225))
            VisibilityBoxes::enabled = !VisibilityBoxes::enabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F2", "ENEMY NAMES", g_ShowNames, 130, 220, 190))
            g_ShowNames = !g_ShowNames;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F5", "TRIGGER BOT", RecoverySuite::triggerBotEnabled, 255, 140, 95))
            RecoverySuite::triggerBotEnabled = !RecoverySuite::triggerBotEnabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F6", "HEAL TRIGGER BOT", RecoverySuite::autoHealEnabled, 110, 230, 120))
            RecoverySuite::autoHealEnabled = !RecoverySuite::autoHealEnabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F7", "UNLOCKER", g_UnlockerEnabled, 195, 150, 250))
            g_UnlockerEnabled = !g_UnlockerEnabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F8", "AUTO-RESPAWN", g_AutoRespawn, 235, 215, 95))
            g_AutoRespawn = !g_AutoRespawn;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F9", "NO SPREAD/RECOIL", g_NoSpreadRecoilEnabled, 255, 175, 95))
            g_NoSpreadRecoilEnabled = !g_NoSpreadRecoilEnabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F10", "GRAYSCALE", RecoverySuite::grayscaleOn, 155, 175, 205))
            RecoverySuite::ApplyGrayscale(!RecoverySuite::grayscaleOn);
        cy += rowH;
        if (ActionRow(canvas, x, cy, w, "F11", "LEAVE MATCH", 240, 115, 140))
            SafeCalls::RunConsoleCommand(L"disconnect");
        cy += rowH;

        cy += 8.0f * scale;
        Line(canvas, x, cy, x + w, cy, 90, 90, 98);
        cy += 12.0f * scale;

        char cardHdr[32];
        wsprintfA(cardHdr, "CARDS - PRESS 1 (%d/5)", g_CardSpamCount);
        DrawString(canvas, x, cy, cardHdr, kSmallScale * scale, 255, 215, 120);
        cy += 20.0f * scale;
        DrawCardRow(canvas, x, cy);
        cy += 62.0f * scale;

        Line(canvas, x, cy, x + w, cy, 90, 90, 98);
        cy += 12.0f * scale;

        DrawString(canvas, x, cy, "FIRE MODES - KEYS 6-9", kSmallScale * scale, 255, 215, 120);
        cy += 20.0f * scale;
        DrawFireModes(canvas, x, cy);
    }

    // ---------------------------------------------------------------------
    // Call once per PostRender tick. LITE never installs a D3D11 hook, so
    // there is no "is the real hook already working" gate to check.
    // ---------------------------------------------------------------------
    inline bool g_LoggedFirstDraw = false;
    inline bool g_LoggedException = false;
    inline void Tick(SDK::UCanvas* canvas) {
        PollToggleKeys();
        PollHudKey();
        PollFireModeKeys();
        PollGrayscaleKey();
        PollLeaveMatchKey();
        PollCardCycleKey();
        __try {
            if (!g_LoggedFirstDraw) {
                g_LoggedFirstDraw = true;
                InitLog("[LiteMenu] HUD first drawn, canvas=%p.", (void*)canvas);
            }
            DrawWalls(canvas);
            DrawEnemyNames(canvas);
            DrawReticleDot(canvas);
            DrawHud(canvas);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            if (!g_LoggedException) {
                g_LoggedException = true;
                InitLog("[LiteMenu] EXCEPTION caught inside Tick() (code 0x%08lX).", GetExceptionCode());
            }
        }
    }
}
