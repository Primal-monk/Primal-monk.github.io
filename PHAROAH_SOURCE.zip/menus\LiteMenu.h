#pragma once
// ============================================================================
//  PHAROAH LITE  —  minimal standalone build for PaladinsSDK-master's PHAROAH
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
//
// The panel for PHAROAH LITE. Deliberately a SIBLING of CanvasMenu.h, not an
// edit to it - LITE is a genuinely separate build, and touching the file the
// full PHAROAH build already depends on risks breaking something proven, for
// zero benefit.
//
// Same drawing rule as CanvasMenu.h and RenderBoxesViaCanvas: Draw2DLine is
// the ONLY primitive used anywhere in this file - see the big comment at the
// top of CanvasMenu.h for why (DrawTile/DrawText crashed a real match twice).
//
// UI MODEL, v4. Fixes from live testing of v3:
//   - MOUSE CLICKS DID NOTHING. Root cause: ToggleRow/ActionRow only ever
//     drew - neither one ever called HitTestRect or checked clickedEdge.
//     The key-press path worked but was never actually verified by testing
//     before v3 shipped, and the click path was simply never wired at all.
//     Fixed: every row now does its own hit-test and returns whether it was
//     clicked, same shape as the old Checkbox()/Button() widgets.
//   - FONT WAS ILLEGIBLE. Every stroke is now drawn TWICE with a 1px
//     perpendicular offset (a bolded stroke), and the base scale is bigger.
//     Still Draw2DLine only - this is just two line calls instead of one
//     per segment.
//   - CURSOR REMOVED. The magenta crosshair was unwanted - gone entirely.
//   - HIDE/SHOW moved to F3, matching the full build's own F3-hides-menu
//     convention exactly (this one instance of an F-key is intentional -
//     it isn't a random function key, it's memory-compatible with the tool
//     people already know).
//   - CARDS REBUILT per explicit description: ONE key ('1') cycles a
//     spam-count 0->1->2->3->4->5->0..., filling that many boxes left to
//     right (plain colour fill, no digits drawn in the boxes). Clicking a
//     box individually still toggles just that slot, as a bonus - the key
//     is the primary/expected way to use it.
//   - WALLS REBUILT as LITE's own function (DrawWalls, below) instead of
//     calling VisibilityBoxes::RenderBoxesViaCanvas - needed real distance-
//     based colour (red close -> pink mid -> purple far) and a thicker
//     stroke, neither of which the shared function does or should be
//     changed to do (it's shared with the full build's fallback). Reuses
//     the SAME gather cache (g_CachedGather) enemy names already read, so
//     this costs nothing extra to compute.
//   - Enemy name colour changed to white.
//
// v5. Fixes from live testing of v4:
//   - CARDS WERE WIRED TO THE WRONG ARRAY. DirectFire::g_CardSpam[]/kCards
//     is the OLD fixed-equip-point path the file's own comments say does not
//     work on a real card ("Cards are NOT fireable devices... firing them
//     does nothing - there is nothing to fire"). The full build's actual
//     "CARD MAXXING" UI drives DirectFire::g_Five[].spam instead - real
//     devices resolved off the eq-point sweep. v4's card cycle/click code
//     toggled g_CardSpam, which is why cards never did anything. Now targets
//     g_Five[].spam/g_PendingFive[] - the same array the full build's own
//     working card UI uses.
//   - TRIGGER BOT HAD NO VISUAL AND WAS MISSING A REQUIRED CALL. The full
//     build's crosshair (VisibilityBoxes::RenderTargetReticle's draw half)
//     is ImGui-only and can never draw in LITE - LITE never had ANY visual
//     reticle. Fixed with LiteMenu's own DrawReticleDot(), Draw2DLine only,
//     reading the exact same g_ReticleOnEnemy/g_ReticleOnHead/
//     g_ReticleOnPredictionBox globals the full build's dot and the trigger
//     bot both already key off. Also: VisibilityBoxes::UpdateMyChampionSpeed()
//     was never called anywhere in LITE's path (the full build only calls it
//     from its own ImGui Highlights tab and RenderBoxes(), neither of which
//     LITE has) - g_MyTableSpeed sat at its -1 default forever, so a
//     projectile champion's purple predicted-box reticle state could never
//     be reached. Now called once per frame from main_lite.cpp.
//   - FONT WAS "DOUBLE" / GHOSTED. v4's bold trick offset every segment
//     perpendicular to ITS OWN direction, so two segments that share a
//     corner got pushed apart in different directions - the corner visibly
//     split into two, reading as doubled/ghosted text. Fixed: bold is now a
//     single constant-direction copy of the WHOLE glyph (draw at (x,y) and
//     again at (x+1,y+1)) - every segment shifts by the exact same vector,
//     so shared corners stay shared. Uniformly bolder, no ghosting.
//   - ENEMY NAMES WERE TOO BIG. Own kNameScale now, well under kSmallScale.
//   - KEYS MOVED FROM NUMPAD TO F-KEYS, again, per explicit request ("use
//     normal numbers or F, make it say F"). F3 stays hide/show (unchanged -
//     matches the full build). F4 stays avoided (Alt+F4, and collides with
//     the full build's own F4 reset hotkey). F12 is also avoided (Steam's
//     default screenshot bind). Everything else moved to F1/F2/F5-F11 - see
//     the keybind table in PHAROAH_LITE_NOTES.md.
//   - BOXES/NAMES/RETICLE FROZE AFTER LEAVING A MATCH. main_lite.cpp only
//     called GatherAndCache/RenderTargetReticle/UpdateAutoFire inside
//     `if (Globals::initObjects())` - the instant that went false (leaving
//     the match), those three simply stopped being called at all, so
//     g_CachedGather kept its LAST live frame forever and boxes/names hung
//     in place on the post-match screen. All three are now called every
//     frame unconditionally - each already self-gates safely on
//     LocalPawn/LocalController being null (SafeGatherBoxes returns
//     ok=false, RenderTargetReticle returns on !gathered.ok, UpdateAutoFire
//     returns and releases any held trigger on !LocalPawn), so calling them
//     with no pawn is exactly what makes the cache clear itself.
//
// v6. Fixes from live testing of v5:
//   - CARDS STILL SHOWED "LEFT CLICK SPAM" ENTRIES. The eq sweep (0-20)
//     sometimes resolves a card slot straight onto the equipped WEAPON's own
//     device - firing that is functionally identical to mashing left click,
//     not a real card effect. IsRealCardSlot() now excludes any g_Five[]
//     entry whose dev == Globals::LocalWeapon from ever being ready/spammable.
//   - FIRE MODES DIDN'T DETECT ANYTHING. Was reading DirectFire::g_Dev[] -
//     the GObjects device sweep built for CARDS. The full build's own
//     PROVEN fire-mode scanner (FireModeMenu.h's ScanEquipPoints) never
//     used that sweep - it calls GetDeviceByEqPoint(i) for eq 0-20 directly.
//     That's exactly what DirectFire::g_Eq[] already caches. Retargeted to
//     read g_Eq instead of g_Dev - same device-discovery path the full
//     build's working scanner uses.
//   - FONT WAS STILL "DOUBLE" ON BOTH THE MENU AND, WORSE, ENEMY NAMES. v5's
//     "fix" (a second glyph offset by a constant vector) was still visibly
//     two strokes at this scale. There is no second font available
//     (Draw2DLine-only, see file header) so v6 goes back to a SINGLE draw,
//     everywhere, no exceptions - legibility now comes from scale/spacing/
//     contrast, not a synthetic bold.
//   - "CRT LINES" ON THE MENU BACKGROUND. FillRectLines stepped 2px between
//     solid rows, leaving a 1px gap of raw game image between every line -
//     that's what read as scanlines. Now steps 1px, genuinely solid, and the
//     panel itself is a darker, flatter monochrome for real contrast.
//   - CHECKBOXES WERE A THIN CHECKMARK. Per explicit request: the key-badge
//     box is now FULLY FILLED - solid green when ON, solid red when OFF -
//     not an outline with a slim checkmark. Every row's LABEL TEXT also now
//     gets its own accent colour (heal trigger bot green, trigger bot
//     orange-red, etc.) so different features are visually distinct, while
//     the box itself stays strictly green=ON/red=OFF everywhere, always.
//   - NO WAY TO CLOSE OR RESIZE THE MENU. Added an X button (same effect as
//     F3) and "-"/"+" buttons (NudgeUiScale) in the header - see g_UiScale.
//   - ALLIES HAD NO VISUAL AT ALL. DrawWalls now also draws a flat blue box
//     on BoxKind::Ally entries alongside the existing enemy boxes (F1 WALLS
//     is the one toggle for both).
//   - HEALTH BARS DREW REGARDLESS OF VISIBILITY (both here and in the full
//     build). Added DrawHealthBarIfHidden(), gated on the SAME
//     wallCheckEnabled/e.isVisible signal the wall-check trigger-bot gate
//     already used - a bar only appears for someone actually hidden behind
//     a wall; when you can see them normally, the game's own HUD/model is
//     enough. VisibilityBoxes.h's RenderBoxes() (the full build's own health
//     bars) got the identical gate added, so both builds agree.
//   - NO ULT-READY INDICATOR. Copied the full build's own ult icon (a small
//     circle next to the name, slowly cycling the colour wheel while
//     e.ultReady is true) - same ImGui::ColorConvertHSVtoRGB call, just
//     filled via FillCircle's Draw2DLine scanlines instead of an ImGui
//     draw-list, since LITE has no ImGui context.
//   - Trigger bot correctly refusing to fire through a wall (wallCheckEnabled
//     gating VisibilityBoxes::RenderTargetReticle's detection) was CONFIRMED
//     WORKING AS INTENDED by live testing - not a bug, no change needed.
//
// v7. A real colour/style system, per "it hurts my eyes to look at it, its
// horrendous" - flat black with white borders is gone:
//   - THEME + SHAPE system: three palettes (COLD - the user's own hex
//     request #2d0049/#00abc9; HOT - mirrors the full build's Volcanic
//     theme; EGYPTIAN - pulls from the full build's own Egyptian Sand
//     theme's gold/turquoise accents), cycled with the THEME button. SHAPE
//     toggles angular (cut corners, cyberpunk panel look) vs soft
//     (chamfered corners) - see StyledOutline/StyledFill. The green=ON/
//     red=OFF state fill stays FIXED across every theme on purpose - that's
//     the one colour that must never change meaning.
//   - Panel width widened (260->320) and the height formula fixed - it was
//     missing two whole header-line terms (card/fire section headers),
//     which is exactly why "the fire modes isn't enveloped in it" - the
//     background rectangle fell short of the content actually drawn below it.
//   - "HEAL TRIGGER BOT" renamed to "HEAL TRIGGER" - "BOT" was overlapping
//     the ON/OFF text at the old row width.
//   - Key-badge label text was near-black (assumed dark-on-bright-fill
//     contrast that didn't read well in practice) - now bright white and
//     10% bigger.
//   - LEAVE MATCH recoloured from brown to a distinct crimson.
//   - LITE's own health bars (behind-wall-only, added last round) REDESIGNED
//     per explicit feedback: vertical (runs the box's height) instead of
//     horizontal, exact colour match to the full build's own health bar
//     ramp (not an approximation), and soft/glowing edges via a new
//     GlowOutline helper (layered, fading-alpha outlines).
//   - Regular PHAROAH fixes bundled in this same pass (not LiteMenu.h, but
//     the same feedback round): heal trigger bot got the same wall-check
//     gate the enemy trigger bot already had (RecoverySuite.h's AUTO HEAL
//     block never checked e.isVisible at all); health-bar recolour's
//     "Recolour enemies"/"Recolour allies" checkboxes now trigger an
//     immediate reapply like every other control on that tab already did
//     (HealthBarColor.h); POTATO MODE is now adaptive by default
//     (Perf::g_AutoPotato) - engages on a real measured hitch, relaxes
//     after several clean seconds, instead of sitting statically ON and
//     silently blocking the health-bar reapply timer on machines that never
//     needed it (the actual root cause of "I have to click Apply Now").
//
// KEYS: F1/F2/F5-F11 for the toggle rows (see PollToggleKeys/DrawHud), F3
// for HUD show/hide (or the header's X button), '1' for the card cycle,
// '6'-'9' for fire modes, header "-"/"+" to resize the panel, "THEME"/
// "SHAPE" to restyle it.
//
// WHAT THIS FILE DOES NOT DO: install a D3D11/kiero hook, create an ImGui
// context, or call into any of PHAROAH's periodic background subsystems
// (HealthBarColor, MeshSkin, DevSkin, skin scanning, the bone/skeleton
// system, RunSafeThreadSubsystems as a whole, Speeden::Update as a whole).
//
// *** EVERY NEW FUNCTION ADDED HERE MUST BE CHECKED FOR ImGui::GetIO() /
// ImGui::GetTime() / ImGui::GetBackgroundDrawList() BEFORE IT SHIPS. ***
// LITE has no ImGui context, ever. Those calls assert/crash with none, and
// it is NOT an SEH exception - __try/__except does not catch it. Grep any
// shared function you're about to call for "ImGui::Get" before wiring it
// in, every single time - this has already shipped broken twice.

#include "globals.h"
#include "ext/kiero/kiero.h"
#include "menus/VisibilityBoxes.h"
#include "menus/DirectFire.h"
#include "menus/RecoverySuite.h"
#include "menus/FireModeMenu.h"
#include "menus/Unlocker.h"
#include "menus/Speeden.h"
#include "Utils/SafeCalls.h"
#include <Windows.h>
#include <cctype>
#include <cmath>

namespace LiteMenu {

    // ---------------------------------------------------------------------
    // INPUT - polled directly against the real game window, independent of
    // any render hook. Works while the game is paused/in a menu, same as
    // any other foreground-independent GetAsyncKeyState/GetCursorPos call.
    // ---------------------------------------------------------------------
    struct InputState {
        float mouseX = 0.0f, mouseY = 0.0f;
        bool mouseDown = false;
        bool clickedEdge = false;
    };
    inline InputState g_Input;

    inline void PollInput() {
        static bool wasDown = false;
        HWND wnd = (HWND)kiero::findRealGameWindow();
        if (!wnd) { g_Input = InputState(); wasDown = false; return; }
        POINT p{};
        GetCursorPos(&p);
        ScreenToClient(wnd, &p);
        g_Input.mouseX = (float)p.x;
        g_Input.mouseY = (float)p.y;
        bool down = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        g_Input.mouseDown = down;
        g_Input.clickedEdge = down && !wasDown;
        wasDown = down;
    }
    inline bool HitTestRect(float x, float y, float w, float h) {
        return g_Input.mouseX >= x && g_Input.mouseX <= x + w &&
               g_Input.mouseY >= y && g_Input.mouseY <= y + h;
    }

    // ---------------------------------------------------------------------
    // DRAWING PRIMITIVES - Draw2DLine only.
    // ---------------------------------------------------------------------
    inline void Line(SDK::UCanvas* canvas, float x0, float y0, float x1, float y1,
                      unsigned char r, unsigned char g, unsigned char b, unsigned char a = 255) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = a;
        canvas->Draw2DLine(x0, y0, x1, y1, c);
    }

    inline void Outline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                         unsigned char r, unsigned char g, unsigned char b) {
        Line(canvas, x,     y,     x + w, y,     r, g, b);
        Line(canvas, x + w, y,     x + w, y + h, r, g, b);
        Line(canvas, x + w, y + h, x,     y + h, r, g, b);
        Line(canvas, x,     y + h, x,     y,     r, g, b);
    }

    // Nested outlines growing outward - the only way to get a "thick" border
    // out of a primitive with no width parameter.
    inline void ThickOutline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                              unsigned char r, unsigned char g, unsigned char b, int thickness) {
        for (int o = 0; o < thickness; o++) {
            Outline(canvas, x - o, y - o, w + o * 2.0f, h + o * 2.0f, r, g, b);
        }
    }

    // v6: row step was 2.0f, leaving a visible 1px gap of raw game image
    // between every filled row - that gap is exactly what read as "CRT scan
    // lines" on the menu background. Every row now, for a genuinely solid fill.
    inline void FillRectLines(SDK::UCanvas* canvas, float x, float y, float w, float h,
                               unsigned char r, unsigned char g, unsigned char b) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = 255;
        for (float row = y; row < y + h; row += 1.0f) {
            canvas->Draw2DLine(x, row, x + w, row, c);
        }
    }

    // Scanline-filled circle (same solid-fill technique as FillRectLines,
    // just circular chords instead of a rectangle) - for the ult-ready icon.
    inline void FillCircle(SDK::UCanvas* canvas, float cx, float cy, float radius,
                            unsigned char r, unsigned char g, unsigned char b) {
        if (!canvas || radius <= 0.0f) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = 255;
        for (float dy = -radius; dy <= radius; dy += 1.0f) {
            float halfW = sqrtf(radius * radius - dy * dy);
            if (halfW <= 0.0f) continue;
            canvas->Draw2DLine(cx - halfW, cy + dy, cx + halfW, cy + dy, c);
        }
    }

    namespace Font {
        struct Seg { float x0, y0, x1, y1; };
        inline int Glyph(char ch, Seg* out) {
            switch (ch) {
            case 'A': out[0]={0,4,0,1}; out[1]={0,1,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,4}; out[4]={0,2,2,2}; return 5;
            case 'B': out[0]={0,0,0,4}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={2,2,2,4}; out[5]={2,4,0,4}; return 6;
            case 'C': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; return 3;
            case 'D': out[0]={0,0,0,4}; out[1]={0,0,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,3}; out[4]={2,3,1,4}; out[5]={1,4,0,4}; return 6;
            case 'E': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={0,2,2,2}; return 4;
            case 'F': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,2,2,2}; return 3;
            case 'G': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,1,2}; return 5;
            case 'H': out[0]={0,0,0,4}; out[1]={2,0,2,4}; out[2]={0,2,2,2}; return 3;
            case 'I': out[0]={0,0,2,0}; out[1]={1,0,1,4}; out[2]={0,4,2,4}; return 3;
            case 'J': out[0]={2,0,2,3}; out[1]={2,3,1,4}; out[2]={1,4,0,3}; return 3;
            case 'K': out[0]={0,0,0,4}; out[1]={2,0,0,2}; out[2]={0,2,2,4}; return 3;
            case 'L': out[0]={0,0,0,4}; out[1]={0,4,2,4}; return 2;
            case 'M': out[0]={0,4,0,0}; out[1]={0,0,1,2}; out[2]={1,2,2,0}; out[3]={2,0,2,4}; return 4;
            case 'N': out[0]={0,4,0,0}; out[1]={0,0,2,4}; out[2]={2,4,2,0}; return 3;
            case 'O': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case 'P': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; return 4;
            case 'Q': out[0]={0,0,2,0}; out[1]={2,0,2,3}; out[2]={2,3,0,3}; out[3]={0,3,0,0}; out[4]={1,3,2,4}; return 5;
            case 'R': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={0,2,2,4}; return 5;
            case 'S': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case 'T': out[0]={0,0,2,0}; out[1]={1,0,1,4}; return 2;
            case 'U': out[0]={0,0,0,4}; out[1]={0,4,2,4}; out[2]={2,4,2,0}; return 3;
            case 'V': out[0]={0,0,1,4}; out[1]={2,0,1,4}; return 2;
            case 'W': out[0]={0,0,0,4}; out[1]={0,4,1,2}; out[2]={1,2,2,4}; out[3]={2,4,2,0}; return 4;
            case 'X': out[0]={0,0,2,4}; out[1]={2,0,0,4}; return 2;
            case 'Y': out[0]={0,0,1,2}; out[1]={2,0,1,2}; out[2]={1,2,1,4}; return 3;
            case 'Z': out[0]={0,0,2,0}; out[1]={2,0,0,4}; out[2]={0,4,2,4}; return 3;
            case '0': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case '1': out[0]={1,0,1,4}; return 1;
            case '2': out[0]={0,0,2,0}; out[1]={2,0,2,2}; out[2]={2,2,0,2}; out[3]={0,2,0,4}; out[4]={0,4,2,4}; return 5;
            case '3': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,2,2,2}; return 4;
            case '4': out[0]={0,0,0,2}; out[1]={0,2,2,2}; out[2]={2,0,2,4}; return 3;
            case '5': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case '6': out[0]={1,0,0,1}; out[1]={0,1,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,0,2}; return 5;
            case '7': out[0]={0,0,2,0}; out[1]={2,0,1,4}; return 2;
            case '8': out[0]={0,0,2,0}; out[1]={0,0,0,4}; out[2]={2,0,2,4}; out[3]={0,4,2,4}; out[4]={0,2,2,2}; return 5;
            case '9': out[0]={0,0,2,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,0,2,4}; return 4;
            case '-': out[0]={0,2,2,2}; return 1;
            // v8: the "+" resize button's label was drawing as a BLANK BOX -
            // '+' had no case here at all, so Font::Glyph fell through to
            // `default: return 0` and drew zero segments. That's the real
            // bug behind "then ' ' then 'x' so the + isn't showing" - the
            // button was there and clickable, its glyph just never existed.
            case '+': out[0]={0,2,2,2}; out[1]={1,1,1,3}; return 2;
            case '/': out[0]={0,4,2,0}; return 1;
            case '?': out[0]={0,1,1,0}; out[1]={1,0,2,1}; out[2]={2,1,1,2}; out[3]={1,3,1,3}; return 4;
            default: return 0;
            }
        }
    }

    // v6: back to a SINGLE draw, no bold duplicate at all. v5's "fix" (a
    // second glyph offset by a constant vector) was still visibly two
    // separate strokes at this font's scale/weight - reported as "double
    // text" on both the menu and, worse, doubled enemy names. There is no
    // real second font available to swap to (Draw2DLine-only, see the file
    // header), so legibility now comes entirely from scale/spacing/contrast,
    // not a synthetic bold. One name over one enemy, one line of text in the
    // menu - what you write is what draws.
    inline void DrawGlyphAt(SDK::UCanvas* canvas, char ch, float x, float y, float scale,
                             unsigned char r, unsigned char g, unsigned char b) {
        Font::Seg segs[8];
        int n = Font::Glyph((char)toupper((unsigned char)ch), segs);
        for (int i = 0; i < n; i++) {
            Line(canvas, x + segs[i].x0 * scale, y + segs[i].y0 * scale,
                         x + segs[i].x1 * scale, y + segs[i].y1 * scale, r, g, b);
        }
    }
    inline void DrawChar(SDK::UCanvas* canvas, char ch, float x, float y, float scale,
                          unsigned char r, unsigned char g, unsigned char b) {
        DrawGlyphAt(canvas, ch, x, y, scale, r, g, b);
    }

    inline float DrawString(SDK::UCanvas* canvas, float x, float y, const char* text, float scale,
                             unsigned char r, unsigned char g, unsigned char b) {
        float cursor = x;
        for (const char* p = text; *p; p++) {
            DrawChar(canvas, *p, cursor, y, scale, r, g, b);
            cursor += 4.6f * scale;
        }
        return cursor - x;
    }
    inline float StringWidth(const char* text, float scale) {
        float n = 0; for (const char* p = text; *p; p++) n += 1.0f;
        return n * 4.6f * scale;
    }

    // Per-character colour cycling through the hue wheel, animated - a real
    // rainbow, for the credits line ("make my name rainbow"). Reuses the
    // same ColorConvertHSVtoRGB the ult-ready icon already uses.
    inline float DrawRainbowString(SDK::UCanvas* canvas, float x, float y, const char* text, float scale) {
        static float t = 0.0f;
        t += 0.006f;
        if (t > 1.0f) t -= 1.0f;
        float cursor = x;
        int i = 0;
        for (const char* p = text; *p; p++, i++) {
            float hue = t + (float)i * 0.05f;
            hue -= floorf(hue);
            float hr, hg, hb;
            ImGui::ColorConvertHSVtoRGB(hue, 0.80f, 1.0f, hr, hg, hb);
            DrawChar(canvas, *p, cursor, y, scale, (unsigned char)(hr * 255.0f), (unsigned char)(hg * 255.0f), (unsigned char)(hb * 255.0f));
            cursor += 4.6f * scale;
        }
        return cursor - x;
    }

    const float kFontScale = 4.2f;
    const float kSmallScale = 3.2f; // the smallest anything is ever drawn at now
    // Enemy names were reported 2.5x too big at kSmallScale - own, smaller
    // scale just for the name text drawn over enemies' heads. NOT affected by
    // g_UiScale below - that's the top-left MENU panel's own size, enemy
    // overlays are a separate, world-space concern the resize buttons don't
    // touch.
    const float kNameScale = kSmallScale / 2.5f;

    // ---------------------------------------------------------------------
    // MENU SIZE - the "-"/"+" buttons in the header scale the whole top-left
    // panel (fonts, box sizes, row spacing) by this factor. Only the panel -
    // world-space drawing (walls, names, the reticle dot) is untouched.
    // ---------------------------------------------------------------------
    inline float g_UiScale = 1.0f;
    inline void NudgeUiScale(float delta) {
        g_UiScale += delta;
        if (g_UiScale < 0.7f) g_UiScale = 0.7f;
        if (g_UiScale > 1.6f) g_UiScale = 1.6f;
    }

    // ========================================================================
    // THEME / SHAPE, v8 - REWORKED PALETTE SET. v7's HOT/EGYPTIAN were
    // reported as "ugly, just brown - the only good theme is purple." Kept
    // COLD (the user's own hex request, loved), dropped the other two, and
    // added five clean, deliberately DIFFERENT combinations per explicit
    // request ("purple and orange... dark red and yellow... light sand...
    // dark grey background and orange... yellow over orange"). Every
    // background stays dark-to-medium so the fixed per-row category colours
    // (cyan/green/orange/purple/etc, set at each ToggleRow call site) stay
    // legible on all of them - a true pale/white background would wash a
    // couple of the dimmer category colours out, so SAND leans "warm
    // parchment" rather than paper-white. Not muddy: every accent is a
    // single clean, saturated hue against its background, no desaturated
    // in-between colours.
    //
    // ONLY the panel's chrome (background/border/title/default text) is
    // themed. The green=ON/red=OFF state fill on every toggle box, and each
    // row's own category accent colour, stay fixed regardless of theme -
    // changing what colour means "on" between themes would make the one
    // thing that has to be unambiguous ("is this enabled") theme-dependent,
    // which defeats the whole point of it being fixed in the first place.
    // ========================================================================
    struct ThemePalette {
        const char* name;
        unsigned char bgR, bgG, bgB;      // panel fill
        unsigned char accR, accG, accB;   // border / title / hover highlight
        unsigned char textR, textG, textB; // default body text (row labels default to this unless overridden by a category colour)
    };
    // v9: trimmed from 6 down to the 3 the user actually wanted kept -
    // "from all the themes, I only want the already existing purple and
    // green theme [COLD], the grey and orange text theme [SLATE+ORANGE] AND
    // the dessert theme [SAND] - everything else, get rid of it."
    static const int kThemeCount = 3;
    inline const ThemePalette g_Themes[kThemeCount] = {
        { "COLD",          0x2d, 0x00, 0x49,  0x00, 0xab, 0xc9,  205, 220, 230 },
        { "SLATE+ORANGE",  0x23, 0x23, 0x26,  0xff, 0x8c, 0x14,  215, 215, 220 },
        { "SAND",          0x96, 0x78, 0x50,  0x3c, 0x23, 0x0f,  50,  32,  16  },
    };
    inline int  g_ThemeIndex = 0;
    inline bool g_ShapeSoft = false; // false = angular cut corners, true = soft chamfer
    inline const ThemePalette& CurTheme() { return g_Themes[g_ThemeIndex]; }
    inline void CycleTheme() { g_ThemeIndex = (g_ThemeIndex + 1) % kThemeCount; }

    // ========================================================================
    // SETTINGS / LANGUAGE, v8. g_Spanish flips every string LiteMenu.h draws
    // between English and Spanish - T(en, es) is the one call site every
    // DrawString below goes through. Spanish strings are written WITHOUT
    // accents/ñ on purpose: the font is a tiny hand-rolled Draw2DLine stick
    // font (see Font::Glyph) with no accented glyphs, and adding a dozen new
    // ones to squeeze into an already-cramped 2x4 grid was a real risk of
    // making the existing letters worse to save a few diacritics - a
    // well-precedented simplification (plenty of ASCII-only tools ship
    // Spanish this way). g_Spanish can be set by the injector's language
    // choice at startup (see main_lite.cpp reading PHAROAH_lang.txt) and
    // toggled any time with the EN/ES header button.
    // ========================================================================
    inline bool g_Spanish = false;
    inline const char* T(const char* en, const char* es) { return g_Spanish ? es : en; }

    inline bool g_ShowTutorial = false;
    inline bool g_ShowCursorIcon = false;
    // Declared here (not down by PollHudKey/DrawHud, where it conceptually
    // "lives") specifically so PollCardKeys/PollGrayscaleKey/
    // PollLeaveMatchKey - all defined earlier in this file - can gate on it
    // too. Header-only inline namespace: a variable has to be declared
    // before anything that reads it, even other inline functions.
    inline bool g_HudVisible = true;

    // Stylised rectangle outline: ANGULAR cuts only the top-right and
    // bottom-left corners (a single asymmetric diagonal, classic sci-fi
    // panel look); SOFT chamfers all four corners a smaller amount - the
    // closest a Draw2DLine-only primitive gets to a rounded corner without
    // an arc primitive to draw one with.
    inline void StyledOutline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                               unsigned char r, unsigned char g, unsigned char b) {
        if (!g_ShapeSoft) {
            float cut = 8.0f * g_UiScale;
            if (cut * 2.0f > w) cut = w * 0.3f;
            if (cut * 2.0f > h) cut = h * 0.3f;
            Line(canvas, x, y, x + w - cut, y, r, g, b);
            Line(canvas, x + w - cut, y, x + w, y + cut, r, g, b);
            Line(canvas, x + w, y + cut, x + w, y + h, r, g, b);
            Line(canvas, x + w, y + h, x + cut, y + h, r, g, b);
            Line(canvas, x + cut, y + h, x, y + h - cut, r, g, b);
            Line(canvas, x, y + h - cut, x, y, r, g, b);
        } else {
            float cut = 4.0f * g_UiScale;
            if (cut * 2.0f > w) cut = w * 0.25f;
            if (cut * 2.0f > h) cut = h * 0.25f;
            Line(canvas, x + cut, y, x + w - cut, y, r, g, b);
            Line(canvas, x + w - cut, y, x + w, y + cut, r, g, b);
            Line(canvas, x + w, y + cut, x + w, y + h - cut, r, g, b);
            Line(canvas, x + w, y + h - cut, x + w - cut, y + h, r, g, b);
            Line(canvas, x + w - cut, y + h, x + cut, y + h, r, g, b);
            Line(canvas, x + cut, y + h, x, y + h - cut, r, g, b);
            Line(canvas, x, y + h - cut, x, y + cut, r, g, b);
            Line(canvas, x, y + cut, x + cut, y, r, g, b);
        }
    }

    // Same corner language, filled - used for panel/box backgrounds so the
    // cut is visible in the fill too, not just the border.
    // alpha defaults to fully opaque (255) - only the main panel background
    // passes anything lower, for the "slightly opacity" request.
    inline void StyledFill(SDK::UCanvas* canvas, float x, float y, float w, float h,
                            unsigned char r, unsigned char g, unsigned char b, unsigned char alpha = 255) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = alpha;
        float cut = (g_ShapeSoft ? 4.0f : 8.0f) * g_UiScale;
        if (cut * 2.0f > w) cut = w * 0.25f;
        if (cut * 2.0f > h) cut = h * 0.25f;
        for (float row = y; row < y + h; row += 1.0f) {
            float left = x, right = x + w;
            float distTop = row - y, distBot = (y + h) - row;
            if (!g_ShapeSoft) {
                if (distTop < cut) right = x + w - (cut - distTop);
                if (distBot < cut) left = x + (cut - distBot);
            } else {
                if (distTop < cut) { left = x + (cut - distTop); right = x + w - (cut - distTop); }
                if (distBot < cut) { left = x + (cut - distBot); right = x + w - (cut - distBot); }
            }
            if (right > left) canvas->Draw2DLine(left, row, right, row, c);
        }
    }

    // Layered, fading-alpha outline - the closest a Draw2DLine-only canvas
    // gets to a soft/glowing edge with no blur or rounded-rect primitive to
    // draw one with. Degrades gracefully even if the engine's Draw2DLine
    // ignores alpha entirely (a few overlapping same-colour rings still
    // reads as a soft halo, just a slightly bolder one). Declared up here
    // (not down by the health bars, where it was first used) so ToggleRow's
    // hover glow can use it too.
    inline void GlowOutline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                             unsigned char r, unsigned char g, unsigned char b, int layers) {
        for (int i = 1; i <= layers; i++) {
            unsigned char a = (unsigned char)(130 / (i + 1));
            float o = (float)i;
            Line(canvas, x - o,     y - o,     x + w + o, y - o,     r, g, b, a);
            Line(canvas, x + w + o, y - o,     x + w + o, y + h + o, r, g, b, a);
            Line(canvas, x + w + o, y + h + o, x - o,      y + h + o, r, g, b, a);
            Line(canvas, x - o,     y + h + o, x - o,      y - o,     r, g, b, a);
        }
    }

    // "[KEY] LABEL ............. ON/OFF" - key badge, label, state, all in
    // one fixed-format row. BOTH the key AND clicking the row toggle it.
    //
    // v6: the key badge box is now FULLY FILLED green (ON) or red (OFF) -
    // "the entire box is fully green [or] full red", not a thin checkmark on
    // an outline, per explicit request: state must be readable at a glance,
    // not squinted at. labelR/G/B lets every row get its own category colour
    // (heal trigger bot green, trigger bot red-orange, etc.) instead of one
    // flat white for every line. Every metric scales with g_UiScale.
    // Returns true the frame it was clicked.
    inline bool ToggleRow(SDK::UCanvas* canvas, float x, float y, float w, const char* keyLabel,
                           const char* label, bool value,
                           unsigned char labelR, unsigned char labelG, unsigned char labelB) {
        const float rowH = 26.0f * g_UiScale, boxSz = 22.0f * g_UiScale;
        const float fs = kSmallScale * g_UiScale;
        const ThemePalette& th = CurTheme();
        bool hovered = HitTestRect(x, y, w, rowH);
        bool clicked = hovered && g_Input.clickedEdge;

        // Full state fill: solid green ON, solid red OFF - unambiguous even
        // at a glance, no squinting at a slim checkmark. This is the one
        // colour that stays FIXED across every theme - state must always
        // read the same way. Frame colour is the theme's own accent.
        if (value) StyledFill(canvas, x, y, boxSz, boxSz, 30, 180, 70);
        else       StyledFill(canvas, x, y, boxSz, boxSz, 170, 35, 45);
        StyledOutline(canvas, x, y, boxSz, boxSz, th.accR, th.accG, th.accB);
        // Key label: was near-black, unreadable sitting on a bright green/red
        // fill - now bright white (works on both), and +10% bigger, per
        // explicit request ("make it bigger by 10%, a way to make it easier
        // to see").
        DrawString(canvas, x + 3 * g_UiScale, y + 3 * g_UiScale, keyLabel, fs * 0.66f, 250, 250, 255);
        DrawString(canvas, x + 32 * g_UiScale, y + 3 * g_UiScale, label, fs, labelR, labelG, labelB);
        const char* state = value ? "ON" : "OFF";
        float sw = StringWidth(state, fs);
        DrawString(canvas, x + w - sw, y + 3 * g_UiScale, state, fs,
                   value ? 90 : 230, value ? 230 : 90, value ? 120 : 95);
        // v8: hover feedback was too subtle to notice ("it already does have
        // an effect but we need it stronger"). A full glow (like the health
        // bars' soft edge) plus a background tint on the whole row now,
        // instead of one thin outline.
        if (hovered) {
            StyledFill(canvas, x - 2, y - 2, w + 4, rowH, (unsigned char)(th.accR / 5), (unsigned char)(th.accG / 5), (unsigned char)(th.accB / 5));
            GlowOutline(canvas, x - 2, y - 2, w + 4, rowH, th.accR, th.accG, th.accB, 3);
            StyledOutline(canvas, x - 2, y - 2, w + 4, rowH, th.accR, th.accG, th.accB);
        }
        return clicked;
    }

    // Same shape, no ON/OFF - for one-shot actions (LEAVE MATCH). Not brown
    // any more per explicit request - a distinct crimson, unrelated to any
    // theme's own background so it never blends in.
    inline bool ActionRow(SDK::UCanvas* canvas, float x, float y, float w, const char* keyLabel,
                           const char* label, unsigned char labelR, unsigned char labelG, unsigned char labelB) {
        const float rowH = 26.0f * g_UiScale, boxSz = 22.0f * g_UiScale;
        const float fs = kSmallScale * g_UiScale;
        const ThemePalette& th = CurTheme();
        bool hovered = HitTestRect(x, y, w, rowH);
        bool clicked = hovered && g_Input.clickedEdge;
        StyledFill(canvas, x, y, boxSz, boxSz, 190, 35, 60);
        StyledOutline(canvas, x, y, boxSz, boxSz, th.accR, th.accG, th.accB);
        DrawString(canvas, x + 3 * g_UiScale, y + 3 * g_UiScale, keyLabel, fs * 0.66f, 250, 250, 255);
        DrawString(canvas, x + 32 * g_UiScale, y + 3 * g_UiScale, label, fs, labelR, labelG, labelB);
        if (hovered) {
            StyledFill(canvas, x - 2, y - 2, w + 4, rowH, (unsigned char)(th.accR / 5), (unsigned char)(th.accG / 5), (unsigned char)(th.accB / 5));
            GlowOutline(canvas, x - 2, y - 2, w + 4, rowH, th.accR, th.accG, th.accB, 3);
            StyledOutline(canvas, x - 2, y - 2, w + 4, rowH, th.accR, th.accG, th.accB);
        }
        return clicked;
    }

    // A small square icon button - "-"/"+"/"X"/"THEME"/"SHAPE" in the header.
    // Same full-fill language as the toggle rows. tintR/G/B (0,0,0 = no
    // tint, the default) lets a few of these get their own colour hint on
    // top of the theme - "give these colors if possible to make it
    // clearer" - X reads red-ish (close), + green-ish, - amber, independent
    // of whichever theme is active.
    inline bool IconButton(SDK::UCanvas* canvas, float x, float y, float w, float h, const char* glyph,
                            unsigned char tintR = 0, unsigned char tintG = 0, unsigned char tintB = 0) {
        const ThemePalette& th = CurTheme();
        bool hovered = HitTestRect(x, y, w, h);
        bool clicked = hovered && g_Input.clickedEdge;
        int add = hovered ? 40 : 15;
        int rr = th.bgR / 2 + add + tintR / 4; if (rr > 255) rr = 255;
        int gg = th.bgG / 2 + add + tintG / 4; if (gg > 255) gg = 255;
        int bbv = th.bgB / 2 + add + tintB / 4; if (bbv > 255) bbv = 255;
        unsigned char br = (unsigned char)rr, bg = (unsigned char)gg, bb = (unsigned char)bbv;
        StyledFill(canvas, x, y, w, h, br, bg, bb);
        StyledOutline(canvas, x, y, w, h, th.accR, th.accG, th.accB);
        float fs = kSmallScale * g_UiScale * 0.6f;
        float gw = StringWidth(glyph, fs);
        float gh = h * 0.5f;
        DrawString(canvas, x + (w - gw) * 0.5f, y + (h - gh) * 0.5f, glyph, fs, 245, 245, 250);
        return clicked;
    }

    // ========================================================================
    // CARDS, v5 - RETARGETED TO THE WORKING ARRAY.
    //
    // v4 drove DirectFire::g_CardSpam[]/g_PendingCard[], which fires through
    // the fixed-equip-point kCards table (5/19/20/21/22). DirectFire.h's own
    // extensive comments say that table does not work on a real card - cards
    // are listener objects, not fireable devices, so firing "the card" does
    // nothing. That's why v4's cards never did anything no matter how they
    // were clicked. The full build's actual "CARD MAXXING" UI (the one that
    // works) drives DirectFire::g_Five[].spam / g_PendingFive[] instead -
    // real ATgDevice pointers resolved off the eq-point sweep
    // (DirectFire::ProcessPending's g_PendingEqSweep block), which is what
    // auto-detects the equipped deck and stays correct across a re-sweep.
    // This now targets that array. Detection itself needed no changes - the
    // eq sweep already runs on its own auto-refresh timer
    // (g_EqAutoSweep/g_AutoSweep, both left on by InitThreadLite).
    //
    // v9 - REDESIGNED per explicit request: the single-key cycling counter
    // is gone. "Over reclicking 1, its actually 1-5... you click 2, it
    // triggers the 2nd box... you can have say box 2 and 5 by clicking
    // that." Keys '1'-'5' now each independently toggle their own slot -
    // press 2 and 5, get exactly boxes 2 and 5 active, any combination.
    // Clicking a box does the identical thing, same as before.
    // g_CardSpamCount is now just a live COUNT for the "(n/5)" header text,
    // recomputed after every change rather than driving anything itself.
    // ========================================================================
    inline int  g_CardSpamCount = 0;
    inline bool g_CardKeyWasDown[5] = {};

    // v6: filter out the weapon's own fire device. The eq sweep (0-20)
    // sometimes resolves a "card" slot straight onto Globals::LocalWeapon
    // itself - firing that via DeviceStartFire/StopFire is functionally
    // indistinguishable from just mashing left click, not a real card
    // effect, and was reported as exactly that ("many of the cards it
    // detects is just left click spam method"). A slot pointing at the
    // equipped weapon is never treated as ready/spammable here.
    inline bool IsRealCardSlot(int i) {
        if (i < 0 || i >= 5) return false;
        SDK::ATgDevice* d = DirectFire::g_Five[i].dev;
        if (!d) return false;
        if (d == Globals::LocalWeapon) return false;
        return true;
    }

    inline void RecountCardSpam() {
        int n = 0;
        for (int k = 0; k < 5; k++) if (IsRealCardSlot(k) && DirectFire::g_Five[k].spam) n++;
        g_CardSpamCount = n;
    }

    inline void PollCardKeys() {
        if (!g_HudVisible) return;
        static const int keys[5] = { '1', '2', '3', '4', '5' };
        for (int i = 0; i < 5; i++) {
            bool down = (GetAsyncKeyState(keys[i]) & 0x8000) != 0;
            if (down && !g_CardKeyWasDown[i] && IsRealCardSlot(i)) {
                DirectFire::g_Five[i].spam = !DirectFire::g_Five[i].spam;
                RecountCardSpam();
            }
            g_CardKeyWasDown[i] = down;
        }
    }

    inline void DrawCardRow(SDK::UCanvas* canvas, float x, float y) {
        const float boxSize = 34.0f * g_UiScale, gap = 8.0f * g_UiScale;
        const ThemePalette& th = CurTheme();
        bool anyReady = false;
        for (int i = 0; i < 5; i++) {
            float bx = x + i * (boxSize + gap);
            bool ready = IsRealCardSlot(i);
            if (ready) anyReady = true;
            bool spamming = ready && DirectFire::g_Five[i].spam;

            if (ready && HitTestRect(bx, y, boxSize, boxSize) && g_Input.clickedEdge) {
                DirectFire::g_Five[i].spam = !DirectFire::g_Five[i].spam;
                RecountCardSpam();
            }

            unsigned char r, g, b;
            if (spamming)      { r = 30; g = 180; b = 70; }
            else if (ready)    { r = th.accR; g = th.accG; b = th.accB; }
            else               { r = 55; g = 55; b = 60; }
            StyledFill(canvas, bx, y, boxSize, boxSize, spamming ? r : r / 4, spamming ? g : g / 4, spamming ? b : b / 4);
            StyledOutline(canvas, bx, y, boxSize, boxSize, r, g, b);

            // v8: was drawing the full device label under the box with no
            // width limit - a longer name overran into the NEXT box's label,
            // reading as "two overlapping things under each box." Fixed two
            // ways: the slot NUMBER now goes INSIDE the box (always fits,
            // always readable), and the label below is truncated to what
            // actually fits in one box+gap slot at this scale, never spilling
            // into the neighbour.
            char slotNum[2] = { (char)('1' + i), 0 };
            float numScale = kSmallScale * g_UiScale * 0.7f;
            float numW = StringWidth(slotNum, numScale);
            DrawString(canvas, bx + (boxSize - numW) * 0.5f, y + boxSize * 0.35f, slotNum, numScale,
                       spamming ? 15 : 235, spamming ? 40 : 235, spamming ? 20 : 240);

            if (ready) {
                char label[8];
                const char* src = DirectFire::g_Five[i].label;
                int n = 0;
                while (src[n] && n < 6) { label[n] = src[n]; n++; }
                label[n] = 0;
                DrawString(canvas, bx + 1, y + boxSize + 3, label, kNameScale * g_UiScale, 190, 190, 200);
            }
        }
        if (!anyReady) {
            DrawString(canvas, x, y + boxSize + 3, T("DETECTING YOUR DECK...", "DETECTANDO MAZO..."), kNameScale * g_UiScale, 200, 170, 130);
        }
    }

    // ========================================================================
    // FIRE MODES, v6 - RETARGETED, same class of bug as cards.
    //
    // Was reading DirectFire::g_Dev[] - the raw GObjects device sweep built
    // for CARDS specifically (kMaxDevRows=96, walks every ATgDevice in
    // memory filtering owner==pawn). The full build's own PROVEN fire-mode
    // scanner (FireModeMenu.h's ScanEquipPoints) never uses that sweep at
    // all - it calls pawn->GetDeviceByEqPoint(i) directly for eq 0-20. That
    // is exactly what DirectFire::g_Eq[] already caches (populated by
    // SafeCalls::GetDeviceByEqPointPawn(eq) in DirectFire::ProcessPending's
    // g_PendingEqSweep block - the very same call, just safe-thread-cached
    // with its own auto-refresh timer instead of a render-thread button
    // press). Reading g_Eq instead of g_Dev means fire-mode detection now
    // uses the SAME device-discovery path the full build's working scanner
    // does, not a different one built for a different purpose.
    // ========================================================================
    struct FireModeSlot {
        SDK::ATgDevice* dev = nullptr;
        int modeCount = 0;
        int key = 0;
        char label[32] = {};
    };
    static const int kMaxFireModeSlots = 4;
    inline FireModeSlot g_FireModeSlots[kMaxFireModeSlots];
    inline int  g_FireModeSlotCount = 0;
    inline bool g_FireModeKeyWasDown[kMaxFireModeSlots] = {};

    // v9: key-cycling removed entirely per explicit request ("I dont think
    // we need at all tbh, just make it regular selecting no numbers to
    // trigger it") - fire modes are click-only now. slot.key stays in the
    // struct (harmless, just unused) rather than restructuring the type for
    // a one-line removal's worth of benefit.
    inline void RebuildFireModeSlots() {
        g_FireModeSlotCount = 0;
        for (int i = 0; i < DirectFire::g_EqCount && g_FireModeSlotCount < kMaxFireModeSlots; i++) {
            const DirectFire::EqRow& row = DirectFire::g_Eq[i];
            if (!row.dev) continue;
            int count = 0;
            __try { count = (int)row.dev->m_FireMode.Num(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
            if (count <= 1) continue;

            FireModeSlot& slot = g_FireModeSlots[g_FireModeSlotCount];
            slot.dev = row.dev;
            slot.modeCount = count;
            lstrcpynA(slot.label, DeviceNames::NameOf(row.deviceId), sizeof(slot.label));
            g_FireModeSlotCount++;
        }
    }

    // g_Eq self-refreshes on pawn change and on its own auto-sweep timer
    // (DirectFire::ProcessPending, g_EqAutoSweep - already on by default) -
    // nothing to trigger here, just re-filter the always-current list every
    // frame. Kept as its own function/name for DrawHud's call site to stay
    // unchanged.
    inline void TickFireModesSafe() {
        RebuildFireModeSlots();
    }

    // PollFireModeKeys removed (v9) - click-only now, see the note above.

    inline void DrawFireModes(SDK::UCanvas* canvas, float x, float y) {
        const float fs = kSmallScale * g_UiScale, boxSz = 22.0f * g_UiScale;
        const ThemePalette& th = CurTheme();
        if (g_FireModeSlotCount == 0) {
            DrawString(canvas, x, y, T("SCANNING FOR ABILITIES...", "BUSCANDO HABILIDADES..."), fs, 200, 170, 130);
            return;
        }
        float cy = y;
        for (int i = 0; i < g_FireModeSlotCount; i++) {
            const FireModeSlot& slot = g_FireModeSlots[i];
            StyledOutline(canvas, x, cy, boxSz, boxSz, th.accR, th.accG, th.accB);
            DrawString(canvas, x + 5 * g_UiScale, cy + 3 * g_UiScale, slot.label, fs * 0.85f, 225, 225, 230);
            cy += 26.0f * g_UiScale;

            int cur = 0;
            __try { cur = slot.dev ? (int)slot.dev->CurrentFireMode : 0; } __except (EXCEPTION_EXECUTE_HANDLER) { cur = 0; }
            for (int m = 0; m < slot.modeCount && m < 8; m++) {
                float px = x + m * 28.0f * g_UiScale;
                bool active = (m == cur);
                if (HitTestRect(px, cy, boxSz, boxSz) && g_Input.clickedEdge) ApplyFireModeRaw(slot.dev, m);
                if (active) StyledFill(canvas, px, cy, boxSz, boxSz, 20, 60, 25);
                unsigned char pr = active ? 90 : th.accR, pg = active ? 230 : th.accG, pb = active ? 120 : th.accB;
                StyledOutline(canvas, px, cy, boxSz, boxSz, pr, pg, pb);
            }
            cy += 28.0f * g_UiScale;
        }
    }

    // ========================================================================
    // WALLS - LITE's OWN drawing (not VisibilityBoxes::RenderBoxesViaCanvas -
    // that function is shared with the full build's fallback and deliberately
    // untouched; this needed real distance colour + thickness neither has).
    // Reuses g_CachedGather (already populated every frame for the trigger
    // bot / enemy names) instead of doing its own separate pawn walk.
    // Colour: red up close, through pink, to purple far away. Distances are
    // in Unreal units (~52.5 per metre, same conversion VisibilityBoxes.h
    // uses elsewhere) - tune kCloseUnits/kFarUnits if the bands feel off in
    // practice.
    // ========================================================================
    inline void DistanceColor(float dist, unsigned char& r, unsigned char& g, unsigned char& b) {
        const float kCloseUnits = 800.0f;   // ~15m - full red at or inside this
        const float kMidUnits   = 2200.0f;  // ~42m - pink
        const float kFarUnits   = 4500.0f;  // ~86m and beyond - full purple
        if (dist <= kMidUnits) {
            float t = (dist - kCloseUnits) / (kMidUnits - kCloseUnits);
            if (t < 0.0f) t = 0.0f; if (t > 1.0f) t = 1.0f;
            r = 255;
            g = (unsigned char)(40.0f  + (80.0f  - 40.0f)  * t);
            b = (unsigned char)(40.0f  + (180.0f - 40.0f)  * t);
        } else {
            float t = (dist - kMidUnits) / (kFarUnits - kMidUnits);
            if (t < 0.0f) t = 0.0f; if (t > 1.0f) t = 1.0f;
            r = (unsigned char)(255.0f + (150.0f - 255.0f) * t);
            g = (unsigned char)(80.0f  + (60.0f  - 80.0f)  * t);
            b = (unsigned char)(180.0f + (220.0f - 180.0f) * t);
        }
    }

    // v7: REDESIGNED per explicit feedback - was a plain horizontal bar
    // above the box with a hard 1px outline. Now:
    //   - VERTICAL, running the length of the box (boxHeight) instead of a
    //     width bar above it - "show length wise along the character's box
    //     over a width healthbar."
    //   - Exact same colour ramp as the full build's own health bars
    //     (VisibilityBoxes.h's RenderBoxes - the inverted dark-red-to-hot-
    //     pink enemy ramp and green-to-red ally ramp), not an
    //     approximation - "the same colour scheme as PHAROAH healthbars."
    //   - Soft edges via GlowOutline instead of one hard outline.
    // Still ONLY drawn when actually hidden behind a wall - mirrors the
    // identical wallCheckEnabled/e.isVisible gate on the full build's own
    // RenderBoxes() health bars (VisibilityBoxes.h), so both builds agree: a
    // bar you can see the person normally is redundant with the game's own
    // HUD/model; a bar for someone behind a wall is the one case the native
    // UI can't help with.
    inline void DrawHealthBarIfHidden(SDK::UCanvas* canvas, const VisibilityBoxes::BoxEntry& e,
                                       float left, float topY, float boxHeight, float boxWidth) {
        if (e.healthPct < 0.0f) return;
        if (!(VisibilityBoxes::wallCheckEnabled && !e.isVisible)) return;

        float barW = boxWidth * 0.18f;
        if (barW < 4.0f) barW = 4.0f;
        if (barW > 10.0f) barW = 10.0f;
        float barX = left - barW - 3.0f;
        float barH = boxHeight;

        // v8 - RETUNED per live feedback: "purple at full, pinker as they
        // lower, more red the lower they get - BUT its lighter colour [than
        // I want]." The v7 version matched the full build's own bar exactly
        // (a dark red->hot pink 2-stop ramp), which is where "purple" was
        // coming from perceptually - but was too light/desaturated. Now a
        // real 3-stop ramp, fully saturated: vivid purple (full) -> hot pink
        // (mid) -> vivid red (low), the red arriving late so it reads as
        // genuine urgency rather than "always kind of red."
        // Ally ramp unchanged (green->red) - no complaint about it.
        unsigned char r, g, b;
        if (e.kind == VisibilityBoxes::BoxKind::Ally) {
            float lowFactor = 1.0f - e.healthPct;
            r = (unsigned char)(51.0f  + (242.0f - 51.0f)  * lowFactor);
            g = (unsigned char)(217.0f - (217.0f - 64.0f)  * lowFactor);
            b = (unsigned char)(89.0f  - (89.0f  - 38.0f)  * lowFactor);
        } else {
            const unsigned char kFullR = 150, kFullG = 25,  kFullB = 215;  // vivid purple
            const unsigned char kMidR  = 235, kMidG  = 20,  kMidB  = 140;  // hot pink
            const unsigned char kLowR  = 255, kLowG  = 25,  kLowB  = 35;   // vivid red
            if (e.healthPct >= 0.5f) {
                float t = 1.0f - (e.healthPct - 0.5f) / 0.5f; // 0 at full, 1 at half
                r = (unsigned char)(kFullR + (kMidR - kFullR) * t);
                g = (unsigned char)(kFullG + (kMidG - kFullG) * t);
                b = (unsigned char)(kFullB + (kMidB - kFullB) * t);
            } else {
                float t = 1.0f - (e.healthPct / 0.5f); // 0 at half, 1 at empty
                r = (unsigned char)(kMidR + (kLowR - kMidR) * t);
                g = (unsigned char)(kMidG + (kLowG - kMidG) * t);
                b = (unsigned char)(kMidB + (kLowB - kMidB) * t);
            }
        }

        FillRectLines(canvas, barX, topY, barW, barH, 18, 18, 21); // background track

        // Fills bottom-up (drains downward as health drops - the usual
        // vertical-HP-bar convention).
        float fillH = barH * e.healthPct;
        float fillY = topY + (barH - fillH);
        FillRectLines(canvas, barX, fillY, barW, fillH, r, g, b);

        Outline(canvas, barX, topY, barW, barH, 12, 12, 14);
        GlowOutline(canvas, barX, topY, barW, barH, r, g, b, 3);
    }

    inline void DrawWalls(SDK::UCanvas* canvas) {
        if (!canvas || !VisibilityBoxes::enabled) return;
        const VisibilityBoxes::GatherResult& g = VisibilityBoxes::g_CachedGather;
        if (!g.ok) return;

        VisibilityBoxes::PlainVec fwd, right, up;
        VisibilityBoxes::RotatorToVectors(g.camPitch, g.camYaw, fwd, right, up);
        ImVec2 screenSize = { (float)canvas->SizeX, (float)canvas->SizeY };

        for (int i = 0; i < g.count; i++) {
            const VisibilityBoxes::BoxEntry& e = g.entries[i];
            bool isEnemy = e.kind == VisibilityBoxes::BoxKind::Enemy;
            bool isAlly  = e.kind == VisibilityBoxes::BoxKind::Ally;
            if (!isEnemy && !isAlly) continue;

            VisibilityBoxes::PlainVec top{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight };
            VisibilityBoxes::PlainVec bot{ e.worldPos.x, e.worldPos.y, e.worldPos.z - e.collisionHeight };
            ImVec2 screenTop, screenBot;
            if (!VisibilityBoxes::WorldToScreen(top, g.camLoc, fwd, right, up, g.fov, screenSize.x, screenSize.y, screenTop)) continue;
            if (!VisibilityBoxes::WorldToScreen(bot, g.camLoc, fwd, right, up, g.fov, screenSize.x, screenSize.y, screenBot)) continue;

            float boxHeight = screenBot.y - screenTop.y;
            if (boxHeight < 4.0f || boxHeight > 2000.0f) continue;
            float boxWidth = (e.collisionHeight > 0.1f) ? boxHeight * (e.collisionRadius / e.collisionHeight) : boxHeight * 0.5f;
            float left = screenTop.x - boxWidth * 0.5f;

            unsigned char r, gg, b;
            if (isEnemy) {
                float dx = e.worldPos.x - g.camLoc.x, dy = e.worldPos.y - g.camLoc.y, dz = e.worldPos.z - g.camLoc.z;
                float dist = sqrtf(dx * dx + dy * dy + dz * dz);
                DistanceColor(dist, r, gg, b);
            } else {
                r = 60; gg = 160; b = 255; // flat blue - allies, no distance gradient
            }

            ThickOutline(canvas, left, screenTop.y, boxWidth, boxHeight, r, gg, b, 2);
            DrawHealthBarIfHidden(canvas, e, left, screenTop.y, boxHeight, boxWidth);
        }
    }

    // ========================================================================
    // ENEMY NAMES - white per explicit request, drawn at kNameScale (reported
    // 2.5x too big at kSmallScale), single draw only (v6 - see DrawChar).
    // Ult-ready icon: a small filled circle next to the name, cycling
    // through the colour wheel, copied from the full build's own ult icon
    // (VisibilityBoxes.h's RenderBoxes - AddCircleFilled + ColorConvertHSVtoRGB
    // on a slow-incrementing hue) - only the fill technique differs
    // (FillCircle's Draw2DLine scanlines instead of ImGui's AddCircleFilled).
    // ========================================================================
    inline bool g_ShowNames = true;

    inline void DrawEnemyNames(SDK::UCanvas* canvas) {
        if (!canvas || !g_ShowNames) return;
        const VisibilityBoxes::GatherResult& g = VisibilityBoxes::g_CachedGather;
        if (!g.ok) return;

        VisibilityBoxes::PlainVec fwd, right, up;
        VisibilityBoxes::RotatorToVectors(g.camPitch, g.camYaw, fwd, right, up);
        ImVec2 screenSize = { (float)canvas->SizeX, (float)canvas->SizeY };

        static float s_UltHue = 0.0f;
        s_UltHue += 0.0008f; // same slow rate as the full build's icon
        if (s_UltHue > 1.0f) s_UltHue -= 1.0f;

        for (int i = 0; i < g.count; i++) {
            const VisibilityBoxes::BoxEntry& e = g.entries[i];
            if (e.kind != VisibilityBoxes::BoxKind::Enemy) continue;
            if (!e.championName[0]) continue;

            VisibilityBoxes::PlainVec top{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight + 16.0f };
            ImVec2 screen;
            if (!VisibilityBoxes::WorldToScreen(top, g.camLoc, fwd, right, up, g.fov, screenSize.x, screenSize.y, screen))
                continue;

            float w = StringWidth(e.championName, kNameScale);
            DrawString(canvas, screen.x - w / 2.0f, screen.y, e.championName, kNameScale, 255, 255, 255);

            if (e.ultReady) {
                float dotR = kNameScale * 2.2f;
                float hr, hgf, hb;
                ImGui::ColorConvertHSVtoRGB(s_UltHue, 0.85f, 1.0f, hr, hgf, hb);
                FillCircle(canvas, screen.x + w / 2.0f + dotR + 4.0f, screen.y + kNameScale * 2.0f, dotR,
                           (unsigned char)(hr * 255.0f), (unsigned char)(hgf * 255.0f), (unsigned char)(hb * 255.0f));
            }
        }
    }

    // ========================================================================
    // TARGET RETICLE DOT, v5 - LITE never had ANY visual reticle before this.
    // The full build's own crosshair (VisibilityBoxes::RenderTargetReticle's
    // draw half) is ImGui-only (GetBackgroundDrawList) and can never run in
    // LITE - it self-guards and returns with no context, by design (see the
    // comment on VisibilityBoxes::g_FallbackScreenW). But the DETECTION half
    // of that same function runs unconditionally and already sets
    // g_ReticleOnEnemy/g_ReticleOnHead/g_ReticleOnPredictionBox every frame -
    // this just draws LITE's own small crosshair off those same globals,
    // Draw2DLine only. Colour priority matches the full build's own dot
    // exactly: purple (prediction box) > yellow (head) > red (body) > grey
    // (nothing). Always drawn - it's a display-only aim reference; whether it
    // actually FIRES is the separate TRIGGER BOT toggle (off by default).
    // ========================================================================
    inline void DrawReticleDot(SDK::UCanvas* canvas) {
        if (!canvas) return;
        float ccx = (float)canvas->SizeX * 0.5f;
        float ccy = (float)canvas->SizeY * 0.5f;

        unsigned char r = 210, g = 210, b = 215;
        if (VisibilityBoxes::g_ReticleOnPredictionBox)   { r = 180; g = 80;  b = 255; }
        else if (VisibilityBoxes::g_ReticleOnHead)       { r = 255; g = 220; b = 40;  }
        else if (VisibilityBoxes::g_ReticleOnEnemy)      { r = 255; g = 60;  b = 60;  }

        const float gap = 5.0f, len = 6.0f;
        Line(canvas, ccx - gap - len, ccy, ccx - gap, ccy, r, g, b);
        Line(canvas, ccx + gap, ccy, ccx + gap + len, ccy, r, g, b);
        Line(canvas, ccx, ccy - gap - len, ccx, ccy - gap, r, g, b);
        Line(canvas, ccx, ccy + gap, ccx, ccy + gap + len, r, g, b);
    }

    // ---------------------------------------------------------------------
    // NO-SPREAD / NO-RECOIL - unchanged from before. Six raw struct-field
    // writes (m_AccuracySettings/m_RecoilSettings), zero ImGui, zero
    // scripted calls - see Speeden.h. Combined into one toggle.
    // ---------------------------------------------------------------------
    inline bool g_NoSpreadRecoilEnabled = true;
    inline SDK::ATgDevice* g_SpreadRecoilDevice = nullptr;
    inline bool g_HaveSpreadRecoilBase = false;

    inline void TickNoSpreadRecoil() {
        SDK::ATgDevice* wep = Globals::LocalWeapon;
        if (!wep) { g_HaveSpreadRecoilBase = false; g_SpreadRecoilDevice = nullptr; return; }
        if (wep != g_SpreadRecoilDevice || !g_HaveSpreadRecoilBase) {
            g_SpreadRecoilDevice = wep;
            g_HaveSpreadRecoilBase = Speeden::TryCaptureAccuracy(wep) && Speeden::TryCaptureRecoil(wep);
        }
        if (!g_HaveSpreadRecoilBase) return;
        if (g_NoSpreadRecoilEnabled) {
            Speeden::TryApplyNoSpread(wep);
            Speeden::TryApplyNoRecoil(wep);
        } else {
            Speeden::TryRestoreAccuracy(wep);
            Speeden::TryRestoreRecoil(wep);
        }
    }

    // ---------------------------------------------------------------------
    // MAGNET AIM, v8 - NEW. "A normal aimbot... just a magnet aim toggle,
    // slider to control strength, wont go off behind walls, automatically
    // fire-gated." Reuses RecoverySuite::ProcessAimAssist() DIRECTLY - the
    // exact same function the full build's own magnet aim runs, not a
    // reimplementation. Three things made this safe to call from LITE:
    //   1. SafeCalls::SetLookAxes (what actually applies the nudge) is a
    //      RAW FIELD WRITE (pi->aTurn/aLookUp), not a scripted ProcessEvent
    //      call - confirmed by reading it - so it's safe from any thread,
    //      same class of call as everything else LITE already does.
    //   2. ProcessAimAssist()'s own ImGui::GetIO().DisplaySize call got the
    //      same g_FallbackScreenW/H fallback every other shared function
    //      needed (see VisibilityBoxes.h) - it would have crashed on first
    //      call otherwise, the exact bug class that's bitten this project
    //      three times already.
    //   3. It early-returns on `!VisibilityBoxes::reticleEnabled` - LITE was
    //      setting that false as a pure cosmetic optimisation (the full
    //      build's ImGui crosshair dot can never draw in LITE anyway, see
    //      DrawReticleDot's own comment), so it's now left true in
    //      InitThreadLite - harmless, and unblocks this.
    // "Automatically fire-gated": wires to bodyLockEnabled specifically
    // (the fire-gated variant - only pulls while g_RealLButtonHeld is true),
    // never bodyLockAlwaysOnEnabled. g_RealLButtonHeld itself used to be
    // hardcoded false forever in LITE ("no WndProc hook") - now genuinely
    // read from GetAsyncKeyState every frame in main_lite.cpp, since that's
    // exactly the same call LiteMenu's own PollInput() already relies on for
    // its UI clicks. Wall-safety is already built into ProcessAimAssist
    // itself (wallCheckEnabled/e.isVisible gates on target pick AND on
    // losing lock if they duck behind cover mid-hold) - nothing new needed.
    // ---------------------------------------------------------------------
    inline bool g_MagnetAimEnabled = false;

    inline void ApplyMagnetAimToggle(bool on) {
        g_MagnetAimEnabled = on;
        RecoverySuite::bodyLockEnabled = on;
        RecoverySuite::bodyLockAlwaysOnEnabled = false;
        RecoverySuite::headLockEnabled = false;
        RecoverySuite::headLockAlwaysOnEnabled = false;
    }
    inline void NudgeMagnetStrength(float delta) {
        RecoverySuite::aimLockStrength += delta;
        if (RecoverySuite::aimLockStrength < 0.02f) RecoverySuite::aimLockStrength = 0.02f;
        if (RecoverySuite::aimLockStrength > 1.0f)  RecoverySuite::aimLockStrength = 1.0f;
    }

    // ---------------------------------------------------------------------
    // HEALTH BAR RECOLOUR, v8 - NEW. Ports the full build's own
    // HealthBarColor feature into LITE, off by default. Confirmed safe to
    // call unmodified: the ONE ImGui::Get* call anywhere in HealthBarColor.h
    // (ImGui::GetIO() inside RunPositionProbe(), the diagnostic probe) is
    // only reachable via g_PendingProbe, which LITE never sets true - so
    // ProcessPending()/ApplyPass()/HidePass() are all clean, raw-field-write
    // paths exactly like everything else LITE already reuses.
    // ---------------------------------------------------------------------
    inline void TickHealthBarColorSafe() {
        __try { HealthBarColor::ProcessPending(); }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }

    // ---------------------------------------------------------------------
    // RESPAWN - unchanged. LITE's own small tracker, not
    // RecoverySuite::ProcessPendingSafeResets (drags in the subsystem sweep
    // LITE exists to avoid).
    // ---------------------------------------------------------------------
    inline bool g_AutoRespawn = true;
    inline bool g_PendingRespawnNow = false;
    inline ULONGLONG g_LastRespawnTryMs = 0;

    inline void TickRespawnSafe() {
        if (g_PendingRespawnNow) {
            g_PendingRespawnNow = false;
            SafeCalls::ServerSetReadyToPlay();
        }
        if (!g_AutoRespawn || !Globals::LocalPawn) return;
        ULONGLONG now = GetTickCount64();
        if (now - g_LastRespawnTryMs < 500) return;
        g_LastRespawnTryMs = now;
        int cur = 0, mx = 0;
        if (SafeCalls::GetPawnHealth(&cur, &mx) && cur <= 0) {
            SafeCalls::ServerSetReadyToPlay();
        }
    }

    // ---------------------------------------------------------------------
    // UNLOCKER - unchanged. Calls Unlocker::RunPass() directly, NOT
    // Unlocker::Tick() (Tick() calls ImGui::GetTime() unconditionally).
    // ---------------------------------------------------------------------
    inline bool g_UnlockerEnabled = true;
    inline ULONGLONG g_LastUnlockRunMs = 0;

    inline void TickUnlockerSafe() {
        if (!g_UnlockerEnabled) return;
        if (Globals::LocalPawn) return;
        ULONGLONG now = GetTickCount64();
        if (now - g_LastUnlockRunMs < 1000) return;
        g_LastUnlockRunMs = now;
        Unlocker::RunPass(false, false, false);
    }

    // ---------------------------------------------------------------------
    // GRAYSCALE - F10, v5 (was NUMPAD8; keys moved to F-keys, see file header).
    // ---------------------------------------------------------------------
    inline bool g_GrayscaleKeyWasDown = false;
    inline void PollGrayscaleKey() {
        if (!g_HudVisible) return;
        bool down = (GetAsyncKeyState(VK_F10) & 0x8000) != 0;
        if (down && !g_GrayscaleKeyWasDown) {
            RecoverySuite::ApplyGrayscale(!RecoverySuite::grayscaleOn);
        }
        g_GrayscaleKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // LEAVE MATCH - F11, v5 (was NUMPAD9).
    // ---------------------------------------------------------------------
    inline bool g_LeaveKeyWasDown = false;
    inline void PollLeaveMatchKey() {
        if (!g_HudVisible) return;
        bool down = (GetAsyncKeyState(VK_F11) & 0x8000) != 0;
        if (down && !g_LeaveKeyWasDown) {
            SafeCalls::RunConsoleCommand(L"disconnect");
        }
        g_LeaveKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // SHOW/HIDE - moved to F3 per explicit request, matching the full
    // build's own F3-hides-menu convention. g_HudVisible itself is declared
    // up in the SETTINGS block near the top of the file now (needed there
    // so PollCardKeys/etc, which are defined earlier in this file, can gate
    // on it too - see the v8 note on PollToggleKeys).
    // ---------------------------------------------------------------------
    inline bool g_HudKeyWasDown = false;
    inline void PollHudKey() {
        bool down = (GetAsyncKeyState(VK_F3) & 0x8000) != 0;
        if (down && !g_HudKeyWasDown) g_HudVisible = !g_HudVisible;
        g_HudKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // Toggle key polling - F1/F2/F5-F9 (v5), plus NUMPAD1/2 for the two new
    // v8 features (health bar recolour, magnet aim) - NUMPAD was freed up
    // entirely when everything else moved to F-keys, so no collision risk.
    // F3 is HUD show/hide (above), F4 stays avoided entirely, F10/F11 are
    // grayscale/leave match (above), F12 stays avoided (Steam's default
    // screenshot bind).
    //
    // v8: gated on g_HudVisible now - "when its closed, toggles DONT work
    // period." While the HUD is hidden, NOTHING can change a setting, by
    // key or by click (see DrawHud's collapsed branch) - only F3 (polled
    // separately, above) can bring it back. This is what stops a real
    // gameplay left-click (or, here, a stray key) from silently toggling
    // something while the panel is collapsed and you can't see it happen.
    // ---------------------------------------------------------------------
    inline bool g_ToggleKeyWasDown[9] = {};
    inline void PollToggleKeys() {
        if (!g_HudVisible) return;
        const int keys[9] = { VK_F1, VK_F2, VK_F5, VK_F6, VK_F7, VK_F8, VK_F9, VK_NUMPAD1, VK_NUMPAD2 };
        for (int i = 0; i < 9; i++) {
            bool down = (GetAsyncKeyState(keys[i]) & 0x8000) != 0;
            if (down && !g_ToggleKeyWasDown[i]) {
                switch (i) {
                    case 0: VisibilityBoxes::enabled = !VisibilityBoxes::enabled; break;
                    case 1: g_ShowNames = !g_ShowNames; break;
                    case 2: RecoverySuite::triggerBotEnabled = !RecoverySuite::triggerBotEnabled; break;
                    case 3: RecoverySuite::autoHealEnabled = !RecoverySuite::autoHealEnabled; break;
                    case 4: g_UnlockerEnabled = !g_UnlockerEnabled; break;
                    case 5: g_AutoRespawn = !g_AutoRespawn; break;
                    case 6: g_NoSpreadRecoilEnabled = !g_NoSpreadRecoilEnabled; break;
                    case 7: HealthBarColor::enabled = !HealthBarColor::enabled; break;
                    case 8: ApplyMagnetAimToggle(!g_MagnetAimEnabled); break;
                }
            }
            g_ToggleKeyWasDown[i] = down;
        }
    }

    // ---------------------------------------------------------------------
    // TUTORIAL PANEL, v8 - NEW. Toggled by the header's TUTORIAL button,
    // draws on the RIGHT side of the screen so it never overlaps the main
    // panel. Explains what each control does in plain language - a real
    // explainer, not a placeholder.
    // ---------------------------------------------------------------------
    inline void TutorialLine(SDK::UCanvas* canvas, float x, float& cy, float scale, const char* line) {
        DrawString(canvas, x, cy, line, kNameScale * scale, 210, 210, 220);
        cy += 15.0f * scale;
    }
    inline void DrawTutorialPanel(SDK::UCanvas* canvas, float mainPanelX, float mainPanelY, float mainPanelH) {
        if (!canvas) return;
        const ThemePalette& th = CurTheme();
        const float scale = g_UiScale;
        float panelW = 300.0f * scale;
        float px = (float)canvas->SizeX - panelW - 18.0f;
        float py = mainPanelY;
        float ph = mainPanelH;
        if (px < mainPanelX + 340.0f * scale) px = mainPanelX + 340.0f * scale; // never overlap the main panel on a narrow screen

        StyledFill(canvas, px, py, panelW, ph, th.bgR, th.bgG, th.bgB);
        StyledOutline(canvas, px, py, panelW, ph, th.accR, th.accG, th.accB);

        float cy = py + 12.0f * scale;
        float tx = px + 10.0f * scale;
        DrawString(canvas, tx, cy, T("HOW TO USE PHAROAH LITE", "COMO USAR PHAROAH LITE"), kSmallScale * scale * 0.9f, th.accR, th.accG, th.accB);
        cy += 22.0f * scale;

        TutorialLine(canvas, tx, cy, scale, T("F3 hides/shows this whole panel.", "F3 oculta/muestra este panel."));
        TutorialLine(canvas, tx, cy, scale, T("Every row: press its key OR click it.", "Cada fila: pulsa su tecla o haz clic."));
        cy += 6.0f * scale;
        TutorialLine(canvas, tx, cy, scale, T("WALLS - boxes on enemies/allies.", "MUROS - cajas en enemigos/aliados."));
        TutorialLine(canvas, tx, cy, scale, T("  Closer = red, far = purple.", "  Cerca = rojo, lejos = morado."));
        TutorialLine(canvas, tx, cy, scale, T("ENEMY NAMES - name above enemies,", "NOMBRES - nombre sobre enemigos,"));
        TutorialLine(canvas, tx, cy, scale, T("  rainbow dot = their ult is ready.", "  punto arcoiris = ult lista."));
        TutorialLine(canvas, tx, cy, scale, T("TRIGGER BOT - fires when the centre", "DISPARO AUTO - dispara si el centro"));
        TutorialLine(canvas, tx, cy, scale, T("  dot is on an enemy. Off by default.", "  esta en un enemigo. Apagado por defecto."));
        TutorialLine(canvas, tx, cy, scale, T("HEAL TRIGGER - holds heal on the", "CURACION AUTO - mantiene curar en"));
        TutorialLine(canvas, tx, cy, scale, T("  ally under your cursor.", "  el aliado bajo tu cursor."));
        TutorialLine(canvas, tx, cy, scale, T("UNLOCKER - unlocks cosmetics in", "DESBLOQUEADOR - desbloquea cosmeticos"));
        TutorialLine(canvas, tx, cy, scale, T("  the menu, only while not in a match.", "  en el menu, solo fuera de partida."));
        TutorialLine(canvas, tx, cy, scale, T("AUTO-RESPAWN - respawns you the", "REAPARICION AUTO - te reaparece al"));
        TutorialLine(canvas, tx, cy, scale, T("  instant you're eliminated.", "  instante de ser eliminado."));
        TutorialLine(canvas, tx, cy, scale, T("NO SPREAD/RECOIL - removes bullet", "SIN DISPERSION - quita dispersion"));
        TutorialLine(canvas, tx, cy, scale, T("  spread and recoil on your weapon.", "  y retroceso de tu arma."));
        TutorialLine(canvas, tx, cy, scale, T("GRAYSCALE - turns the game black", "ESCALA DE GRISES - pone el juego en"));
        TutorialLine(canvas, tx, cy, scale, T("  and white.", "  blanco y negro."));
        TutorialLine(canvas, tx, cy, scale, T("LEAVE MATCH - disconnects instantly,", "SALIR PARTIDA - desconecta al instante,"));
        TutorialLine(canvas, tx, cy, scale, T("  no confirmation.", "  sin confirmacion."));
        TutorialLine(canvas, tx, cy, scale, T("HEALTHBAR RECOLOR - recolours the", "RECOLOR BARRAS VIDA - recolorea las"));
        TutorialLine(canvas, tx, cy, scale, T("  game's own health bars.", "  barras de vida del juego."));
        TutorialLine(canvas, tx, cy, scale, T("MAGNET AIM - pulls your aim toward", "IMAN DE PUNTERIA - atrae tu punteria"));
        TutorialLine(canvas, tx, cy, scale, T("  an enemy while you hold fire.", "  hacia un enemigo mientras disparas."));
        TutorialLine(canvas, tx, cy, scale, T("  Never triggers through a wall.", "  Nunca funciona a traves de un muro."));
        cy += 6.0f * scale;
        TutorialLine(canvas, tx, cy, scale, T("CARDS - press NUM 1 to cycle how", "CARTAS - pulsa NUM 1 para elegir"));
        TutorialLine(canvas, tx, cy, scale, T("  many detected cards get spammed.", "  cuantas cartas detectadas se usan."));
        TutorialLine(canvas, tx, cy, scale, T("FIRE MODES - keys 6-9 cycle any", "MODOS DE DISPARO - teclas 6-9 cambian"));
        TutorialLine(canvas, tx, cy, scale, T("  ability with more than one mode.", "  cualquier habilidad con varios modos."));
    }

    // ---------------------------------------------------------------------
    // CURSOR ICON, v8 - NEW ("re-add the cursor icon... make it non-invasive
    // and you can toggle it off"). A small pink cross at the REAL cursor
    // position - off by default. Purely cosmetic; click hit-testing already
    // worked from the real cursor position with or without this being drawn.
    // ---------------------------------------------------------------------
    inline void DrawCursorIcon(SDK::UCanvas* canvas) {
        if (!canvas) return;
        float cx = g_Input.mouseX, cyc = g_Input.mouseY;
        const unsigned char r = 255, g = 90, b = 200;
        const float half = 6.0f * g_UiScale;
        Line(canvas, cx - half, cyc, cx + half, cyc, r, g, b, 200);
        Line(canvas, cx, cyc - half, cx, cyc + half, r, g, b, 200);
    }

    // ---------------------------------------------------------------------
    // THE HUD - always drawn (unless collapsed via F3/the X button, which
    // still leaves a clickable one-line reminder). Every row below both a
    // key AND a click.
    //
    // v6: darker, flatter monochrome background (was a lighter grey the
    // scanline fill made look striped/CRT - see FillRectLines' fix). Each
    // row gets its own accent colour on the LABEL TEXT so different
    // features are visually distinct at a glance, while the little key-box
    // itself stays strictly green=ON/red=OFF, never anything else - state
    // must always read the same way everywhere. X/+/- buttons in the header:
    // X does the same thing as F3, +/- call NudgeUiScale to resize the whole
    // panel.
    // ---------------------------------------------------------------------
    inline void DrawHud(SDK::UCanvas* canvas) {
        if (!canvas) return;
        PollInput();
        const ThemePalette& th = CurTheme();

        if (!g_HudVisible) {
            // v8: no longer click-to-reopen. That click hit-test was the
            // real bug behind "even after F3 to close, it will still click"
            // - the real cursor, invisible while playing, can genuinely
            // land on this rect during normal aim, and a shooting click
            // would silently reopen the HUD without the player noticing why.
            // F3 is now the ONLY way back in while collapsed - this rect is
            // purely a visual reminder, not a button.
            const float hw = 210.0f, hh = 26.0f;
            StyledFill(canvas, 16, 16, hw, hh, (unsigned char)(th.bgR / 2), (unsigned char)(th.bgG / 2), (unsigned char)(th.bgB / 2));
            StyledOutline(canvas, 16, 16, hw, hh, th.accR, th.accG, th.accB);
            DrawString(canvas, 22, 20, T("[F3] SHOW LITE", "[F3] MOSTRAR LITE"), kSmallScale, th.accR, th.accG, th.accB);
            return;
        }

        // v7: WIDER panel (was 260, long labels like "NO SPREAD/RECOIL" and
        // the old "HEAL TRIGGER BOT" overlapped the ON/OFF text on the
        // right - "the BOT goes on top of the ON/OFF"). Renamed that one
        // label too (HEAL TRIGGER BOT -> HEAL TRIGGER) as an extra margin
        // of safety, but the real fix is the wider row.
        const float scale = g_UiScale;
        // 340, not 320 - "NO SPREAD/RECOIL" (17 chars) was still overlapping
        // the ON/OFF text by a few pixels at 320 once the actual per-char
        // width is worked out exactly; this gives real clearance.
        const float x = 18.0f, y = 18.0f, w = 340.0f * scale;
        float cy = y + 10.0f * scale;
        const float rowH = 30.0f * scale;

        // v8: every term here matches an actual cy += below, one for one -
        // this formula was the real bug behind "fire modes isn't enveloped
        // in it" once before (missing terms), so each new row added this
        // round got its term added here in the same edit, not after.
        float fireTail = (g_FireModeSlotCount > 0) ? (g_FireModeSlotCount * 54.0f) : 20.0f;
        float unscaledH = 10.0f /*top pad*/ + 22.0f /*title*/ + 22.0f /*toolbar row 1*/ + 22.0f /*toolbar row 2*/
                         + 18.0f + 18.0f /*credits, 2 lines - bigger now, v9*/
                         + 10 * 30.0f /*10 toggle/action rows*/ + 20.0f /*magnet strength stepper*/
                         + 20.0f /*sep1*/ + 20.0f /*card hdr*/ + 62.0f /*card row*/
                         + 20.0f /*sep2*/ + 20.0f /*fire hdr*/ + fireTail + 16.0f /*bottom pad*/;
        float h = unscaledH * scale;

        // Themed panel chrome - was flat black with a flat white border
        // ("very very ugly"). Background/border/title now come from the
        // active theme (COLD/SLATE+ORANGE/SAND, cycled with the THEME
        // button). v9: background is slightly translucent now ("can you
        // make PHAROAH_LITE be slightly opacity, just a bit") - 228/255,
        // enough to see a hint of the game through it without hurting
        // legibility. The border/outline stays fully opaque so the panel's
        // edge still reads crisply.
        StyledFill(canvas, x - 10, y - 10, w + 20, h, th.bgR, th.bgG, th.bgB, 228);
        StyledOutline(canvas, x - 10, y - 10, w + 20, h, th.accR, th.accG, th.accB);

        DrawString(canvas, x, cy, "PHAROAH LITE", kFontScale * scale, th.accR, th.accG, th.accB);
        cy += 22.0f * scale;

        // Toolbar row 1: style/resize/close buttons, right-aligned. X is
        // BIGGER than the rest per explicit request (easier to hit/see).
        // Each gets its own colour hint now too (IconButton's tint params) -
        // X red, + green, - amber - independent of the active theme.
        const float btnH = 18.0f * scale, btnGap = 4.0f * scale;
        const float smallBtnW = 18.0f * scale, wideBtnW = 48.0f * scale;
        const float closeBtnW = 26.0f * scale, closeBtnH = 24.0f * scale;
        float bx = x + w - closeBtnW;
        if (IconButton(canvas, bx, cy - 3.0f * scale, closeBtnW, closeBtnH, "X", 255, 60, 60)) g_HudVisible = false;
        bx -= (smallBtnW + btnGap + (closeBtnW - smallBtnW));
        if (IconButton(canvas, bx, cy, smallBtnW, btnH, "+", 60, 220, 90)) NudgeUiScale(0.1f);
        bx -= (smallBtnW + btnGap);
        if (IconButton(canvas, bx, cy, smallBtnW, btnH, "-", 240, 170, 50)) NudgeUiScale(-0.1f);
        bx -= (wideBtnW + btnGap);
        if (IconButton(canvas, bx, cy, wideBtnW, btnH, T("THEME", "TEMA"))) CycleTheme();
        bx -= (wideBtnW + btnGap);
        if (IconButton(canvas, bx, cy, wideBtnW, btnH, T("SHAPE", "FORMA"))) g_ShapeSoft = !g_ShapeSoft;
        DrawString(canvas, x, cy + 2.0f * scale, T("PRESS F3 TO HIDE", "PULSA F3 PARA OCULTAR"), kNameScale * scale, th.textR, th.textG, th.textB);
        cy += 22.0f * scale;

        // Toolbar row 2: TUTORIAL (explainer panel, right side of screen),
        // EN/ES (language), a cursor-icon toggle - all header buttons, not
        // full rows, to keep them out of the main toggle list.
        bx = x + w - wideBtnW;
        if (IconButton(canvas, bx, cy, wideBtnW, btnH, g_ShowTutorial ? "TUT:ON" : "TUTORIAL")) g_ShowTutorial = !g_ShowTutorial;
        bx -= (wideBtnW + btnGap);
        if (IconButton(canvas, bx, cy, wideBtnW * 0.7f, btnH, g_Spanish ? "ES" : "EN", 90, 170, 255)) g_Spanish = !g_Spanish;
        bx -= (wideBtnW * 0.7f + btnGap);
        if (IconButton(canvas, bx, cy, wideBtnW * 0.8f, btnH, g_ShowCursorIcon ? "CURSOR:ON" : "CURSOR", 230, 90, 200)) g_ShowCursorIcon = !g_ShowCursorIcon;
        cy += 22.0f * scale;

        // Credits, per explicit request - rainbow name, smaller/lighter
        // troubleshooting credit underneath. v9: both made bigger per
        // explicit follow-up request.
        DrawRainbowString(canvas, x, cy, T("MADE BY: PRIMAL_MONKE", "CREADO POR: PRIMAL_MONKE"), kSmallScale * scale * 0.85f);
        cy += 18.0f * scale;
        DrawString(canvas, x, cy, T("TROUBLESHOOTING: SPIDER", "SOPORTE TECNICO: SPIDER"), kNameScale * scale * 1.4f, 150, 190, 220);
        cy += 18.0f * scale;

        if (ToggleRow(canvas, x, cy, w, "F1", T("WALLS", "MUROS"), VisibilityBoxes::enabled, 120, 205, 225))
            VisibilityBoxes::enabled = !VisibilityBoxes::enabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F2", T("ENEMY NAMES", "NOMBRES ENEMIGOS"), g_ShowNames, 130, 220, 190))
            g_ShowNames = !g_ShowNames;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F5", T("TRIGGER BOT", "DISPARO AUTO"), RecoverySuite::triggerBotEnabled, 255, 140, 95))
            RecoverySuite::triggerBotEnabled = !RecoverySuite::triggerBotEnabled;
        cy += rowH;
        // Renamed from "HEAL TRIGGER BOT" - "BOT" was overlapping the
        // ON/OFF text at this row width. Same feature, same key.
        if (ToggleRow(canvas, x, cy, w, "F6", T("HEAL TRIGGER", "CURACION AUTO"), RecoverySuite::autoHealEnabled, 110, 230, 120))
            RecoverySuite::autoHealEnabled = !RecoverySuite::autoHealEnabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F7", T("UNLOCKER", "DESBLOQUEADOR"), g_UnlockerEnabled, 195, 150, 250))
            g_UnlockerEnabled = !g_UnlockerEnabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F8", T("AUTO-RESPAWN", "REAPARICION AUTO"), g_AutoRespawn, 235, 215, 95))
            g_AutoRespawn = !g_AutoRespawn;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F9", T("NO SPREAD/RECOIL", "SIN DISPERSION"), g_NoSpreadRecoilEnabled, 255, 175, 95))
            g_NoSpreadRecoilEnabled = !g_NoSpreadRecoilEnabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "F10", T("GRAYSCALE", "ESCALA DE GRISES"), RecoverySuite::grayscaleOn, 155, 175, 205))
            RecoverySuite::ApplyGrayscale(!RecoverySuite::grayscaleOn);
        cy += rowH;
        if (ActionRow(canvas, x, cy, w, "F11", T("LEAVE MATCH", "SALIR PARTIDA"), 240, 115, 140))
            SafeCalls::RunConsoleCommand(L"disconnect");
        cy += rowH;
        // v8, both new: health bar recolour (ported from the full build,
        // off by default) and magnet aim (toggle + strength stepper below).
        if (ToggleRow(canvas, x, cy, w, "N1", T("HP BAR COLOR", "COLOR BARRA VIDA"), HealthBarColor::enabled, 90, 220, 230))
            HealthBarColor::enabled = !HealthBarColor::enabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "N2", T("MAGNET AIM", "IMAN DE PUNTERIA"), g_MagnetAimEnabled, 255, 120, 60))
            ApplyMagnetAimToggle(!g_MagnetAimEnabled);
        cy += rowH;

        // Strength stepper - a thin sub-row, no key/click-row of its own,
        // just two small +/- buttons and the current value. Simpler and
        // more reliable to hit-test than a drag slider with no ImGui.
        {
            const float stepBtn = 16.0f * scale;
            char strTxt[24];
            wsprintfA(strTxt, "%.2f", RecoverySuite::aimLockStrength);
            DrawString(canvas, x + 32.0f * scale, cy + 2.0f * scale, T("STRENGTH", "FUERZA"), kNameScale * scale, 200, 190, 210);
            float labelW = StringWidth(T("STRENGTH", "FUERZA"), kNameScale * scale);
            float vx = x + 32.0f * scale + labelW + 8.0f * scale;
            DrawString(canvas, vx, cy + 2.0f * scale, strTxt, kNameScale * scale, 235, 235, 240);
            float bxs = x + w - stepBtn;
            if (IconButton(canvas, bxs, cy, stepBtn, stepBtn, "+", 60, 220, 90)) NudgeMagnetStrength(0.05f);
            bxs -= (stepBtn + 4.0f * scale);
            if (IconButton(canvas, bxs, cy, stepBtn, stepBtn, "-", 240, 170, 50)) NudgeMagnetStrength(-0.05f);
        }
        cy += 20.0f * scale;

        cy += 8.0f * scale;
        Line(canvas, x, cy, x + w, cy, th.accR, th.accG, th.accB, 90);
        cy += 12.0f * scale;

        char cardHdr[32];
        wsprintfA(cardHdr, "%s (%d/5)", T("CARDS - NUM 1-5", "CARTAS - NUM 1-5"), g_CardSpamCount);
        // Slightly smaller than the other section headers - this one's text
        // got longer ("PRESS NUM 1" vs "PRESS 1") and would otherwise run
        // past the panel's right edge at the normal header scale.
        DrawString(canvas, x, cy, cardHdr, kSmallScale * scale * 0.78f, th.accR, th.accG, th.accB);
        cy += 20.0f * scale;
        DrawCardRow(canvas, x, cy);
        cy += 62.0f * scale;

        Line(canvas, x, cy, x + w, cy, th.accR, th.accG, th.accB, 90);
        cy += 12.0f * scale;

        DrawString(canvas, x, cy, T("FIRE MODES - CLICK TO SELECT", "MODOS DE DISPARO - HAZ CLIC"), kSmallScale * scale, th.accR, th.accG, th.accB);
        cy += 20.0f * scale;
        DrawFireModes(canvas, x, cy);

        if (g_ShowTutorial) DrawTutorialPanel(canvas, x - 10, y - 10, h);
        if (g_ShowCursorIcon) DrawCursorIcon(canvas);
    }

    // ---------------------------------------------------------------------
    // Call once per PostRender tick. LITE never installs a D3D11 hook, so
    // there is no "is the real hook already working" gate to check.
    // ---------------------------------------------------------------------
    inline bool g_LoggedFirstDraw = false;
    inline bool g_LoggedException = false;
    inline void Tick(SDK::UCanvas* canvas) {
        PollToggleKeys();
        PollHudKey();
        PollGrayscaleKey();
        PollLeaveMatchKey();
        PollCardKeys();
        __try {
            if (!g_LoggedFirstDraw) {
                g_LoggedFirstDraw = true;
                InitLog("[LiteMenu] HUD first drawn, canvas=%p.", (void*)canvas);
            }
            DrawWalls(canvas);
            DrawEnemyNames(canvas);
            DrawReticleDot(canvas);
            DrawHud(canvas);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            if (!g_LoggedException) {
                g_LoggedException = true;
                InitLog("[LiteMenu] EXCEPTION caught inside Tick() (code 0x%08lX).", GetExceptionCode());
            }
        }
    }
}
