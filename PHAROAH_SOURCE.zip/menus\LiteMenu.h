#pragma once
// ============================================================================
//  PHAROAH LITE  —  minimal standalone build for PaladinsSDK-master's PHAROAH
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
//
// The panel for PHAROAH LITE. Deliberately a SIBLING of CanvasMenu.h, not an
// edit to it - LITE is a genuinely separate build, and touching the file the
// full PHAROAH build already depends on risks breaking something proven, for
// zero benefit.
//
// Same drawing rule as CanvasMenu.h and RenderBoxesViaCanvas: Draw2DLine is
// the ONLY primitive used anywhere in this file - see the big comment at the
// top of CanvasMenu.h for why (DrawTile/DrawText crashed a real match twice).
//
// UI MODEL, v4. Fixes from live testing of v3:
//   - MOUSE CLICKS DID NOTHING. Root cause: ToggleRow/ActionRow only ever
//     drew - neither one ever called HitTestRect or checked clickedEdge.
//     The key-press path worked but was never actually verified by testing
//     before v3 shipped, and the click path was simply never wired at all.
//     Fixed: every row now does its own hit-test and returns whether it was
//     clicked, same shape as the old Checkbox()/Button() widgets.
//   - FONT WAS ILLEGIBLE. Every stroke is now drawn TWICE with a 1px
//     perpendicular offset (a bolded stroke), and the base scale is bigger.
//     Still Draw2DLine only - this is just two line calls instead of one
//     per segment.
//   - CURSOR REMOVED. The magenta crosshair was unwanted - gone entirely.
//   - HIDE/SHOW moved to F3, matching the full build's own F3-hides-menu
//     convention exactly (this one instance of an F-key is intentional -
//     it isn't a random function key, it's memory-compatible with the tool
//     people already know).
//   - CARDS REBUILT per explicit description: ONE key ('1') cycles a
//     spam-count 0->1->2->3->4->5->0..., filling that many boxes left to
//     right (plain colour fill, no digits drawn in the boxes). Clicking a
//     box individually still toggles just that slot, as a bonus - the key
//     is the primary/expected way to use it.
//   - WALLS REBUILT as LITE's own function (DrawWalls, below) instead of
//     calling VisibilityBoxes::RenderBoxesViaCanvas - needed real distance-
//     based colour (red close -> pink mid -> purple far) and a thicker
//     stroke, neither of which the shared function does or should be
//     changed to do (it's shared with the full build's fallback). Reuses
//     the SAME gather cache (g_CachedGather) enemy names already read, so
//     this costs nothing extra to compute.
//   - Enemy name colour changed to white.
//
// KEYS: NUMPAD1-9 + NUMPAD0 for everything except HUD show/hide (F3, see
// above), plus '1' for the card cycle and 6-9 for fire modes (unchanged).
//
// WHAT THIS FILE DOES NOT DO: install a D3D11/kiero hook, create an ImGui
// context, or call into any of PHAROAH's periodic background subsystems
// (HealthBarColor, MeshSkin, DevSkin, skin scanning, the bone/skeleton
// system, RunSafeThreadSubsystems as a whole, Speeden::Update as a whole).
//
// *** EVERY NEW FUNCTION ADDED HERE MUST BE CHECKED FOR ImGui::GetIO() /
// ImGui::GetTime() / ImGui::GetBackgroundDrawList() BEFORE IT SHIPS. ***
// LITE has no ImGui context, ever. Those calls assert/crash with none, and
// it is NOT an SEH exception - __try/__except does not catch it. Grep any
// shared function you're about to call for "ImGui::Get" before wiring it
// in, every single time - this has already shipped broken twice.

#include "globals.h"
#include "ext/kiero/kiero.h"
#include "menus/VisibilityBoxes.h"
#include "menus/DirectFire.h"
#include "menus/RecoverySuite.h"
#include "menus/FireModeMenu.h"
#include "menus/Unlocker.h"
#include "menus/Speeden.h"
#include "Utils/SafeCalls.h"
#include <Windows.h>
#include <cctype>
#include <cmath>

namespace LiteMenu {

    // ---------------------------------------------------------------------
    // INPUT - polled directly against the real game window, independent of
    // any render hook. Works while the game is paused/in a menu, same as
    // any other foreground-independent GetAsyncKeyState/GetCursorPos call.
    // ---------------------------------------------------------------------
    struct InputState {
        float mouseX = 0.0f, mouseY = 0.0f;
        bool mouseDown = false;
        bool clickedEdge = false;
    };
    inline InputState g_Input;

    inline void PollInput() {
        static bool wasDown = false;
        HWND wnd = (HWND)kiero::findRealGameWindow();
        if (!wnd) { g_Input = InputState(); wasDown = false; return; }
        POINT p{};
        GetCursorPos(&p);
        ScreenToClient(wnd, &p);
        g_Input.mouseX = (float)p.x;
        g_Input.mouseY = (float)p.y;
        bool down = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        g_Input.mouseDown = down;
        g_Input.clickedEdge = down && !wasDown;
        wasDown = down;
    }
    inline bool HitTestRect(float x, float y, float w, float h) {
        return g_Input.mouseX >= x && g_Input.mouseX <= x + w &&
               g_Input.mouseY >= y && g_Input.mouseY <= y + h;
    }

    // ---------------------------------------------------------------------
    // DRAWING PRIMITIVES - Draw2DLine only.
    // ---------------------------------------------------------------------
    inline void Line(SDK::UCanvas* canvas, float x0, float y0, float x1, float y1,
                      unsigned char r, unsigned char g, unsigned char b, unsigned char a = 255) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = a;
        canvas->Draw2DLine(x0, y0, x1, y1, c);
    }

    inline void Outline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                         unsigned char r, unsigned char g, unsigned char b) {
        Line(canvas, x,     y,     x + w, y,     r, g, b);
        Line(canvas, x + w, y,     x + w, y + h, r, g, b);
        Line(canvas, x + w, y + h, x,     y + h, r, g, b);
        Line(canvas, x,     y + h, x,     y,     r, g, b);
    }

    // Nested outlines growing outward - the only way to get a "thick" border
    // out of a primitive with no width parameter.
    inline void ThickOutline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                              unsigned char r, unsigned char g, unsigned char b, int thickness) {
        for (int o = 0; o < thickness; o++) {
            Outline(canvas, x - o, y - o, w + o * 2.0f, h + o * 2.0f, r, g, b);
        }
    }

    inline void FillRectLines(SDK::UCanvas* canvas, float x, float y, float w, float h,
                               unsigned char r, unsigned char g, unsigned char b) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = 255;
        for (float row = y; row < y + h; row += 2.0f) {
            canvas->Draw2DLine(x, row, x + w, row, c);
        }
    }

    namespace Font {
        struct Seg { float x0, y0, x1, y1; };
        inline int Glyph(char ch, Seg* out) {
            switch (ch) {
            case 'A': out[0]={0,4,0,1}; out[1]={0,1,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,4}; out[4]={0,2,2,2}; return 5;
            case 'B': out[0]={0,0,0,4}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={2,2,2,4}; out[5]={2,4,0,4}; return 6;
            case 'C': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; return 3;
            case 'D': out[0]={0,0,0,4}; out[1]={0,0,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,3}; out[4]={2,3,1,4}; out[5]={1,4,0,4}; return 6;
            case 'E': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={0,2,2,2}; return 4;
            case 'F': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,2,2,2}; return 3;
            case 'G': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,1,2}; return 5;
            case 'H': out[0]={0,0,0,4}; out[1]={2,0,2,4}; out[2]={0,2,2,2}; return 3;
            case 'I': out[0]={0,0,2,0}; out[1]={1,0,1,4}; out[2]={0,4,2,4}; return 3;
            case 'J': out[0]={2,0,2,3}; out[1]={2,3,1,4}; out[2]={1,4,0,3}; return 3;
            case 'K': out[0]={0,0,0,4}; out[1]={2,0,0,2}; out[2]={0,2,2,4}; return 3;
            case 'L': out[0]={0,0,0,4}; out[1]={0,4,2,4}; return 2;
            case 'M': out[0]={0,4,0,0}; out[1]={0,0,1,2}; out[2]={1,2,2,0}; out[3]={2,0,2,4}; return 4;
            case 'N': out[0]={0,4,0,0}; out[1]={0,0,2,4}; out[2]={2,4,2,0}; return 3;
            case 'O': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case 'P': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; return 4;
            case 'Q': out[0]={0,0,2,0}; out[1]={2,0,2,3}; out[2]={2,3,0,3}; out[3]={0,3,0,0}; out[4]={1,3,2,4}; return 5;
            case 'R': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={0,2,2,4}; return 5;
            case 'S': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case 'T': out[0]={0,0,2,0}; out[1]={1,0,1,4}; return 2;
            case 'U': out[0]={0,0,0,4}; out[1]={0,4,2,4}; out[2]={2,4,2,0}; return 3;
            case 'V': out[0]={0,0,1,4}; out[1]={2,0,1,4}; return 2;
            case 'W': out[0]={0,0,0,4}; out[1]={0,4,1,2}; out[2]={1,2,2,4}; out[3]={2,4,2,0}; return 4;
            case 'X': out[0]={0,0,2,4}; out[1]={2,0,0,4}; return 2;
            case 'Y': out[0]={0,0,1,2}; out[1]={2,0,1,2}; out[2]={1,2,1,4}; return 3;
            case 'Z': out[0]={0,0,2,0}; out[1]={2,0,0,4}; out[2]={0,4,2,4}; return 3;
            case '0': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case '1': out[0]={1,0,1,4}; return 1;
            case '2': out[0]={0,0,2,0}; out[1]={2,0,2,2}; out[2]={2,2,0,2}; out[3]={0,2,0,4}; out[4]={0,4,2,4}; return 5;
            case '3': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,2,2,2}; return 4;
            case '4': out[0]={0,0,0,2}; out[1]={0,2,2,2}; out[2]={2,0,2,4}; return 3;
            case '5': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case '6': out[0]={1,0,0,1}; out[1]={0,1,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,0,2}; return 5;
            case '7': out[0]={0,0,2,0}; out[1]={2,0,1,4}; return 2;
            case '8': out[0]={0,0,2,0}; out[1]={0,0,0,4}; out[2]={2,0,2,4}; out[3]={0,4,2,4}; out[4]={0,2,2,2}; return 5;
            case '9': out[0]={0,0,2,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,0,2,4}; return 4;
            case '-': out[0]={0,2,2,2}; return 1;
            case '/': out[0]={0,4,2,0}; return 1;
            case '?': out[0]={0,1,1,0}; out[1]={1,0,2,1}; out[2]={2,1,1,2}; out[3]={1,3,1,3}; return 4;
            default: return 0;
            }
        }
    }

    // BOLD: every segment is drawn twice, offset ~1px perpendicular to its
    // own direction. Still Draw2DLine only - just two calls instead of one.
    // This is the fix for "the font is super hard to read."
    inline void DrawChar(SDK::UCanvas* canvas, char ch, float x, float y, float scale,
                          unsigned char r, unsigned char g, unsigned char b) {
        Font::Seg segs[8];
        int n = Font::Glyph((char)toupper((unsigned char)ch), segs);
        for (int i = 0; i < n; i++) {
            float x0 = x + segs[i].x0 * scale, y0 = y + segs[i].y0 * scale;
            float x1 = x + segs[i].x1 * scale, y1 = y + segs[i].y1 * scale;
            Line(canvas, x0, y0, x1, y1, r, g, b);
            float dx = x1 - x0, dy = y1 - y0;
            float len = sqrtf(dx * dx + dy * dy);
            if (len > 0.01f) {
                float nx = -dy / len * 1.15f, ny = dx / len * 1.15f;
                Line(canvas, x0 + nx, y0 + ny, x1 + nx, y1 + ny, r, g, b);
            }
        }
    }

    inline float DrawString(SDK::UCanvas* canvas, float x, float y, const char* text, float scale,
                             unsigned char r, unsigned char g, unsigned char b) {
        float cursor = x;
        for (const char* p = text; *p; p++) {
            DrawChar(canvas, *p, cursor, y, scale, r, g, b);
            cursor += 4.3f * scale;
        }
        return cursor - x;
    }
    inline float StringWidth(const char* text, float scale) {
        float n = 0; for (const char* p = text; *p; p++) n += 1.0f;
        return n * 4.3f * scale;
    }

    // Bumped up from v3 (was 3.0) - the single biggest legibility lever
    // besides the bold stroke above.
    const float kFontScale = 4.2f;
    const float kSmallScale = 3.2f; // the smallest anything is ever drawn at now - v3 went down to 0.55-0.7x of a smaller base, which was unreadable

    // "[KEY] LABEL ............. ON/OFF" - key badge, label, checkmark, all
    // in one fixed-format row. BOTH the key AND clicking the row toggle it -
    // v3 only had the key wired, mouse clicks silently did nothing.
    // Returns true the frame it was clicked.
    inline bool ToggleRow(SDK::UCanvas* canvas, float x, float y, float w, const char* keyLabel,
                           const char* label, bool value) {
        bool hovered = HitTestRect(x, y, w, 26.0f);
        bool clicked = hovered && g_Input.clickedEdge;

        unsigned char br = hovered ? 230 : 190, bg = hovered ? 230 : 190, bb = hovered ? 235 : 195;
        Outline(canvas, x, y, 22, 22, br, bg, bb);
        DrawString(canvas, x + 3, y + 3, keyLabel, kSmallScale * 0.6f, 255, 210, 110);
        DrawString(canvas, x + 32, y + 3, label, kSmallScale, 230, 230, 235);
        const char* state = value ? "ON" : "OFF";
        float sw = StringWidth(state, kSmallScale);
        DrawString(canvas, x + w - sw, y + 3, state, kSmallScale,
                   value ? 90 : 190, value ? 230 : 190, value ? 120 : 195);
        if (value) {
            Line(canvas, x + 4, y + 12, x + 9, y + 17, 90, 230, 120);
            Line(canvas, x + 9, y + 17, x + 18, y + 5,  90, 230, 120);
        }
        if (hovered) ThickOutline(canvas, x - 2, y - 2, w + 4, 26.0f, 90, 160, 230, 1);
        return clicked;
    }

    // Same shape, no ON/OFF - for one-shot actions (LEAVE MATCH).
    inline bool ActionRow(SDK::UCanvas* canvas, float x, float y, float w, const char* keyLabel, const char* label) {
        bool hovered = HitTestRect(x, y, w, 26.0f);
        bool clicked = hovered && g_Input.clickedEdge;
        Outline(canvas, x, y, 22, 22, 230, 150, 130);
        DrawString(canvas, x + 3, y + 3, keyLabel, kSmallScale * 0.6f, 255, 210, 110);
        DrawString(canvas, x + 32, y + 3, label, kSmallScale, 240, 200, 180);
        if (hovered) ThickOutline(canvas, x - 2, y - 2, w + 4, 26.0f, 230, 120, 100, 1);
        return clicked;
    }

    // ========================================================================
    // CARDS - rebuilt per explicit description: ONE key ('1') cycles a
    // spam-count 0..5, filling that many boxes left to right with plain
    // colour (no digits drawn inside them). Individually clicking a box is
    // still wired as a bonus, toggling just that slot - '1' is the primary,
    // expected way to use it. DirectFire.h's existing g_Five/g_CardSpam/
    // g_AutoSweep machinery is completely unchanged - this only changes how
    // it's driven and drawn.
    // ========================================================================
    inline int  g_CardSpamCount = 0;
    inline bool g_CardCycleKeyWasDown = false;

    inline void PollCardCycleKey() {
        bool down = (GetAsyncKeyState('1') & 0x8000) != 0;
        if (down && !g_CardCycleKeyWasDown) {
            g_CardSpamCount = (g_CardSpamCount + 1) % 6; // 0,1,2,3,4,5,0,...
            for (int i = 0; i < 5; i++) DirectFire::g_CardSpam[i] = (i < g_CardSpamCount);
        }
        g_CardCycleKeyWasDown = down;
    }

    inline void DrawCardRow(SDK::UCanvas* canvas, float x, float y) {
        const float boxSize = 34.0f, gap = 8.0f;
        for (int i = 0; i < 5; i++) {
            float bx = x + i * (boxSize + gap);
            bool ready = DirectFire::g_Five[i].dev != nullptr;
            bool spamming = DirectFire::g_CardSpam[i];

            if (HitTestRect(bx, y, boxSize, boxSize) && g_Input.clickedEdge) {
                DirectFire::g_CardSpam[i] = !DirectFire::g_CardSpam[i];
                // Resync the counter to match, so the '1' key picks up from
                // here rather than fighting a manual click on the next press.
                int n = 0; for (int k = 0; k < 5; k++) if (DirectFire::g_CardSpam[k]) n++;
                g_CardSpamCount = n;
            }

            unsigned char r = ready ? 70 : 50, g = ready ? 70 : 50, b = ready ? 75 : 50;
            if (spamming) { r = 90; g = 230; b = 120; }
            if (spamming) FillRectLines(canvas, bx, y, boxSize, boxSize, r / 3, g / 3, b / 3);
            ThickOutline(canvas, bx, y, boxSize, boxSize, r, g, b, spamming ? 2 : 1);
        }
    }

    // ========================================================================
    // FIRE MODES - unchanged detection/backend from before (see the big
    // comment above RebuildFireModeSlots), just bigger/bolder drawing.
    // ========================================================================
    struct FireModeSlot {
        SDK::ATgDevice* dev = nullptr;
        int modeCount = 0;
        int key = 0;
        char label[24] = {};
    };
    static const int kMaxFireModeSlots = 4;
    inline FireModeSlot g_FireModeSlots[kMaxFireModeSlots];
    inline int  g_FireModeSlotCount = 0;
    inline void* g_FireModeSweptPawn = nullptr;
    inline ULONGLONG g_LastFireModeRescanMs = 0;
    inline bool g_FireModeKeyWasDown[kMaxFireModeSlots] = {};

    inline void RebuildFireModeSlots() {
        g_FireModeSlotCount = 0;
        for (int i = 0; i < DirectFire::g_DevCount && g_FireModeSlotCount < kMaxFireModeSlots; i++) {
            const DirectFire::DevRow& row = DirectFire::g_Dev[i];
            if (!row.dev || row.isCard) continue;
            int count = 0;
            __try { count = (int)row.dev->m_FireMode.Num(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
            if (count <= 1) continue;

            FireModeSlot& slot = g_FireModeSlots[g_FireModeSlotCount];
            slot.dev = row.dev;
            slot.modeCount = count;
            slot.key = '6' + g_FireModeSlotCount;
            lstrcpynA(slot.label, row.label[0] ? row.label : row.name, sizeof(slot.label));
            g_FireModeSlotCount++;
        }
    }

    // Detection is retriggered on pawn change (immediately) or every 4s -
    // this is a real GObjects sweep (hundreds of thousands of objects), see
    // DirectFire::g_PendingDevSweep, so it is NOT run every frame on purpose.
    inline void TickFireModesSafe() {
        if (Globals::LocalPawn != g_FireModeSweptPawn) {
            g_FireModeSweptPawn = Globals::LocalPawn;
            DirectFire::g_PendingDevSweep = true;
            g_LastFireModeRescanMs = GetTickCount64();
            return;
        }
        ULONGLONG now = GetTickCount64();
        if (now - g_LastFireModeRescanMs > 4000) {
            g_LastFireModeRescanMs = now;
            DirectFire::g_PendingDevSweep = true;
        }
        RebuildFireModeSlots();
    }

    inline void PollFireModeKeys() {
        for (int i = 0; i < g_FireModeSlotCount; i++) {
            bool down = (GetAsyncKeyState(g_FireModeSlots[i].key) & 0x8000) != 0;
            if (down && !g_FireModeKeyWasDown[i]) {
                SDK::ATgDevice* d = g_FireModeSlots[i].dev;
                if (d) {
                    int cur = 0;
                    __try { cur = (int)d->CurrentFireMode; } __except (EXCEPTION_EXECUTE_HANDLER) { cur = 0; }
                    int next = (cur + 1) % g_FireModeSlots[i].modeCount;
                    ApplyFireModeRaw(d, next);
                }
            }
            g_FireModeKeyWasDown[i] = down;
        }
    }

    inline void DrawFireModes(SDK::UCanvas* canvas, float x, float y) {
        if (g_FireModeSlotCount == 0) {
            DrawString(canvas, x, y, "SCANNING FOR ABILITIES...", kSmallScale, 200, 170, 130);
            return;
        }
        float cy = y;
        for (int i = 0; i < g_FireModeSlotCount; i++) {
            const FireModeSlot& slot = g_FireModeSlots[i];
            Outline(canvas, x, cy, 22, 22, 210, 210, 215);
            char keyCh[2] = { (char)slot.key, 0 };
            DrawString(canvas, x + 5, cy + 3, keyCh, kSmallScale, 255, 210, 110);
            DrawString(canvas, x + 30, cy + 3, slot.label, kSmallScale * 0.85f, 225, 225, 230);
            cy += 26.0f;

            int cur = 0;
            __try { cur = slot.dev ? (int)slot.dev->CurrentFireMode : 0; } __except (EXCEPTION_EXECUTE_HANDLER) { cur = 0; }
            for (int m = 0; m < slot.modeCount && m < 8; m++) {
                float px = x + m * 28.0f;
                bool active = (m == cur);
                if (HitTestRect(px, cy, 22, 22) && g_Input.clickedEdge) ApplyFireModeRaw(slot.dev, m);
                if (active) FillRectLines(canvas, px, cy, 22, 22, 20, 60, 25);
                ThickOutline(canvas, px, cy, 22, 22, active ? 90 : 170, active ? 230 : 170, active ? 120 : 175, active ? 2 : 1);
            }
            cy += 28.0f;
        }
    }

    // ========================================================================
    // WALLS - LITE's OWN drawing (not VisibilityBoxes::RenderBoxesViaCanvas -
    // that function is shared with the full build's fallback and deliberately
    // untouched; this needed real distance colour + thickness neither has).
    // Reuses g_CachedGather (already populated every frame for the trigger
    // bot / enemy names) instead of doing its own separate pawn walk.
    // Colour: red up close, through pink, to purple far away. Distances are
    // in Unreal units (~52.5 per metre, same conversion VisibilityBoxes.h
    // uses elsewhere) - tune kCloseUnits/kFarUnits if the bands feel off in
    // practice.
    // ========================================================================
    inline void DistanceColor(float dist, unsigned char& r, unsigned char& g, unsigned char& b) {
        const float kCloseUnits = 800.0f;   // ~15m - full red at or inside this
        const float kMidUnits   = 2200.0f;  // ~42m - pink
        const float kFarUnits   = 4500.0f;  // ~86m and beyond - full purple
        if (dist <= kMidUnits) {
            float t = (dist - kCloseUnits) / (kMidUnits - kCloseUnits);
            if (t < 0.0f) t = 0.0f; if (t > 1.0f) t = 1.0f;
            r = 255;
            g = (unsigned char)(40.0f  + (80.0f  - 40.0f)  * t);
            b = (unsigned char)(40.0f  + (180.0f - 40.0f)  * t);
        } else {
            float t = (dist - kMidUnits) / (kFarUnits - kMidUnits);
            if (t < 0.0f) t = 0.0f; if (t > 1.0f) t = 1.0f;
            r = (unsigned char)(255.0f + (150.0f - 255.0f) * t);
            g = (unsigned char)(80.0f  + (60.0f  - 80.0f)  * t);
            b = (unsigned char)(180.0f + (220.0f - 180.0f) * t);
        }
    }

    inline void DrawWalls(SDK::UCanvas* canvas) {
        if (!canvas || !VisibilityBoxes::enabled) return;
        const VisibilityBoxes::GatherResult& g = VisibilityBoxes::g_CachedGather;
        if (!g.ok) return;

        VisibilityBoxes::PlainVec fwd, right, up;
        VisibilityBoxes::RotatorToVectors(g.camPitch, g.camYaw, fwd, right, up);
        ImVec2 screenSize = { (float)canvas->SizeX, (float)canvas->SizeY };

        for (int i = 0; i < g.count; i++) {
            const VisibilityBoxes::BoxEntry& e = g.entries[i];
            if (e.kind != VisibilityBoxes::BoxKind::Enemy) continue;

            VisibilityBoxes::PlainVec top{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight };
            VisibilityBoxes::PlainVec bot{ e.worldPos.x, e.worldPos.y, e.worldPos.z - e.collisionHeight };
            ImVec2 screenTop, screenBot;
            if (!VisibilityBoxes::WorldToScreen(top, g.camLoc, fwd, right, up, g.fov, screenSize.x, screenSize.y, screenTop)) continue;
            if (!VisibilityBoxes::WorldToScreen(bot, g.camLoc, fwd, right, up, g.fov, screenSize.x, screenSize.y, screenBot)) continue;

            float boxHeight = screenBot.y - screenTop.y;
            if (boxHeight < 4.0f || boxHeight > 2000.0f) continue;
            float boxWidth = (e.collisionHeight > 0.1f) ? boxHeight * (e.collisionRadius / e.collisionHeight) : boxHeight * 0.5f;
            float left = screenTop.x - boxWidth * 0.5f;

            float dx = e.worldPos.x - g.camLoc.x, dy = e.worldPos.y - g.camLoc.y, dz = e.worldPos.z - g.camLoc.z;
            float dist = sqrtf(dx * dx + dy * dy + dz * dz);
            unsigned char r, gg, b;
            DistanceColor(dist, r, gg, b);

            ThickOutline(canvas, left, screenTop.y, boxWidth, boxHeight, r, gg, b, 2);
        }
    }

    // ========================================================================
    // ENEMY NAMES - white per explicit request. Same gather cache as walls.
    // ========================================================================
    inline bool g_ShowNames = true;

    inline void DrawEnemyNames(SDK::UCanvas* canvas) {
        if (!canvas || !g_ShowNames) return;
        const VisibilityBoxes::GatherResult& g = VisibilityBoxes::g_CachedGather;
        if (!g.ok) return;

        VisibilityBoxes::PlainVec fwd, right, up;
        VisibilityBoxes::RotatorToVectors(g.camPitch, g.camYaw, fwd, right, up);
        ImVec2 screenSize = { (float)canvas->SizeX, (float)canvas->SizeY };

        for (int i = 0; i < g.count; i++) {
            const VisibilityBoxes::BoxEntry& e = g.entries[i];
            if (e.kind != VisibilityBoxes::BoxKind::Enemy) continue;
            if (!e.championName[0]) continue;

            VisibilityBoxes::PlainVec top{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight + 16.0f };
            ImVec2 screen;
            if (!VisibilityBoxes::WorldToScreen(top, g.camLoc, fwd, right, up, g.fov, screenSize.x, screenSize.y, screen))
                continue;

            float w = StringWidth(e.championName, kSmallScale);
            DrawString(canvas, screen.x - w / 2.0f, screen.y, e.championName, kSmallScale, 255, 255, 255);
        }
    }

    // ---------------------------------------------------------------------
    // NO-SPREAD / NO-RECOIL - unchanged from before. Six raw struct-field
    // writes (m_AccuracySettings/m_RecoilSettings), zero ImGui, zero
    // scripted calls - see Speeden.h. Combined into one toggle.
    // ---------------------------------------------------------------------
    inline bool g_NoSpreadRecoilEnabled = true;
    inline SDK::ATgDevice* g_SpreadRecoilDevice = nullptr;
    inline bool g_HaveSpreadRecoilBase = false;

    inline void TickNoSpreadRecoil() {
        SDK::ATgDevice* wep = Globals::LocalWeapon;
        if (!wep) { g_HaveSpreadRecoilBase = false; g_SpreadRecoilDevice = nullptr; return; }
        if (wep != g_SpreadRecoilDevice || !g_HaveSpreadRecoilBase) {
            g_SpreadRecoilDevice = wep;
            g_HaveSpreadRecoilBase = Speeden::TryCaptureAccuracy(wep) && Speeden::TryCaptureRecoil(wep);
        }
        if (!g_HaveSpreadRecoilBase) return;
        if (g_NoSpreadRecoilEnabled) {
            Speeden::TryApplyNoSpread(wep);
            Speeden::TryApplyNoRecoil(wep);
        } else {
            Speeden::TryRestoreAccuracy(wep);
            Speeden::TryRestoreRecoil(wep);
        }
    }

    // ---------------------------------------------------------------------
    // RESPAWN - unchanged. LITE's own small tracker, not
    // RecoverySuite::ProcessPendingSafeResets (drags in the subsystem sweep
    // LITE exists to avoid).
    // ---------------------------------------------------------------------
    inline bool g_AutoRespawn = true;
    inline bool g_PendingRespawnNow = false;
    inline ULONGLONG g_LastRespawnTryMs = 0;

    inline void TickRespawnSafe() {
        if (g_PendingRespawnNow) {
            g_PendingRespawnNow = false;
            SafeCalls::ServerSetReadyToPlay();
        }
        if (!g_AutoRespawn || !Globals::LocalPawn) return;
        ULONGLONG now = GetTickCount64();
        if (now - g_LastRespawnTryMs < 500) return;
        g_LastRespawnTryMs = now;
        int cur = 0, mx = 0;
        if (SafeCalls::GetPawnHealth(&cur, &mx) && cur <= 0) {
            SafeCalls::ServerSetReadyToPlay();
        }
    }

    // ---------------------------------------------------------------------
    // UNLOCKER - unchanged. Calls Unlocker::RunPass() directly, NOT
    // Unlocker::Tick() (Tick() calls ImGui::GetTime() unconditionally).
    // ---------------------------------------------------------------------
    inline bool g_UnlockerEnabled = true;
    inline ULONGLONG g_LastUnlockRunMs = 0;

    inline void TickUnlockerSafe() {
        if (!g_UnlockerEnabled) return;
        if (Globals::LocalPawn) return;
        ULONGLONG now = GetTickCount64();
        if (now - g_LastUnlockRunMs < 1000) return;
        g_LastUnlockRunMs = now;
        Unlocker::RunPass(false, false, false);
    }

    // ---------------------------------------------------------------------
    // GRAYSCALE (NUMPAD8) - unchanged.
    // ---------------------------------------------------------------------
    inline bool g_GrayscaleKeyWasDown = false;
    inline void PollGrayscaleKey() {
        bool down = (GetAsyncKeyState(VK_NUMPAD8) & 0x8000) != 0;
        if (down && !g_GrayscaleKeyWasDown) {
            RecoverySuite::ApplyGrayscale(!RecoverySuite::grayscaleOn);
        }
        g_GrayscaleKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // LEAVE MATCH (NUMPAD9) - unchanged.
    // ---------------------------------------------------------------------
    inline bool g_LeaveKeyWasDown = false;
    inline void PollLeaveMatchKey() {
        bool down = (GetAsyncKeyState(VK_NUMPAD9) & 0x8000) != 0;
        if (down && !g_LeaveKeyWasDown) {
            SafeCalls::RunConsoleCommand(L"disconnect");
        }
        g_LeaveKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // SHOW/HIDE - moved to F3 per explicit request, matching the full
    // build's own F3-hides-menu convention. The collapsed hint is itself
    // clickable too (not just a key), same click-fix as everything else.
    // ---------------------------------------------------------------------
    inline bool g_HudVisible = true;
    inline bool g_HudKeyWasDown = false;
    inline void PollHudKey() {
        bool down = (GetAsyncKeyState(VK_F3) & 0x8000) != 0;
        if (down && !g_HudKeyWasDown) g_HudVisible = !g_HudVisible;
        g_HudKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // Toggle key polling - NUMPAD1-7. Mirrors DirectFire::TickCards' pattern.
    // ---------------------------------------------------------------------
    inline bool g_ToggleKeyWasDown[7] = {};
    inline void PollToggleKeys() {
        const int keys[7] = { VK_NUMPAD1, VK_NUMPAD2, VK_NUMPAD3, VK_NUMPAD4, VK_NUMPAD5, VK_NUMPAD6, VK_NUMPAD7 };
        for (int i = 0; i < 7; i++) {
            bool down = (GetAsyncKeyState(keys[i]) & 0x8000) != 0;
            if (down && !g_ToggleKeyWasDown[i]) {
                switch (i) {
                    case 0: VisibilityBoxes::enabled = !VisibilityBoxes::enabled; break;
                    case 1: g_ShowNames = !g_ShowNames; break;
                    case 2: RecoverySuite::triggerBotEnabled = !RecoverySuite::triggerBotEnabled; break;
                    case 3: RecoverySuite::autoHealEnabled = !RecoverySuite::autoHealEnabled; break;
                    case 4: g_UnlockerEnabled = !g_UnlockerEnabled; break;
                    case 5: g_AutoRespawn = !g_AutoRespawn; break;
                    case 6: g_NoSpreadRecoilEnabled = !g_NoSpreadRecoilEnabled; break;
                }
            }
            g_ToggleKeyWasDown[i] = down;
        }
    }

    // ---------------------------------------------------------------------
    // THE HUD - always drawn (unless collapsed via F3, which still leaves a
    // clickable one-line reminder). Every row below both a key AND a click.
    // ---------------------------------------------------------------------
    inline void DrawHud(SDK::UCanvas* canvas) {
        if (!canvas) return;
        PollInput();

        if (!g_HudVisible) {
            const float hw = 210.0f, hh = 26.0f;
            FillRectLines(canvas, 16, 16, hw, hh, 18, 18, 20);
            Outline(canvas, 16, 16, hw, hh, 130, 130, 140);
            DrawString(canvas, 22, 20, "[F3] SHOW LITE", kSmallScale, 255, 215, 120);
            if (HitTestRect(16, 16, hw, hh) && g_Input.clickedEdge) g_HudVisible = true;
            return;
        }

        const float x = 18.0f, y = 18.0f, w = 260.0f;
        float cy = y + 10.0f;
        const float rowH = 30.0f;

        float h = 40.0f + 8 * rowH + 18.0f + 48.0f + 18.0f + (g_FireModeSlotCount > 0 ? g_FireModeSlotCount * 56.0f + 14.0f : 26.0f);
        FillRectLines(canvas, x - 10, y - 10, w + 20, h, 14, 14, 16);
        ThickOutline(canvas, x - 10, y - 10, w + 20, h, 140, 140, 150, 1);

        DrawString(canvas, x, cy, "PHAROAH LITE", kFontScale, 255, 215, 120);
        cy += 32.0f;

        if (ToggleRow(canvas, x, cy, w, "NP1", "WALLS", VisibilityBoxes::enabled)) VisibilityBoxes::enabled = !VisibilityBoxes::enabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "NP2", "ENEMY NAMES", g_ShowNames)) g_ShowNames = !g_ShowNames;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "NP3", "TRIGGER BOT", RecoverySuite::triggerBotEnabled)) RecoverySuite::triggerBotEnabled = !RecoverySuite::triggerBotEnabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "NP4", "HEAL TRIGGER BOT", RecoverySuite::autoHealEnabled)) RecoverySuite::autoHealEnabled = !RecoverySuite::autoHealEnabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "NP5", "UNLOCKER", g_UnlockerEnabled)) g_UnlockerEnabled = !g_UnlockerEnabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "NP6", "AUTO-RESPAWN", g_AutoRespawn)) g_AutoRespawn = !g_AutoRespawn;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "NP7", "NO SPREAD/RECOIL", g_NoSpreadRecoilEnabled)) g_NoSpreadRecoilEnabled = !g_NoSpreadRecoilEnabled;
        cy += rowH;
        if (ToggleRow(canvas, x, cy, w, "NP8", "GRAYSCALE", RecoverySuite::grayscaleOn)) RecoverySuite::ApplyGrayscale(!RecoverySuite::grayscaleOn);
        cy += rowH;
        if (ActionRow(canvas, x, cy, w, "NP9", "LEAVE MATCH")) SafeCalls::RunConsoleCommand(L"disconnect");
        cy += rowH;

        cy += 8.0f;
        Line(canvas, x, cy, x + w, cy, 100, 100, 110);
        cy += 12.0f;

        char cardHdr[32];
        wsprintfA(cardHdr, "CARDS - PRESS 1 (%d/5)", g_CardSpamCount);
        DrawString(canvas, x, cy, cardHdr, kSmallScale, 255, 215, 120);
        cy += 20.0f;
        DrawCardRow(canvas, x, cy);
        cy += 48.0f;

        Line(canvas, x, cy, x + w, cy, 100, 100, 110);
        cy += 12.0f;

        DrawString(canvas, x, cy, "FIRE MODES - KEYS 6-9", kSmallScale, 255, 215, 120);
        cy += 20.0f;
        DrawFireModes(canvas, x, cy);
    }

    // ---------------------------------------------------------------------
    // Call once per PostRender tick. LITE never installs a D3D11 hook, so
    // there is no "is the real hook already working" gate to check.
    // ---------------------------------------------------------------------
    inline bool g_LoggedFirstDraw = false;
    inline bool g_LoggedException = false;
    inline void Tick(SDK::UCanvas* canvas) {
        PollToggleKeys();
        PollHudKey();
        PollFireModeKeys();
        PollGrayscaleKey();
        PollLeaveMatchKey();
        PollCardCycleKey();
        __try {
            if (!g_LoggedFirstDraw) {
                g_LoggedFirstDraw = true;
                InitLog("[LiteMenu] HUD first drawn, canvas=%p.", (void*)canvas);
            }
            DrawWalls(canvas);
            DrawEnemyNames(canvas);
            DrawHud(canvas);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            if (!g_LoggedException) {
                g_LoggedException = true;
                InitLog("[LiteMenu] EXCEPTION caught inside Tick() (code 0x%08lX).", GetExceptionCode());
            }
        }
    }
}
