#pragma once
// ============================================================================
//  PHAROAH LITE  —  minimal standalone build for PaladinsSDK-master's PHAROAH
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
//
// The panel for PHAROAH LITE. Deliberately a SIBLING of CanvasMenu.h, not an
// edit to it - LITE is a genuinely separate build, and touching the file the
// full PHAROAH build already depends on risks breaking something proven, for
// zero benefit (this file needs its own extra widgets - card boxes, fire-mode
// pips, enemy name labels - that the full build's fallback panel has no
// reason to carry).
//
// Same drawing rule as CanvasMenu.h and RenderBoxesViaCanvas: Draw2DLine is
// the ONLY primitive used anywhere in this file. That is not a style choice -
// DrawTile/DrawText/SetPos crashed a real match twice (see the big comment at
// the top of CanvasMenu.h for the full story). Draw2DLine has been exercised
// at high volume across many full matches with zero incidents. Every pixel
// below goes through it, directly or via the tiny stroke font copied from
// CanvasMenu.h (same glyphs, same reasoning, kept local so this file has no
// dependency on the full build's fallback panel). Enemy names use this same
// font too, NOT the engine's native DrawText - that's the whole reason a
// hand-rolled stroke font exists in this codebase at all.
//
// WHAT THIS FILE DOES NOT DO: install a D3D11/kiero hook, create an ImGui
// context, or call into any of PHAROAH's periodic background subsystems
// (Unlocker, HealthBarColor, MeshSkin, DevSkin, skin scanning, the bone/
// skeleton system). LITE's whole reason to exist is to be the small, explicit
// allow-list version - see main_lite.cpp for exactly what runs each frame.

#include "globals.h"
#include "ext/kiero/kiero.h"
#include "menus/VisibilityBoxes.h"
#include "menus/DirectFire.h"
#include "menus/RecoverySuite.h"
#include "menus/FireModeMenu.h"
#include "Utils/SafeCalls.h"
#include <Windows.h>
#include <cctype>

namespace LiteMenu {

    // ---------------------------------------------------------------------
    // INPUT - identical approach to CanvasMenu.h: polled directly against
    // the real game window, independent of any render hook.
    // ---------------------------------------------------------------------
    struct InputState {
        float mouseX = 0.0f, mouseY = 0.0f;
        bool mouseDown = false;
        bool clickedEdge = false;
    };
    inline InputState g_Input;

    inline void PollInput() {
        static bool wasDown = false;
        HWND wnd = (HWND)kiero::findRealGameWindow();
        if (!wnd) { g_Input = InputState(); wasDown = false; return; }
        POINT p{};
        GetCursorPos(&p);
        ScreenToClient(wnd, &p);
        g_Input.mouseX = (float)p.x;
        g_Input.mouseY = (float)p.y;
        bool down = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        g_Input.mouseDown = down;
        g_Input.clickedEdge = down && !wasDown;
        wasDown = down;
    }

    // ---------------------------------------------------------------------
    // MENU OPEN/CLOSE + TAB. Two tabs, kept to two on purpose (per
    // PRIMAL_MONKE: "keep minimal tabs, 1 if possible, 2 if needed") - MAIN
    // holds everything that's always relevant, FIRE MODES is split out only
    // because its row count depends on how many multi-mode abilities are
    // detected and cluttered MAIN badly when it lived there.
    // ---------------------------------------------------------------------
    inline bool g_MenuOpen = false;
    inline int  g_ActiveTab = 0; // 0 = MAIN, 1 = FIRE MODES
    inline void PollToggleKey() {
        static bool wasDown = false;
        bool down = (GetAsyncKeyState(VK_INSERT) & 0x8000) != 0;
        if (down && !wasDown) g_MenuOpen = !g_MenuOpen;
        wasDown = down;

        static bool tabWasDown = false;
        bool tabDown = (GetAsyncKeyState(VK_TAB) & 0x8000) != 0;
        if (g_MenuOpen && tabDown && !tabWasDown) g_ActiveTab = 1 - g_ActiveTab;
        tabWasDown = tabDown;
    }

    // ---------------------------------------------------------------------
    // DRAWING PRIMITIVES - copied from CanvasMenu.h on purpose (see the file
    // header). Draw2DLine only.
    // ---------------------------------------------------------------------
    inline void Line(SDK::UCanvas* canvas, float x0, float y0, float x1, float y1,
                      unsigned char r, unsigned char g, unsigned char b, unsigned char a = 255) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = a;
        canvas->Draw2DLine(x0, y0, x1, y1, c);
    }

    inline void Outline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                         unsigned char r, unsigned char g, unsigned char b) {
        Line(canvas, x,     y,     x + w, y,     r, g, b);
        Line(canvas, x + w, y,     x + w, y + h, r, g, b);
        Line(canvas, x + w, y + h, x,     y + h, r, g, b);
        Line(canvas, x,     y + h, x,     y,     r, g, b);
    }

    inline void FillRectLines(SDK::UCanvas* canvas, float x, float y, float w, float h,
                               unsigned char r, unsigned char g, unsigned char b) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = 255;
        for (float row = y; row < y + h; row += 2.0f) {
            canvas->Draw2DLine(x, row, x + w, row, c);
        }
    }

    namespace Font {
        struct Seg { float x0, y0, x1, y1; };
        inline int Glyph(char ch, Seg* out) {
            switch (ch) {
            case 'A': out[0]={0,4,0,1}; out[1]={0,1,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,4}; out[4]={0,2,2,2}; return 5;
            case 'B': out[0]={0,0,0,4}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={2,2,2,4}; out[5]={2,4,0,4}; return 6;
            case 'C': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; return 3;
            case 'D': out[0]={0,0,0,4}; out[1]={0,0,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,3}; out[4]={2,3,1,4}; out[5]={1,4,0,4}; return 6;
            case 'E': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={0,2,2,2}; return 4;
            case 'F': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,2,2,2}; return 3;
            case 'G': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,1,2}; return 5;
            case 'H': out[0]={0,0,0,4}; out[1]={2,0,2,4}; out[2]={0,2,2,2}; return 3;
            case 'I': out[0]={0,0,2,0}; out[1]={1,0,1,4}; out[2]={0,4,2,4}; return 3;
            case 'J': out[0]={2,0,2,3}; out[1]={2,3,1,4}; out[2]={1,4,0,3}; return 3;
            case 'K': out[0]={0,0,0,4}; out[1]={2,0,0,2}; out[2]={0,2,2,4}; return 3;
            case 'L': out[0]={0,0,0,4}; out[1]={0,4,2,4}; return 2;
            case 'M': out[0]={0,4,0,0}; out[1]={0,0,1,2}; out[2]={1,2,2,0}; out[3]={2,0,2,4}; return 4;
            case 'N': out[0]={0,4,0,0}; out[1]={0,0,2,4}; out[2]={2,4,2,0}; return 3;
            case 'O': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case 'P': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; return 4;
            case 'Q': out[0]={0,0,2,0}; out[1]={2,0,2,3}; out[2]={2,3,0,3}; out[3]={0,3,0,0}; out[4]={1,3,2,4}; return 5;
            case 'R': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={0,2,2,4}; return 5;
            case 'S': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case 'T': out[0]={0,0,2,0}; out[1]={1,0,1,4}; return 2;
            case 'U': out[0]={0,0,0,4}; out[1]={0,4,2,4}; out[2]={2,4,2,0}; return 3;
            case 'V': out[0]={0,0,1,4}; out[1]={2,0,1,4}; return 2;
            case 'W': out[0]={0,0,0,4}; out[1]={0,4,1,2}; out[2]={1,2,2,4}; out[3]={2,4,2,0}; return 4;
            case 'X': out[0]={0,0,2,4}; out[1]={2,0,0,4}; return 2;
            case 'Y': out[0]={0,0,1,2}; out[1]={2,0,1,2}; out[2]={1,2,1,4}; return 3;
            case 'Z': out[0]={0,0,2,0}; out[1]={2,0,0,4}; out[2]={0,4,2,4}; return 3;
            case '0': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case '1': out[0]={1,0,1,4}; return 1;
            case '2': out[0]={0,0,2,0}; out[1]={2,0,2,2}; out[2]={2,2,0,2}; out[3]={0,2,0,4}; out[4]={0,4,2,4}; return 5;
            case '3': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,2,2,2}; return 4;
            case '4': out[0]={0,0,0,2}; out[1]={0,2,2,2}; out[2]={2,0,2,4}; return 3;
            case '5': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case '6': out[0]={1,0,0,1}; out[1]={0,1,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,0,2}; return 5;
            case '7': out[0]={0,0,2,0}; out[1]={2,0,1,4}; return 2;
            case '8': out[0]={0,0,2,0}; out[1]={0,0,0,4}; out[2]={2,0,2,4}; out[3]={0,4,2,4}; out[4]={0,2,2,2}; return 5;
            case '9': out[0]={0,0,2,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,0,2,4}; return 4;
            case '-': out[0]={0,2,2,2}; return 1;
            case '/': out[0]={0,4,2,0}; return 1;
            case '?': out[0]={0,1,1,0}; out[1]={1,0,2,1}; out[2]={2,1,1,2}; out[3]={1,3,1,3}; return 4;
            default: return 0;
            }
        }
    }

    inline void DrawChar(SDK::UCanvas* canvas, char ch, float x, float y, float scale,
                          unsigned char r, unsigned char g, unsigned char b) {
        Font::Seg segs[8];
        int n = Font::Glyph((char)toupper((unsigned char)ch), segs);
        for (int i = 0; i < n; i++) {
            Line(canvas, x + segs[i].x0 * scale, y + segs[i].y0 * scale,
                         x + segs[i].x1 * scale, y + segs[i].y1 * scale, r, g, b);
        }
    }

    inline float DrawString(SDK::UCanvas* canvas, float x, float y, const char* text, float scale,
                             unsigned char r, unsigned char g, unsigned char b) {
        float cursor = x;
        for (const char* p = text; *p; p++) {
            DrawChar(canvas, *p, cursor, y, scale, r, g, b);
            cursor += 4.0f * scale;
        }
        return cursor - x;
    }
    inline float StringWidth(const char* text, float scale) {
        float n = 0; for (const char* p = text; *p; p++) n += 1.0f;
        return n * 4.0f * scale;
    }

    // ---------------------------------------------------------------------
    // LAYOUT + WIDGETS - same shape as CanvasMenu.h's.
    // ---------------------------------------------------------------------
    struct Layout { float x, width; float cursorY; };
    inline Layout Begin(float x, float y, float width) { Layout L; L.x = x; L.width = width; L.cursorY = y; return L; }
    inline bool HitTest(const Layout& L, float h) {
        return g_Input.mouseX >= L.x && g_Input.mouseX <= L.x + L.width &&
               g_Input.mouseY >= L.cursorY && g_Input.mouseY <= L.cursorY + h;
    }
    inline bool HitTestRect(float x, float y, float w, float h) {
        return g_Input.mouseX >= x && g_Input.mouseX <= x + w &&
               g_Input.mouseY >= y && g_Input.mouseY <= y + h;
    }

    const float kFontScale = 3.0f;

    inline void Header(SDK::UCanvas* canvas, Layout& L, const char* title) {
        DrawString(canvas, L.x, L.cursorY, title, kFontScale, 255, 210, 110);
        L.cursorY += 22.0f;
    }
    inline void Separator(SDK::UCanvas* canvas, Layout& L) {
        Line(canvas, L.x, L.cursorY, L.x + L.width, L.cursorY, 90, 90, 95);
        L.cursorY += 8.0f;
    }
    inline bool Checkbox(SDK::UCanvas* canvas, Layout& L, const char* label, bool* value) {
        const float h = 20.0f;
        bool hovered = HitTest(L, h);
        bool clicked = hovered && g_Input.clickedEdge;
        if (clicked) *value = !*value;
        unsigned char boxR = hovered ? 220 : 190, boxG = hovered ? 220 : 190, boxB = hovered ? 225 : 190;
        Outline(canvas, L.x, L.cursorY, 16, 16, boxR, boxG, boxB);
        if (hovered) Outline(canvas, L.x - 1, L.cursorY - 1, 18, 18, boxR, boxG, boxB);
        if (*value) {
            Line(canvas, L.x + 3,  L.cursorY + 8,  L.x + 6,  L.cursorY + 12, 90, 230, 120);
            Line(canvas, L.x + 6,  L.cursorY + 12, L.x + 13, L.cursorY + 3,  90, 230, 120);
        }
        DrawString(canvas, L.x + 24, L.cursorY + 2, label, kFontScale, 225, 225, 225);
        L.cursorY += h + 6.0f;
        return clicked;
    }
    inline bool Button(SDK::UCanvas* canvas, Layout& L, const char* label) {
        const float h = 22.0f;
        bool hovered = HitTest(L, h);
        bool clicked = hovered && g_Input.clickedEdge;
        unsigned char r = hovered ? 140 : 150, g = hovered ? 220 : 180, b = hovered ? 160 : 160;
        Outline(canvas, L.x, L.cursorY, L.width, h, r, g, b);
        if (hovered) Outline(canvas, L.x - 1, L.cursorY - 1, L.width + 2, h + 2, r, g, b);
        DrawString(canvas, L.x + 8, L.cursorY + 5, label, kFontScale, 235, 235, 235);
        L.cursorY += h + 6.0f;
        return clicked;
    }
    // Small tab button, side by side rather than stacked - used only for the
    // two-tab switcher at the top of the panel.
    inline bool TabButton(SDK::UCanvas* canvas, float x, float y, float w, float h,
                           const char* label, bool active) {
        bool hovered = HitTestRect(x, y, w, h);
        bool clicked = hovered && g_Input.clickedEdge;
        unsigned char r = active ? 90 : (hovered ? 70 : 50);
        unsigned char g = active ? 230 : (hovered ? 90 : 50);
        unsigned char b = active ? 120 : (hovered ? 95 : 55);
        if (active) FillRectLines(canvas, x, y, w, h, r / 4, g / 4, b / 4);
        Outline(canvas, x, y, w, h, r, g, b);
        float tw = StringWidth(label, kFontScale * 0.85f);
        DrawString(canvas, x + (w - tw) / 2.0f, y + h / 2.0f - 6.0f, label, kFontScale * 0.85f,
                   active ? 40 : 220, active ? 255 : 220, active ? 120 : 225);
        return clicked;
    }

    // ---------------------------------------------------------------------
    // THE 5 CARD BOXES
    //
    // Per PRIMAL_MONKE: "5 boxes, click a number and each box will fill up,
    // signifying another card that's being spammed." DirectFire.h ALREADY
    // maps number keys 1-5 to its 5 resolved card slots (g_CardKey[5] =
    // {'1'..'5'}, toggling g_CardSpam[5]) and already auto-detects the
    // equipped deck (g_AutoSweep is on by default) - nothing new needed on
    // the backend, this just draws it. Filled box = that slot's spam is on.
    // Mouse click on a box is wired too, for parity with clicking anywhere
    // else in this panel.
    // ---------------------------------------------------------------------
    inline void DrawCardRow(SDK::UCanvas* canvas, float x, float y) {
        const float boxSize = 30.0f, gap = 8.0f;
        for (int i = 0; i < 5; i++) {
            float bx = x + i * (boxSize + gap);
            bool ready = DirectFire::g_Five[i].dev != nullptr;
            bool spamming = DirectFire::g_CardSpam[i];

            if (HitTestRect(bx, y, boxSize, boxSize) && g_Input.clickedEdge) {
                DirectFire::g_CardSpam[i] = !DirectFire::g_CardSpam[i];
            }

            unsigned char r = ready ? 90 : 60, g = ready ? 90 : 60, b = ready ? 95 : 60;
            if (spamming) { r = 90; g = 230; b = 120; }
            if (spamming) FillRectLines(canvas, bx, y, boxSize, boxSize, r / 3, g / 3, b / 3);
            Outline(canvas, bx, y, boxSize, boxSize, r, g, b);

            char num[2] = { (char)('1' + i), 0 };
            DrawString(canvas, bx + boxSize / 2.0f - 3.0f, y + boxSize / 2.0f - 6.0f, num, kFontScale,
                       spamming ? 20 : 220, spamming ? 40 : 220, spamming ? 20 : 220);
        }
        // Card names + shot counts, small, under the boxes.
        for (int i = 0; i < 5; i++) {
            if (!DirectFire::g_Five[i].dev) continue;
            float bx = x + i * (boxSize + gap);
            DrawString(canvas, bx, y + boxSize + 4.0f, DirectFire::g_Five[i].label, kFontScale * 0.6f, 180, 180, 190);
        }
    }

    // ========================================================================
    // FIRE MODES - detects every device (weapon + each ability) that actually
    // HAS more than one fire mode, and gives each one its own number key.
    //
    // ATgDevice::m_FireMode is a plain TArray - its Num() IS the real count of
    // configured modes for that specific device (VisibilityBoxes.h's own
    // projectile-speed reader already trusts this same field the same way).
    // A device with 1 (or 0) is not cyclable and is left out entirely, so the
    // list only ever shows abilities that actually have something to switch.
    //
    // Detection reuses DirectFire::g_PendingDevSweep - the SAME sweep the
    // card system already has, which walks GObjects for every ATgDevice
    // owned by the local pawn. That walk is expensive (hundreds of thousands
    // of objects), which is exactly why it's a one-shot flag, not something
    // that runs every frame - so this only triggers it a few seconds apart,
    // or right away on a pawn/weapon change.
    // ========================================================================
    struct FireModeSlot {
        SDK::ATgDevice* dev = nullptr;
        int modeCount = 0;
        int key = 0;
        char label[24] = {};
    };
    static const int kMaxFireModeSlots = 4;
    inline FireModeSlot g_FireModeSlots[kMaxFireModeSlots];
    inline int  g_FireModeSlotCount = 0;
    inline void* g_FireModeSweptPawn = nullptr;
    inline ULONGLONG g_LastFireModeRescanMs = 0;
    inline bool g_FireModeKeyWasDown[kMaxFireModeSlots] = {};

    // Safe-thread only: reads dev->m_FireMode.Num() and rebuilds the slot
    // list from whatever DirectFire's sweep last found. Called after
    // DirectFire::ProcessPending() so a sweep just triggered has already run.
    inline void RebuildFireModeSlots() {
        g_FireModeSlotCount = 0;
        for (int i = 0; i < DirectFire::g_DevCount && g_FireModeSlotCount < kMaxFireModeSlots; i++) {
            const DirectFire::DevRow& row = DirectFire::g_Dev[i];
            if (!row.dev || row.isCard) continue;
            int count = 0;
            __try { count = (int)row.dev->m_FireMode.Num(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
            if (count <= 1) continue;

            FireModeSlot& slot = g_FireModeSlots[g_FireModeSlotCount];
            slot.dev = row.dev;
            slot.modeCount = count;
            slot.key = '6' + g_FireModeSlotCount; // 6,7,8,9 - 1-5 already belong to cards
            lstrcpynA(slot.label, row.label[0] ? row.label : row.name, sizeof(slot.label));
            g_FireModeSlotCount++;
        }
    }

    // Safe-thread only (scripted-free, but keeps everything device-related
    // together with the sweep trigger). Re-scans on pawn change or every 4s.
    inline void TickFireModesSafe() {
        if (Globals::LocalPawn != g_FireModeSweptPawn) {
            g_FireModeSweptPawn = Globals::LocalPawn;
            DirectFire::g_PendingDevSweep = true;
            g_LastFireModeRescanMs = GetTickCount64();
            return; // let the sweep actually run this pass before reading g_Dev
        }
        ULONGLONG now = GetTickCount64();
        if (now - g_LastFireModeRescanMs > 4000) {
            g_LastFireModeRescanMs = now;
            DirectFire::g_PendingDevSweep = true;
        }
        RebuildFireModeSlots();
    }

    // Render-thread safe: GetAsyncKeyState only, mirrors DirectFire::TickCards.
    inline void PollFireModeKeys() {
        for (int i = 0; i < g_FireModeSlotCount; i++) {
            bool down = (GetAsyncKeyState(g_FireModeSlots[i].key) & 0x8000) != 0;
            if (down && !g_FireModeKeyWasDown[i]) {
                SDK::ATgDevice* d = g_FireModeSlots[i].dev;
                if (d) {
                    int cur = 0;
                    __try { cur = (int)d->CurrentFireMode; } __except (EXCEPTION_EXECUTE_HANDLER) { cur = 0; }
                    int next = (cur + 1) % g_FireModeSlots[i].modeCount;
                    ApplyFireModeRaw(d, next);
                }
            }
            g_FireModeKeyWasDown[i] = down;
        }
    }

    inline void DrawFireModesTab(SDK::UCanvas* canvas, Layout& L) {
        if (g_FireModeSlotCount == 0) {
            DrawString(canvas, L.x, L.cursorY, "NO MULTI-MODE", kFontScale * 0.8f, 200, 160, 120);
            L.cursorY += 14.0f;
            DrawString(canvas, L.x, L.cursorY, "ABILITIES FOUND", kFontScale * 0.8f, 200, 160, 120);
            L.cursorY += 20.0f;
            DrawString(canvas, L.x, L.cursorY, "RESCANS EVERY 4S", kFontScale * 0.6f, 150, 150, 155);
            L.cursorY += 16.0f;
            return;
        }
        for (int i = 0; i < g_FireModeSlotCount; i++) {
            const FireModeSlot& slot = g_FireModeSlots[i];
            // Key badge.
            Outline(canvas, L.x, L.cursorY, 20, 20, 200, 200, 210);
            char keyCh[2] = { (char)slot.key, 0 };
            DrawString(canvas, L.x + 5, L.cursorY + 3, keyCh, kFontScale, 255, 210, 110);

            // Label.
            DrawString(canvas, L.x + 28, L.cursorY + 3, slot.label, kFontScale * 0.75f, 220, 220, 225);
            L.cursorY += 24.0f;

            // Mode pips - small squares, one per detected mode, current one filled.
            // (Circles were the original idea, but every widget in this panel is
            // built from straight Draw2DLine segments - a filled square reads just
            // as clearly as "this one is active" and stays visually consistent.)
            int cur = 0;
            __try { cur = slot.dev ? (int)slot.dev->CurrentFireMode : 0; } __except (EXCEPTION_EXECUTE_HANDLER) { cur = 0; }
            for (int m = 0; m < slot.modeCount && m < 8; m++) {
                float px = L.x + m * 26.0f;
                bool active = (m == cur);
                if (HitTestRect(px, L.cursorY, 20, 20) && g_Input.clickedEdge) {
                    ApplyFireModeRaw(slot.dev, m);
                }
                if (active) FillRectLines(canvas, px, L.cursorY, 20, 20, 20, 60, 25);
                Outline(canvas, px, L.cursorY, 20, 20, active ? 90 : 150, active ? 230 : 150, active ? 120 : 155);
                char mch[2] = { (char)('0' + m), 0 };
                DrawString(canvas, px + 6, L.cursorY + 3, mch, kFontScale * 0.8f,
                           active ? 30 : 210, active ? 255 : 210, active ? 60 : 215);
            }
            L.cursorY += 30.0f;
        }
    }

    // ========================================================================
    // ENEMY NAMES - reads the SAME gather cache the trigger bot's reticle
    // detection already uses (VisibilityBoxes::g_CachedGather, refreshed once
    // per frame in HookedProcessEventLite before this ever runs), so this
    // costs nothing extra beyond the projection math and a few DrawString
    // calls - no additional scripted or raw game reads of its own.
    // ========================================================================
    inline bool g_ShowNames = true;

    inline void DrawEnemyNames(SDK::UCanvas* canvas) {
        if (!canvas || !g_ShowNames) return;
        const VisibilityBoxes::GatherResult& g = VisibilityBoxes::g_CachedGather;
        if (!g.ok) return;

        VisibilityBoxes::PlainVec fwd, right, up;
        VisibilityBoxes::RotatorToVectors(g.camPitch, g.camYaw, fwd, right, up);
        ImVec2 screenSize = { (float)canvas->SizeX, (float)canvas->SizeY };

        for (int i = 0; i < g.count; i++) {
            const VisibilityBoxes::BoxEntry& e = g.entries[i];
            if (e.kind != VisibilityBoxes::BoxKind::Enemy) continue;
            if (!e.championName[0]) continue;

            VisibilityBoxes::PlainVec top{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight + 14.0f };
            ImVec2 screen;
            if (!VisibilityBoxes::WorldToScreen(top, g.camLoc, fwd, right, up, g.fov, screenSize.x, screenSize.y, screen))
                continue;

            float w = StringWidth(e.championName, kFontScale * 0.75f);
            DrawString(canvas, screen.x - w / 2.0f, screen.y, e.championName, kFontScale * 0.75f, 255, 225, 140);
        }
    }

    // ---------------------------------------------------------------------
    // FIRE MODE (weapon-only quick cycle) - kept on MAIN as a one-button
    // fallback for whatever's in your hand right now, separate from the
    // per-ability list on the FIRE MODES tab.
    // ---------------------------------------------------------------------
    inline int g_LiteFireMode = 0;
    inline void CycleFireMode() {
        if (!Globals::LocalWeapon) return;
        int count = 3;
        __try { int n = (int)Globals::LocalWeapon->m_FireMode.Num(); if (n > 0) count = n; } __except (EXCEPTION_EXECUTE_HANDLER) {}
        g_LiteFireMode = (g_LiteFireMode + 1) % count;
        ApplyFireModeRaw(Globals::LocalWeapon, g_LiteFireMode);
    }

    // ---------------------------------------------------------------------
    // RESPAWN - LITE's own small tracker, deliberately NOT reusing
    // RecoverySuite::ProcessPendingSafeResets (that function also drives
    // RunSafeThreadSubsystems - Unlocker, HealthBarColor, skin scanning and
    // a dozen other things LITE exists specifically to not run every frame).
    // Same underlying call (SafeCalls::ServerSetReadyToPlay), same 1x/sec
    // throttle while dead, just without dragging in everything else.
    // ---------------------------------------------------------------------
    inline bool g_AutoRespawn = true;
    inline bool g_PendingRespawnNow = false;
    inline ULONGLONG g_LastRespawnTryMs = 0;

    inline void TickRespawnSafe() {
        if (g_PendingRespawnNow) {
            g_PendingRespawnNow = false;
            SafeCalls::ServerSetReadyToPlay();
        }
        if (!g_AutoRespawn || !Globals::LocalPawn) return;
        ULONGLONG now = GetTickCount64();
        if (now - g_LastRespawnTryMs < 500) return;
        g_LastRespawnTryMs = now;
        int cur = 0, mx = 0;
        if (SafeCalls::GetPawnHealth(&cur, &mx) && cur <= 0) {
            SafeCalls::ServerSetReadyToPlay();
        }
    }

    // ---------------------------------------------------------------------
    // THE PANEL
    // ---------------------------------------------------------------------
    inline void DrawMainTab(SDK::UCanvas* canvas, Layout& L) {
        Checkbox(canvas, L, "WALLS", &VisibilityBoxes::enabled);
        Checkbox(canvas, L, "ENEMY NAMES", &g_ShowNames);
        Checkbox(canvas, L, "TRIGGER BOT", &RecoverySuite::triggerBotEnabled);
        Checkbox(canvas, L, "HEAL TRIGGER BOT", &RecoverySuite::autoHealEnabled);

        Separator(canvas, L);
        if (Button(canvas, L, "CYCLE WEAPON FIRE MODE")) CycleFireMode();
        DrawString(canvas, L.x, L.cursorY, "MODE", kFontScale * 0.7f, 160, 160, 170);
        DrawChar(canvas, (char)('0' + g_LiteFireMode), L.x + 40, L.cursorY, kFontScale * 0.7f, 255, 210, 110);
        DrawString(canvas, L.x + 60, L.cursorY, "MORE ON FIRE MODES TAB", kFontScale * 0.55f, 150, 150, 160);
        L.cursorY += 16.0f;

        Separator(canvas, L);
        Checkbox(canvas, L, "AUTO-RESPAWN", &g_AutoRespawn);
        if (Button(canvas, L, "RESPAWN NOW")) g_PendingRespawnNow = true;

        Separator(canvas, L);
        DrawString(canvas, L.x, L.cursorY, "CARDS 1-5", kFontScale, 255, 210, 110);
        L.cursorY += 18.0f;
        DrawCardRow(canvas, L.x, L.cursorY);
        L.cursorY += 50.0f;

        DrawString(canvas, L.x, L.cursorY, DirectFire::g_ObjCount > 0 ? "DECK FOUND" : "SCANNING", kFontScale * 0.7f,
                   DirectFire::g_ObjCount > 0 ? 120 : 200, DirectFire::g_ObjCount > 0 ? 220 : 160, 130);
    }

    inline void DrawPanel(SDK::UCanvas* canvas) {
        if (!canvas) return;
        const float panelX = 60.0f, panelY = 60.0f, panelW = 280.0f, panelH = 360.0f;

        FillRectLines(canvas, panelX - 10, panelY - 10, panelW + 20, panelH, 18, 18, 20);
        Outline(canvas, panelX - 10, panelY - 10, panelW + 20, panelH, 120, 120, 130);

        Layout L = Begin(panelX, panelY, panelW);
        Header(canvas, L, "PHAROAH LITE");

        // Tab switcher - click either, or press TAB in game.
        float tabW = (panelW - 8.0f) / 2.0f;
        if (TabButton(canvas, L.x, L.cursorY, tabW, 22.0f, "MAIN", g_ActiveTab == 0)) g_ActiveTab = 0;
        if (TabButton(canvas, L.x + tabW + 8.0f, L.cursorY, tabW, 22.0f, "FIRE MODES", g_ActiveTab == 1)) g_ActiveTab = 1;
        L.cursorY += 30.0f;
        Separator(canvas, L);

        if (g_ActiveTab == 0) DrawMainTab(canvas, L);
        else                  DrawFireModesTab(canvas, L);
    }

    inline void DrawHint(SDK::UCanvas* canvas) {
        if (!canvas) return;
        FillRectLines(canvas, 16, 16, 260, 22, 18, 18, 20);
        Outline(canvas, 16, 16, 260, 22, 120, 120, 130);
        DrawString(canvas, 24, 20, "INSERT-MENU TAB-SWITCH", kFontScale * 0.85f, 255, 210, 110);
    }

    inline bool g_LoggedCursorFirstDraw = false;
    inline void DrawCursor(SDK::UCanvas* canvas) {
        if (!canvas) return;
        float x = g_Input.mouseX, y = g_Input.mouseY;
        if (!g_LoggedCursorFirstDraw) {
            g_LoggedCursorFirstDraw = true;
            InitLog("[LiteMenu] cursor first drawn at client-space (%.0f, %.0f).", x, y);
        }
        Line(canvas, x - 20, y, x + 20, y, 255, 0, 255);
        Line(canvas, x, y - 20, x, y + 20, 255, 0, 255);
        Outline(canvas, x - 4, y - 4, 8, 8, 255, 0, 255);
    }

    // Call once per PostRender tick. LITE never installs a D3D11 hook, so
    // unlike CanvasMenu::Tick this has no "is the real hook already working"
    // gate to check - it always runs. Enemy names and fire-mode key polling
    // both run regardless of whether the panel is open - names are a passive
    // ESP feature (same as walls), and fire-mode keys are meant to work
    // mid-fight without needing the menu open to use them.
    inline bool g_LoggedException = false;
    inline void Tick(SDK::UCanvas* canvas) {
        PollToggleKey();
        PollFireModeKeys();
        __try {
            DrawHint(canvas);
            DrawEnemyNames(canvas);
            if (!g_MenuOpen) return;
            PollInput();
            DrawPanel(canvas);
            DrawCursor(canvas);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            if (!g_LoggedException) {
                g_LoggedException = true;
                InitLog("[LiteMenu] EXCEPTION caught inside Tick() (code 0x%08lX).", GetExceptionCode());
            }
        }
    }
}
