#pragma once
// ============================================================================
//  PHAROAH LITE  —  minimal standalone build for PaladinsSDK-master's PHAROAH
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
//
// The panel for PHAROAH LITE. Deliberately a SIBLING of CanvasMenu.h, not an
// edit to it - LITE is a genuinely separate build, and touching the file the
// full PHAROAH build already depends on risks breaking something proven, for
// zero benefit (this file needs its own extra widgets - a 5-box card row -
// that the full build's fallback panel has no reason to carry).
//
// Same drawing rule as CanvasMenu.h and RenderBoxesViaCanvas: Draw2DLine is
// the ONLY primitive used anywhere in this file. That is not a style choice -
// DrawTile/DrawText/SetPos crashed a real match twice (see the big comment at
// the top of CanvasMenu.h for the full story). Draw2DLine has been exercised
// at high volume across many full matches with zero incidents. Every pixel
// below goes through it, directly or via the tiny stroke font copied from
// CanvasMenu.h (same glyphs, same reasoning, kept local so this file has no
// dependency on the full build's fallback panel).
//
// WHAT THIS FILE DOES NOT DO: install a D3D11/kiero hook, create an ImGui
// context, or call into any of PHAROAH's periodic background subsystems
// (Unlocker, HealthBarColor, MeshSkin, DevSkin, skin scanning, the bone/
// skeleton system). LITE's whole reason to exist is to be the small, explicit
// allow-list version - see main_lite.cpp for exactly what runs each frame.

#include "globals.h"
#include "ext/kiero/kiero.h"
#include "menus/VisibilityBoxes.h"
#include "menus/DirectFire.h"
#include "menus/RecoverySuite.h"
#include "menus/FireModeMenu.h"
#include "Utils/SafeCalls.h"
#include <Windows.h>
#include <cctype>

namespace LiteMenu {

    // ---------------------------------------------------------------------
    // INPUT - identical approach to CanvasMenu.h: polled directly against
    // the real game window, independent of any render hook.
    // ---------------------------------------------------------------------
    struct InputState {
        float mouseX = 0.0f, mouseY = 0.0f;
        bool mouseDown = false;
        bool clickedEdge = false;
    };
    inline InputState g_Input;

    inline void PollInput() {
        static bool wasDown = false;
        HWND wnd = (HWND)kiero::findRealGameWindow();
        if (!wnd) { g_Input = InputState(); wasDown = false; return; }
        POINT p{};
        GetCursorPos(&p);
        ScreenToClient(wnd, &p);
        g_Input.mouseX = (float)p.x;
        g_Input.mouseY = (float)p.y;
        bool down = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        g_Input.mouseDown = down;
        g_Input.clickedEdge = down && !wasDown;
        wasDown = down;
    }

    inline bool g_MenuOpen = false;
    inline void PollToggleKey() {
        static bool wasDown = false;
        bool down = (GetAsyncKeyState(VK_INSERT) & 0x8000) != 0;
        if (down && !wasDown) g_MenuOpen = !g_MenuOpen;
        wasDown = down;
    }

    // ---------------------------------------------------------------------
    // DRAWING PRIMITIVES - copied from CanvasMenu.h on purpose (see the file
    // header). Draw2DLine only.
    // ---------------------------------------------------------------------
    inline void Line(SDK::UCanvas* canvas, float x0, float y0, float x1, float y1,
                      unsigned char r, unsigned char g, unsigned char b, unsigned char a = 255) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = a;
        canvas->Draw2DLine(x0, y0, x1, y1, c);
    }

    inline void Outline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                         unsigned char r, unsigned char g, unsigned char b) {
        Line(canvas, x,     y,     x + w, y,     r, g, b);
        Line(canvas, x + w, y,     x + w, y + h, r, g, b);
        Line(canvas, x + w, y + h, x,     y + h, r, g, b);
        Line(canvas, x,     y + h, x,     y,     r, g, b);
    }

    inline void FillRectLines(SDK::UCanvas* canvas, float x, float y, float w, float h,
                               unsigned char r, unsigned char g, unsigned char b) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = 255;
        for (float row = y; row < y + h; row += 2.0f) {
            canvas->Draw2DLine(x, row, x + w, row, c);
        }
    }

    namespace Font {
        struct Seg { float x0, y0, x1, y1; };
        inline int Glyph(char ch, Seg* out) {
            switch (ch) {
            case 'A': out[0]={0,4,0,1}; out[1]={0,1,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,4}; out[4]={0,2,2,2}; return 5;
            case 'B': out[0]={0,0,0,4}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={2,2,2,4}; out[5]={2,4,0,4}; return 6;
            case 'C': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; return 3;
            case 'D': out[0]={0,0,0,4}; out[1]={0,0,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,3}; out[4]={2,3,1,4}; out[5]={1,4,0,4}; return 6;
            case 'E': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={0,2,2,2}; return 4;
            case 'F': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,2,2,2}; return 3;
            case 'G': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,1,2}; return 5;
            case 'H': out[0]={0,0,0,4}; out[1]={2,0,2,4}; out[2]={0,2,2,2}; return 3;
            case 'I': out[0]={0,0,2,0}; out[1]={1,0,1,4}; out[2]={0,4,2,4}; return 3;
            case 'K': out[0]={0,0,0,4}; out[1]={2,0,0,2}; out[2]={0,2,2,4}; return 3;
            case 'L': out[0]={0,0,0,4}; out[1]={0,4,2,4}; return 2;
            case 'M': out[0]={0,4,0,0}; out[1]={0,0,1,2}; out[2]={1,2,2,0}; out[3]={2,0,2,4}; return 4;
            case 'N': out[0]={0,4,0,0}; out[1]={0,0,2,4}; out[2]={2,4,2,0}; return 3;
            case 'O': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case 'P': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; return 4;
            case 'R': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={0,2,2,4}; return 5;
            case 'S': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case 'T': out[0]={0,0,2,0}; out[1]={1,0,1,4}; return 2;
            case 'U': out[0]={0,0,0,4}; out[1]={0,4,2,4}; out[2]={2,4,2,0}; return 3;
            case 'V': out[0]={0,0,1,4}; out[1]={2,0,1,4}; return 2;
            case 'W': out[0]={0,0,0,4}; out[1]={0,4,1,2}; out[2]={1,2,2,4}; out[3]={2,4,2,0}; return 4;
            case 'X': out[0]={0,0,2,4}; out[1]={2,0,0,4}; return 2;
            case 'Y': out[0]={0,0,1,2}; out[1]={2,0,1,2}; out[2]={1,2,1,4}; return 3;
            case '0': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case '1': out[0]={1,0,1,4}; return 1;
            case '2': out[0]={0,0,2,0}; out[1]={2,0,2,2}; out[2]={2,2,0,2}; out[3]={0,2,0,4}; out[4]={0,4,2,4}; return 5;
            case '3': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,2,2,2}; return 4;
            case '4': out[0]={0,0,0,2}; out[1]={0,2,2,2}; out[2]={2,0,2,4}; return 3;
            case '5': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case '6': out[0]={1,0,0,1}; out[1]={0,1,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,0,2}; return 5;
            case '-': out[0]={0,2,2,2}; return 1;
            case '/': out[0]={0,4,2,0}; return 1;
            default: return 0;
            }
        }
    }

    inline void DrawChar(SDK::UCanvas* canvas, char ch, float x, float y, float scale,
                          unsigned char r, unsigned char g, unsigned char b) {
        Font::Seg segs[8];
        int n = Font::Glyph((char)toupper((unsigned char)ch), segs);
        for (int i = 0; i < n; i++) {
            Line(canvas, x + segs[i].x0 * scale, y + segs[i].y0 * scale,
                         x + segs[i].x1 * scale, y + segs[i].y1 * scale, r, g, b);
        }
    }

    inline float DrawString(SDK::UCanvas* canvas, float x, float y, const char* text, float scale,
                             unsigned char r, unsigned char g, unsigned char b) {
        float cursor = x;
        for (const char* p = text; *p; p++) {
            DrawChar(canvas, *p, cursor, y, scale, r, g, b);
            cursor += 4.0f * scale;
        }
        return cursor - x;
    }

    // ---------------------------------------------------------------------
    // LAYOUT + WIDGETS - same shape as CanvasMenu.h's.
    // ---------------------------------------------------------------------
    struct Layout { float x, width; float cursorY; };
    inline Layout Begin(float x, float y, float width) { Layout L; L.x = x; L.width = width; L.cursorY = y; return L; }
    inline bool HitTest(const Layout& L, float h) {
        return g_Input.mouseX >= L.x && g_Input.mouseX <= L.x + L.width &&
               g_Input.mouseY >= L.cursorY && g_Input.mouseY <= L.cursorY + h;
    }
    inline bool HitTestRect(float x, float y, float w, float h) {
        return g_Input.mouseX >= x && g_Input.mouseX <= x + w &&
               g_Input.mouseY >= y && g_Input.mouseY <= y + h;
    }

    const float kFontScale = 3.0f;

    inline void Header(SDK::UCanvas* canvas, Layout& L, const char* title) {
        DrawString(canvas, L.x, L.cursorY, title, kFontScale, 255, 210, 110);
        L.cursorY += 22.0f;
    }
    inline void Separator(SDK::UCanvas* canvas, Layout& L) {
        Line(canvas, L.x, L.cursorY, L.x + L.width, L.cursorY, 90, 90, 95);
        L.cursorY += 8.0f;
    }
    inline bool Checkbox(SDK::UCanvas* canvas, Layout& L, const char* label, bool* value) {
        const float h = 20.0f;
        bool hovered = HitTest(L, h);
        bool clicked = hovered && g_Input.clickedEdge;
        if (clicked) *value = !*value;
        unsigned char boxR = hovered ? 220 : 190, boxG = hovered ? 220 : 190, boxB = hovered ? 225 : 190;
        Outline(canvas, L.x, L.cursorY, 16, 16, boxR, boxG, boxB);
        if (hovered) Outline(canvas, L.x - 1, L.cursorY - 1, 18, 18, boxR, boxG, boxB);
        if (*value) {
            Line(canvas, L.x + 3,  L.cursorY + 8,  L.x + 6,  L.cursorY + 12, 90, 230, 120);
            Line(canvas, L.x + 6,  L.cursorY + 12, L.x + 13, L.cursorY + 3,  90, 230, 120);
        }
        DrawString(canvas, L.x + 24, L.cursorY + 2, label, kFontScale, 225, 225, 225);
        L.cursorY += h + 6.0f;
        return clicked;
    }
    inline bool Button(SDK::UCanvas* canvas, Layout& L, const char* label) {
        const float h = 22.0f;
        bool hovered = HitTest(L, h);
        bool clicked = hovered && g_Input.clickedEdge;
        unsigned char r = hovered ? 140 : 150, g = hovered ? 220 : 180, b = hovered ? 160 : 160;
        Outline(canvas, L.x, L.cursorY, L.width, h, r, g, b);
        if (hovered) Outline(canvas, L.x - 1, L.cursorY - 1, L.width + 2, h + 2, r, g, b);
        DrawString(canvas, L.x + 8, L.cursorY + 5, label, kFontScale, 235, 235, 235);
        L.cursorY += h + 6.0f;
        return clicked;
    }

    // ---------------------------------------------------------------------
    // THE 5 CARD BOXES
    //
    // Per PRIMAL_MONKE: "5 boxes, click a number and each box will fill up,
    // signifying another card that's being spammed." DirectFire.h ALREADY
    // maps number keys 1-5 to its 5 resolved card slots (g_CardKey[5] =
    // {'1'..'5'}, toggling g_CardSpam[5]) and already auto-detects the
    // equipped deck (g_AutoSweep is on by default) - nothing new needed on
    // the backend, this just draws it. Filled box = that slot's spam is on.
    // Mouse click on a box is wired too, for parity with clicking anywhere
    // else in this panel.
    // ---------------------------------------------------------------------
    inline void DrawCardRow(SDK::UCanvas* canvas, float x, float y) {
        const float boxSize = 30.0f, gap = 8.0f;
        for (int i = 0; i < 5; i++) {
            float bx = x + i * (boxSize + gap);
            bool ready = DirectFire::g_Five[i].dev != nullptr;
            bool spamming = DirectFire::g_CardSpam[i];

            if (HitTestRect(bx, y, boxSize, boxSize) && g_Input.clickedEdge) {
                DirectFire::g_CardSpam[i] = !DirectFire::g_CardSpam[i];
            }

            unsigned char r = ready ? 90 : 60, g = ready ? 90 : 60, b = ready ? 95 : 60;
            if (spamming) { r = 90; g = 230; b = 120; }
            if (spamming) FillRectLines(canvas, bx, y, boxSize, boxSize, r / 3, g / 3, b / 3);
            Outline(canvas, bx, y, boxSize, boxSize, r, g, b);

            char num[2] = { (char)('1' + i), 0 };
            DrawString(canvas, bx + boxSize / 2.0f - 3.0f, y + boxSize / 2.0f - 6.0f, num, kFontScale,
                       spamming ? 20 : 220, spamming ? 40 : 220, spamming ? 20 : 220);
        }
        // Card names + shot counts, small, under the boxes.
        for (int i = 0; i < 5; i++) {
            if (!DirectFire::g_Five[i].dev) continue;
            float bx = x + i * (boxSize + gap);
            DrawString(canvas, bx, y + boxSize + 4.0f, DirectFire::g_Five[i].label, kFontScale * 0.6f, 180, 180, 190);
        }
    }

    // ---------------------------------------------------------------------
    // FIRE MODE - simpler than the full menu's version: one button cycles
    // the current weapon through modes 0/1/2 using the same raw three-field
    // write PHAROAH's Super Drogoz automation uses (ApplyFireModeRaw in
    // FireModeMenu.h) - not the engine's own SetFireMode(), which silently
    // refuses the hidden modes this is for.
    // ---------------------------------------------------------------------
    inline int g_LiteFireMode = 0;
    inline void CycleFireMode() {
        if (!Globals::LocalWeapon) return;
        g_LiteFireMode = (g_LiteFireMode + 1) % 3;
        ApplyFireModeRaw(Globals::LocalWeapon, g_LiteFireMode);
    }

    // ---------------------------------------------------------------------
    // RESPAWN - LITE's own small tracker, deliberately NOT reusing
    // RecoverySuite::ProcessPendingSafeResets (that function also drives
    // RunSafeThreadSubsystems - Unlocker, HealthBarColor, skin scanning and
    // a dozen other things LITE exists specifically to not run every frame).
    // Same underlying call (SafeCalls::ServerSetReadyToPlay), same 1x/sec
    // throttle while dead, just without dragging in everything else.
    // ---------------------------------------------------------------------
    inline bool g_AutoRespawn = true;
    inline bool g_PendingRespawnNow = false;
    inline ULONGLONG g_LastRespawnTryMs = 0;

    inline void TickRespawnSafe() {
        if (g_PendingRespawnNow) {
            g_PendingRespawnNow = false;
            SafeCalls::ServerSetReadyToPlay();
        }
        if (!g_AutoRespawn || !Globals::LocalPawn) return;
        ULONGLONG now = GetTickCount64();
        if (now - g_LastRespawnTryMs < 500) return;
        g_LastRespawnTryMs = now;
        int cur = 0, mx = 0;
        if (SafeCalls::GetPawnHealth(&cur, &mx) && cur <= 0) {
            SafeCalls::ServerSetReadyToPlay();
        }
    }

    // ---------------------------------------------------------------------
    // THE PANEL
    // ---------------------------------------------------------------------
    inline void DrawPanel(SDK::UCanvas* canvas) {
        if (!canvas) return;
        const float panelX = 60.0f, panelY = 60.0f, panelW = 260.0f, panelH = 330.0f;

        FillRectLines(canvas, panelX - 10, panelY - 10, panelW + 20, panelH, 18, 18, 20);
        Outline(canvas, panelX - 10, panelY - 10, panelW + 20, panelH, 120, 120, 130);

        Layout L = Begin(panelX, panelY, panelW);
        Header(canvas, L, "PHAROAH LITE");
        Separator(canvas, L);

        Checkbox(canvas, L, "WALLS", &VisibilityBoxes::enabled);
        Checkbox(canvas, L, "TRIGGER BOT", &RecoverySuite::triggerBotEnabled);
        Checkbox(canvas, L, "HEAL TRIGGER BOT", &RecoverySuite::autoHealEnabled);

        Separator(canvas, L);
        if (Button(canvas, L, "CYCLE FIRE MODE")) CycleFireMode();
        DrawString(canvas, L.x, L.cursorY, "MODE", kFontScale * 0.7f, 160, 160, 170);
        DrawChar(canvas, (char)('0' + g_LiteFireMode), L.x + 40, L.cursorY, kFontScale * 0.7f, 255, 210, 110);
        L.cursorY += 16.0f;

        Separator(canvas, L);
        Checkbox(canvas, L, "AUTO-RESPAWN", &g_AutoRespawn);
        if (Button(canvas, L, "RESPAWN NOW")) g_PendingRespawnNow = true;

        Separator(canvas, L);
        DrawString(canvas, L.x, L.cursorY, "CARDS 1-5", kFontScale, 255, 210, 110);
        L.cursorY += 18.0f;
        DrawCardRow(canvas, L.x, L.cursorY);
        L.cursorY += 50.0f;

        DrawString(canvas, L.x, L.cursorY, DirectFire::g_ObjCount > 0 ? "DECK FOUND" : "SCANNING", kFontScale * 0.7f,
                   DirectFire::g_ObjCount > 0 ? 120 : 200, DirectFire::g_ObjCount > 0 ? 220 : 160, 130);
    }

    inline void DrawHint(SDK::UCanvas* canvas) {
        if (!canvas) return;
        FillRectLines(canvas, 16, 16, 220, 22, 18, 18, 20);
        Outline(canvas, 16, 16, 220, 22, 120, 120, 130);
        DrawString(canvas, 24, 20, "INSERT-MENU", kFontScale, 255, 210, 110);
    }

    inline bool g_LoggedCursorFirstDraw = false;
    inline void DrawCursor(SDK::UCanvas* canvas) {
        if (!canvas) return;
        float x = g_Input.mouseX, y = g_Input.mouseY;
        if (!g_LoggedCursorFirstDraw) {
            g_LoggedCursorFirstDraw = true;
            InitLog("[LiteMenu] cursor first drawn at client-space (%.0f, %.0f).", x, y);
        }
        Line(canvas, x - 20, y, x + 20, y, 255, 0, 255);
        Line(canvas, x, y - 20, x, y + 20, 255, 0, 255);
        Outline(canvas, x - 4, y - 4, 8, 8, 255, 0, 255);
    }

    // Call once per PostRender tick. LITE never installs a D3D11 hook, so
    // unlike CanvasMenu::Tick this has no "is the real hook already working"
    // gate to check - it always runs.
    inline bool g_LoggedException = false;
    inline void Tick(SDK::UCanvas* canvas) {
        PollToggleKey();
        __try {
            DrawHint(canvas);
            if (!g_MenuOpen) return;
            PollInput();
            DrawPanel(canvas);
            DrawCursor(canvas);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            if (!g_LoggedException) {
                g_LoggedException = true;
                InitLog("[LiteMenu] EXCEPTION caught inside Tick() (code 0x%08lX).", GetExceptionCode());
            }
        }
    }
}
