#pragma once
// ============================================================================
//  PHAROAH LITE  —  minimal standalone build for PaladinsSDK-master's PHAROAH
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
//
// The panel for PHAROAH LITE. Deliberately a SIBLING of CanvasMenu.h, not an
// edit to it - LITE is a genuinely separate build, and touching the file the
// full PHAROAH build already depends on risks breaking something proven, for
// zero benefit.
//
// Same drawing rule as CanvasMenu.h and RenderBoxesViaCanvas: Draw2DLine is
// the ONLY primitive used anywhere in this file - see the big comment at the
// top of CanvasMenu.h for why (DrawTile/DrawText crashed a real match twice).
//
// UI MODEL, v2 - ALWAYS VISIBLE. Per PRIMAL_MONKE, directly: "I demand next
// time this appear no matter what." The old design gated the whole panel
// behind INSERT, and a v1 crash (see PHAROAH_LITE_NOTES.md) meant pressing
// INSERT sometimes showed nothing at all - which reads as "the menu doesn't
// exist" even when the crash is the real bug. So there is no more open/
// closed state for the list itself: it draws every frame, top-left, always.
// Every toggle is an F-key (F1-F9), shown right next to its own checkmark,
// so "what do I press" never depends on remembering anything or reading a
// separate legend. F8 collapses it to a one-line reminder - never fully
// gone, per the same demand. Numbers 1-5 (cards) and 6-9 (fire modes) are
// untouched from before; F-keys were chosen for everything new specifically
// so they can never collide with those.
//
// WHAT THIS FILE DOES NOT DO: install a D3D11/kiero hook, create an ImGui
// context, or call into any of PHAROAH's periodic background subsystems
// (HealthBarColor, MeshSkin, DevSkin, skin scanning, the bone/skeleton
// system, RunSafeThreadSubsystems as a whole). LITE's whole reason to exist
// is to be the small, explicit allow-list version - see main_lite.cpp for
// exactly what runs each frame. Unlocker IS now included (per explicit
// request - "unlocker comes from our own code"), called directly via its
// own RunPass(), NOT via its Tick() - see TickUnlockerSafe below for why.
//
// *** EVERY NEW FUNCTION ADDED HERE MUST BE CHECKED FOR ImGui::GetIO() /
// ImGui::GetTime() / ImGui::GetBackgroundDrawList() BEFORE IT SHIPS. ***
// LITE has no ImGui context, ever. Those calls assert/crash with none, and
// it is NOT an SEH exception - __try/__except does not catch it. This is
// not a style note, it is the exact bug that shipped twice already (see
// PHAROAH_LITE_NOTES.md). Grep any shared function you're about to call for
// "ImGui::Get" before wiring it in, every single time.

#include "globals.h"
#include "ext/kiero/kiero.h"
#include "menus/VisibilityBoxes.h"
#include "menus/DirectFire.h"
#include "menus/RecoverySuite.h"
#include "menus/FireModeMenu.h"
#include "menus/Unlocker.h"
#include "Utils/SafeCalls.h"
#include <Windows.h>
#include <cctype>

namespace LiteMenu {

    // ---------------------------------------------------------------------
    // INPUT - polled directly against the real game window, independent of
    // any render hook. A BONUS way to click card boxes / fire-mode pips -
    // not required for anything, every one of those also has a key.
    // ---------------------------------------------------------------------
    struct InputState {
        float mouseX = 0.0f, mouseY = 0.0f;
        bool mouseDown = false;
        bool clickedEdge = false;
    };
    inline InputState g_Input;

    inline void PollInput() {
        static bool wasDown = false;
        HWND wnd = (HWND)kiero::findRealGameWindow();
        if (!wnd) { g_Input = InputState(); wasDown = false; return; }
        POINT p{};
        GetCursorPos(&p);
        ScreenToClient(wnd, &p);
        g_Input.mouseX = (float)p.x;
        g_Input.mouseY = (float)p.y;
        bool down = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        g_Input.mouseDown = down;
        g_Input.clickedEdge = down && !wasDown;
        wasDown = down;
    }
    inline bool HitTestRect(float x, float y, float w, float h) {
        return g_Input.mouseX >= x && g_Input.mouseX <= x + w &&
               g_Input.mouseY >= y && g_Input.mouseY <= y + h;
    }

    // ---------------------------------------------------------------------
    // DRAWING PRIMITIVES - Draw2DLine only.
    // ---------------------------------------------------------------------
    inline void Line(SDK::UCanvas* canvas, float x0, float y0, float x1, float y1,
                      unsigned char r, unsigned char g, unsigned char b, unsigned char a = 255) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = a;
        canvas->Draw2DLine(x0, y0, x1, y1, c);
    }

    inline void Outline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                         unsigned char r, unsigned char g, unsigned char b) {
        Line(canvas, x,     y,     x + w, y,     r, g, b);
        Line(canvas, x + w, y,     x + w, y + h, r, g, b);
        Line(canvas, x + w, y + h, x,     y + h, r, g, b);
        Line(canvas, x,     y + h, x,     y,     r, g, b);
    }

    inline void FillRectLines(SDK::UCanvas* canvas, float x, float y, float w, float h,
                               unsigned char r, unsigned char g, unsigned char b) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = 255;
        for (float row = y; row < y + h; row += 2.0f) {
            canvas->Draw2DLine(x, row, x + w, row, c);
        }
    }

    namespace Font {
        struct Seg { float x0, y0, x1, y1; };
        inline int Glyph(char ch, Seg* out) {
            switch (ch) {
            case 'A': out[0]={0,4,0,1}; out[1]={0,1,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,4}; out[4]={0,2,2,2}; return 5;
            case 'B': out[0]={0,0,0,4}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={2,2,2,4}; out[5]={2,4,0,4}; return 6;
            case 'C': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; return 3;
            case 'D': out[0]={0,0,0,4}; out[1]={0,0,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,3}; out[4]={2,3,1,4}; out[5]={1,4,0,4}; return 6;
            case 'E': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={0,2,2,2}; return 4;
            case 'F': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,2,2,2}; return 3;
            case 'G': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,1,2}; return 5;
            case 'H': out[0]={0,0,0,4}; out[1]={2,0,2,4}; out[2]={0,2,2,2}; return 3;
            case 'I': out[0]={0,0,2,0}; out[1]={1,0,1,4}; out[2]={0,4,2,4}; return 3;
            case 'J': out[0]={2,0,2,3}; out[1]={2,3,1,4}; out[2]={1,4,0,3}; return 3;
            case 'K': out[0]={0,0,0,4}; out[1]={2,0,0,2}; out[2]={0,2,2,4}; return 3;
            case 'L': out[0]={0,0,0,4}; out[1]={0,4,2,4}; return 2;
            case 'M': out[0]={0,4,0,0}; out[1]={0,0,1,2}; out[2]={1,2,2,0}; out[3]={2,0,2,4}; return 4;
            case 'N': out[0]={0,4,0,0}; out[1]={0,0,2,4}; out[2]={2,4,2,0}; return 3;
            case 'O': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case 'P': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; return 4;
            case 'Q': out[0]={0,0,2,0}; out[1]={2,0,2,3}; out[2]={2,3,0,3}; out[3]={0,3,0,0}; out[4]={1,3,2,4}; return 5;
            case 'R': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={0,2,2,4}; return 5;
            case 'S': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case 'T': out[0]={0,0,2,0}; out[1]={1,0,1,4}; return 2;
            case 'U': out[0]={0,0,0,4}; out[1]={0,4,2,4}; out[2]={2,4,2,0}; return 3;
            case 'V': out[0]={0,0,1,4}; out[1]={2,0,1,4}; return 2;
            case 'W': out[0]={0,0,0,4}; out[1]={0,4,1,2}; out[2]={1,2,2,4}; out[3]={2,4,2,0}; return 4;
            case 'X': out[0]={0,0,2,4}; out[1]={2,0,0,4}; return 2;
            case 'Y': out[0]={0,0,1,2}; out[1]={2,0,1,2}; out[2]={1,2,1,4}; return 3;
            case 'Z': out[0]={0,0,2,0}; out[1]={2,0,0,4}; out[2]={0,4,2,4}; return 3;
            case '0': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case '1': out[0]={1,0,1,4}; return 1;
            case '2': out[0]={0,0,2,0}; out[1]={2,0,2,2}; out[2]={2,2,0,2}; out[3]={0,2,0,4}; out[4]={0,4,2,4}; return 5;
            case '3': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,2,2,2}; return 4;
            case '4': out[0]={0,0,0,2}; out[1]={0,2,2,2}; out[2]={2,0,2,4}; return 3;
            case '5': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case '6': out[0]={1,0,0,1}; out[1]={0,1,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,0,2}; return 5;
            case '7': out[0]={0,0,2,0}; out[1]={2,0,1,4}; return 2;
            case '8': out[0]={0,0,2,0}; out[1]={0,0,0,4}; out[2]={2,0,2,4}; out[3]={0,4,2,4}; out[4]={0,2,2,2}; return 5;
            case '9': out[0]={0,0,2,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,0,2,4}; return 4;
            case '-': out[0]={0,2,2,2}; return 1;
            case '/': out[0]={0,4,2,0}; return 1;
            case '?': out[0]={0,1,1,0}; out[1]={1,0,2,1}; out[2]={2,1,1,2}; out[3]={1,3,1,3}; return 4;
            default: return 0;
            }
        }
    }

    inline void DrawChar(SDK::UCanvas* canvas, char ch, float x, float y, float scale,
                          unsigned char r, unsigned char g, unsigned char b) {
        Font::Seg segs[8];
        int n = Font::Glyph((char)toupper((unsigned char)ch), segs);
        for (int i = 0; i < n; i++) {
            Line(canvas, x + segs[i].x0 * scale, y + segs[i].y0 * scale,
                         x + segs[i].x1 * scale, y + segs[i].y1 * scale, r, g, b);
        }
    }

    inline float DrawString(SDK::UCanvas* canvas, float x, float y, const char* text, float scale,
                             unsigned char r, unsigned char g, unsigned char b) {
        float cursor = x;
        for (const char* p = text; *p; p++) {
            DrawChar(canvas, *p, cursor, y, scale, r, g, b);
            cursor += 4.0f * scale;
        }
        return cursor - x;
    }
    inline float StringWidth(const char* text, float scale) {
        float n = 0; for (const char* p = text; *p; p++) n += 1.0f;
        return n * 4.0f * scale;
    }

    const float kFontScale = 3.0f;

    // "[F1] LABEL ............... ON/OFF" - key badge, label, checkmark, all
    // in one fixed-format row. The key IS the click; this isn't a mouse
    // widget. Returns nothing - caller advances its own cursorY.
    inline void ToggleRow(SDK::UCanvas* canvas, float x, float y, const char* keyLabel,
                           const char* label, bool value) {
        Outline(canvas, x, y, 18, 18, 200, 200, 210);
        DrawString(canvas, x + 2, y + 2, keyLabel, kFontScale * 0.75f, 255, 210, 110);
        DrawString(canvas, x + 26, y + 2, label, kFontScale * 0.8f, 220, 220, 225);
        const char* state = value ? "ON" : "OFF";
        float sw = StringWidth(state, kFontScale * 0.8f);
        DrawString(canvas, x + 210 - sw, y + 2, state, kFontScale * 0.8f,
                   value ? 90 : 170, value ? 230 : 170, value ? 120 : 175);
        if (value) {
            Line(canvas, x + 3, y + 10, x + 7, y + 14, 90, 230, 120);
            Line(canvas, x + 7, y + 14, x + 15, y + 4,  90, 230, 120);
        }
    }

    // Same shape, no ON/OFF - for one-shot actions (LEAVE MATCH) rather than
    // toggles.
    inline void ActionRow(SDK::UCanvas* canvas, float x, float y, const char* keyLabel, const char* label) {
        Outline(canvas, x, y, 18, 18, 220, 140, 120);
        DrawString(canvas, x + 2, y + 2, keyLabel, kFontScale * 0.75f, 255, 210, 110);
        DrawString(canvas, x + 26, y + 2, label, kFontScale * 0.8f, 235, 190, 170);
    }

    // ---------------------------------------------------------------------
    // THE 5 CARD BOXES - unchanged mechanic from before: DirectFire.h's
    // existing g_CardKey[5]={'1'..'5'} already maps each number key to its
    // own resolved card slot and toggles that slot's spam independently;
    // this only draws it. Filled box = that slot currently spamming.
    // ---------------------------------------------------------------------
    inline void DrawCardRow(SDK::UCanvas* canvas, float x, float y) {
        const float boxSize = 28.0f, gap = 6.0f;
        for (int i = 0; i < 5; i++) {
            float bx = x + i * (boxSize + gap);
            bool ready = DirectFire::g_Five[i].dev != nullptr;
            bool spamming = DirectFire::g_CardSpam[i];

            if (HitTestRect(bx, y, boxSize, boxSize) && g_Input.clickedEdge) {
                DirectFire::g_CardSpam[i] = !DirectFire::g_CardSpam[i];
            }

            unsigned char r = ready ? 90 : 60, g = ready ? 90 : 60, b = ready ? 95 : 60;
            if (spamming) { r = 90; g = 230; b = 120; }
            if (spamming) FillRectLines(canvas, bx, y, boxSize, boxSize, r / 3, g / 3, b / 3);
            Outline(canvas, bx, y, boxSize, boxSize, r, g, b);

            char num[2] = { (char)('1' + i), 0 };
            DrawString(canvas, bx + boxSize / 2.0f - 3.0f, y + boxSize / 2.0f - 6.0f, num, kFontScale,
                       spamming ? 20 : 220, spamming ? 40 : 220, spamming ? 20 : 220);
        }
    }

    // ========================================================================
    // FIRE MODES - detects every device (weapon + each ability) that actually
    // HAS more than one fire mode (ATgDevice::m_FireMode.Num() > 1, a real
    // field read, not a guess), gives each one its own key (6,7,8,9 - 1-5
    // are cards). Detection reuses DirectFire::g_PendingDevSweep, the SAME
    // GObjects sweep the card system already has - expensive, so throttled
    // to pawn-change-or-4s, never every frame.
    // ========================================================================
    struct FireModeSlot {
        SDK::ATgDevice* dev = nullptr;
        int modeCount = 0;
        int key = 0;
        char label[24] = {};
    };
    static const int kMaxFireModeSlots = 4;
    inline FireModeSlot g_FireModeSlots[kMaxFireModeSlots];
    inline int  g_FireModeSlotCount = 0;
    inline void* g_FireModeSweptPawn = nullptr;
    inline ULONGLONG g_LastFireModeRescanMs = 0;
    inline bool g_FireModeKeyWasDown[kMaxFireModeSlots] = {};

    inline void RebuildFireModeSlots() {
        g_FireModeSlotCount = 0;
        for (int i = 0; i < DirectFire::g_DevCount && g_FireModeSlotCount < kMaxFireModeSlots; i++) {
            const DirectFire::DevRow& row = DirectFire::g_Dev[i];
            if (!row.dev || row.isCard) continue;
            int count = 0;
            __try { count = (int)row.dev->m_FireMode.Num(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
            if (count <= 1) continue;

            FireModeSlot& slot = g_FireModeSlots[g_FireModeSlotCount];
            slot.dev = row.dev;
            slot.modeCount = count;
            slot.key = '6' + g_FireModeSlotCount;
            lstrcpynA(slot.label, row.label[0] ? row.label : row.name, sizeof(slot.label));
            g_FireModeSlotCount++;
        }
    }

    inline void TickFireModesSafe() {
        if (Globals::LocalPawn != g_FireModeSweptPawn) {
            g_FireModeSweptPawn = Globals::LocalPawn;
            DirectFire::g_PendingDevSweep = true;
            g_LastFireModeRescanMs = GetTickCount64();
            return;
        }
        ULONGLONG now = GetTickCount64();
        if (now - g_LastFireModeRescanMs > 4000) {
            g_LastFireModeRescanMs = now;
            DirectFire::g_PendingDevSweep = true;
        }
        RebuildFireModeSlots();
    }

    inline void PollFireModeKeys() {
        for (int i = 0; i < g_FireModeSlotCount; i++) {
            bool down = (GetAsyncKeyState(g_FireModeSlots[i].key) & 0x8000) != 0;
            if (down && !g_FireModeKeyWasDown[i]) {
                SDK::ATgDevice* d = g_FireModeSlots[i].dev;
                if (d) {
                    int cur = 0;
                    __try { cur = (int)d->CurrentFireMode; } __except (EXCEPTION_EXECUTE_HANDLER) { cur = 0; }
                    int next = (cur + 1) % g_FireModeSlots[i].modeCount;
                    ApplyFireModeRaw(d, next);
                }
            }
            g_FireModeKeyWasDown[i] = down;
        }
    }

    inline void DrawFireModes(SDK::UCanvas* canvas, float x, float y) {
        if (g_FireModeSlotCount == 0) {
            DrawString(canvas, x, y, "NO MULTI-MODE ABILITIES FOUND", kFontScale * 0.65f, 170, 170, 175);
            return;
        }
        float cy = y;
        for (int i = 0; i < g_FireModeSlotCount; i++) {
            const FireModeSlot& slot = g_FireModeSlots[i];
            Outline(canvas, x, cy, 18, 18, 200, 200, 210);
            char keyCh[2] = { (char)slot.key, 0 };
            DrawString(canvas, x + 4, cy + 2, keyCh, kFontScale * 0.8f, 255, 210, 110);
            DrawString(canvas, x + 24, cy + 2, slot.label, kFontScale * 0.6f, 210, 210, 215);
            cy += 22.0f;

            int cur = 0;
            __try { cur = slot.dev ? (int)slot.dev->CurrentFireMode : 0; } __except (EXCEPTION_EXECUTE_HANDLER) { cur = 0; }
            for (int m = 0; m < slot.modeCount && m < 8; m++) {
                float px = x + m * 24.0f;
                bool active = (m == cur);
                if (HitTestRect(px, cy, 18, 18) && g_Input.clickedEdge) ApplyFireModeRaw(slot.dev, m);
                if (active) FillRectLines(canvas, px, cy, 18, 18, 20, 60, 25);
                Outline(canvas, px, cy, 18, 18, active ? 90 : 150, active ? 230 : 150, active ? 120 : 155);
                char mch[2] = { (char)('0' + m), 0 };
                DrawString(canvas, px + 5, cy + 2, mch, kFontScale * 0.7f,
                           active ? 30 : 210, active ? 255 : 210, active ? 60 : 215);
            }
            cy += 24.0f;
        }
    }

    // ========================================================================
    // ENEMY NAMES - reads the same gather cache the trigger bot's reticle
    // detection already uses. No extra reads of its own.
    // ========================================================================
    inline bool g_ShowNames = true;

    inline void DrawEnemyNames(SDK::UCanvas* canvas) {
        if (!canvas || !g_ShowNames) return;
        const VisibilityBoxes::GatherResult& g = VisibilityBoxes::g_CachedGather;
        if (!g.ok) return;

        VisibilityBoxes::PlainVec fwd, right, up;
        VisibilityBoxes::RotatorToVectors(g.camPitch, g.camYaw, fwd, right, up);
        ImVec2 screenSize = { (float)canvas->SizeX, (float)canvas->SizeY };

        for (int i = 0; i < g.count; i++) {
            const VisibilityBoxes::BoxEntry& e = g.entries[i];
            if (e.kind != VisibilityBoxes::BoxKind::Enemy) continue;
            if (!e.championName[0]) continue;

            VisibilityBoxes::PlainVec top{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight + 14.0f };
            ImVec2 screen;
            if (!VisibilityBoxes::WorldToScreen(top, g.camLoc, fwd, right, up, g.fov, screenSize.x, screenSize.y, screen))
                continue;

            float w = StringWidth(e.championName, kFontScale * 0.75f);
            DrawString(canvas, screen.x - w / 2.0f, screen.y, e.championName, kFontScale * 0.75f, 255, 225, 140);
        }
    }

    // ---------------------------------------------------------------------
    // RESPAWN - LITE's own small tracker, deliberately NOT reusing
    // RecoverySuite::ProcessPendingSafeResets (that also drives the whole
    // subsystem sweep LITE exists to avoid). Same underlying call
    // (SafeCalls::ServerSetReadyToPlay), same 1x/sec throttle while dead.
    // ---------------------------------------------------------------------
    inline bool g_AutoRespawn = true;
    inline bool g_PendingRespawnNow = false;
    inline ULONGLONG g_LastRespawnTryMs = 0;

    inline void TickRespawnSafe() {
        if (g_PendingRespawnNow) {
            g_PendingRespawnNow = false;
            SafeCalls::ServerSetReadyToPlay();
        }
        if (!g_AutoRespawn || !Globals::LocalPawn) return;
        ULONGLONG now = GetTickCount64();
        if (now - g_LastRespawnTryMs < 500) return;
        g_LastRespawnTryMs = now;
        int cur = 0, mx = 0;
        if (SafeCalls::GetPawnHealth(&cur, &mx) && cur <= 0) {
            SafeCalls::ServerSetReadyToPlay();
        }
    }

    // ---------------------------------------------------------------------
    // UNLOCKER - reuses Unlocker::RunPass() directly, NOT Unlocker::Tick().
    // Tick() calls ImGui::GetTime() unconditionally (see the file-header
    // warning) - exactly the crash category this build already got bitten
    // by twice. RunPass() itself (the actual scan+write walk) has zero
    // ImGui calls - confirmed by reading it in full. This wrapper is LITE's
    // own GetTickCount64 throttle standing in for what Tick() would have
    // done, at the same ~1s cadence Unlocker defaults to
    // (g_PersistSecs=1.0), and the same "nothing to do in a match" gate.
    // Also bypasses Perf::g_PotatoMode on purpose - that flag exists to
    // suppress exactly this kind of background scan in the FULL build,
    // where several such scans stack up; LITE only ever runs this one, so
    // there is nothing for Potato Mode to protect here. g_Mode defaults to
    // MODE_EVERYTHING (unlock everything), matching "a FULL unlocker".
    // ---------------------------------------------------------------------
    inline bool g_UnlockerEnabled = true;
    inline ULONGLONG g_LastUnlockRunMs = 0;

    inline void TickUnlockerSafe() {
        if (!g_UnlockerEnabled) return;
        if (Globals::LocalPawn) return; // matches Unlocker's own "nothing to re-apply in a match" gate
        ULONGLONG now = GetTickCount64();
        if (now - g_LastUnlockRunMs < 1000) return;
        g_LastUnlockRunMs = now;
        Unlocker::RunPass(false, false, false);
    }

    // ---------------------------------------------------------------------
    // GRAYSCALE (F9) - matches regular PHAROAH's own keybind exactly, per
    // explicit request ("F9 doesn't cause grayscale, fix this"). Reuses
    // RecoverySuite::ApplyGrayscale (a plain flag-set, safe from anywhere)
    // for the toggle itself, and RecoverySuite::ProcessPendingGrayscaleSafe
    // (the ProcessEvent-thread-safe reapply path - NOT ForceGrayscaleIfEnabled,
    // which is the hkPresent/render-thread version LITE has no equivalent
    // thread for) called once per frame from main_lite.cpp. Needs
    // RecoverySuite::g_EffectsSafe kept up to date - main_lite.cpp sets it
    // from Globals::initObjects() each frame, same meaning as the full
    // build's own runSafeBlock gate.
    // ---------------------------------------------------------------------
    inline bool g_GrayscaleKeyWasDown = false;
    inline void PollGrayscaleKey() {
        bool down = (GetAsyncKeyState(VK_F9) & 0x8000) != 0;
        if (down && !g_GrayscaleKeyWasDown) {
            RecoverySuite::ApplyGrayscale(!RecoverySuite::grayscaleOn);
        }
        g_GrayscaleKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // LEAVE MATCH (F7) - same route regular PHAROAH's LeaveMatch.h uses
    // (APlayerController::ConsoleCommand("disconnect")), called directly via
    // SafeCalls rather than pulling in LeaveMatch.h's whole ImGui-drawn
    // confirm-button UI, which LITE has no use for. No confirmation step
    // here (unlike the full build's deliberate two-step) - LITE has no
    // mouse-driven confirm dialog to show, and a dedicated key you have to
    // know about and press is already a deliberate action.
    // ---------------------------------------------------------------------
    inline bool g_LeaveKeyWasDown = false;
    inline void PollLeaveMatchKey() {
        bool down = (GetAsyncKeyState(VK_F7) & 0x8000) != 0;
        if (down && !g_LeaveKeyWasDown) {
            SafeCalls::RunConsoleCommand(L"disconnect");
        }
        g_LeaveKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // SHOW/HIDE (F8) - never fully gone, per "I demand this appear no
    // matter what": collapsed state still draws a one-line reminder.
    // ---------------------------------------------------------------------
    inline bool g_HudVisible = true;
    inline bool g_HudKeyWasDown = false;
    inline void PollHudKey() {
        bool down = (GetAsyncKeyState(VK_F8) & 0x8000) != 0;
        if (down && !g_HudKeyWasDown) g_HudVisible = !g_HudVisible;
        g_HudKeyWasDown = down;
    }

    // ---------------------------------------------------------------------
    // THE HUD - always drawn (unless collapsed via F8, which still leaves a
    // one-line reminder). No more open/closed panel state, no more tabs.
    // ---------------------------------------------------------------------
    inline void DrawHud(SDK::UCanvas* canvas) {
        if (!canvas) return;

        if (!g_HudVisible) {
            FillRectLines(canvas, 16, 16, 170, 20, 18, 18, 20);
            Outline(canvas, 16, 16, 170, 20, 120, 120, 130);
            DrawString(canvas, 22, 19, "[F8] SHOW PHAROAH LITE", kFontScale * 0.7f, 255, 210, 110);
            return;
        }

        const float x = 16.0f, y = 16.0f, w = 230.0f;
        float cy = y + 8.0f;
        const float rowH = 22.0f;

        // Background sized to fit everything - measured out, not guessed:
        // header + 7 toggle/action rows + separator + cards row + separator
        // + fire modes (up to 4 slots x 2 rows).
        float h = 34.0f + 7 * rowH + 16.0f + 40.0f + 16.0f + (g_FireModeSlotCount > 0 ? g_FireModeSlotCount * 46.0f + 10.0f : 20.0f);
        FillRectLines(canvas, x - 8, y - 8, w + 16, h, 16, 16, 18);
        Outline(canvas, x - 8, y - 8, w + 16, h, 120, 120, 130);

        DrawString(canvas, x, cy, "PHAROAH LITE", kFontScale, 255, 210, 110);
        cy += 26.0f;

        ToggleRow(canvas, x, cy, "F1", "WALLS", VisibilityBoxes::enabled);
        cy += rowH;

        ToggleRow(canvas, x, cy, "F2", "ENEMY NAMES", g_ShowNames);
        cy += rowH;

        ToggleRow(canvas, x, cy, "F3", "TRIGGER BOT", RecoverySuite::triggerBotEnabled);
        cy += rowH;

        ToggleRow(canvas, x, cy, "F4", "HEAL TRIGGER BOT", RecoverySuite::autoHealEnabled);
        cy += rowH;

        ToggleRow(canvas, x, cy, "F5", "UNLOCKER", g_UnlockerEnabled);
        cy += rowH;

        ToggleRow(canvas, x, cy, "F6", "AUTO-RESPAWN", g_AutoRespawn);
        cy += rowH;

        ToggleRow(canvas, x, cy, "F9", "GRAYSCALE", RecoverySuite::grayscaleOn);
        cy += rowH;

        ActionRow(canvas, x, cy, "F7", "LEAVE MATCH");
        cy += rowH;

        cy += 6.0f;
        Line(canvas, x, cy, x + w, cy, 90, 90, 95);
        cy += 10.0f;

        DrawString(canvas, x, cy, "CARDS 1-5", kFontScale * 0.8f, 255, 210, 110);
        cy += 16.0f;
        DrawCardRow(canvas, x, cy);
        cy += 40.0f;

        Line(canvas, x, cy, x + w, cy, 90, 90, 95);
        cy += 10.0f;

        DrawString(canvas, x, cy, "FIRE MODES 6-9", kFontScale * 0.8f, 255, 210, 110);
        cy += 16.0f;
        DrawFireModes(canvas, x, cy);

        PollInput();
        // Cursor - only meaningful while the HUD is visible (nothing to
        // click while collapsed).
        float mx = g_Input.mouseX, my = g_Input.mouseY;
        Line(canvas, mx - 18, my, mx + 18, my, 255, 0, 255);
        Line(canvas, mx, my - 18, mx, my + 18, 255, 0, 255);
        Outline(canvas, mx - 4, my - 4, 8, 8, 255, 0, 255);
    }

    // ---------------------------------------------------------------------
    // Toggle key polling - F1-F6 flip the same bools ToggleRow just drew.
    // Kept as a small array + edge-detect loop rather than one-off bools
    // per key, mirroring DirectFire::TickCards' pattern.
    // ---------------------------------------------------------------------
    inline bool g_ToggleKeyWasDown[6] = {};
    inline void PollToggleKeys() {
        const int keys[6] = { VK_F1, VK_F2, VK_F3, VK_F4, VK_F5, VK_F6 };
        for (int i = 0; i < 6; i++) {
            bool down = (GetAsyncKeyState(keys[i]) & 0x8000) != 0;
            if (down && !g_ToggleKeyWasDown[i]) {
                switch (i) {
                    case 0: VisibilityBoxes::enabled = !VisibilityBoxes::enabled; break;
                    case 1: g_ShowNames = !g_ShowNames; break;
                    case 2: RecoverySuite::triggerBotEnabled = !RecoverySuite::triggerBotEnabled; break;
                    case 3: RecoverySuite::autoHealEnabled = !RecoverySuite::autoHealEnabled; break;
                    case 4: g_UnlockerEnabled = !g_UnlockerEnabled; break;
                    case 5: g_AutoRespawn = !g_AutoRespawn; break;
                }
            }
            g_ToggleKeyWasDown[i] = down;
        }
    }

    // ---------------------------------------------------------------------
    // Call once per PostRender tick. LITE never installs a D3D11 hook, so
    // there is no "is the real hook already working" gate to check.
    // ---------------------------------------------------------------------
    inline bool g_LoggedFirstDraw = false;
    inline bool g_LoggedException = false;
    inline void Tick(SDK::UCanvas* canvas) {
        PollToggleKeys();
        PollHudKey();
        PollFireModeKeys();
        PollGrayscaleKey();
        PollLeaveMatchKey();
        __try {
            if (!g_LoggedFirstDraw) {
                g_LoggedFirstDraw = true;
                InitLog("[LiteMenu] HUD first drawn, canvas=%p.", (void*)canvas);
            }
            DrawEnemyNames(canvas);
            DrawHud(canvas);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            if (!g_LoggedException) {
                g_LoggedException = true;
                InitLog("[LiteMenu] EXCEPTION caught inside Tick() (code 0x%08lX).", GetExceptionCode());
            }
        }
    }
}
