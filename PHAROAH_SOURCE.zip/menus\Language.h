#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
//
// LANGUAGE — one flag, one helper, shared by every file that draws ImGui
// text. Split out into its own header (v10 follow-up) specifically so
// files that can't include RecoverySuite.h without a circular include
// (VisibilityBoxes.h, DirectFire.h, FireModeMenu.h, Gating.h,
// HealthBarColor.h — RecoverySuite.h includes THEM, not the other way
// round) can still translate their own on-screen text. Before this, only
// RecoverySuite.h's own strings (the header row + tab names) could use
// g_SpanishMode/Tm() at all — everything drawn by those other files had no
// way to reach it, which is why turning ESPANOL on only changed the tab
// NAMES and left everything INSIDE each tab in English.
//
// Same technique everywhere, same as PHAROAH LITE's own LiteMenu.h T()
// helper: wrap a visible string as Tm("English text", "Texto en espanol")
// at the call site. No new files needed per string, no separate localised
// copies of any file — the English and Spanish versions sit side by side
// in the same source line, in the existing files, exactly where the
// English-only string used to be.
// ============================================================================

namespace Language {
    inline bool g_Spanish = false;
    inline const char* Tm(const char* en, const char* es) { return g_Spanish ? es : en; }
}
