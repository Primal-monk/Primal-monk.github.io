#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include "menus/SkinDatabase.h"
#include "menus/Language.h"
using Language::Tm;
#include <Windows.h>
#include <string>

// ============================================================================
// SKIN SWAP — client-side skin changing
//
// WHAT THIS IS, HONESTLY:
// This does NOT unlock anything. It changes what YOUR client renders. Other
// players still see your real skin, because the server never agrees you own the
// one you picked. That's the same reason this class of tool can show skins as
// "unlocked" and you still can't equip them — the display flag is client-side,
// the ownership check is server-side.
//
// It's also exactly what the client-side custom skins seen in the Tempest scene
// are: a local visual override, visible only to you.
//
// HOW IT WORKS:
//   ATgPawn::r_nSkinId        (0x----, Net)  the skin the pawn renders
//   ATgPawn::r_nWeaponSkinId  (Net)          weapon skin
//   ATgPawn::r_nMountSkinId   (Net)          mount skin
//   ATgPawn::FlashChangeMesh()               rebuilds the mesh from those ids
//
// Writing the id alone does nothing visible — the mesh was already built. The
// rebuild is the essential second half, and FlashChangeMesh() is the game's own
// function for it (it's what runs when a skin legitimately changes mid-match).
//
// The ids are (Net), so the server WILL replicate its value back over ours. So
// like the grayscale/speed cases, we reassert on a throttle rather than once.
//
// NOTE ON WHY SetSkin ISN'T USED: ATgSkeletalMeshActor_Lobby::SetSkin exists but
// belongs to the LOBBY PREVIEW mesh, not the in-game pawn — it has no effect in a
// match. UTgBattleCheatManager::SetMountSkin is admin/standalone-gated. Neither
// is the in-match path.
//
// THREADING: FlashChangeMesh is a scripted ProcessEvent call, so it is deferred
// to the safe thread. The id writes are raw fields and safe anywhere, but they're
// done alongside the rebuild so the two stay in step.
// ============================================================================

namespace SkinSwap {

    inline bool  enabled = false;
    inline int   desiredSkinId = 0;
    inline int   desiredWeaponSkinId = 0;
    inline int   desiredMountSkinId = 0;
    inline bool  applyWeaponSkin = false;
    inline bool  applyMountSkin = false;

    inline bool  g_PendingApply = false;
    inline bool  g_PendingRestore = false;
    inline int   reassertIntervalMs = 1500;
    inline ULONGLONG g_LastAssertMs = 0;

    // Captured so "restore" puts back the genuine values rather than guesses.
    inline SDK::APawn* g_BasePawn = nullptr;
    inline int  g_BaseSkinId = -1, g_BaseWeaponSkinId = -1, g_BaseMountSkinId = -1;
    inline bool g_HaveBase = false;

    inline int  g_LiveSkinId = -1;
    inline int  g_ApplyCount = 0;
    inline bool g_LastRebuildOk = false;

    inline bool TryCaptureBase(SDK::ATgPawn* p) {
        __try {
            g_BaseSkinId       = p->r_nSkinId;
            g_BaseWeaponSkinId = p->r_nWeaponSkinId;
            g_BaseMountSkinId  = p->r_nMountSkinId;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryReadLive(SDK::ATgPawn* p, int* outSkin) {
        __try { *outSkin = p->r_nSkinId; return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryWriteSkinIds(SDK::ATgPawn* p, int skin, int weapon, int mount,
                                bool doWeapon, bool doMount) {
        __try {
            if (skin > 0) p->r_nSkinId = skin;
            if (doWeapon && weapon > 0) p->r_nWeaponSkinId = weapon;
            if (doMount && mount > 0) p->r_nMountSkinId = mount;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Scripted call — safe thread only.
    inline bool TryRebuildMesh(SDK::ATgPawn* p) {
        __try {
            p->FlashChangeMesh();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Called from HookedProcessEvent (the safe thread), because FlashChangeMesh
    // goes through ProcessEvent.
    inline void ProcessPending() {
        SDK::APawn* pawn = Globals::LocalPawn;
        if (!pawn) { g_HaveBase = false; g_BasePawn = nullptr; return; }
        SDK::ATgPawn* tg = (SDK::ATgPawn*)pawn;

        // Re-capture on pawn change (respawn / champion swap), otherwise a
        // "restore" would write another champion's skin id.
        if (pawn != g_BasePawn || !g_HaveBase) {
            g_BasePawn = pawn;
            g_HaveBase = TryCaptureBase(tg);
        }
        TryReadLive(tg, &g_LiveSkinId);

        if (g_PendingRestore) {
            g_PendingRestore = false;
            if (g_HaveBase) {
                TryWriteSkinIds(tg, g_BaseSkinId, g_BaseWeaponSkinId, g_BaseMountSkinId, true, true);
                TryRebuildMesh(tg);
            }
            return;
        }

        bool wantApply = g_PendingApply;
        if (!wantApply && enabled) {
            // The ids are replicated, so the server pushes its own value back.
            // Reassert periodically rather than once — same reasoning as the
            // grayscale reapply. Not every frame: FlashChangeMesh is a full mesh
            // rebuild and would visibly stutter.
            ULONGLONG now = GetTickCount64();
            if (now - g_LastAssertMs > (ULONGLONG)reassertIntervalMs) {
                g_LastAssertMs = now;
                // Only bother if the live value has actually drifted back.
                if (desiredSkinId > 0 && g_LiveSkinId != desiredSkinId) wantApply = true;
            }
        }

        if (wantApply) {
            g_PendingApply = false;
            if (desiredSkinId > 0) {
                TryWriteSkinIds(tg, desiredSkinId, desiredWeaponSkinId, desiredMountSkinId,
                                applyWeaponSkin, applyMountSkin);
                g_LastRebuildOk = TryRebuildMesh(tg);
                g_ApplyCount++;
                g_LastAssertMs = GetTickCount64();
            }
        }
    }

    // ---- browser state & helpers -----------------------------------------
    inline int  championFilter = 0;          // 0 = all champions
    inline char searchBuf[64] = {};
    inline const char* g_Champions[80] = { "(all champions)" };
    inline int  g_ChampionCount = 1;
    inline bool g_ChampionsBuilt = false;

    // Derived from the database itself, so the dropdown can never list a champion
    // that has no skins or miss one that does.
    inline void BuildChampionList() {
        if (g_ChampionsBuilt) return;
        g_ChampionsBuilt = true;
        for (int i = 0; i < SkinDB::kSkinCount; ++i) {
            const char* c = SkinDB::kSkins[i].champion;
            bool seen = false;
            for (int j = 1; j < g_ChampionCount; ++j) {
                if (lstrcmpA(g_Champions[j], c) == 0) { seen = true; break; }
            }
            if (!seen && g_ChampionCount < 80) g_Champions[g_ChampionCount++] = c;
        }
    }

    inline bool NameHas(const char* hay, const char* needle) {
        if (!hay || !needle || !needle[0]) return true;
        for (int i = 0; hay[i]; ++i) {
            int j = 0;
            while (needle[j]) {
                char a = hay[i + j], b = needle[j];
                if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
                if (b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
                if (a != b) break;
                ++j;
            }
            if (!needle[j]) return true;
        }
        return false;
    }

    // Reads the local pawn's class name and points the dropdown at that champion.
    // Uses the GNames index rather than FName(const char*) — that scans ~200k
    // entries and is what caused the bone crash and the jitter elsewhere.
    inline bool CopyPawnChampion(SDK::APawn* p, char* buf, int cap) {
        __try {
            buf[0] = '\0';
            if (!p) return false;
            SDK::UClass* cls = p->Class;
            if (!cls || cls->Name.Index == 0) return false;
            auto& names = SDK::FName::GetGlobalNames();
            if (!names.IsValidIndex((size_t)cls->Name.Index)) return false;
            SDK::FNameEntry* e = names[cls->Name.Index];
            if (!e) return false;
            const char* n = e->GetAnsiName();
            if (!n) return false;
            // Class names look like "TgPawn_Kinessa"; strip the prefix.
            const char* src = n;
            const char* pfx = "TgPawn_";
            int k = 0;
            bool match = true;
            for (; pfx[k]; ++k) {
                char a = n[k], b = pfx[k];
                if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
                if (b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
                if (a != b) { match = false; break; }
            }
            if (match) src = n + k;
            int i = 0;
            for (; i < cap - 1 && src[i]; ++i) buf[i] = src[i];
            buf[i] = '\0';
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline void SelectMyChampion() {
        BuildChampionList();
        char mine[64] = {};
        if (!CopyPawnChampion(Globals::LocalPawn, mine, 64) || !mine[0]) return;
        // Substring match both ways: the class name and the display name don't
        // always agree exactly (e.g. "MalDamba" vs "Mal'Damba").
        for (int j = 1; j < g_ChampionCount; ++j) {
            if (NameHas(g_Champions[j], mine) || NameHas(mine, g_Champions[j])) {
                championFilter = j;
                return;
            }
        }
    }

    inline void DrawControls(bool inMatch) {
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.9f, 1.0f)), Tm("SKIN SWAP  (client-side only)", "INTERCAMBIO DE PELIS  (solo lado cliente)"));
        ImGui::TextWrapped(Tm("This does NOT unlock anything. It changes what YOUR client renders — "
            "other players still see your real skin, because the server never agrees you own the "
            "one you picked. That is exactly what the client-side custom skins in the Tempest scene "
            "are, and it's why this class of tool can show skins as unlocked while you still can't equip them.",
            "Esto NO desbloquea nada. Cambia lo que YOUR cliente renderiza — "
            "los otros jugadores siguen viendo tu piel real, porque el servidor nunca acepta que "
            "posees la que elegiste. Eso es exactamente lo que las pieles personalizadas lado cliente "
            "en la escena Tempest son, y por eso esta clase de herramienta puede mostrar pieles como "
            "desbloqueadas mientras aún no puedes equiparlas."));
        ImGui::Separator();

        if (!inMatch) { ImGui::TextDisabled(Tm("Join a match first.", "Únete a una partida primero.")); return; }

        ImGui::Checkbox(Tm("Enable skin swap", "Habilitar intercambio de pieles"), &enabled);
        ImGui::SameLine();
        if (ImGui::Button(Tm("Apply Now", "Aplicar Ahora"), ImVec2(110, 24))) g_PendingApply = true;
        ImGui::SameLine();
        ImGui::Button(Tm("Restore Real Skin", "Restaurar Piel Real"), ImVec2(150, 24)) g_PendingRestore = true;

        // ---- SKIN BROWSER -------------------------------------------------
        // 2541 real skins across 59 champions, baked in at build time from
        // Paladins_Ids(1).txt. No file reading at runtime, so there is nothing to
        // ship alongside the DLL and nothing to go missing.
        BuildChampionList();

        ImGui::Separator();
        ImGui::PushItemWidth(170);
        ImGui::Combo(Tm("Champion", "Campeón"), &championFilter, g_Champions, g_ChampionCount);
        ImGui::PopItemWidth();
        ImGui::SameLine();
        if (ImGui::Button(Tm("Detect mine", "Detectar la mía"))) SelectMyChampion();
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip(Tm("Jumps the list to the champion you're currently playing.", "Salta la lista al campeón que estás jugando ahora."));
        }

        ImGui::PushItemWidth(170);
        ImGui::InputText(Tm("Search", "Buscar"), searchBuf, sizeof(searchBuf));
        ImGui::PopItemWidth();

        ImGui::BeginChild("skinlist", ImVec2(0, 240), true);
        int shown = 0;
        for (int i = 0; i < SkinDB::kSkinCount; ++i) {
            const SkinDB::Entry& e = SkinDB::kSkins[i];
            if (championFilter > 0 && lstrcmpA(e.champion, g_Champions[championFilter]) != 0) continue;
            if (searchBuf[0] && !NameHas(e.name, searchBuf)) continue;
            shown++;

            char label[160];
            wsprintfA(label, "%-6d  %-9s %s##s%d", e.id, e.rarity, e.name, i);

            // Colour by rarity so the list is scannable rather than a wall of text.
            ImVec4 col(0.85f, 0.85f, 0.85f, 1.0f);
            if (lstrcmpA(e.rarity, "Legendary") == 0)      col = ImVec4(1.00f, 0.78f, 0.35f, 1.0f);
            else if (lstrcmpA(e.rarity, "Epic") == 0)      col = ImVec4(0.78f, 0.55f, 1.00f, 1.0f);
            else if (lstrcmpA(e.rarity, "Rare") == 0)      col = ImVec4(0.45f, 0.75f, 1.00f, 1.0f);
            else if (lstrcmpA(e.rarity, "Default") == 0)   col = ImVec4(0.65f, 0.65f, 0.65f, 1.0f);

            ImGui::PushStyleColor(ImGuiCol_Text, col);
            bool clicked = ImGui::Selectable(label, desiredSkinId == e.id);
            ImGui::PopStyleColor();

            if (clicked) {
                desiredSkinId = e.id;
                enabled = true;          // clicking a skin means you want it on
                g_PendingApply = true;   // and applied now, not on the next drift check
            }
            if (ImGui::IsItemHovered() && championFilter == 0) {
                ImGui::SetTooltip("%s", e.champion);
            }
            if (shown >= 400) {          // keep the frame cheap on "(all champions)"
                ImGui::TextDisabled(Tm("...narrow the filter to see more", "...restringe el filtro para ver más"));
                break;
            }
        }
        if (shown == 0) ImGui::TextDisabled(Tm("Nothing matches that filter.", "Nada coincide con ese filtro."));
        ImGui::EndChild();
        ImGui::TextDisabled(Tm("Click a skin to apply it immediately. Default is listed first.", "Haz clic en una piel para aplicarla automáticamente. La predeterminada está primero."));

        ImGui::PushItemWidth(140);
        ImGui::InputInt(Tm("Skin ID", "ID de Piel"), &desiredSkinId);
        ImGui::PopItemWidth();

        ImGui::Spacing();
        ImGui::Checkbox(Tm("Also swap weapon skin", "También intercambiar piel de arma"), &applyWeaponSkin);
        if (applyWeaponSkin) {
            ImGui::PushItemWidth(140);
            ImGui::InputInt(Tm("Weapon Skin ID", "ID de Piel de Arma"), &desiredWeaponSkinId);
            ImGui::PopItemWidth();
        }
        ImGui::Checkbox(Tm("Also swap mount skin", "También intercambiar piel de monte"), &applyMountSkin);
        if (applyMountSkin) {
            ImGui::PushItemWidth(140);
            ImGui::InputInt(Tm("Mount Skin ID", "ID de Piel de Monte"), &desiredMountSkinId);
            ImGui::PopItemWidth();
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text(Tm("Your real skin ID   : %d", "ID de tu piel real   : %d"), g_BaseSkinId);
        ImGui::Text(Tm("Currently rendering : %d", "Renderizando actualmente : %d"), g_LiveSkinId);
        ImGui::Text(Tm("Applies: %d   |   last mesh rebuild: %s", "Aplicaciones: %d   |   última reconstrucción de mesh: %s"),
                    g_ApplyCount, g_LastRebuildOk ? "OK" : "failed/none");
        ImGui::SliderInt(Tm("Reassert every (ms)", "Reafirmar cada (ms)"), &reassertIntervalMs, 500, 5000);
        ImGui::TextWrapped(Tm("The skin id is replicated, so the server pushes its own value back — it "
            "gets reasserted on that interval, but only when the live id has actually drifted. "
            "FlashChangeMesh is a full mesh rebuild, so doing it every frame would visibly stutter.",
            "El id de piel se replica, así que el servidor empuja su propio valor - "
            "se reafirma en ese intervalo, pero solo cuando el id vivo realmente ha cambiado. "
            "FlashChangeMesh es una reconstrucción completa del mesh, así que hacerlo cada frame "
            "causaría estuttering visible."));

        if (g_LiveSkinId == desiredSkinId && desiredSkinId > 0) {
            ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), Tm("Swap is holding.", "El intercambio se mantiene."));
        } else if (enabled && desiredSkinId > 0) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)), Tm("Not currently applied - press Apply Now.", "No aplicado actualmente - presiona Aplicar Ahora."));
        }
    }
}
