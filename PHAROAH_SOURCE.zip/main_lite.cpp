// ============================================================================
//  PHAROAH LITE  —  minimal standalone build for PaladinsSDK-master's PHAROAH
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
//
// WHY THIS FILE EXISTS, SEPARATE FROM main.cpp
//
// Per PRIMAL_MONKE, directly: two DLLs, not one DLL with a mode switch. The
// full build (main.cpp) installs a D3D11/kiero Present hook and an ImGui
// menu; on some machines that hook silently never fires (see initlogs.md -
// kiero::bind() itself reports Success, but hkPresent never gets called),
// and PHAROAH's existing Canvas fallback (RenderBoxesViaCanvas / CanvasMenu)
// already catches that and keeps working. But that fallback still runs
// ALONGSIDE every other subsystem the full build has running each frame
// (Unlocker, HealthBarColor, MeshSkin, DevSkin, skin scanning, the bone/
// skeleton system) - none of that goes away just because the D3D11 hook
// stayed silent. If THAT is the actual source of a reported stutter (still
// happening even in fallback mode), skipping the D3D11 hook alone does not
// fix it - only actually not running those subsystems does.
//
// So PHAROAH LITE is a genuinely separate, smaller build:
//   - Same SDK init / ProcessEvent hook as the full build (Main(), copied
//     verbatim below - it has no D3D11/kiero/ImGui dependency of its own).
//   - NO kiero, NO D3D11 hook, NO ImGui context - ever.
//   - Every frame's work is an explicit, short allow-list (see the safe-
//     thread section in HookedProcessEventLite below) instead of the full
//     build's much larger subsystem sweep - see menus/LiteMenu.h for what's
//     actually in scope: walls, trigger bot, heal trigger bot, a simpler
//     fire-mode cycle, insta-respawn, and the 5-card macro.
//
// Everything reused below (RenderBoxesViaCanvas, DirectFire's card system,
// RecoverySuite::UpdateAutoFire, ApplyFireModeRaw, SafeCalls) is EXISTING,
// already-hardened PHAROAH code - LITE does not reimplement any of that
// logic from scratch. It only chooses, explicitly, what actually gets
// called each frame.
// ============================================================================
#include <windows.h>
#include <detours.h>
#include <cstdarg>
#include <cstdio>

// Same extern pattern main.cpp uses - VisibilityBoxes.h/RecoverySuite.h read
// these two regardless of which build they're compiled into. LITE never sets
// g_D3D11RenderHookConfirmedWorking true (there is no D3D11 hook to confirm),
// so RenderBoxesViaCanvas's "hook already working, stay off" gate never
// trips - LITE's boxes always draw. g_SimulateFallbackMode is unused here
// (that's an F6 test-mode concept from the full build) but still needs to
// exist as a real symbol since VisibilityBoxes.h references it.
volatile bool g_D3D11RenderHookConfirmedWorking = false;
volatile bool g_SimulateFallbackMode = false;
// The full build's UpdateAutoFire() reads this to suppress the trigger bot
// while its menu is open. LITE's HUD is always on screen (no open/closed
// state to tie this to), so it just stays false permanently - the trigger
// bot is never suppressed by HUD visibility in this build.
bool g_bShowMenu = false;

// Three more globals main.cpp normally owns, needed by shared headers this
// build also includes (Utils/TEB.h wants xorKey; RecoverySuite.h's trigger
// bot and magnet aim want the other two). g_RealLButtonHeld USED to be
// hardcoded false forever - "no WndProc hook to track it from" - but v8
// added magnet aim to LITE, which needs to know when the real mouse button
// is actually held for its fire-gating (RecoverySuite::ProcessAimAssist's
// `fireGatedEnabled && g_RealLButtonHeld` check). It's now updated every
// frame in HookedProcessEventLite from the exact same GetAsyncKeyState(
// VK_LBUTTON) call LiteMenu::PollInput() already makes for its own UI
// clicks - no new hook needed, just actually reading it instead of leaving
// it permanently false.
uintptr_t xorKey = 0;
ULONG_PTR kAutoFireExtraInfoTag = 0x50414C41; // "PALA" - same marker main.cpp uses
bool g_RealLButtonHeld = false;

static void InitLog(const char* fmt, ...);
// Forward declared for the same reason main.cpp does: RecoverySuite.h's
// "TEST RHI FALLBACK" button references this by name. LITE has no RHI-probe
// machinery at all, so this is a no-op stub (defined further down) - it only
// needs to exist so that unreachable button code still links.
DWORD WINAPI ManualRHITestThread(LPVOID);

#include "memory_manager.h"
#include "spoofer/return_spoofer.h"
#include "globals.h"
#include "ext/kiero/kiero.h"   // ONLY for kiero::findRealGameWindow() - no init()/bind() ever called
#include "menus/EquipEmoteMenu.h" // must come before RecoverySuite.h - see Utils/Helper.h's "emotes" dependency, same order main.cpp uses
#include "menus/VisibilityBoxes.h"
#include "menus/FireModeMenu.h"
#include "menus/DirectFire.h"
#include "menus/RecoverySuite.h"
#include "menus/LiteMenu.h"
#include "Utils/SafeCalls.h"

// ============================================================================
// LOGGING - separate file from the full build's PHAROAH_init.log, so running
// both side by side (or a user reporting a problem) never mixes the two up.
// ============================================================================
static void InitLog(const char* fmt, ...) {
    char msg[512];
    va_list ap;
    va_start(ap, fmt);
    _vsnprintf_s(msg, sizeof(msg), _TRUNCATE, fmt, ap);
    va_end(ap);

    printf("%s\n", msg);

    FILE* lf = nullptr;
    if (fopen_s(&lf, "PHAROAH_LITE_init.log", "a") == 0 && lf) {
        SYSTEMTIME st; GetLocalTime(&st);
        fprintf(lf, "[%02d:%02d:%02d.%03d] %s\n",
                st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, msg);
        fflush(lf);
        fclose(lf);
    }
}

// ============================================================================
// A handful of symbols the full build's headers reference that only make
// sense in the context of the full D3D11/RHI-probe machinery. RecoverySuite.h
// is shared between both builds unmodified (see the file header for why:
// touching it to strip these out would risk the full build to save nothing -
// unused code costs no runtime CPU). Stubs only - never called in LITE.
// ============================================================================
DWORD WINAPI ManualRHITestThread(LPVOID) { return 0; }

// Copied verbatim from main.cpp - same reasoning as Main() below: no D3D11/
// kiero/ImGui dependency of its own, purely a diagnostic resolve logged by
// Main(), safe to duplicate rather than share.
bool HookKeyState() {
    HMODULE API = (HMODULE)GetModuleBase(L"win32u.dll");
    if (API != NULL) {
        o_getasynckeystate = (LPFN_MBA)GetProcAddress(API, "NtUserGetAsyncKeyState");
        return o_getasynckeystate != NULL;
    }
    return false;
}

// ============================================================================
// Main() - COPIED VERBATIM from main.cpp. Pure SDK pattern-scanning and the
// ProcessEvent Detour attach; no D3D11/kiero/ImGui dependency of its own, so
// it is exactly as correct here as it is in the full build. Kept as an exact
// copy rather than a shared function specifically so nothing about the full
// build's file has to change for LITE to exist - see the file header.
// ============================================================================
void Main() {
    InitLog("[Init] Main() starting...");

    moduleBase = (HMODULE)GetModuleBase(L"Paladins.exe");
    InitLog("[Init] moduleBase = 0x%p %s", moduleBase, moduleBase ? "(OK)" : "(FAILED - module not found!)");

    PBYTE gobject_address = GetMovAddress<PBYTE>(
        FindPattern("48 8B 05 ? ? ? ? 4C 8B 04 0A 4C 33 04 F0 44", L"Paladins.exe"));
    InitLog("[Init] gobject_address = 0x%p %s", gobject_address, gobject_address ? "(OK)" : "(FAILED - pattern not found, likely game was updated)");
    GObject = reinterpret_cast<decltype(GObject)>(gobject_address);
    SDK::UObject::GObjects = reinterpret_cast<SDK::TAntiCheatArray<SDK::UObject*>*>(gobject_address);

    PBYTE gname_address = GetMovAddress<PBYTE>(
        FindPattern("48 8B 05 ? ? ? ? B9 ? ? ? ? 48 8B 0C 0A 48 BA", L"Paladins.exe"));
    InitLog("[Init] gname_address = 0x%p %s", gname_address, gname_address ? "(OK)" : "(FAILED - pattern not found)");
    GName = gname_address;
    SDK::FName::GNames = reinterpret_cast<SDK::TAntiCheatArray<SDK::FNameEntry*>*>(gname_address);

    Globals::UEngineAddr = GetMovAddress<DWORD_PTR>(
        FindPattern("48 8B 0D ? ? ? ? 48 85 C9 0F 84 ? ? ? ? 48 39 B9 ? ? ? ?", L"Paladins.exe"));
    InitLog("[Init] UEngineAddr = 0x%p %s", (void*)Globals::UEngineAddr, Globals::UEngineAddr ? "(OK)" : "(FAILED - pattern not found)");

    ProcessEventOriginal = GetCallAddress<tProcessEvent>(
        FindPattern("E8 ? ? ? ? 8D 4E ? 41 3B CD", L"Paladins.exe"));
    InitLog("[Init] ProcessEventOriginal = 0x%p %s", (void*)ProcessEventOriginal, ProcessEventOriginal ? "(OK)" : "(FAILED - pattern not found)");

    Globals::xorFunc = GetCallAddress<void*>(
        FindPattern("E8 ? ? ? ? 85 C0 75 0F 48 8B 03", L"Paladins.exe"));
    InitLog("[Init] xorFunc = 0x%p %s", Globals::xorFunc, Globals::xorFunc ? "(OK)" : "(FAILED - pattern not found)");

    if (Globals::xorFunc) {
        xorKey = (uintptr_t)GetAndValue<void*>((void*)((DWORD64)Globals::xorFunc + 0x63));
        InitLog("[Init] xorKey = 0x%p", (void*)xorKey);
    } else {
        InitLog("[Init] SKIPPED xorKey (xorFunc was null, would have crashed here otherwise)");
    }

    InitLog("[Init] HookKeyState() = %s", HookKeyState() ? "true" : "false");

    if (!ProcessEventOriginal) {
        InitLog("[Init] ABORTING hook attach - ProcessEventOriginal is null, DetourAttach would crash.");
        return;
    }

    if (DetourTransactionBegin() != NO_ERROR) { InitLog("[Init] DetourTransactionBegin FAILED"); return; }
    if (DetourUpdateThread(GetCurrentThread()) != NO_ERROR) { InitLog("[Init] DetourUpdateThread FAILED"); DetourTransactionAbort(); return; }
    extern void HookedProcessEventLite(void*, void*, void*, __int64);
    DetourAttach(&(LPVOID&)ProcessEventOriginal, (PBYTE)HookedProcessEventLite);
    LONG result = DetourTransactionCommit();
    InitLog("[Init] DetourTransactionCommit result = %ld %s", result, result == NO_ERROR ? "(OK)" : "(FAILED)");

    InitLog("[Init] Pre-warming class lookups...");
    SDK::ATgPawn::StaticClass();
    SDK::ATgPawn_Character::StaticClass();
    InitLog("[Init] Pre-warming done.");

    InitLog("[Init] Main() finished.");
}

void UnhookEverything() {
    if (ProcessEventOriginal) {
        DetourTransactionBegin();
        DetourUpdateThread(GetCurrentThread());
        extern void HookedProcessEventLite(void*, void*, void*, __int64);
        DetourDetach(&(LPVOID&)ProcessEventOriginal, (PBYTE)HookedProcessEventLite);
        DetourTransactionCommit();
    }
}

// Reentrancy check, pulled into its own function on purpose: MSVC's C2712
// forbids a __try anywhere in a function that also contains a C++ object
// needing unwinding (the DepthGuard struct's destructor counts), even in a
// separate nested scope. HookedProcessEventLite below needs __try for the
// PostRender name lookup, so the guard object has to live somewhere else.
static bool IsReentrantCallLite() {
    static thread_local int recursionDepth = 0;
    struct DepthGuard {
        DepthGuard() { recursionDepth++; }
        ~DepthGuard() { recursionDepth--; }
    } depthGuard;
    return recursionDepth > 1;
}

// ============================================================================
// HookedProcessEventLite - the entire per-call hot path for LITE. Deliberately
// short: the whole point of this build is that this function's body is an
// exhaustive list, not "everything RunSafeThreadSubsystems would have done".
// ============================================================================
void HookedProcessEventLite(void* pObject, void* pFunction, void* pParms, __int64 pResult) {
    // Reentrancy guard - identical reason to the full build's
    // HookedProcessEvent: without it, a scripted call made FROM one of the
    // safe-thread functions below (e.g. DeviceStartFire) would recurse back
    // into this same hook and could run the once-per-frame block twice in
    // the same frame, or worse, nest custom logic inside itself.
    if (IsReentrantCallLite()) {
        ProcessEventOriginal((SDK::UObject*)pObject, (SDK::UFunction*)pFunction, pParms, pResult);
        return;
    }

    // Not wrapped in __try: this is the real engine dispatch, unchanged from
    // how it would run with no hook installed at all - nothing about our own
    // code executes inside this call, so there's nothing of ours to guard
    // against here (everything PHAROAH LITE itself does below IS wrapped,
    // in ProcessPending/GatherAndCache/Tick, each in their own function).
    ProcessEventOriginal((SDK::UObject*)pObject, (SDK::UFunction*)pFunction, pParms, pResult);

    // PostRender detection - same name-cached approach as the full build
    // (a full-path FindObject lookup is not reliable in this SDK), just
    // without needing a shared cache across two unrelated call sites.
    static SDK::UFunction* prKey[64] = {};
    static unsigned char   prVal[64] = {};
    const size_t kPRCache = 64;

    bool isPostRender = false;
    {
        size_t slot = (((size_t)pFunction) >> 4) % kPRCache;
        size_t start = slot;
        while (true) {
            if (prKey[slot] == pFunction) { isPostRender = (prVal[slot] == 2); break; }
            if (prKey[slot] == nullptr) {
                char nm[80] = {};
                __try {
                    SDK::UFunction* fn = (SDK::UFunction*)pFunction;
                    if (fn && fn->Name.Index != 0) {
                        auto& names = SDK::FName::GetGlobalNames();
                        if (names.IsValidIndex((size_t)fn->Name.Index)) {
                            SDK::FNameEntry* entry = names[fn->Name.Index];
                            if (entry) {
                                const char* ansi = entry->GetAnsiName();
                                if (ansi) strncpy_s(nm, sizeof(nm), ansi, _TRUNCATE);
                            }
                        }
                    }
                }
                __except (EXCEPTION_EXECUTE_HANDLER) { nm[0] = 0; }
                unsigned char v = 1;
                if (nm[0] && _stricmp(nm, "PostRender") == 0) v = 2;
                prKey[slot] = (SDK::UFunction*)pFunction;
                prVal[slot] = v;
                isPostRender = (v == 2);
                break;
            }
            slot = (slot + 1) % kPRCache;
            if (slot == start) break;
        }
    }

    if (!isPostRender || !pParms) return;

    SDK::UCanvas* canvas = *(SDK::UCanvas**)pParms;

    // LITE has no ImGui context, ever - anything downstream that would
    // normally read ImGui::GetIO().DisplaySize for screen dimensions
    // (RenderTargetReticle, UpdateAutoFire) falls back to this instead. Real
    // canvas size, updated every frame, not a guessed resolution.
    if (canvas && canvas->SizeX > 0 && canvas->SizeY > 0) {
        VisibilityBoxes::g_FallbackScreenW = (float)canvas->SizeX;
        VisibilityBoxes::g_FallbackScreenH = (float)canvas->SizeY;
    }

    // DRAWING - always safe, no scripted calls, runs every PostRender.
    // Walls are drawn INSIDE LiteMenu::Tick now (LiteMenu::DrawWalls) - not
    // VisibilityBoxes::RenderBoxesViaCanvas, which is shared with the full
    // build's fallback and deliberately left alone; LITE needed real
    // distance-based colour and a thicker stroke neither has.
    LiteMenu::Tick(canvas);

    // ONCE PER FRAME - exactly one PostRender drives this, same throttle
    // pattern as the full build, so this can't run multiple times per frame
    // even though the game may call PostRender more than once in odd cases.
    static SDK::UFunction* prPreferred = nullptr;
    static ULONGLONG prPreferredLastMs = 0;
    ULONGLONG nowMs = GetTickCount64();
    if (prPreferred == nullptr || (nowMs - prPreferredLastMs) > 500) prPreferred = (SDK::UFunction*)pFunction;
    if ((SDK::UFunction*)pFunction != prPreferred) return;
    prPreferredLastMs = nowMs;

    // v8 FPS DIAGNOSTIC - "PHAROAH_LITE people report low FPS, not stutters,
    // and lowering game settings does nothing." Not reproducible here, so
    // this can't be root-caused blind, but it CAN be measured so the next
    // report brings real numbers instead of "it's laggy." Two things logged
    // every 5 seconds: how long THIS ENTIRE once-per-frame block actually
    // took (QueryPerformanceCounter, high-resolution, real CPU cost of
    // LITE's own work), and the wall-clock time between successive
    // once-per-frame entries (the effective frame time PostRender itself is
    // firing at - if THIS number is high while the block time is low, the
    // slowdown isn't LITE, it's upstream of it). Negligible overhead: two
    // QPC reads and a few comparisons, once per frame, not per ProcessEvent
    // call (which fires far more often than once a frame).
    LARGE_INTEGER qpcFreq, qpcStart;
    QueryPerformanceFrequency(&qpcFreq);
    QueryPerformanceCounter(&qpcStart);
    static ULONGLONG s_LastFrameMs = 0;
    static ULONGLONG s_DiagWindowStartMs = 0;
    static double s_WorstBlockMs = 0.0;
    static double s_WorstFrameGapMs = 0.0;
    static int s_FramesThisWindow = 0;
    if (s_LastFrameMs != 0) {
        double gap = (double)(nowMs - s_LastFrameMs);
        if (gap > s_WorstFrameGapMs) s_WorstFrameGapMs = gap;
    }
    s_LastFrameMs = nowMs;
    s_FramesThisWindow++;

    // ==== THE EXPLICIT ALLOW-LIST. This is the whole point of this build. ====
    DirectFire::TickCards();       // polls the 1-5 card hotkeys (render-thread safe: GetAsyncKeyState only)

    __try { DirectFire::ProcessPending(); }      // card sweep + fire (scripted calls, safe-thread only)
    __except (EXCEPTION_EXECUTE_HANDLER) {}

    __try { LiteMenu::TickFireModesSafe(); }     // detects multi-mode abilities, rebuilds the fire-modes list
    __except (EXCEPTION_EXECUTE_HANDLER) {}

    __try { LiteMenu::TickUnlockerSafe(); }      // own GetTickCount64 throttle - see the note on this function
    __except (EXCEPTION_EXECUTE_HANDLER) {}

    // g_EffectsSafe gates grayscale's reapply the same way the full build's
    // own runSafeBlock does - "is the object chain fully valid right now".
    RecoverySuite::g_EffectsSafe = Globals::initObjects();
    __try { RecoverySuite::ProcessPendingGrayscaleSafe(); } // F10 - the ProcessEvent-thread-safe path, not the hkPresent one
    __except (EXCEPTION_EXECUTE_HANDLER) {}

    __try { LiteMenu::TickNoSpreadRecoil(); }    // F9 - raw field writes only, see the note on this function
    __except (EXCEPTION_EXECUTE_HANDLER) {}

    __try { LiteMenu::TickHealthBarColorSafe(); } // N1 - ported from the full build, off by default
    __except (EXCEPTION_EXECUTE_HANDLER) {}

    // v5 fix: these three used to be gated behind `if (Globals::initObjects())`,
    // which meant the instant you left a match (initObjects() starts
    // returning false) they simply stopped being called at all - so
    // g_CachedGather kept its LAST live frame forever, and boxes/names/the
    // reticle hung frozen on the post-match screen instead of clearing. Now
    // called unconditionally every frame - each already self-gates safely on
    // LocalPawn/LocalController being null (SafeGatherBoxes returns
    // ok=false immediately, RenderTargetReticle returns on !gathered.ok,
    // UpdateAutoFire returns early AND releases any held trigger), so
    // calling them with no pawn is exactly what makes the cache clear
    // itself the next frame.
    VisibilityBoxes::UpdateMyChampionSpeed(); // resolves g_MyTableSpeed - the full build only calls this from its own ImGui Highlights tab, which LITE has no equivalent of, so the purple predicted-position reticle/trigger-bot path was never reachable until now
    VisibilityBoxes::GatherAndCache();        // raw field reads only (reticleHeadDistinct forced off in InitThreadLite)
    VisibilityBoxes::RenderTargetReticle();   // sets g_ReticleOnEnemy/g_ReticleOnHead/g_ReticleOnPredictionBox - LiteMenu::DrawReticleDot's colour and the trigger bot's fire signal both read these
    RecoverySuite::UpdateAutoFire();          // trigger bot + heal trigger bot

    // N2 - magnet aim (v8). g_RealLButtonHeld is what makes this "automatically
    // fire-gated" - read fresh every frame instead of the permanently-false
    // value it used to be, same GetAsyncKeyState call LiteMenu::PollInput()
    // already makes for its own UI clicks.
    g_RealLButtonHeld = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
    __try { RecoverySuite::ProcessAimAssist(); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}

    __try { RevertForcedFireModeIfWeaponChanged(Globals::LocalWeapon); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}

    {
        LARGE_INTEGER qpcEnd;
        QueryPerformanceCounter(&qpcEnd);
        double blockMs = (double)(qpcEnd.QuadPart - qpcStart.QuadPart) * 1000.0 / (double)qpcFreq.QuadPart;
        if (blockMs > s_WorstBlockMs) s_WorstBlockMs = blockMs;
        if (s_DiagWindowStartMs == 0) s_DiagWindowStartMs = nowMs;
        if (nowMs - s_DiagWindowStartMs >= 5000) {
            InitLog("[Perf] 5s window: %d frames, worst LITE-block time %.2f ms, worst frame gap %.1f ms",
                    s_FramesThisWindow, s_WorstBlockMs, s_WorstFrameGapMs);
            s_DiagWindowStartMs = nowMs;
            s_WorstBlockMs = 0.0;
            s_WorstFrameGapMs = 0.0;
            s_FramesThisWindow = 0;
        }
    }

    LiteMenu::TickRespawnSafe();                 // insta-respawn (LITE's own small tracker, see LiteMenu.h)
}

// ============================================================================
// InitThreadLite / DllMain - trimmed to match. No AllocConsole log window
// clutter avoided is minor; kept because InitLog already writes it for free
// and it costs nothing extra here either.
// ============================================================================
DWORD WINAPI InitThreadLite(LPVOID) {
    AllocConsole();
    FILE* f;
    freopen_s(&f, "CONOUT$", "w", stdout);
    freopen_s(&f, "CONOUT$", "w", stderr);

    { FILE* lf = nullptr; if (fopen_s(&lf, "PHAROAH_LITE_init.log", "w") == 0 && lf) fclose(lf); }

    InitLog("[Init] ==== PHAROAH LITE injected, InitThreadLite running ====");
    InitLog("[Init] build: " __DATE__ " " __TIME__);

    // v8 - LANGUAGE. The injector writes PHAROAH_lang.txt next to the DLL
    // ("EN" or "ES") when the user picks a language before injecting -
    // "in the DLL injector itself you can set two settings ENGLISH/ESPANOL
    // and it will auto-inject to be showing in the language you select."
    // Missing/unreadable file just means English, the existing default -
    // this is a nice-to-have starting point, not a requirement, and the
    // in-menu EN/ES button (top-left panel) still changes it any time
    // after injection regardless of what this file said.
    {
        FILE* lang = nullptr;
        if (fopen_s(&lang, "PHAROAH_lang.txt", "r") == 0 && lang) {
            char buf[8] = {};
            fgets(buf, sizeof(buf), lang);
            fclose(lang);
            if (_strnicmp(buf, "ES", 2) == 0) {
                LiteMenu::g_Spanish = true;
                InitLog("[Init] PHAROAH_lang.txt says ES - starting in Spanish.");
            } else {
                InitLog("[Init] PHAROAH_lang.txt found, not ES - starting in English.");
            }
        } else {
            InitLog("[Init] No PHAROAH_lang.txt (or unreadable) - starting in English (default).");
        }
    }

    InitLog("[Init] stage 1/2: Main() - SDK init, ProcessEvent detour");
    Main();
    InitLog("[Init] stage 2/2: Main() returned OK");

    // LITE-specific defaults. See LiteMenu.h and the DirectFire.h comments
    // this reuses for why each of these is already correct on its own -
    // nothing here is new logic, just turning the right existing switches on.
    VisibilityBoxes::enabled = true;             // walls on by default
    VisibilityBoxes::reticleHeadDistinct = false; // guarantees GatherAndCache never makes a scripted call
    // The ImGui-drawn crosshair dot (RenderTargetReticle's visual half) can
    // never draw in LITE anyway - it has no ImGui context, and that function
    // self-guards and returns instantly when there isn't one (see
    // VisibilityBoxes.h). LITE draws its OWN dot instead: LiteMenu::
    // DrawReticleDot(), Draw2DLine only, reading the same g_ReticleOnEnemy/
    // g_ReticleOnHead/g_ReticleOnPredictionBox globals RenderTargetReticle's
    // DETECTION half (which runs regardless of this flag) already sets.
    // v8: flipped to TRUE - RecoverySuite::ProcessAimAssist() (now reused
    // for LITE's own magnet aim) early-returns when this is false, and
    // that's the ONLY thing this flag was ever gating for safety-adjacent
    // reasons in this file; the dead ImGui draw branch it also skips was
    // always harmless dead code here regardless of its value.
    VisibilityBoxes::reticleEnabled = true;
    VisibilityBoxes::showSkeleton = false;        // never on in LITE - the bone system is exactly the kind of per-frame cost this build exists to avoid
    VisibilityBoxes::showHeadBox = false;
    // OFF, on purpose - DirectFire::TickCards() (still called every frame,
    // below) polls g_CardKey[5]={'1'..'5'} independently and would toggle
    // card slot 0 on its OWN every time '1' is pressed, fighting
    // LiteMenu::PollCardCycleKey()'s counter-based use of that same key.
    // LiteMenu now drives g_CardSpam[] entirely itself (the '1' cycle key,
    // plus direct box clicks) - g_HotkeysOn=false just stops TickCards from
    // also reacting to key state; ProcessPending() (the actual card FIRING)
    // is untouched by this flag and keeps working exactly as before.
    DirectFire::g_HotkeysOn = false;
    DirectFire::g_AutoSweep = true;               // already the default - auto-detects the equipped deck, no button needed
    // Unlocker::g_Mode already defaults to MODE_EVERYTHING - explicit here
    // anyway so "a FULL unlocker" is a readable line in this file, not an
    // assumption about Unlocker.h's own default.
    Unlocker::g_Mode = Unlocker::MODE_EVERYTHING;

    InitLog("[Init] ==== setup complete - no D3D11/kiero hook, no ImGui. HUD is on screen now, top-left. ====");
    return 0;
}

BOOL WINAPI DllMain(HMODULE hModule, DWORD dwReason) {
    if (dwReason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        CreateThread(nullptr, 0, InitThreadLite, nullptr, 0, nullptr);
    } else if (dwReason == DLL_PROCESS_DETACH) {
        UnhookEverything();
    }
    return TRUE;
}
