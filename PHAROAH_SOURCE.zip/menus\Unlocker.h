#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "menus/Perf.h"   // POTATO MODE - this file's Tick was the main stutter
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"   // SetClientValue - the CDO mechanism the checkmark fix rides on
#include <Windows.h>
#include <cstddef>

// ============================================================================
// ITEM UNLOCKER  —  PHAROAH's own independent implementation of the item-unlock mechanism
// ============================================================================
// Walks the global object array, keeps only UUIDataItem instances, and writes 1
// into UUIDataItem::m_qwInventorySessionId.A (+0x68) — the client's "this item
// is in my session inventory" signal.
//
// Built from independent SDK analysis - no third-party tool's code was copied.
// The hardest step other such tools face (the encrypted global object array
// with its TLS-resident key table) was already solved independently in
// Utils/TEB.cpp before this mechanism was ever investigated, so enumeration
// is free for us.
//
// ---------------------------------------------------------------------------
// CHEST MODE — why it exists and how it works
// ---------------------------------------------------------------------------
// A chest will not open once you already own everything inside it: the UI shows
// (313/313) and there is nothing left for it to give. Unlocking EVERYTHING is
// therefore self-defeating if what you want is what comes OUT of chests.
//
// The fix is not string-matching item names — that was a guess and it failed.
// The SDK hands us the real data:
//
//   UUIData_ChestExtended
//       nItemId      +0x68   int           <- the chest's own item id
//       nAllLootIds  +0x88   TArray<int>   <- every item id inside that chest
//   UUIDataItem
//       m_nId        +0x70   int           <- this item's id
//
// So chests and chest contents are identified BY ID, from the game's own tables.
// No name matching, no guessing.
//
//   MODE_EVERYTHING   - unlock all items (classic unlock-everything behaviour)
//   MODE_CHESTS_ONLY  - unlock ONLY chest items. Everything a chest could give
//                       stays locked, so every chest is full and openable.
//   MODE_NOT_CONTENTS - unlock everything EXCEPT things found inside chests.
//                       Keeps the incidental unlocks; chests stay full.
//
// THE CLASS FILTER IS NOT OPTIONAL. +0x68 means something different on every
// other UObject class; an unfiltered sweep writes into ~200k live objects and
// takes the game down. Every candidate is IsA()-checked first.
// ============================================================================

namespace Unlocker {

    // Derived from the SDK dump rather than hardcoded, so a regenerated dump
    // carries the offset automatically and a moved field breaks the build loudly
    // instead of silently scribbling on the wrong bytes.
    static const int kSessionIdOffset = (int)offsetof(SDK::UUIDataItem, m_qwInventorySessionId);
    static_assert((int)offsetof(SDK::UUIDataItem, m_qwInventorySessionId) == 0x68,
                  "UUIDataItem::m_qwInventorySessionId moved - re-verify against the new SDK dump.");

    enum Mode { MODE_EVERYTHING = 0, MODE_CHESTS_ONLY = 1, MODE_NOT_CONTENTS = 2 };

    inline bool  g_Enabled     = true;    // inject-and-done, no menu interaction required
    inline bool  g_Persist     = true;    // menus rebuild items as you navigate
    // WAS 1.0 SECONDS. That meant a walk of the ENTIRE GObjects array - a couple
    // of hundred thousand objects with string compares - once per second, on by
    // default, forever, whether or not the menu was even open.
    //
    // That is the stutter users reported: a hitch every second that never showed
    // in the FPS average because it is not a framerate drop.
    //
    // The unlocker only needs to re-run because the game rebuilds inventory
    // items as you navigate MENUS, and this walk is now ALSO what refreshes
    // the checkmark's per-frame re-stamp list with newly-built UUIDataPlayer
    // objects. Lowered 5.0 -> 1.0 so a freshly-opened menu's player card joins
    // the re-stamp list within ~1s instead of up to 5s (the per-frame tick
    // then holds it steady). Still skipped entirely in a match (see Tick), so
    // the frame budget that matters is untouched.
    inline float g_PersistSecs = 1.0f;
    // DEFAULT IS EVERYTHING - inject and you get all skins, all items, and the
    // one-of-each-chest side effect. This is the behaviour that actually feels
    // good to use, so it is the default again.
    //
    // CHESTS_ONLY exists and works (it does correctly unlock only chests), but
    // chests turned out to be a dead end: the grant is server-side, so an opened
    // chest never delivers anything. No reason to pay for that with fewer skins.
    //
    // NOTE if this is ever flipped back: the auto-tick fires within a second of
    // injection, so whatever this is set to has already been applied before the
    // tab can be opened. Changing mode afterwards cannot un-count a chest screen
    // that has already been built.
    inline int   g_Mode        = MODE_EVERYTHING;

    // ---- THE VALUE WE WRITE ----------------------------------------------
    // Writing literal 1 is the classic approach. It turns out the UI renders
    // this field as a QUANTITY, not a yes/no - which is why chests show "1".
    // So this is adjustable, because "what happens at other values" is a real
    // question with a cheap answer.
    //
    // It is a 32-bit SIGNED int: wraps at 2147483647 -> -2147483648.
    // Interesting values to try:
    //     1           the classic approach
    //     5, 100      does the count displayed follow it?
    //     2147483647  INT_MAX
    //     -1          all bits set
    //     0           re-locks
    // None of this can make a server grant you anything. What it CAN do is
    // trip a client-side check written as (count > 0) or (count >= needed),
    // and that is worth knowing.
    inline int   g_WriteValue  = 1;

    // m_qwInventorySessionId is an FQWord {int A; int B;} - a 64-bit id in two
    // halves. We have only ever written A. B is completely untested, and is the
    // last unexamined lever on this field. Off by default because writing it
    // makes the full 64-bit id enormous, which may well read as invalid.
    inline bool  g_WriteB      = false;
    inline int   g_WriteValueB = 0;

    // Retry collecting chest ids until it succeeds - the chest objects do not
    // exist until the game has built that screen at least once.
    inline double g_NextCollect = 0.0;

    inline int   g_LastScanned = 0;
    inline int   g_LastMatched = 0;
    inline int   g_LastWritten = 0;
    inline int   g_LastAlready = 0;
    inline int   g_LastSkipped = 0;
    inline int   g_LastCleared = 0;
    inline int   g_LastCheckmarksSet = 0;  // used by RunPass (checkmark folded into its walk) and the UI

    // Cached pointer to the ONE UUIDataPlayer representing PRIMAL_MONKE
    // themself (bIsSelf). Kept for the UI readout only now - the real work
    // moved to g_PlayerObjs below.
    inline SDK::UUIDataPlayer* g_SelfPlayerObj = nullptr;

    // ---- EVERY live UUIDataPlayer, cached from the last full walk ----------
    // THE CHECKMARK FIX, take three. Takes one and two ("walk every 5s and
    // stamp" / "pin only the bIsSelf object and stamp that one every frame")
    // both failed the same way, and PRIMAL_MONKE's report told us exactly
    // why: "shows in some menus, not others; appears and vanishes as I
    // switch tabs." That is not one object flickering - it is MANY different
    // objects, because every menu surface (queue card bottom-right, friends
    // list, champ-select nameplate, match record, profile) builds its OWN
    // separate UUIDataPlayer. Pinning just the bIsSelf one only ever fixed
    // whichever single surface happened to own it.
    //
    // The actual mechanism, best model of it: each screen's object starts
    // life at the backend's real value (0 = not verified), and an async
    // profile response can overwrite it at an unpredictable time - so a 5s
    // (or even 0.25s) walk sometimes lands before that write, sometimes
    // after. Whack-a-mole against an async writer.
    //
    // The fix that actually beats an async overwrite: cache the pointers to
    // ALL currently-live UUIDataPlayer objects (there are only a handful -
    // tens, not the 200k of the full GObjects array), then re-stamp EVERY
    // one of them EVERY FRAME. The full 200k walk still runs on its timer,
    // but only to REFRESH this small list (catch newly-built objects); the
    // per-frame cost is just re-writing a dword on a few dozen already-known
    // pointers, which is nothing. Now, even when the backend writes 0 right
    // after a screen builds, the very next frame writes 1 back before the UI
    // re-reads it - so it holds instead of flickering. Each pointer is
    // re-validated with IsA() before every write (same staleness rule as
    // every cached UObject* in this codebase - the object can be freed when
    // a screen tears down), and a slot that fails validation is dropped.
    // TWO classes carry bIsVerifiedPlayer/bIsPaidBattlePass, at DIFFERENT
    // offsets, and different menu surfaces read from different ones - which
    // is a second, independent reason the checkmark showed "in some menus,
    // not others": we were only ever writing UUIDataPlayer (friends/profile/
    // queue card) and never UUIData_PlayerMatchRecord (the scoreboard and
    // match-history record). Both are covered now. kind tells the write which
    // typed struct to cast to so the correct bitfield offset is used.
    enum VerifyKind { VK_DataPlayer = 0, VK_MatchRecord = 1 };
    struct VerifyTarget { SDK::UObject* obj; unsigned char kind; };
    static const int kMaxPlayerObjs = 512;
    inline VerifyTarget g_PlayerObjs[kMaxPlayerObjs];
    inline int  g_PlayerObjCount = 0;
    inline int  g_LastFastStamped = 0;   // how many held steady last frame (UI readout)

    inline char  g_Status[224] = "Not run yet.";
    inline double g_NextRun    = 0.0;

    // ---- chest id sets, collected from UUIData_ChestExtended --------------
    static const int kMaxChests = 512;
    static const int kMaxLoot   = 20000;
    inline int  g_ChestIds[kMaxChests];   inline int g_ChestIdCount = 0;
    inline int  g_LootIds[kMaxLoot];      inline int g_LootIdCount  = 0;
    inline int  g_ChestObjects = 0;
    inline char g_ChestStatus[192] = "Chest ids not collected yet.";

    static const int kMaxSample = 600;
    inline char g_Sample[kMaxSample][144];
    inline int  g_SampleCount = 0;

    // ---- guarded primitives (POD only; __try cannot share scope with
    // anything needing unwinding — the C2712 rule this codebase learned) ----

    inline SDK::UClass* TryGetClass_DataItem() {
        __try { return SDK::UUIDataItem::StaticClass(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    inline SDK::UClass* TryGetClass_ChestExtended() {
        __try { return SDK::UUIData_ChestExtended::StaticClass(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    inline SDK::UClass* TryGetClass_DataPlayer() {
        __try { return SDK::UUIDataPlayer::StaticClass(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    inline SDK::UClass* TryGetClass_MatchRecord() {
        __try { return SDK::UUIData_PlayerMatchRecord::StaticClass(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    // bIsVerifiedPlayer AND bIsPaidBattlePass are both real SDK-confirmed
    // bitfields on UUIDataPlayer, packed into the SAME dword right next to
    // each other — bIsPaidBattlePass is the "golden name" PRIMAL_MONKE
    // asked about, same shape as the checkmark, same class, so it rides
    // along in the same write for free. Going through the actual typed
    // struct members (not raw offset+mask arithmetic like the item-unlock
    // write below) so the compiler handles the bit positions correctly
    // regardless of how these specific fields are packed, which raw
    // pointer math can't guarantee for a single bit.
    // Write the verified+golden bits using the correct typed struct for the
    // object's actual class (the two classes put these bits at different
    // offsets, so a single cast can't serve both). POD-only, SEH-safe.
    //
    // ONLY writes the LOCAL player's own object. PRIMAL_MONKE caught the
    // earlier version stamping EVERY player at the match-end scoreboard
    // ("everyone has a checkmark, ofc only I see it") - because
    // UUIData_PlayerMatchRecord exists once per player in the match and we
    // were writing all of them. Each class carries its own "this is me" bit
    // (bIsSelf on UUIDataPlayer, bLocal on the match record); we gate on it
    // so only your row is ever touched. Returns false for a non-self object
    // so the caller neither counts nor caches it.
    inline bool TryWriteVerifiedBits(SDK::UObject* o, unsigned char kind) {
        __try {
            if (kind == VK_MatchRecord) {
                SDK::UUIData_PlayerMatchRecord* r = (SDK::UUIData_PlayerMatchRecord*)o;
                if (!r->bLocal) return false;          // someone else's scoreboard row - leave it
                r->bIsVerifiedPlayer = 1;
                r->bIsPaidBattlePass = 1;
            } else {
                SDK::UUIDataPlayer* p = (SDK::UUIDataPlayer*)o;
                if (!p->bIsSelf) return false;         // someone else's profile object - leave it
                p->bIsVerifiedPlayer = 1;
                p->bIsPaidBattlePass = 1;
                g_SelfPlayerObj = p;                   // this IS us (UI readout)
            }
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    // Called from the full walk. Writes the bits AND records the object into
    // the per-frame re-stamp list (deduped). The walk resets the count to 0
    // first (see RunPass), so the list rebuilds fresh each walk.
    inline bool TryMarkVerified(SDK::UObject* o, unsigned char kind) {
        if (!TryWriteVerifiedBits(o, kind)) return false;
        if (g_PlayerObjCount < kMaxPlayerObjs) {
            bool already = false;
            for (int i = 0; i < g_PlayerObjCount; ++i)
                if (g_PlayerObjs[i].obj == o) { already = true; break; }
            if (!already) { g_PlayerObjs[g_PlayerObjCount].obj = o;
                            g_PlayerObjs[g_PlayerObjCount].kind = kind; g_PlayerObjCount++; }
        }
        return true;
    }
    // Re-stamp a single already-known target every frame. Re-validates IsA
    // against the class matching its stored kind; returns false so the caller
    // drops it if the object was freed / the screen torn down.
    inline bool TryRestampKnown(const VerifyTarget& t, SDK::UClass* playerCls, SDK::UClass* recordCls) {
        __try {
            SDK::UClass* cls = (t.kind == VK_MatchRecord) ? recordCls : playerCls;
            if (!t.obj || !cls) return false;
            if (!t.obj->IsA(cls)) return false;      // stale/freed - caller drops it
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
        return TryWriteVerifiedBits(t.obj, t.kind);
    }
    inline SDK::UObject* TryObjAt(SDK::TAntiCheatArray<SDK::UObject*>& arr, size_t i) {
        __try {
            if (!arr.IsValidIndex(i)) return nullptr;
            return arr[i];
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    inline bool TryIsA(SDK::UObject* o, SDK::UClass* cls) {
        __try {
            if (!o || !cls) return false;
            return o->IsA(cls);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool TryReadSessionId(SDK::UObject* o, int* out) {
        __try { *out = *(int*)((unsigned char*)o + kSessionIdOffset); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool TryWriteSessionId(SDK::UObject* o, int val) {
        __try {
            *(int*)((unsigned char*)o + kSessionIdOffset) = val;
            if (g_WriteB) *(int*)((unsigned char*)o + kSessionIdOffset + 4) = g_WriteValueB;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline int TryReadItemId(SDK::UObject* o) {
        __try { return ((SDK::UUIDataItem*)o)->m_nId; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }
    inline int TryReadChestItemId(SDK::UObject* o) {
        __try { return ((SDK::UUIData_ChestExtended*)o)->nItemId; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }
    // Copies a chest's loot-id list out. Returns how many were written.
    inline int TryReadChestLoot(SDK::UObject* o, int* dst, int cap) {
        __try {
            SDK::UUIData_ChestExtended* c = (SDK::UUIData_ChestExtended*)o;
            size_t n = c->nAllLootIds.Num();
            if (n > 100000) return 0;                     // obviously bad
            int w = 0;
            for (size_t i = 0; i < n && w < cap; ++i) dst[w++] = c->nAllLootIds[i];
            return w;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }
    inline bool TryCopyFStr(const SDK::FString* fs, char* buf, int cap) {
        __try {
            buf[0] = '\0';
            const wchar_t* w = fs->c_str();
            if (!w) return false;
            int n = 0;
            while (w[n] && n < cap - 1) { buf[n] = (char)(w[n] & 0x7F); n++; }
            buf[n] = '\0';
            return n > 0;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { buf[0] = '\0'; return false; }
    }
    inline bool TryCopyItemName(SDK::UObject* o, char* b, int c) {
        return TryCopyFStr(&((SDK::UUIDataItem*)o)->m_sName, b, c);
    }
    inline bool TryCopyItemIcon(SDK::UObject* o, char* b, int c) {
        return TryCopyFStr(&((SDK::UUIDataItem*)o)->m_sIcon, b, c);
    }

    inline bool IdIn(const int* set, int count, int id) {
        for (int i = 0; i < count; ++i) if (set[i] == id) return true;
        return false;
    }

    // ---- collect the chest id sets ---------------------------------------
    inline void CollectChestIds() {
        g_ChestIdCount = g_LootIdCount = g_ChestObjects = 0;

        if (!SDK::UObject::GObjects) {
            lstrcpynA(g_ChestStatus, "GObjects not initialised.", 190);
            return;
        }
        SDK::UClass* cls = TryGetClass_ChestExtended();
        if (!cls) {
            lstrcpynA(g_ChestStatus, "Could not resolve Class TgClient.UIData_ChestExtended.", 190);
            return;
        }

        auto& arr = *SDK::UObject::GObjects;
        size_t count = 0;
        __try { count = arr.Num(); } __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
        if (!count || count > 4000000) {
            lstrcpynA(g_ChestStatus, "GObjects unreadable.", 190);
            return;
        }

        static int tmp[4096];
        for (size_t i = 0; i < count; ++i) {
            SDK::UObject* o = TryObjAt(arr, i);
            if (!o || !TryIsA(o, cls)) continue;
            g_ChestObjects++;

            int cid = TryReadChestItemId(o);
            if (cid > 0 && g_ChestIdCount < kMaxChests && !IdIn(g_ChestIds, g_ChestIdCount, cid))
                g_ChestIds[g_ChestIdCount++] = cid;

            int n = TryReadChestLoot(o, tmp, 4096);
            for (int k = 0; k < n && g_LootIdCount < kMaxLoot; ++k) {
                if (tmp[k] > 0 && !IdIn(g_LootIds, g_LootIdCount, tmp[k]))
                    g_LootIds[g_LootIdCount++] = tmp[k];
            }
        }

        wsprintfA(g_ChestStatus, "%d chest objects -> %d chest ids, %d ids found inside chests.",
                  g_ChestObjects, g_ChestIdCount, g_LootIdCount);
    }

    // Should this item be unlocked under the current mode?
    inline bool ShouldUnlock(SDK::UObject* o) {
        if (g_Mode == MODE_EVERYTHING) return true;
        int id = TryReadItemId(o);
        if (id <= 0) return false;                        // unknown id: leave alone
        if (g_Mode == MODE_CHESTS_ONLY)  return IdIn(g_ChestIds, g_ChestIdCount, id);
        if (g_Mode == MODE_NOT_CONTENTS) return !IdIn(g_LootIds, g_LootIdCount, id);
        return true;
    }

    // ---- the pass ---------------------------------------------------------
    // clearUnwanted: also write 0 back over items this mode does NOT want. This
    // matters because a previous EVERYTHING pass (or a previous injection) has
    // already stamped them, and switching mode cannot un-own them otherwise —
    // which is exactly why the chest still said 313/313.
    // g_LastCheckmarksSet is defined further down with the rest of the
    // checkmark feature, but written here too - forward-declared via this
    // comment since RunPass (above its old definition) now folds that scan
    // in. See the CHECKMARK block below for the full story on WHY this
    // moved in here instead of staying its own separate walk.
    inline void RunPass(bool dryRun, bool collectSample, bool clearUnwanted) {
        g_LastScanned = g_LastMatched = g_LastWritten = 0;
        g_LastAlready = g_LastSkipped = g_LastCleared = 0;
        g_LastCheckmarksSet = 0;
        g_PlayerObjCount = 0;   // rebuild the per-frame re-stamp list fresh each walk
        if (collectSample) g_SampleCount = 0;

        if (!SDK::UObject::GObjects) { lstrcpynA(g_Status, "GObjects not initialised.", 220); return; }
        SDK::UClass* cls = TryGetClass_DataItem();
        if (!cls) { lstrcpynA(g_Status, "Could not resolve Class TgClient.UIDataItem.", 220); return; }
        // May legitimately be null (e.g. this build's dump doesn't have the
        // class, or the very first resolution attempt landed at a bad
        // moment - see the CHECKMARK comment below) - checked per-object,
        // never assumed non-null.
        SDK::UClass* playerCls = TryGetClass_DataPlayer();
        SDK::UClass* recordCls = TryGetClass_MatchRecord();   // scoreboard/match-record checkmark

        if (g_Mode != MODE_EVERYTHING && g_ChestIdCount == 0 && g_LootIdCount == 0)
            CollectChestIds();

        auto& arr = *SDK::UObject::GObjects;
        size_t count = 0;
        __try { count = arr.Num(); } __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
        if (!count || count > 4000000) { lstrcpynA(g_Status, "GObjects unreadable (bad count).", 220); return; }

        for (size_t i = 0; i < count; ++i) {
            SDK::UObject* o = TryObjAt(arr, i);
            if (!o) continue;
            g_LastScanned++;

            // Checkmark pass, folded into this SAME walk instead of its own
            // separate 200k-object sweep - see the CHECKMARK block below for
            // why a second independent walk was the wrong shape. Two classes
            // carry the verified/golden bits (profile card + scoreboard
            // record); neither is ever also a UUIDataItem, so this is a clean
            // either/or per object, not extra redundant work.
            if (playerCls && TryIsA(o, playerCls)) {
                if (TryMarkVerified(o, VK_DataPlayer)) g_LastCheckmarksSet++;
                continue;
            }
            if (recordCls && TryIsA(o, recordCls)) {
                if (TryMarkVerified(o, VK_MatchRecord)) g_LastCheckmarksSet++;
                continue;
            }

            if (!TryIsA(o, cls)) continue;          // NOT optional
            g_LastMatched++;

            int cur = 0;
            bool readOk = TryReadSessionId(o, &cur);
            if (readOk && cur != 0) g_LastAlready++;

            bool want = ShouldUnlock(o);
            if (!want) g_LastSkipped++;

            if (collectSample && g_SampleCount < kMaxSample) {
                char nm[96], ic[96];
                bool a = TryCopyItemName(o, nm, sizeof(nm));
                if (!TryCopyItemIcon(o, ic, sizeof(ic))) ic[0] = '\0';
                int id = TryReadItemId(o);
                bool isChest = IdIn(g_ChestIds, g_ChestIdCount, id);
                bool inChest = IdIn(g_LootIds, g_LootIdCount, id);
                if (a && nm[0]) {
                    wsprintfA(g_Sample[g_SampleCount], "%s id=%-7d %-26s | %s",
                              isChest ? "[CHEST]" : (inChest ? "[loot ]" : "[     ]"),
                              id, nm, ic);
                    g_SampleCount++;
                }
            }

            if (dryRun) continue;

            if (want) {
                if (!readOk || cur != g_WriteValue) {
                    if (TryWriteSessionId(o, g_WriteValue)) g_LastWritten++;
                }
            } else if (clearUnwanted && readOk && cur != 0) {
                if (TryWriteSessionId(o, 0)) g_LastCleared++;
            }
        }

        const char* mn = (g_Mode == MODE_CHESTS_ONLY)  ? "CHESTS ONLY"
                       : (g_Mode == MODE_NOT_CONTENTS) ? "ALL EXCEPT CHEST CONTENTS"
                                                       : "EVERYTHING";
        if (dryRun)
            wsprintfA(g_Status, "SCAN [%s]: %d items, %d already owned, %d would stay locked.",
                      mn, g_LastMatched, g_LastAlready, g_LastSkipped);
        else
            wsprintfA(g_Status, "APPLIED [%s]: %d items, %d unlocked, %d re-locked, %d left alone.",
                      mn, g_LastMatched, g_LastWritten, g_LastCleared, g_LastSkipped);
    }

    // ============================================================================
    // CHECKMARK  —  same mechanism as the item unlocker above, different
    // class and field. UUIDataPlayer is the general "player profile" UI data
    // object — populated whenever the game builds a screen with a player
    // summary on it (friends list, scoreboard, profile). bIsVerifiedPlayer is
    // a real, SDK-confirmed field on it, with matching UI elements
    // (m_mcCheckmark, m_mcEquippedCheckmark) that render it — same shape as
    // the title system.
    //
    // THE CAVEAT, worth keeping visible rather than burying: this is very
    // likely the same kind of thing as the title-ID trick — each viewer's
    // OWN client most plausibly builds their OWN UUIDataPlayer for you
    // independently (a backend profile lookup, not live network
    // replication), so this most likely changes what YOU see about
    // YOURSELF, not what anyone else sees of you.
    //
    // ORIGINALLY its own separate GObjects walk on the same 5-second timer.
    // TWO PROBLEMS that caused: (1) a hard engine crash — "Illegal call to
    // StaticFindObject() while serializing object data or garbage
    // collecting!" — because resolving UUIDataPlayer::StaticClass() for the
    // first time is itself a StaticFindObject call, and a SEPARATE walk
    // meant a SECOND independent chance per tick for that first-ever lookup
    // to land during a GC pass and hard-crash the game outright (not
    // something __try/__except can catch — the engine chooses to fatally
    // abort on purpose). (2) the flicker PRIMAL_MONKE reported ("appears
    // and vanishes as I switch menu tabs") — the game rebuilds a fresh
    // UUIDataPlayer (flag back to false) every time it constructs that
    // screen again, same as it does for items, and a full second 200k-object
    // walk every 5 seconds was simply too slow to keep up with fast tab
    // switching. Folded into RunPass's existing walk above instead - one
    // walk, one shared 5-second cadence, half the background cost, and the
    // same class-resolution risk profile the item unlocker already carried
    // rather than doubling it.
    //
    // No separate enable flag, per PRIMAL_MONKE: "just by default its in" -
    // runs automatically whenever the item-unlock pass does.
    //
    // Kept as its own callable (the "run now" button uses it) - just
    // delegates into the real, merged pass above instead of re-walking.
    inline void RunCheckmarkPass() {
        RunPass(false, false, g_Mode != MODE_EVERYTHING);
    }

    inline void Tick() {
        if (!g_Enabled || !g_Persist) return;

        // POTATO MODE stops this entirely. The unlock already happened on
        // injection; this pass only re-applies it as menus rebuild, so skipping
        // it costs a user with a slow PC nothing they will notice.
        if (!Perf::AllowBackgroundScan()) return;

        // IN A MATCH THERE IS NOTHING TO RE-APPLY.
        //
        // Inventory items get rebuilt when you navigate the front-end menus. In
        // an actual match that screen does not exist, so this was walking 200k
        // objects every second to change nothing at all - during the one time
        // the frame budget actually matters.
        if (Globals::LocalPawn) return;

        double now = ImGui::GetTime();

        // Keep trying to build the chest id set until we have one. The chest
        // objects only exist after the game has built that screen once, so at
        // inject time there is nothing to find - and until we DO have ids,
        // CHESTS_ONLY correctly unlocks nothing at all rather than guessing.
        if (g_Mode != MODE_EVERYTHING && g_ChestIdCount == 0 && now >= g_NextCollect) {
            g_NextCollect = now + 3.0;
            CollectChestIds();
        }

        if (now < g_NextRun) return;
        g_NextRun = now + ((g_PersistSecs < 0.25f ? 0.25f : g_PersistSecs)
                           * Perf::IntervalScale());

        // In a filtered mode with no ids yet, do nothing. Writing on a guess is
        // what caused the original problem.
        if (g_Mode != MODE_EVERYTHING && g_ChestIdCount == 0) return;

        RunPass(false, false, g_Mode != MODE_EVERYTHING); // checkmark is folded into this walk now
    }

    // Runs EVERY FRAME (from main.cpp), re-stamping every UUIDataPlayer the
    // last full walk found. This is what actually beats the async backend
    // writer: the full walk (Tick, on its timer) only DISCOVERS objects and
    // refreshes the list; this holds all of them steady between walks, so a
    // backend "write 0" gets overwritten back to 1 the very next frame,
    // before the UI re-reads. Cheap - a few dozen dword writes, no 200k walk.
    // Compacts the list in place, dropping any pointer that fails IsA
    // re-validation (screen torn down, object freed).
    inline void TickCheckmarkFast() {
        if (!g_Enabled || !g_Persist) return;
        if (Globals::LocalPawn) return;            // no profile UI exists mid-match, nothing to reapply
        if (g_PlayerObjCount <= 0) return;         // nothing found yet - next full walk will populate

        SDK::UClass* playerCls = TryGetClass_DataPlayer();
        SDK::UClass* recordCls = TryGetClass_MatchRecord();
        if (!playerCls && !recordCls) return;

        int live = 0;
        for (int i = 0; i < g_PlayerObjCount; ++i) {
            if (TryRestampKnown(g_PlayerObjs[i], playerCls, recordCls)) {
                g_PlayerObjs[live++] = g_PlayerObjs[i];   // keep (compact)
            }
            // else: drop - the next full walk will re-add it if it comes back
        }
        g_PlayerObjCount = live;
        g_LastFastStamped = live;
    }

    // ------------------------------------------------------------------
    // CDO FIX — the actual missing piece PRIMAL_MONKE pointed at directly:
    // "the spam applying stuff never really got us anywhere... maybe we
    // need to spoof something we're missing." Everything above (the full
    // walk, the fast per-object tick) chases INSTANCES after they already
    // exist — which is why it was inconsistent screen to screen: profile,
    // friends list, match record, and champ select each build their OWN
    // separate UUIDataPlayer, and only ones already caught by a pass ever
    // read verified. ClientValues.h already has a CONFIRMED WORKING
    // mechanism for exactly this shape of problem (found in an earlier
    // session): ATgPlayerController::SetClientValue writes onto a CLASS
    // DEFAULT OBJECT, not an instance — that's what the community's
    // Input.ini bindings use to turn on wallhack/third-person/aim-magnet
    // for every champion class at once. The same trick applies here: write
    // bIsVerifiedPlayer/bIsPaidBattlePass onto Default__UIDataPlayer once,
    // and every UUIDataPlayer ANY menu screen constructs from that point
    // forward starts life already verified/golden - no race, no per-screen
    // gap, because the value is baked into what "new" even means for that
    // class from here on. Does NOT retroactively fix instances that already
    // existed before this ran - the walk/fast-tick above still matter for
    // those - so this is additive, not a replacement.
    // CDO naming convention confirmed against ClientValues.h's already-
    // working kPawnCDOs ("Default__TgPawn", not "Default__TgGame.TgPawn"):
    // bare UnrealScript class name, no package qualifier, no A/U SDK
    // prefix letter. UUIDataPlayer's real name (StaticClass() resolves
    // "Class TgClient.UIDataPlayer") is UIDataPlayer, so the CDO is
    // Default__UIDataPlayer - not independently verified live yet.
    // REMOVED: the CDO (class-default) write. Setting Default__UIDataPlayer's
    // bIsVerifiedPlayer changed the default for EVERY UUIDataPlayer the game
    // builds - your own AND every other player's - which is why the whole
    // scoreboard lit up with checkmarks. A class default is inherently
    // all-instances, so it can never be "only me." The per-frame re-stamp of
    // just the local (bIsSelf/bLocal) objects is the correct, targeted path
    // and fully replaces this. Kept as a no-op stub only so any lingering UI
    // reference compiles; nothing calls it from the frame loop any more.
    inline bool g_CDOApplied = false;
    inline void ApplyCheckmarkCDO() { /* intentionally does nothing - see note above */ }

    // ---- UI ---------------------------------------------------------------
    inline void DrawControls(bool /*inMatch*/) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(g_Enabled ? ImVec4(0.4f, 1.0f, 0.5f, 1.0f)
                                                           : ImVec4(1.0f, 0.6f, 0.4f, 1.0f)));
        ImGui::Checkbox("ACTIVATE UNLOCKER (off = completely inactive)", &g_Enabled);
        ImGui::PopStyleColor();
        if (!g_Enabled) {
            ImGui::TextWrapped("Unlocker is OFF. Nothing runs — no scanning, no writes, no timer.");
            return;
        }

        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("WHAT TO UNLOCK");
        ImGui::PopStyleColor();
        ImGui::RadioButton("Everything (classic unlock-all behaviour)", &g_Mode, MODE_EVERYTHING);
        ImGui::RadioButton("ONLY chests   <- chests stay full and openable", &g_Mode, MODE_CHESTS_ONLY);
        ImGui::RadioButton("Everything EXCEPT what is inside chests", &g_Mode, MODE_NOT_CONTENTS);

        ImGui::Spacing();
        ImGui::TextWrapped("A chest will not open once you own everything in it - that is the "
            "(313/313). The two filtered modes leave chest contents locked, so a chest always has "
            "something to give.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        if (ImGui::Button("Collect chest ids", ImVec2(200, 30))) CollectChestIds();
        ImGui::SameLine();
        ImGui::TextWrapped("%s", g_ChestStatus);

        if (g_ChestIdCount == 0 && g_Mode != MODE_EVERYTHING) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.6f, 0.4f, 1.0f)));
            ImGui::TextWrapped("No chest ids yet. Open the Store / Chests screen so the game builds "
                "those objects, then press Collect.");
            ImGui::PopStyleColor();
        }

        ImGui::Spacing();
        if (ImGui::Button("SCAN (read-only)", ImVec2(180, 32))) RunPass(true, true, false);
        ImGui::SameLine();
        if (ImGui::Button(">>> APPLY NOW <<<", ImVec2(190, 32)))
            RunPass(false, true, g_Mode != MODE_EVERYTHING);
        ImGui::SameLine();
        if (ImGui::Button("Copy report", ImVec2(120, 32))) {
            static char big[120000];
            int n = wsprintfA(big, "%s\r\n%s\r\n\r\nItems (%d shown):\r\n",
                              g_Status, g_ChestStatus, g_SampleCount);
            for (int i = 0; i < g_SampleCount && n < 118000; i++)
                n += wsprintfA(big + n, "%s\r\n", g_Sample[i]);
            ImGui::SetClipboardText(big);
        }

        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.55f, 0.22f, 0.18f, 1.0f));
        if (ImGui::Button("RE-LOCK EVERYTHING (write 0 to all items)", ImVec2(340, 28))) {
            int savedMode = g_Mode;
            g_Mode = MODE_CHESTS_ONLY;
            int savedChests = g_ChestIdCount;
            g_ChestIdCount = 0;              // nothing qualifies -> clears all
            RunPass(false, false, true);
            g_ChestIdCount = savedChests;
            g_Mode = savedMode;
            lstrcpynA(g_Status, "Re-locked every item (wrote 0). Menus may take a moment to catch up.", 220);
        }
        ImGui::PopStyleColor();
        ImGui::TextDisabled("Use this if a previous 'Everything' pass already marked things owned "
                            "and the chest still says it is full.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("VALUE WRITTEN  (this is the number the UI shows as a count)");
        ImGui::PopStyleColor();
        ImGui::SetNextItemWidth(200);
        ImGui::InputInt("##wval", &g_WriteValue);
        ImGui::SameLine();
        if (ImGui::SmallButton("1"))           g_WriteValue = 1;
        ImGui::SameLine();
        if (ImGui::SmallButton("5"))           g_WriteValue = 5;
        ImGui::SameLine();
        if (ImGui::SmallButton("100"))         g_WriteValue = 100;
        ImGui::SameLine();
        if (ImGui::SmallButton("INT_MAX"))     g_WriteValue = 2147483647;
        ImGui::SameLine();
        if (ImGui::SmallButton("-1"))          g_WriteValue = -1;
        ImGui::TextDisabled("Signed 32-bit: wraps at 2147483647 to -2147483648. Chests showing '1'\n"
                            "is this value being drawn, so it IS a quantity. A bigger number cannot\n"
                            "make the server grant anything, but it may trip a client-side check.");
        ImGui::Checkbox("Also write the B half of the id (untested)", &g_WriteB);
        if (g_WriteB) {
            ImGui::SameLine();
            ImGui::SetNextItemWidth(140);
            ImGui::InputInt("B##wvalb", &g_WriteValueB);
        }
        ImGui::TextDisabled("m_qwInventorySessionId is FQWord {int A; int B;}. Only A has ever been\n"
                            "written. B is the last untried lever on this field.");
        ImGui::Separator();
        ImGui::Spacing();
        ImGui::Checkbox("Re-apply on a timer (menus rebuild items as you navigate)", &g_Persist);
        if (g_Persist) {
            ImGui::SetNextItemWidth(200);
            ImGui::SliderFloat("seconds##unlockrate", &g_PersistSecs, 0.25f, 5.0f, "%.2f s");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextWrapped("%s", g_Status);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("CHECKMARK + GOLDEN NAME");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Runs automatically alongside the item unlock above, no separate switch - "
            "sets UUIDataPlayer::bIsVerifiedPlayer (checkmark) AND bIsPaidBattlePass (golden name) "
            "together, one write, wherever the game has one of those objects built (profile screens, "
            "scoreboard, friends list) - same class, same field group, so the golden name rides "
            "along free.");
        ImGui::TextColored(ImVec4(1.0f, 0.82f, 0.25f, 1.0f), "Confirmed live and flickering by "
            "PRIMAL_MONKE: shows for a split second while queuing, name genuinely turns gold when it's "
            "on, then both vanish again - it IS reaching the real fields, it just isn't STAYING. Root "
            "cause was the 5-second walk being too slow to survive the game rebuilding this object as "
            "fast as it does. Fixed this round with a second, O(1) mechanism (TickCheckmarkFast, runs "
            "every single frame): the full walk below finds the ONE UUIDataPlayer with bIsSelf true "
            "and pins its pointer; every frame after that, just that one object gets re-verified and "
            "re-written directly, no 200k-object walk needed. Closes the gap from up to 5s down to "
            "about one frame. If the game gives your self-object a NEW address on rebuild (not just "
            "resetting the same one), there can still be one slow catch-up cycle before it's re-pinned "
            "- watch \"Self object pinned\" below to see this happening live.");
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.75f, 0.35f, 1.0f));
        ImGui::TextWrapped("Same caveat as the title trick: architecturally likely self-view only - "
            "each other player's client most plausibly builds its OWN copy of your profile "
            "independently. Genuinely unclear right now given how it's flickering on YOUR OWN "
            "screen too - worth re-testing once the flicker itself is fixed, since a value that "
            "won't even hold still locally is not a fair test of whether it reaches anyone else.");
        ImGui::PopStyleColor();
        if (g_PlayerObjCount > 0)
            ImGui::TextColored(ImVec4(0.4f, 1.0f, 0.5f, 1.0f),
                "Holding YOUR checkmark on %d of your own object(s), every frame. Only your own "
                "row is ever touched now - not other players (that scoreboard-wide bug is fixed).",
                g_PlayerObjCount);
        else
            ImGui::TextColored(ImVec4(1.0f, 0.6f, 0.4f, 1.0f),
                "Your own player object not found yet - open a menu with your name on it (profile, "
                "queue card) and the next pass will pick it up.");
        if (ImGui::Button("Run checkmark pass now", ImVec2(220, 28))) RunCheckmarkPass();

        if (g_SampleCount > 0) {
            ImGui::Spacing();
            if (ImGui::CollapsingHeader("Items found  ([CHEST] = a chest, [loot] = inside a chest)")) {
                ImGui::TextDisabled("Showing %d of %d matched.", g_SampleCount, g_LastMatched);
                ImGui::BeginChild("##unlocklist", ImVec2(0, 280), true,
                                  ImGuiWindowFlags_HorizontalScrollbar);
                for (int i = 0; i < g_SampleCount; i++) ImGui::TextUnformatted(g_Sample[i]);
                ImGui::EndChild();
            }
        }

        if (ImGui::CollapsingHeader("How the chest filter works")) {
            ImGui::TextWrapped("UUIData_ChestExtended carries nItemId (the chest's own id) and "
                "nAllLootIds (every item id inside it). UUIDataItem carries m_nId. Chests and "
                "chest contents are matched by ID, from the game's own tables - no guessing at "
                "names, which is what failed last time.");
            ImGui::Spacing();
            ImGui::TextWrapped("If Collect finds 0 chests, the chest screen has not been built this "
                "session and those objects do not exist yet. Open it, then collect.");
        }
    }
}
