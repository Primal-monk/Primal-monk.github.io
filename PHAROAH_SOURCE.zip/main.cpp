// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include <map>
#include <mutex>
#include <vector>
#include <cstring>
#include <windows.h>
#include <wininet.h>
#include <regex>
#include <chrono>
#include <d3d11.h>
#include <dxgi1_2.h> // IDXGISwapChain1 / Present1 - see hkPresent1
#include <detours.h>
#include <cstdarg>   // InitLog
#include <tlhelp32.h> // LogKnownOverlayModules
#include <Psapi.h>    // MODULEINFO / K32GetModuleInformation - crash handler module-offset resolution

#include "ext/ImGUI/imgui.h"
#include "ext/ImGUI/imgui_impl_dx11.h"
#include "ext/ImGUI/imgui_impl_win32.h"

// Forward declaration - defined near InitThread below. Every [Init] diagnostic
// line in this file goes through this (not raw printf) specifically so it
// survives in PHAROAH_init.log, not just the console window. A console-only
// line is lost the moment someone doesn't screenshot/copy it in time, or
// scrolls past it - which is exactly what made an earlier real bug report
// come back "mostly empty" despite the hook having genuinely run. The log
// file is the one artifact that reliably makes it back to us.
static void InitLog(const char* fmt, ...);
// Defined near hkPresent below - true once the D3D11 render hook is
// CONFIRMED actually firing (not just "installed without error"). Read from
// VisibilityBoxes.h so the Canvas fallback box system knows whether it's
// needed at all - see RenderBoxesViaCanvas for the full story.
extern volatile bool g_D3D11RenderHookConfirmedWorking;
// Defined near hkPresent below - F6 toggles it live. See the big comment
// there. Read from VisibilityBoxes.h/CanvasMenu.h so the Canvas fallback
// activates on a WORKING machine too, on demand, without needing a second
// build or a second person's machine to see what it looks like.
extern volatile bool g_SimulateFallbackMode;
// Defined near InitThread below (RHI PROBE section). Spawns a one-shot
// thread that forces the same retry the automatic fallback only ever runs
// when the real hook is silent - see the big comment above its definition.
// Called directly from the "TEST RHI FALLBACK" button in RecoverySuite.h -
// kiero::unbind/shutdown/bind are plain memory patches, not scripted
// ProcessEvent calls, so calling CreateThread for this from inside ImGui's
// own render-thread code is safe, same distinction as everywhere else here.
DWORD WINAPI ManualRHITestThread(LPVOID);

#include "memory_manager.h"
#include "spoofer/return_spoofer.h"
#include "globals.h"
#include "ext/kiero/kiero.h"
#include "ext/kiero/minhook/include/MinHook.h" // proxy-mode factory hook (CreateSwapChainForHwnd) - see PharoahD3D11CreateDevice
#include "menus/EquipEmoteMenu.h"
#include "Utils/Helper.h"
#include "UI/Style.h"

#include "menus/FireModeMenu.h"
#include "menus/VisibilityBoxes.h"
#include "menus/Silhouette.h"
#include "menus/ColorGrading.h"
#include "menus/RecoverySuite.h" // pulls in menus/Speeden.h - CanvasMenu.h below needs both namespaces
#include "menus/CanvasMenu.h"
#include "menus/CallLogger.h"

int g_IsSimulatingInput = 0;
bool g_bShowMenu = true; // toggled with INSERT — hidden by default frees your mouse/aim
bool g_ShowFPS = true;

// Per-feature toggles — start OFF so you can enable one at a time and isolate
// which one (if any) causes a crash, instead of everything running at once.
bool g_bEnableFireMode = false;
bool g_bEnableTalent = false;
bool g_bEnableEmote = false;

float g_UIScale = 1.0f; // 1.0 = normal, 0.5 = half size

// CRASH FIX (ImGui assertion: WindowBorderHoverPadding > 0.0f).
// The old version called ScaleAllSizes(ratio) repeatedly, compounding on top of
// the already-scaled style. Shrinking a few times drove small style values to
// zero, and ImGui asserts on some of them being <= 0. Worse, it's lossy — those
// values never come back when you scale up again.
//
// Fix: snapshot the pristine style ONCE, then always rebuild from that snapshot
// and scale it a single time. No compounding, fully reversible.
// Set by ApplyUIScale, consumed once by the PHAROAH window on the next frame.
// 0 = nothing pending.
//
// Scaling the STYLE only ever changed fonts and padding - the window itself
// stayed the same size, so "50%" gave you tiny text rattling around in the same
// big box. The window has to be resized by the same ratio for the whole tool to
// actually get smaller, and only the window that owns itself can do that, hence
// the handoff instead of doing it here.
float g_PendingWindowScaleRatio = 0.0f;

void ApplyUIScale(float newScale) {
    static ImGuiStyle baseStyle;
    static bool baseCaptured = false;
    if (!baseCaptured) { baseStyle = ImGui::GetStyle(); baseCaptured = true; }

    if (newScale < 0.4f) newScale = 0.4f;
    if (newScale > 2.5f) newScale = 2.5f;

    // Ratio against where we ARE, so repeated 10% steps compound correctly.
    if (g_UIScale > 0.0001f && newScale != g_UIScale)
        g_PendingWindowScaleRatio = newScale / g_UIScale;

    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4 savedColors[ImGuiCol_COUNT];
    memcpy(savedColors, style.Colors, sizeof(savedColors)); // keep the current theme

    style = baseStyle;              // back to pristine geometry
    style.ScaleAllSizes(newScale);  // scale once, from clean values
    memcpy(style.Colors, savedColors, sizeof(savedColors)); // restore theme colors

    ImGui::GetIO().FontGlobalScale = newScale;
    g_UIScale = newScale;
}

void RenderControlPanel() {
    ImGui::SetNextWindowPos(ImVec2(15, 15), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(260, 0), ImGuiCond_FirstUseEver);

    if (!ImGui::Begin("Control Panel")) { ImGui::End(); return; }

    ImGui::Text("Enable one at a time to isolate crashes:");
    ImGui::Separator();
    ImGui::Checkbox("Fire Mode Panel", &g_bEnableFireMode);
    ImGui::Checkbox("Talent Selection Panel", &g_bEnableTalent);
    ImGui::Checkbox("Emote Menu", &g_bEnableEmote);

    ImGui::Separator();
    ImGui::Text("UI Size:");
    if (ImGui::Button("100%")) ApplyUIScale(1.0f);
    ImGui::SameLine();
    if (ImGui::Button("75%")) ApplyUIScale(0.75f);
    ImGui::SameLine();
    if (ImGui::Button("50%")) ApplyUIScale(0.5f);

    ImGui::Separator();
    ImGui::TextDisabled("INSERT = show/hide everything");

    ImGui::End();
}

uintptr_t xorKey;

typedef HRESULT(__stdcall* IDXGISwapChain_Present_t)(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags);
typedef HRESULT(__stdcall* IDXGISwapChain_ResizeBuffers_t)(IDXGISwapChain* pSwapChain, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT NewFormat, UINT SwapChainFlags);

IDXGISwapChain_Present_t oPresent = nullptr;
// Present1's own trampoline. Never actually called - see hkPresent1 below for
// why we deliberately discard it and fall through to oPresent instead.
void* oPresent1Unused = nullptr;
WNDPROC oWndProc;
HWND window = NULL;
ID3D11Device* pDevice = nullptr;
ID3D11DeviceContext* pContext = nullptr;
ID3D11RenderTargetView* mainRenderTargetView = nullptr;
IDXGISwapChain_ResizeBuffers_t oResizeBuffers = nullptr;

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// ===== AIM FEATURES =====
namespace AimFeatures {
    static SDK::UFunction* getAdjustedAimNativeFunc = nullptr;

    struct GetAdjustedAimNative_Params {
        class SDK::ATgDevice* Weapon;
        SDK::FVector StartFireLoc;
        SDK::FRotator Rotation;
    };

    // Calculate distance between two 3D points
    inline float Distance3D(const SDK::FVector& a, const SDK::FVector& b) {
        float dx = a.X - b.X, dy = a.Y - b.Y, dz = a.Z - b.Z;
        return sqrtf(dx*dx + dy*dy + dz*dz);
    }

    // Rotation math: convert yaw/pitch to direction and back
    inline SDK::FVector RotationToDirection(const SDK::FRotator& rot) {
        float pitchRad = rot.Pitch * (3.14159265f / 32768.0f);
        float yawRad = rot.Yaw * (3.14159265f / 32768.0f);
        return SDK::FVector{
            cosf(pitchRad) * cosf(yawRad),
            cosf(pitchRad) * sinf(yawRad),
            sinf(pitchRad)
        };
    }

    inline SDK::FRotator DirectionToRotation(const SDK::FVector& dir) {
        float yaw = atan2f(dir.Y, dir.X) * (32768.0f / 3.14159265f);
        float pitch = asinf(dir.Z) * (32768.0f / 3.14159265f);
        return SDK::FRotator{ (int)pitch, (int)yaw, 0 };
    }

    // Simple magnet: reduce rotation distance from center
    inline void ApplyAimMagnet(SDK::FRotator& rotation, float magnetX, float magnetY) {
        if (magnetX < 1.01f && magnetY < 1.01f) return;
        float pullStrength = 0.02f;
        if (magnetX > 1.01f) rotation.Yaw *= (1.0f - pullStrength * (magnetX - 1.0f));
        if (magnetY > 1.01f) rotation.Pitch *= (1.0f - pullStrength * (magnetY - 1.0f));
    }

    // Head lock: aim directly at enemy head bone position
    inline void ApplyHeadLock(SDK::FRotator& rotation, const SDK::FVector& startPos, SDK::ATgPawn* targetPawn) {
        if (!targetPawn || !targetPawn->m_HeadMesh) return;
        SDK::FVector headPos = targetPawn->m_HeadMesh->GetBoneLocation(targetPawn->m_HeadShotBoneName, 0);
        SDK::FVector dir = (headPos - startPos);
        float len = sqrtf(dir.X*dir.X + dir.Y*dir.Y + dir.Z*dir.Z);
        if (len > 1.0f) {
            dir.X /= len; dir.Y /= len; dir.Z /= len;
            rotation = DirectionToRotation(dir);
        }
    }

    // Projectile prediction: calculate lead for slow-moving projectiles
    inline void ApplyProjectilePrediction(SDK::FRotator& rotation, const SDK::FVector& startPos, SDK::ATgPawn* targetPawn, float projectileSpeed) {
        if (!targetPawn || projectileSpeed < 100.0f) return;

        SDK::FVector targetVel = targetPawn->Velocity;
        SDK::FVector targetPos = targetPawn->Location;

        // Estimate where target will be when projectile reaches them
        float distToTarget = Distance3D(startPos, targetPos);
        float timeToTarget = distToTarget / projectileSpeed;

        // Predicted position = current position + velocity * time
        SDK::FVector predictedPos = targetPos;
        predictedPos.X += targetVel.X * timeToTarget * 0.5f; // dampen for stability
        predictedPos.Y += targetVel.Y * timeToTarget * 0.5f;
        predictedPos.Z += targetVel.Z * timeToTarget * 0.5f;

        SDK::FVector dir = (predictedPos - startPos);
        float len = sqrtf(dir.X*dir.X + dir.Y*dir.Y + dir.Z*dir.Z);
        if (len > 1.0f) {
            dir.X /= len; dir.Y /= len; dir.Z /= len;
            rotation = DirectionToRotation(dir);
        }
    }

    // Isolated: NO C++ objects in scope, only POD types. Safe to call from __try.
    inline void ProcessAimHook_Isolated(AimFeatures::GetAdjustedAimNative_Params* params) {
        if (!params || !params->Weapon || !Globals::LocalPawn) return;

        if (RecoverySuite::headLockEnabled) {
            // THE ACTUAL BUG behind "locks a totally different enemy the
            // moment I fire": this hook computes the real shot's aim
            // adjustment, completely separately from RecoverySuite::
            // ProcessAimAssist()'s cosmetic camera nudge (which already picks
            // correctly, by screen distance to the cursor). This hook used to
            // walk the pawn list itself and grab whichever enemy happened to
            // be first — arbitrary engine order, nothing to do with where you
            // were aiming. Now it prefers the SAME target ProcessAimAssist()
            // already picked (published in g_FireGatedLockedTarget every
            // frame it has one).
            //
            // CRASH-HARDENING NOTE: g_FireGatedLockedTarget is a pointer
            // cached on a DIFFERENT thread, possibly several frames old by
            // the time it's read here — it must never be dereferenced
            // directly (that was the original version of this fix, and it
            // was a real risk: a stale pointer into a pawn destroyed since).
            // It is now ONLY ever compared by address against pawns this
            // exact walk just freshly discovered as genuinely alive right
            // now — so a stale/dangling value simply fails to match instead
            // of ever being read through. Falls back to the first valid
            // enemy found, same as the original behaviour, if the preferred
            // target isn't in this frame's live list at all.
            SDK::ATgPawn* preferred = RecoverySuite::g_FireGatedLockedTarget;
            SDK::ATgPawn* chosen = nullptr;
            if (Globals::LocalPawn) {
                // WALL CHECK for the fallback path below (preferred is already
                // wall-filtered upstream by ProcessAimAssist, since occluded
                // targets never get published into g_FireGatedLockedTarget).
                // Without this, an occluded preferred target falls through to
                // "first valid candidate" - which had NO visibility awareness
                // at all and would happily snap the real shot onto whoever is
                // first in the engine's pawn list, wall or no wall. Plain
                // field reads only (LastRenderTime / TimeSeconds), same as
                // everything else in this isolated function - no scripted call.
                SDK::AWorldInfo* wi = ((SDK::ATgPawn*)Globals::LocalPawn)->WorldInfo;
                float worldTime = wi ? wi->TimeSeconds : -1.0f;

                SDK::APawn* pawn = wi ? wi->PawnList : nullptr;
                while (pawn) {
                    SDK::ATgPawn* tgPawn = (SDK::ATgPawn*)pawn;
                    if (pawn != Globals::LocalPawn && !pawn->bDeleteMe && pawn->IsA(SDK::ATgPawn::StaticClass())) {
                        int myTeam = -1, theirTeam = -1;
                        if (((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo) {
                            SDK::ATgRepInfo_Player* myPri = (SDK::ATgRepInfo_Player*)((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo;
                            if (myPri->r_TaskForce) myTeam = myPri->r_TaskForce->TeamIndex;
                        }
                        if (tgPawn->PlayerReplicationInfo && ((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo) {
                            SDK::ATgRepInfo_Player* priThem = (SDK::ATgRepInfo_Player*)tgPawn->PlayerReplicationInfo;
                            if (priThem->r_TaskForce) theirTeam = priThem->r_TaskForce->TeamIndex;
                            if (priThem->r_nHealthCurrent > 0 && theirTeam != myTeam && theirTeam != -1) {
                                bool visible = true;
                                if (VisibilityBoxes::wallCheckEnabled && worldTime >= 0.0f && tgPawn->Mesh) {
                                    float lastRender = tgPawn->Mesh->LastRenderTime;
                                    if (lastRender > 0.0f) {
                                        visible = (worldTime - lastRender) <= VisibilityBoxes::wallCheckToleranceSeconds;
                                    }
                                }
                                if (visible) {
                                    if (tgPawn == preferred) { chosen = tgPawn; break; } // confirmed alive THIS frame — safe to use
                                    if (!chosen) chosen = tgPawn; // first valid, VISIBLE candidate, kept as fallback
                                }
                            }
                        }
                    }
                    pawn = pawn->NextPawn;
                }
            }
            if (chosen) {
                AimFeatures::ApplyHeadLock(params->Rotation, params->StartFireLoc, chosen);
            }
        }
        else if (false) {  // projectilePredictionEnabled removed
            if (Globals::LocalPawn) {
                SDK::APawn* pawn = ((SDK::ATgPawn*)Globals::LocalPawn)->WorldInfo->PawnList;
                while (pawn) {
                    SDK::ATgPawn* tgPawn = (SDK::ATgPawn*)pawn;
                    if (pawn != Globals::LocalPawn && !pawn->bDeleteMe && pawn->IsA(SDK::ATgPawn::StaticClass())) {
                        int myTeam = -1, theirTeam = -1;
                        if (((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo) {
                            SDK::ATgRepInfo_Player* myPri = (SDK::ATgRepInfo_Player*)((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo;
                            if (myPri->r_TaskForce) myTeam = myPri->r_TaskForce->TeamIndex;
                        }
                        if (tgPawn->PlayerReplicationInfo && ((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo) {
                            SDK::ATgRepInfo_Player* priThem = (SDK::ATgRepInfo_Player*)tgPawn->PlayerReplicationInfo;
                            if (priThem->r_TaskForce) theirTeam = priThem->r_TaskForce->TeamIndex;
                            if (priThem->r_nHealthCurrent > 0 && theirTeam != myTeam && theirTeam != -1) {
                                AimFeatures::ApplyProjectilePrediction(params->Rotation, params->StartFireLoc, tgPawn, 1500.0f);
                                break;
                            }
                        }
                    }
                    pawn = pawn->NextPawn;
                }
            }
        }
        else {
            AimFeatures::ApplyAimMagnet(params->Rotation, RecoverySuite::aimAssistX, RecoverySuite::aimAssistY);
        }
    }
}

void HookedProcessEvent(void* pObject, void* pFunction, void* pParms, __int64 pResult) {

    // REENTRANCY GUARD in its own scope — ends before __try below
    {
        static thread_local int recursionDepth = 0;
        struct DepthGuard {
            DepthGuard() { recursionDepth++; }
            ~DepthGuard() { recursionDepth--; }
        } depthGuard;

        if (recursionDepth > 1) {
            // We're inside our own nested call — skip all custom logic, just
            // pass through to the real engine function and return immediately.
            ProcessEventOriginal((SDK::UObject*)pObject, (SDK::UFunction*)pFunction, pParms, pResult);
            return;
        }
    } // DepthGuard scope ends here, destructor runs

    // MAJOR PERFORMANCE FIX: ProcessEvent fires for the ENTIRE game's script
    // logic, potentially thousands of times per frame — not just our stuff.
    // The old code called GetFullName() (allocates a new string, walks the
    // object hierarchy) on every single one of those calls just to check if
    // it happened to be the one function we care about. That's thousands of
    // string allocations per frame, constantly, just from being injected —
    // this is almost certainly the real cause of "FPS tanked just from
    // injecting, before touching anything." Fixed: find the target function
    // ONCE and compare raw pointers from then on (near-zero cost) instead of
    // building and comparing strings on every single call.
    // ========================================================================
    // MAJOR BUG FIX. This FindObject lookup was returning null (or a different
    // object than the one actually dispatched), so `pFunction == postRenderFunc`
    // was NEVER true and this entire block never ran — not once. Proven by the
    // safe-thread heartbeat reading 0 and g_EffectsSafe reading 0 while in a
    // live match with a valid pawn.
    //
    // Consequences, all now explained: every DEFERRED action silently never
    // fired (respawn, Octavia buffs, item shop, ServerSetValue/Exec probes, card
    // requests), and moving grayscale to "the safe thread" appeared to break it
    // because that thread's work was never executing. Render-thread features
    // (boxes, reticle, view turn) were unaffected, which is why anything worked
    // at all.
    //
    // Fix: match on the function's NAME rather than a full-path string lookup.
    // The Call Logger already resolves names reliably this way — and it logged
    // "PostRender x33357", proving the function is dispatched constantly. Names
    // are resolved once per unique UFunction* and cached by pointer, so the hot
    // path stays a pointer compare (no per-call string work — that was the
    // original, valid reason for avoiding GetFullName here).
    // ========================================================================
    // FIX #2. The previous version tried FindObject first and only fell back to
    // name matching when it returned NULL. But it returned a NON-NULL, WRONG
    // UFunction — so the fallback never triggered, `pFunction == postRenderFunc`
    // never matched, and the heartbeat stayed 0 while the UI cheerfully reported
    // "anchor found: YES". That combination is what gave it away.
    //
    // FindObject is now abandoned entirely for this. We identify PostRender
    // purely by the name on the LIVE dispatch, which is guaranteed correct
    // because it's the object actually being called. Costs one name lookup per
    // call until the first PostRender arrives (within the first frame), then
    // it's a pointer compare forever.
    // ========================================================================
    // THE INJECTION-TIMING BUG (root cause of "worked once, never again")
    //
    // "PostRender" is NOT a unique function name — several classes define one.
    // The previous version latched onto the FIRST UFunction named PostRender it
    // ever saw and cached that pointer forever. Consequences:
    //
    //   inject at the MAIN MENU -> latches the menu's PostRender. Heartbeat
    //   climbs while you're in menus, then that object STOPS being dispatched
    //   once you're in a match. Heartbeat freezes (the reported "1675 and not
    //   climbing") and every deferred feature silently dies.
    //
    //   inject AFTER spawning -> latches the in-match one, everything works.
    //
    // That is why respawn, health bar recolouring, Octavia shields and the
    // pickups all "worked once and never again" — it was never the features, it
    // was which PostRender we happened to bind to.
    //
    // FIX: don't bind to one forever. Recognise ANY function named PostRender
    // (verdict cached per pointer, so the hot path stays a cheap compare), and
    // prefer whichever one is CURRENTLY being dispatched. If the preferred one
    // goes quiet for 500ms, switch to another live one. That makes injection
    // timing irrelevant and survives menu <-> match transitions in both
    // directions.
    // ========================================================================
    static const int kPRCache = 512;
    static SDK::UFunction* prKey[kPRCache] = {};
    static unsigned char   prVal[kPRCache] = {};   // 1 = not PostRender, 2 = PostRender
    static SDK::UFunction* prPreferred = nullptr;
    static ULONGLONG       prPreferredLastMs = 0;
    static int             prDistinctSeen = 0;

    bool isPostRender = false;
    {
        size_t slot = (((size_t)pFunction) >> 4) % kPRCache;
        size_t start = slot;
        while (true) {
            if (prKey[slot] == pFunction) { isPostRender = (prVal[slot] == 2); break; }
            if (prKey[slot] == nullptr) {
                char nm[80];
                CallLogger::TryCopyFuncName((SDK::UFunction*)pFunction, nm, sizeof(nm));
                unsigned char v = 1;
                if (nm[0] && _stricmp(nm, "PostRender") == 0) { v = 2; prDistinctSeen++; }
                prKey[slot] = (SDK::UFunction*)pFunction;
                prVal[slot] = v;
                isPostRender = (v == 2);
                break;
            }
            slot = (slot + 1) % kPRCache;
            if (slot == start) break; // cache full — treat as uninteresting
        }
    }

    bool runSafeBlock = false;
    if (isPostRender) {
        ULONGLONG nowMs = GetTickCount64();
        // Adopt this one if we have no preference, or the preferred one has gone
        // quiet (i.e. we changed context: menu -> match, match -> menu).
        if (prPreferred == nullptr || (nowMs - prPreferredLastMs) > 500) {
            prPreferred = (SDK::UFunction*)pFunction;
        }
        if (pFunction == prPreferred) {
            prPreferredLastMs = nowMs;
            runSafeBlock = true;   // exactly one PostRender drives the block per frame
        }

        // CANVAS BOX DRAWING - see the big comment on RenderBoxesViaCanvas in
        // VisibilityBoxes.h for why this exists. PostRender's one parameter IS
        // the UCanvas to draw this frame's HUD/overlay with (the SDK confirms
        // the signature: PostRender(class UCanvas* Canvas)) - Parms is just
        // that pointer, laid out exactly like every other single-pointer-arg
        // function already read raw elsewhere in this hook. Runs for EVERY
        // live PostRender seen this frame, not just the preferred one - the
        // preferred-function logic above exists to pick ONE for the
        // respawn/grayscale/etc safe-thread tick (running that twice would be
        // wrong), but drawing is idempotent per Canvas, so there's no reason
        // to also gate it behind that and risk missing frames during a
        // menu<->match transition.
        if (pParms) {
            SDK::UCanvas* canvas = *(SDK::UCanvas**)pParms;
            VisibilityBoxes::RenderBoxesViaCanvas(canvas);
            // Fallback interactive menu - see the big comment on CanvasMenu::Tick
            // for why this is gated and independent from g_bShowMenu.
            CanvasMenu::Tick(canvas);
        }
    }

    RecoverySuite::g_PostRenderResolved = (prPreferred != nullptr);
    RecoverySuite::g_PostRenderByName = true;
    RecoverySuite::g_PostRenderVariants = prDistinctSeen;

    // ===== BORDER COLOUR VIA RANGE INTERCEPT =====
    // The game colours enemy outlines by whether the target is inside the
    // weapon's effective range (in range = red, out of range = yellow — which is
    // why Drogoz's mode 2 shows yellow at all distances). Range is computed, not
    // stored, so we override the RESULT of the call instead of a field. Same
    // technique as the aim hook: let the original run, then rewrite pResult.
    if ((VisibilityBoxes::forceOutOfRangeBorders || VisibilityBoxes::forceInRangeBorders) && pResult) {
        static SDK::UFunction* withinRangeFn = nullptr;
        static bool triedResolve = false;
        if (!triedResolve) {
            triedResolve = true;
            withinRangeFn = SDK::UObject::FindObject<SDK::UFunction>("Function TgGame.TgDeviceFire.IsWithinEffectiveRange");
        }
        bool isTarget = (withinRangeFn && pFunction == withinRangeFn);
        if (!isTarget) {
            // Name fallback, for the same reason PostRender needed one — the
            // full-path lookup is not reliable in this SDK.
            char nm[80];
            CallLogger::TryCopyFuncName((SDK::UFunction*)pFunction, nm, sizeof(nm));
            isTarget = (nm[0] && _stricmp(nm, "IsWithinEffectiveRange") == 0);
        }
        if (isTarget) {
            // Let the engine compute its real answer first, then overwrite it.
            ProcessEventOriginal((SDK::UObject*)pObject, (SDK::UFunction*)pFunction, pParms, pResult);
            *(bool*)pResult = VisibilityBoxes::forceInRangeBorders ? true : false;
            VisibilityBoxes::g_RangeHookHits++;
            return; // already dispatched — must not fall through and call it twice
        }
    }

    // Diagnostic call logger — sees EVERY script call passing through the hook,
    // which is how we can record the game's own real function sequence (and
    // spot Client*-prefixed server replies to our RPCs). Cheap no-op unless
    // explicitly enabled in the Call Log tab.
    CallLogger::OnProcessEvent((SDK::UFunction*)pFunction);

    // SKIN CAPTURE: watch the game's OWN skin calls in the menu so we can read the
    // real classId / skinId / DEVICE id / DEVICE-SKIN id it uses. This is how we
    // learn the weapon parameters instead of guessing them.
    if (RecoverySuite::g_SkinsSystemEnabled && DevSkin::g_CaptureSkinCalls && pFunction && pParms) {
        // Pointers are resolved by the UI (DevSkin::ResolveSkinCaptureFns), never
        // here — no FindObject on the hot hook path at all now.
        SDK::UFunction* fnCCM = DevSkin::g_fnCapCCM;
        SDK::UFunction* fnCTM = DevSkin::g_fnCapCTM;
        SDK::UFunction* fnSS  = DevSkin::g_fnCapSS;
        // Broad net: also record ANY function whose name contains both "Skin" and
        // a lobby/model hint, so if the real call isn't one of the three above we
        // still find out what it actually is instead of silently capturing zero.
        if (DevSkin::g_CapWideNet && pFunction) {
            DevSkin::LogWideSkinCall((SDK::UFunction*)pFunction, pParms);
        }
        if (fnCCM && pFunction == fnCCM) {
            int v[5]; for (int i = 0; i < 5; ++i) v[i] = *(int*)((char*)pParms + i * 4);
            DevSkin::LogSkinCall("ChangeClassModel class,skin,device,devSkin,pedestal", v, 5);
        } else if (fnCTM && pFunction == fnCTM) {
            int v[6]; for (int i = 0; i < 6; ++i) v[i] = *(int*)((char*)pParms + i * 4);
            DevSkin::LogSkinCall("ChangeTeamModel friendly,idx,class,skin,device,devSkin", v, 6);
        } else if (fnSS && pFunction == fnSS) {
            int v[2]; v[0] = *(int*)pParms; v[1] = *(int*)((char*)pParms + 4);
            DevSkin::LogSkinCall("Lobby.SetSkin skin,deviceSkin", v, 2);
        }
    }

    // DEV-SHOP CAPTURE: the dev menu registers each of its entries through
    // AddCommand(Section, Command, DisplayName). Watching it dumps the hidden
    // developer item shop's real command strings straight out of the game.
    if (RecoverySuite::g_SkinsSystemEnabled && DevSkin::g_CaptureDevCommands && pFunction) {
        // Same rule: resolve only outside a match (see note above).
        static SDK::UFunction* addCmdFn = nullptr;
        static bool addCmdLookedUp = false;
        if (!addCmdLookedUp && !Globals::LocalPawn) {
            addCmdLookedUp = true;
            addCmdFn = SDK::UObject::FindObject<SDK::UFunction>(
                "Function TgClient.TgDevMenuMoviePlayer.AddCommand");
        }
        if (addCmdFn && pFunction == addCmdFn) {
            DevSkin::OnDevAddCommand(pParms);
        }
    }

    // ===== AIM ASSIST HOOKS =====
    // Checked outside try/except to avoid C2712 in presence of other objects in this function
    if (RecoverySuite::aimAssistEnabled || RecoverySuite::headLockEnabled) {
        if (!AimFeatures::getAdjustedAimNativeFunc) {
            AimFeatures::getAdjustedAimNativeFunc = SDK::UObject::FindObject<SDK::UFunction>("Function TgGame.TgPawn.GetAdjustedAimNative");
        }
        if (pFunction == AimFeatures::getAdjustedAimNativeFunc) {
            // Call isolated function without try/except wrapper here
            // The function itself is safe from crashes
            AimFeatures::ProcessAimHook_Isolated((AimFeatures::GetAdjustedAimNative_Params*)pParms);
        }
    }

    if (runSafeBlock) {
        bool inGame = Globals::initObjects();
        // Gate every periodic SCRIPTED effect on this. It flips false the instant
        // we leave a match, which is what stops grayscale's reapply from firing
        // at a controller that's mid-teardown (the match-end crash).
        RecoverySuite::g_EffectsSafe = inGame;
        if (!inGame) {
            exploits.selectedTalent = -1;
            Helpers::resetFirstEmoteToDefault();

            // CRASH FIX: these were pointing at devices that get destroyed
            // when you leave a match. Next frame's render would read freed
            // memory (this is what caused the Decrypt/GetName crash on
            // match transitions). Clear them the instant we detect we're
            // no longer in a match.
            g_ManualDevice = nullptr;
            g_ScanResults.clear();

            // Match ended: just stop tracking the forced device, don't write
            // to it — see the comment on RevertForcedFireModeIfAny for why a
            // write at this exact transition point was likely a use-after-free.
            RevertForcedFireModeIfAny();

            // Third person: just reset the toggle state for the new match.
            RecoverySuite::thirdPersonOn = false;
        }

        // Extra safety: also clear if your pawn itself changed (respawn,
        // champion switch, new match) even while technically still "in game" —
        // the old device pointer could still be dangling in these cases too.
        static SDK::APawn* lastSeenPawn = nullptr;
        if (Globals::LocalPawn != lastSeenPawn) {
            g_ManualDevice = nullptr;
            g_ScanResults.clear();
            lastSeenPawn = Globals::LocalPawn;

            // Death/respawn re-applies desaturation — the game itself clears it
            // when your pawn changes (dying, respawning, new match), which was
            // why grayscale kept silently turning itself back off. This call
            // happens on the SAME thread already inside ProcessEvent dispatch
            // (not the render thread), so it's a safe same-thread recursive
            // call under the reentrancy guard above, not a cross-thread race.
            if (RecoverySuite::grayscaleOn) {
                RecoverySuite::ApplyGrayscale(true);
            }
        }

        // The ONLY place that actually writes a fire-mode revert now — every
        // frame, while genuinely still in-game with a valid current weapon
        // reference. If the weapon changed (died/respawned/switched loadout),
        // the OLD device is still safely alive at this exact moment (unlike
        // at match-end), so writing to it here is safe.
        if (Globals::LocalWeapon) {
            RevertForcedFireModeIfWeaponChanged(Globals::LocalWeapon);
        }

        // RESPAWN FIX #2: the pawn-changed check above assumes a new pawn
        // object gets created on respawn, but this engine may just reuse the
        // SAME pawn object and reset its health instead — in that case
        // lastSeenPawn never changes, so the block above never fires, and
        // grayscale silently stayed off after the first death. This catches
        // that case directly: watch health go from <=0 back to >0.
        static int lastHealth = -1;
        if (Globals::LocalPawn) {
            SDK::ATgPawn* myPawn = (SDK::ATgPawn*)Globals::LocalPawn;
            if (myPawn->PlayerReplicationInfo) {
                SDK::ATgRepInfo_Player* pri = (SDK::ATgRepInfo_Player*)myPawn->PlayerReplicationInfo;
                int health = pri->r_nHealthCurrent;
                if (lastHealth <= 0 && health > 0 && RecoverySuite::grayscaleOn) {
                    RecoverySuite::ApplyGrayscale(true); // just respawned, reapply
                }
                lastHealth = health;
            }
        }

        // PERFORMANCE + CRASH SURFACE: this rebuilds the entire talent list
        // from scratch and walks the HUD/scene-stack chain every single
        // frame. The comment here used to say "only run while the menu is
        // shown," but the actual gate was just g_bShowMenu — meaning it ran
        // on EVERY tab, not just Talents. Tightened to the tab actually
        // showing this data: fewer needless allocations per frame, and less
        // time spent touching a pointer chain that's briefly unsafe during a
        // real match transition (see Utils/Helper.h's isolated accessors).
        if (g_bShowMenu && RecoverySuite::activeSection == RecoverySuite::Section::Talents) {
            Helpers::CacheTalentInfos();
        }

        // CONCLUSION after testing: every PERIODIC scripted call (grayscale
        // reapply, silhouette, box/head gather, LOS check) silently fails to
        // take effect when called from here (inside HookedProcessEvent /
        // PostRender), even ones with zero camera dependency like grayscale —
        // so it's not specifically about camera/view timing, something about
        // this call site in general doesn't work for periodic scripted calls.
        // All periodic calls live in hkPresent now, accepting the same
        // throttled residual crash risk across the board rather than
        // features that just silently don't work. The ONE-SHOT toggles below
        // (F4 reset, outline master toggle) stay here since THOSE were the
        // ones directly tied to reproduced instant crashes, and being one-off
        // rather than periodic, moving them doesn't carry the same "silently
        // broken" risk.
        RecoverySuite::ProcessPendingSafeResets();
        Silhouette::ProcessPendingMasterToggle();
        VisualEffects::ProcessPendingEffects(); // one-shot triggers, same safe pattern as the toggles above
        Testing::ProcessPendingSafeActions(); // pickup ApplyEffect / Commander passive trigger — same fix
        CallLogger::PollState(); // always-on state watcher (self-throttled to ~3x/sec)
        RecoverySuite::ProcessPendingTurn(); // controller view-turn, scripted call so it runs here not on the render thread
        // ProcessAimAssist() removed from here — it's a plain raw field write
        // (SetLookAxes), not a scripted call, so unlike ProcessPendingTurn it
        // doesn't need this thread. Calling it here TOO, alongside hkPresent,
        // meant it could run many times per rendered frame (this hook fires
        // for essentially every scripted call, not once per frame), each time
        // writing an unsmoothed direction — the likely source of warpy/jittery
        // aim-lock movement. Now only called once per frame, from hkPresent,
        // same as trigger bot's UpdateAutoFire().

        // BUG FOUND while wiring the Canvas fallback menu: Speeden::Update()
        // (no-spread, no-recoil, fire rate, hide ammo, time dilation, energy
        // experiment) was called ONLY from hkPresent - meaning on a machine
        // where that never fires (Spider's, confirmed via initlogs.md), none
        // of it ever ran, silently, regardless of what any menu/checkbox said.
        // Fixed by also running it here, on the SAME thread that already
        // reliably runs the Canvas fallback (HookedProcessEvent's PostRender
        // detection) - minus PollKeyBinding/UpdateTeleport, which use
        // SafeCalls (a genuine scripted ProcessEvent call) and stay
        // render-thread-only, unchanged. Everything else here is pure struct-
        // field writes, same category as ProcessAimAssist() right above,
        // which this project already established is safe and effective from
        // this exact call site - unlike the truly SCRIPTED calls (grayscale
        // reapply, silhouette, box/head gather, LOS check) the big comment
        // above this block found silently do NOT take effect from here.
        // Tagged log below so this can be confirmed from a log file alone,
        // same as everything else in this investigation - not assumed.
        {
            static bool loggedFirstSafeThreadApply = false;
            if (!loggedFirstSafeThreadApply && (Speeden::noSpreadEnabled || Speeden::noRecoilEnabled)) {
                loggedFirstSafeThreadApply = true;
                InitLog("[SpeedenSafe] Applying no-spread/no-recoil (and the rest of Speeden::Update) "
                        "from HookedProcessEvent for the first time - this is the path that keeps these "
                        "working even when hkPresent never fires.");
            }
            Speeden::Update(false);
        }
        // Same fix, same reasoning, for the rest of the raw-field/Win32-input
        // features that were ALSO only ever called from hkPresent - checked
        // each of their bodies for SafeCalls/ProcessEvent usage first (none
        // found, all pure field writes or SendInput, same safe category as
        // Speeden::Update above) before adding them here:
        UpdateSuperDrogoz();        // raw field reads/writes only
        Unlocker::Tick();           // raw field writes, self-throttled, no-op unless its own switch is on
        RecoverySuite::UpdateAutoFire(); // pure Win32 input simulation (SendInput), no SDK calls
    }

    ProcessEventOriginal((SDK::UObject*) pObject, (SDK::UFunction*) pFunction, pParms, pResult);
}

// AUTO-FIRE FIX: GetAsyncKeyState(VK_LBUTTON) was being used to detect "is
// the user physically holding left click" — but our OWN synthetic clicks
// update that exact same OS key-state, so right after our first synthetic
// release, Windows reports the button as "up" even though the real finger
// never moved, breaking hold-detection after one pulse (this is what looked
// like "it holds the button down" — the repeat loop was actually getting
// confused about whether it was still being held). Fixed by tracking the
// REAL hold state from actual window messages instead, tagging our own
// synthetic input with a marker so it's never mistaken for real input.
ULONG_PTR kAutoFireExtraInfoTag = 0x50414C41; // "PALA" - arbitrary marker
bool g_RealLButtonHeld = false;
bool g_LButtonClickedThisFrame = false;

// ============================================================================
// WHY WNDPROC MESSAGES GET QUEUED INSTEAD OF HANDED TO IMGUI DIRECTLY
// ============================================================================
// WndProc runs on whatever thread owns the game window's message pump - the
// GAME thread. hkPresent (and everything ImGui does inside it - NewFrame,
// Render, the whole draw) runs on the RENDER thread. Paladins is UE3 with
// threaded rendering, so those are two different threads.
//
// ImGui_ImplWin32_WndProcHandler used to be called straight from WndProc,
// which means AddMousePosEvent/AddKeyEvent/etc were mutating
// g.InputEventsQueue (a plain, non-thread-safe ImVector) from the game
// thread while ImGui::NewFrame() drains and clears that SAME vector on the
// render thread, every frame, completely unsynchronized. That is a textbook
// data race, and it is exactly what crashed: FindLatestInputEvent() reading
// g.InputEventsQueue[n] (imgui.cpp:1735, called from AddMousePosEvent) while
// the vector's Size/Data were mid-mutation on the other thread. Confirmed
// from PRIMAL_MONKE's crash reports - one stack traced straight through
// WndProc -> ImGui_ImplWin32_WndProcHandler -> AddMousePosEvent ->
// FindLatestInputEvent -> ImVector::operator[] crash; a second, differently-
// shaped crash with no PHAROAH symbols at all is consistent with the same
// race corrupting the heap and something unrelated tripping over it moments
// later - "different crash paths, shared underlying component," which is
// exactly what a race like this looks like from the outside.
//
// This bug always existed - it just took enough mouse traffic through
// WndProc to open the window reliably, which is exactly what interacting
// with the new talent/emote combo boxes does far more of than idle tabs.
//
// Fix: WndProc no longer touches ImGui at all except reading io flags it
// already read before (last-frame values, same as always - see the
// WantCaptureMouse/Keyboard block below, unchanged). Raw messages are
// queued here and replayed into ImGui_ImplWin32_WndProcHandler on the
// RENDER thread, right before ImGui_ImplDX11_NewFrame(), so ImGui's input
// queue is only ever touched from one thread.
struct QueuedWinMsg { HWND hWnd; UINT msg; WPARAM wParam; LPARAM lParam; };
std::mutex g_WinMsgQueueMutex;
std::vector<QueuedWinMsg> g_WinMsgQueue;

LRESULT __stdcall WndProc(const HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

    {
        std::lock_guard<std::mutex> lock(g_WinMsgQueueMutex);
        g_WinMsgQueue.push_back({ hWnd, uMsg, wParam, lParam });
    }

    // Suppress the OS cursor while the menu is open. We draw our own pyramid,
    // and without this you get TWO cursors: ours plus the white system arrow
    // the game lets through once the overlay is taking input. Answering
    // WM_SETCURSOR with a NULL cursor is the clean way to do it - it does not
    // touch the ShowCursor refcount, which the game also manipulates and would
    // fight us over.
    if (uMsg == WM_SETCURSOR && g_bShowMenu) {
        SetCursor(nullptr);
        return TRUE;
    }

    if (GetMessageExtraInfo() != kAutoFireExtraInfoTag) {
        if (uMsg == WM_LBUTTONDOWN) {
            g_RealLButtonHeld = true;
            g_LButtonClickedThisFrame = true;
        }
        else if (uMsg == WM_LBUTTONUP) {
            g_RealLButtonHeld = false;
        }
    }

    // No clicking through / Typing through.
    //
    // HARD GUARD: only ever swallow input while the overlay is actually SHOWN.
    // Without this, a text field (e.g. the skins "champion filter" InputText) that
    // still holds ImGui focus keeps io.WantCaptureKeyboard true after the overlay
    // is hidden — and every keystroke gets eaten, so WASD, the item shop and every
    // bind stop responding with no visible menu to explain it. Requiring
    // g_bShowMenu makes that state impossible to get stuck in.
    if (ImGui::GetCurrentContext() && g_bShowMenu) {
        ImGuiIO& io = ImGui::GetIO();

        if (io.WantCaptureKeyboard && g_IsSimulatingInput <= 0) {
            switch (uMsg) {
            case WM_KEYDOWN:
            case WM_SYSKEYDOWN:
            case WM_KEYUP:
            case WM_SYSKEYUP:
            case WM_CHAR:
            case WM_IME_CHAR:
                return true;
            }
        }

        if (io.WantCaptureMouse) {
            switch (uMsg) {
                case WM_LBUTTONDOWN:
                case WM_LBUTTONUP:
                case WM_LBUTTONDBLCLK:
                case WM_RBUTTONDOWN:
                case WM_RBUTTONUP:
                case WM_RBUTTONDBLCLK:
                case WM_MBUTTONDOWN:
                case WM_MBUTTONUP:
                case WM_MBUTTONDBLCLK:
                case WM_MOUSEWHEEL:
                case WM_MOUSEHWHEEL:
                    return true;
            }
        }
    }

    return CallWindowProcW(oWndProc, hWnd, uMsg, wParam, lParam);
}

bool init = false;

// Set true the moment hkPresent is CONFIRMED to actually be firing (not just
// "kiero::bind reported success" - the whole reason that distinction
// matters is the entire investigation behind this build). Read from
// RenderBoxesViaCanvas (VisibilityBoxes.h) so the Canvas fallback can stay
// silent on every machine where the real render hook already works, and
// only activate on ones where it's genuinely broken - one DLL, one inject
// button, automatic per-machine detection, no "which button do I click"
// and no duplicate/overlapping box systems on machines that don't need it.
volatile bool g_D3D11RenderHookConfirmedWorking = false;

// SIMULATE-FALLBACK MODE — toggled with F6, live, no restart, no separate
// download. This exists to answer one question without ever having to ask a
// user with a broken D3D11 hook to test anything: "what does MY machine look
// like through the fallback path?" On a machine where the real hook works
// fine (i.e. every dev machine that's ever tested this), the Canvas fallback
// (RenderBoxesViaCanvas / CanvasMenu.h) normally never activates at all -
// see g_D3D11RenderHookConfirmedWorking above. With this flag on, hkPresent
// stops building/drawing/rendering the real ImGui frame entirely (skips
// straight to oPresent) for as long as it's on, which makes
// g_D3D11RenderHookConfirmedWorking irrelevant for gating purposes - the
// Canvas gate checks THIS flag too (see VisibilityBoxes.h / CanvasMenu.h) and
// treats it exactly like "the hook never fired," even though it did. What
// you then see on screen is, as closely as this project can arrange without
// two separate builds, exactly what a genuinely broken machine sees - same
// code path, same gate, just entered a different way. Toggle it back off and
// the real menu resumes exactly where it left off; nothing is torn down.
volatile bool g_SimulateFallbackMode = false;

HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags) {
    // HEARTBEAT — proves the hook is actually firing, not just that kiero::bind
    // reported success at install time. "kiero::bind done... SUCCESS" only means
    // the vtable slot was patched without erroring; it says nothing about
    // whether the game's REAL present calls ever reach it. Every "silent
    // failure" report so far has shown a clean install log with no way to tell
    // whether hkPresent ever actually got called even once. This closes that
    // gap for any future report.
    {
        static bool loggedFirstPresent = false;
        static ULONGLONG frameCount = 0;
        static ULONGLONG lastHeartbeatMs = 0;
        frameCount++;
        if (!loggedFirstPresent) {
            loggedFirstPresent = true;
            lastHeartbeatMs = GetTickCount64();
            g_D3D11RenderHookConfirmedWorking = true;
            InitLog("[Init] hkPresent CALLED for the first time - the hook is genuinely firing.\n");
        }
        // ONGOING heartbeat, not just the first call. A hook that fires once
        // and then goes silent later (e.g. something stomps it well after
        // install, or a delayed crash) looks IDENTICAL to "never fired" in a
        // log that only records the first call - this tells them apart. Once
        // every ~10s, cheap enough to never worry about.
        ULONGLONG now = GetTickCount64();
        if (now - lastHeartbeatMs > 10000) {
            lastHeartbeatMs = now;
            InitLog("[Init] hkPresent heartbeat - still rendering, %llu frames so far.", frameCount);
        }
    }

    if (!init)
    {
        if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)& pDevice)))
        {
            pDevice->GetImmediateContext(&pContext);
            DXGI_SWAP_CHAIN_DESC sd;
            pSwapChain->GetDesc(&sd);
            window = sd.OutputWindow;

            // ADAPTER IDENTIFICATION — the classic silent-hook-install failure is
            // kiero's own dummy device landing on a DIFFERENT GPU than the one the
            // game actually renders with (hybrid-graphics laptops: Intel iGPU +
            // NVIDIA/AMD dGPU). When that happens the hook installs "successfully"
            // against the wrong vtable and never intercepts the real game. Logging
            // which adapter we actually got lets a report distinguish that
            // instantly instead of guessing.
            {
                IDXGIDevice* dxgiDevice = nullptr;
                if (SUCCEEDED(pDevice->QueryInterface(__uuidof(IDXGIDevice), (void**)&dxgiDevice)) && dxgiDevice) {
                    IDXGIAdapter* adapter = nullptr;
                    if (SUCCEEDED(dxgiDevice->GetAdapter(&adapter)) && adapter) {
                        DXGI_ADAPTER_DESC desc{};
                        if (SUCCEEDED(adapter->GetDesc(&desc))) {
                            char narrow[128] = {0};
                            WideCharToMultiByte(CP_ACP, 0, desc.Description, -1, narrow, sizeof(narrow), nullptr, nullptr);
                            InitLog("[Init] Real D3D11 device is on adapter: %s\n", narrow);
                        }
                        adapter->Release();
                    }
                    dxgiDevice->Release();
                }
            }

            ImGui::CreateContext();
            ImGuiIO& io = ImGui::GetIO();
            io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange | ImGuiConfigFlags_NavEnableKeyboard;

            ImGui_ImplWin32_Init(window);
            ImGui_ImplDX11_Init(pDevice, pContext);

            // Load the real PHAROAH logo into a D3D texture. Done here because
            // this is the one place a valid ID3D11Device is guaranteed. It tries
            // once; on failure the menu falls back to the drawn vector glyph, so a
            // missing file can never cost us the header.
            LogoTexture::EnsureLoaded(pDevice);
            io.BackendFlags |= ImGuiBackendFlags_RendererHasVtxOffset;

            // FONT LOAD, WITH A GUARANTEED FALLBACK.
            //
            // This used to be a single AddFontFromFileTTF against a hardcoded
            // absolute path with NO fallback and NO error check. On a machine
            // where that exact file isn't at that exact path - a different
            // Windows language/locale build, a Windows N/KN edition (several
            // default fonts are missing entirely), a corrupted font cache, a
            // stripped-down image - AddFontFromFileTTF returns null and the
            // atlas is left with ZERO fonts. Every init-log line up to this
            // point in InitThread already printed "OK" (they all run before
            // this), so the console shows a clean success while ImGui's
            // per-frame pipeline (NewFrame -> font atlas build) silently never
            // completes correctly from here on - which also takes F9 down
            // with it, since key detection goes through ImGui::IsKeyPressed,
            // which depends on that same per-frame pipeline actually running.
            // This is the leading theory for "log says everything hooked,
            // nothing ever shows, not even F9" reports.
            //
            // Fix: fall back to ImGui's own embedded default font (zero disk
            // access, cannot fail) if the system font didn't load, so the
            // atlas can never end up empty regardless of what's on disk.
            ImFontConfig config;
            config.OversampleH = 2;
            config.OversampleV = 2;
            config.PixelSnapH = true;
            ImFont* loadedFont = io.Fonts->AddFontFromFileTTF(
                "C:\\Windows\\Fonts\\segoeui.ttf", 15.0f, &config, io.Fonts->GetGlyphRangesDefault());
            if (loadedFont) {
                InitLog("[Init] Segoe UI loaded from disk.\n");
            } else {
                InitLog("[Init] WARNING: Segoe UI failed to load from disk - falling back to "
                       "ImGui's built-in default font so the menu can still render.\n");
                io.Fonts->AddFontDefault();
            }

            ApplyModernStyle();

            oWndProc = (WNDPROC)SetWindowLongPtrW(window, GWLP_WNDPROC, (LONG_PTR)WndProc);

            init = true;
        }
        else
            return oPresent(pSwapChain, SyncInterval, Flags);
    }

    if (!mainRenderTargetView) {
        ID3D11Texture2D* pBackBuffer;
        pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)& pBackBuffer);
        pDevice->CreateRenderTargetView(pBackBuffer, NULL, &mainRenderTargetView);
        pBackBuffer->Release();
    }

    // Edge-triggered toggles: INSERT or F3 both show/hide. F4 resets everything.
    {
        static bool insertWasDown = false, f3WasDown = false, f4WasDown = false, f6WasDown = false, f7WasDown = false;

        // DO NOT FIRE HOTKEYS WHILE THE USER IS TYPING.
        //
        // These read raw OS key state, which does not care that an ImGui text
        // box has focus. Typing a 9 into the notes panel therefore toggled
        // grayscale - that is the "grayscale turned on for no reason" - and
        // typing F4 silently reset every setting in the tool.
        //
        // WantTextInput is true only while a text field is actually focused, so
        // this blocks nothing during normal play.
        const bool typing = ImGui::GetCurrentContext() && ImGui::GetIO().WantTextInput;

        bool insertDown = !typing && (GetAsyncKeyState(VK_INSERT) & 0x8000) != 0;
        bool f3Down     = !typing && (GetAsyncKeyState(VK_F3)     & 0x8000) != 0;
        bool f4Down     = !typing && (GetAsyncKeyState(VK_F4)     & 0x8000) != 0;
        bool f6Down     = !typing && (GetAsyncKeyState(VK_F6)     & 0x8000) != 0;
        bool f7Down     = !typing && (GetAsyncKeyState(VK_F7)     & 0x8000) != 0;

        if ((insertDown && !insertWasDown) || (f3Down && !f3WasDown)) {
            g_bShowMenu = !g_bShowMenu;
        }
        if (f4Down && !f4WasDown) {
            RecoverySuite::ResetAllToDefaults();
        }
        // F6 — SIMULATE-FALLBACK MODE. See the big comment on
        // g_SimulateFallbackMode above hkPresent for what this does and why.
        // Force the real menu closed on the way in so it can't stay open
        // underneath a frame that's about to stop drawing it - and log the
        // transition, so this shows up in the same log file as everything
        // else here rather than being an invisible local-only toggle.
        if (f6Down && !f6WasDown) {
            g_SimulateFallbackMode = !g_SimulateFallbackMode;
            if (g_SimulateFallbackMode) {
                g_bShowMenu = false;
                // Open the fallback panel automatically too - first live test
                // of this reported pressing INSERT/clicking did nothing,
                // because nothing on screen said INSERT was even the key to
                // press. F6 now shows it immediately instead of relying on
                // that being remembered.
                CanvasMenu::g_MenuOpen = true;
                InitLog("[Init] F6 - SIMULATE-FALLBACK MODE ON. Real ImGui menu/walls are "
                        "suppressed this frame onward; the Canvas fallback (boxes + INSERT "
                        "menu) is active instead, same as a machine where the D3D11 hook "
                        "never fires. Press F6 again to go back to normal.");
            } else {
                InitLog("[Init] F6 - SIMULATE-FALLBACK MODE OFF. Back to the real ImGui menu/walls.");
            }
        }
        // F7 — MANUAL RHI FALLBACK TEST. Forces the same retry the automatic
        // fallback (RHIAutoFallbackThread) only ever runs when the real hook
        // is silent - see PerformRHIFallbackAttempt's big comment. Lets this
        // be tested on a machine where the hook already works, deliberately,
        // instead of only ever finding out from someone else's broken one.
        // Same action as the "TEST RHI FALLBACK" button in RecoverySuite.h -
        // this is just a second way to trigger it.
        if (f7Down && !f7WasDown) {
            InitLog("[Init] F7 pressed - manually triggering the RHI fallback test.");
            CreateThread(nullptr, 0, ManualRHITestThread, nullptr, 0, nullptr);
        }
        // GRAYSCALE HOTKEY: F9 by default, not the bare 9 key (9 is a GAME
        // key - pressing it in a match to pick a loadout slot used to toggle
        // grayscale too). Now rebindable (Themes tab -> Keybinds) since F9
        // clashes with Steam's own FPS-overlay bind on some setups - a
        // known, previously unfixed issue.
        if (!typing && RecoverySuite::g_BindGrayscaleKey != ImGuiKey_None &&
            ImGui::IsKeyPressed(RecoverySuite::g_BindGrayscaleKey, false)) {
            RecoverySuite::ApplyGrayscale(!RecoverySuite::grayscaleOn);
        }

        // User-configurable binds (Themes tab, "Keybinds"). Skipped while
        // typing (same rule as above) and while a bind is actively being
        // captured, so the keypress that finishes a rebind can't also fire
        // the old action on the same frame.
        if (!typing && !RecoverySuite::g_CapturingBindTarget && ImGui::GetCurrentContext()) {
            if (RecoverySuite::g_BindInstantRespawn != ImGuiKey_None &&
                ImGui::IsKeyPressed(RecoverySuite::g_BindInstantRespawn, false)) {
                RecoverySuite::g_PendingInstantRespawn = true;
            }
            if (RecoverySuite::g_BindCardsAutoToggle != ImGuiKey_None &&
                ImGui::IsKeyPressed(RecoverySuite::g_BindCardsAutoToggle, false)) {
                CardSuite::g_AutoEnabled = !CardSuite::g_AutoEnabled;
            }
            if (RecoverySuite::g_BindAimToggle != ImGuiKey_None &&
                ImGui::IsKeyPressed(RecoverySuite::g_BindAimToggle, false)) {
                RecoverySuite::magnetAimEnabled = !RecoverySuite::magnetAimEnabled;
            }
        }

        UpdateRGBThemeIfEnabled(); // pure color math, cheap, runs every frame when the RGB theme is on

        insertWasDown = insertDown;
        f3WasDown = f3Down;
        f4WasDown = f4Down;
        f6WasDown = f6Down;
        f7WasDown = f7Down;
    }

    // Replay this frame's queued WndProc messages HERE, on the render
    // thread, before touching ImGui at all — see the big comment above
    // WndProc for why. Swap-and-release the lock immediately rather than
    // holding it while calling into ImGui, so a WndProc call arriving
    // mid-replay (game thread) never blocks on it.
    //
    // Drained UNCONDITIONALLY, even in simulate-fallback mode below - every
    // WndProc call (every mouse move) pushes into this queue regardless of
    // what hkPresent does with it, so skipping the drain would leak memory
    // for as long as simulate mode stayed on. Just don't hand it to ImGui
    // while simulating; there's no frame for it to matter to.
    {
        std::vector<QueuedWinMsg> drained;
        {
            std::lock_guard<std::mutex> lock(g_WinMsgQueueMutex);
            drained.swap(g_WinMsgQueue);
        }
        if (!g_SimulateFallbackMode) {
            for (const QueuedWinMsg& m : drained) {
                ImGui_ImplWin32_WndProcHandler(m.hWnd, m.msg, m.wParam, m.lParam);
            }
        }
    }

    // SIMULATE-FALLBACK MODE: skip building/drawing/rendering the real ImGui
    // frame entirely and go straight to oPresent, exactly like the early
    // "not initialized yet" bail-out above - just entered by choice instead
    // of by the hook failing. Globals::LocalPawn/LocalController etc. stay
    // fresh regardless (HookedProcessEvent's own runSafeBlock refreshes them
    // independently - see Globals::initObjects() there), so the Canvas
    // fallback keeps working normally while this is skipped.
    if (g_SimulateFallbackMode) {
        return oPresent(pSwapChain, SyncInterval, Flags);
    }

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    // ---- SOFTWARE CURSOR ----------------------------------------------
    // The game hides the OS cursor while you play, so with the menu open there
    // was nothing to aim with. MouseDrawCursor makes ImGui draw its own cursor
    // into the same draw list as the menu, which means it is always ON TOP of
    // the tool and disappears the instant the tool does - no OS cursor to
    // leak out, nothing left behind over the game.
    // We draw our OWN cursor below, so ImGui must not also draw its default one.
    ImGui::GetIO().MouseDrawCursor = false;

    ImGui::NewFrame();

    // Track the worst frame each second. A periodic hitch does not move the
    // FPS average, which is why users reported "stuttering but FPS says 50".
    Perf::Tick(ImGui::GetIO().DeltaTime);

    bool objectsReady = Globals::initObjects();
    VisibilityBoxes::GatherAndCache(); // moved back here — see HookedProcessEvent for why the ProcessEvent-thread version broke boxes entirely
    VisibilityBoxes::UpdateLosCacheOnePerFrame(); // moved back here too — LineOfSightTo produced no visible boxes at all from the safe thread
    VisibilityBoxes::RenderBoxes(); // runs regardless of menu visibility, gated internally by its own "enabled" checkbox
    VisibilityBoxes::RenderBoxesNoWalls(); // separate test feature, own toggle, reads the LOS cache only — no scripted calls here
    VisibilityBoxes::RenderTargetReticle(); // display-only crosshair colour feedback, no input simulation
    Silhouette::UpdateSilhouettes(); // moved back here too — same reason
    RecoverySuite::ForceGrayscaleIfEnabled(); // moved back here — the safe-thread experiment made it stop working entirely, not just crash less
    RecoverySuite::UpdateAutoFire(); // pure Win32 input simulation, no SDK calls — safe from any thread
    // View turn: plain field writes only (no ProcessEvent), so it runs here on
    // the render thread as well as from the ProcessEvent side. Writing it from
    // both points covers the case where the engine consumes the input axes
    // earlier in the frame than PostRender fires.
    RecoverySuite::ProcessPendingTurn();
    UpdateSuperDrogoz(); // raw field reads/writes only — no ProcessEvent calls
    Speeden::Update();   // raw field writes to GroundSpeed/AirSpeed/AccelRate, safe here
    // All three below are raw field reads/writes only. Anything scripted they need
    // is flagged here and dispatched from RunSafeThreadSubsystems on the
    // ProcessEvent thread — calling scripted functions from this thread is what
    // corrupted pawn state previously.
    // Runs here, NOT inside RecoverySuite::Render, because Render only happens
    // while the menu is visible. The unlocker has to work inject-and-forget with
    // the menu closed, inject-and-forget. Self-throttled, and a no-op unless its
    // own switch is on.
    Unlocker::Tick();
    // Every-frame re-stamp of ONLY the local player's own verified/golden
    // objects. (The CDO write that used to be here was removed - it set the
    // CLASS DEFAULT, which verified every player including enemies, exactly
    // the "everyone has a checkmark" bug PRIMAL_MONKE saw on the scoreboard.)
    Unlocker::TickCheckmarkFast();
    // HOLD-unblur, if enabled. No-op otherwise. Must run every frame to beat
    // another DLL that re-applies the blur each frame.
    ColorGrading::Update();
    // Flush the notes scratchpad to disk if it changed and typing has settled.
    // Cheap: touches the disk only when there is something new to write.
    RecoverySuite::TickNotesAutosave();
    // Persist any changed setting a second after it settles.
    Persist::Tick();
    DirectFire::Tick();
    DirectFire::TickCards();   // card-slot spam; no-op unless a slot is ticked
    CardSuite::Tick();    // card-suite auto-fire; no-op unless enabled   // no-op unless SPAM is ticked; must run with menu closed
    InstantReload::Update();  // scales m_fTotalReloadTime (not Net)
    VGSSpam::Update();        // reads c_nCurrentVGSPlaying to learn ids; queues sends
    CameraTools::Update();    // FOVAngle/DesiredFOV/DefaultFOV (none Net)
    // Gated by the skins master switch (default OFF). This ran every single frame
    // regardless of whether the Skins tab was ever opened — it writes raw mesh
    // pointers, walks GObjects on a timer and re-applies persistence, so a fault
    // here affected normal play. Off = not executed.
    if (RecoverySuite::g_SkinsSystemEnabled)
        MeshSkin::Update();  // raw mesh pointer write - no server involvement
    Crosshair::Render();      // pure ImGui overlay — touches no game object at all
    // NOTE: 4th Talent and Emotes both used to be separate floating windows
    // called from here (RecoverySuite::DrawTalentPanel() / RenderEquipEmoteMenu()).
    // Both are now embedded tab content instead — see RecoverySuite::Talents
    // and RecoverySuite::Emotes, drawn from RecoverySuite::Render() like every
    // other tab. Nothing to call from hkPresent for either any more. The old
    // radial-wheel emote file (menus/EquipEmoteMenu.h) is left on disk, just
    // unwired.
    RecoverySuite::ProcessAimAssist(); // aim assist nudge using analog input
    g_LButtonClickedThisFrame = false; // reset click flag after this frame's firing logic

    if (g_ShowFPS) {
        char fpsText[32];
        snprintf(fpsText, sizeof(fpsText), "FPS: %.0f", ImGui::GetIO().Framerate);
        ImGui::GetForegroundDrawList()->AddText(ImVec2(10, 10), IM_COL32(255, 255, 0, 255), fpsText);
    }

    // Track show->hide so we can release keyboard focus exactly once on hide.
    // A widget that still holds focus (e.g. an InputText) keeps
    // io.WantCaptureKeyboard true, which silently eats every key — dead WASD,
    // dead binds, no visible menu to explain why.
    static bool s_MenuWasShown = false;
    if (g_bShowMenu)
    {
        // Apply any theme requested last frame BEFORE anything is drawn, so
        // the whole frame uses one palette. See RequestPharoahTheme.
        ApplyPendingTheme();
        ApplyRGBBorderAccent();
        RecoverySuite::Render(objectsReady);
        s_MenuWasShown = true;
    }
    else if (s_MenuWasShown)
    {
        s_MenuWasShown = false;
        ImGui::SetWindowFocus(nullptr);   // drop focused window + its active widget
    }

    // ---- PHAROAH CURSOR ------------------------------------------------
    // A pyramid. Drawn into the FOREGROUND draw list, which is composited
    // after every window, so it is always on top of the tool - and because it
    // is part of our own frame it vanishes with the menu, leaving nothing
    // stranded over the game.
    //
    // Two passes: a dark silhouette one pixel out, then the blue fill. Without
    // the silhouette the cursor disappears against a light wall or a skybox.
    if (g_bShowMenu) {
        ImDrawList* fg = ImGui::GetForegroundDrawList();
        ImVec2 m = ImGui::GetIO().MousePos;
        const float h = 22.0f;   // height of the pyramid
        const float w = 8.5f;    // base half-width - narrow, so it stays a pointer

        // THE TIP LEANS LEFT.
        //
        // A real mouse pointer is not symmetrical - its tip is the top-left
        // corner and the body falls away down-right. The old version put the
        // apex straight above the base, which read as a road sign rather than a
        // cursor. Shifting the apex left of the base centre gives it the lean,
        // and the hotspot stays exactly on m so clicking still lands where you
        // point.
        const float lean = 0.42f;   // how far left the tip sits, as a fraction of w

        ImVec2 apex = ImVec2(m.x, m.y);
        // Base corners, both down-right of the tip. The left corner is pulled in
        // close so the left edge is nearly vertical - that near-vertical edge is
        // what makes it read as a pointer.
        ImVec2 bl   = ImVec2(m.x + w * lean * 0.30f, m.y + h);
        ImVec2 br   = ImVec2(m.x + w * 1.45f,        m.y + h * 0.70f);

        // The notch: a real cursor has a tail. Cutting back toward the tip on
        // the lower-left turns a plain triangle into something with a waist,
        // which is most of what makes an arrow look like an arrow.
        ImVec2 waist = ImVec2(m.x + w * 0.34f, m.y + h * 0.74f);

        const ImU32 kFill    = IM_COL32(47, 182, 212, 245);  // logo aqua-blue
        const ImU32 kEdgeCol = IM_COL32(15, 74, 85, 255);    // deep blue edge
        const ImU32 kGold    = IM_COL32(217, 174, 56, 220);  // PHAROAH gold seam
        const ImU32 kShine   = IM_COL32(150, 226, 240, 210); // lit left face

        // Body as a quad: tip -> tail -> waist -> right corner. Convex, so
        // AddConvexPolyFilled renders it in one pass with no seam.
        ImVec2 body[4] = { apex, bl, waist, br };
        fg->AddConvexPolyFilled(body, 4, kFill);

        // Lit left face, so it reads as a solid pyramid rather than a flat
        // triangle. Drawn on top of the fill, inside the silhouette.
        ImVec2 lit[3] = { apex, bl, waist };
        fg->AddConvexPolyFilled(lit, 3, kShine);

        // Outline last so it sits over both fills and keeps the shape crisp
        // against a light wall or a skybox.
        fg->AddPolyline(body, 4, kEdgeCol, ImDrawFlags_Closed, 1.3f);

        // Gold seam down the ridge - the PHAROAH tell.
        fg->AddLine(apex, waist, kGold, 1.1f);
    }

    ImGui::Render();

    pContext->OMSetRenderTargets(1, &mainRenderTargetView, NULL);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

    return oPresent(pSwapChain, SyncInterval, Flags);
}

// FLIP-MODEL PRESENT1 HOOK.
//
// kiero's dummy device only ever captures the classic IDXGISwapChain vtable
// (Present at slot 8). Some systems put the real game on a flip-model
// swapchain, where the engine calls IDXGISwapChain1::Present1() instead of
// the inherited Present() - a completely different vtable slot. When that
// happens, kiero::bind still reports "SUCCESS" (patching slot 8 never fails
// on its own), but hkPresent above is never reached: no ImGui frame ever
// runs, so the menu never draws and F9 never fires (both live inside
// hkPresent), while anything going through ProcessEvent (instant respawn,
// healthbar recolor) keeps working fine since that is a totally separate
// hook. This was the real root cause of "log says everything hooked, still
// totally silent" reports that persisted even after the font-atlas fix -
// this bug has nothing to do with fonts, it is that hkPresent was never
// being called at all for the affected users.
//
// IDXGISwapChain1 inherits IDXGISwapChain (same object, same `this`), so we
// just upcast and run the exact same hkPresent logic rather than duplicating
// it. At the end that logic calls oPresent (the classic trampoline) - which
// is safe and correct to call even for a flip-model swapchain, since
// Present() remains a fully valid entry point on the same COM object
// regardless of which slot the game itself happened to call. We never need a
// real Present1 trampoline as a result, so oPresent1Unused is captured only
// to satisfy MinHook's API and is never called.
HRESULT __stdcall hkPresent1(IDXGISwapChain1* pSwapChain, UINT SyncInterval, UINT Flags, const DXGI_PRESENT_PARAMETERS* pPresentParameters)
{
    return hkPresent((IDXGISwapChain*)pSwapChain, SyncInterval, Flags);
}

HRESULT __stdcall hkResizeBuffers(IDXGISwapChain* pSwapChain, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT NewFormat, UINT SwapChainFlags)
{
    if (mainRenderTargetView) {
        pContext->OMSetRenderTargets(0, 0, 0);
        mainRenderTargetView->Release();
        mainRenderTargetView = nullptr;
    }

    return oResizeBuffers(pSwapChain, BufferCount, Width, Height, NewFormat, SwapChainFlags);
}

bool HookKeyState() {
    HMODULE API = (HMODULE)GetModuleBase(L"win32u.dll");

    if (API != NULL)
    {
        o_getasynckeystate = (LPFN_MBA)GetProcAddress(API, "NtUserGetAsyncKeyState");
        if (o_getasynckeystate != NULL)
            return true;
        else
            return false;
    }
    return false; // win32u.dll not found — was falling off the end with no return
}

void Main() {

    InitLog("[Init] Main() starting...\n");

    moduleBase = (HMODULE) GetModuleBase(L"Paladins.exe");
    InitLog("[Init] moduleBase = 0x%p %s\n", moduleBase, moduleBase ? "(OK)" : "(FAILED - module not found!)");

    PBYTE gobject_address = GetMovAddress<PBYTE>(
        FindPattern("48 8B 05 ? ? ? ? 4C 8B 04 0A 4C 33 04 F0 44", L"Paladins.exe"));
    InitLog("[Init] gobject_address = 0x%p %s\n", gobject_address, gobject_address ? "(OK)" : "(FAILED - pattern not found, likely game was updated)");
    GObject = reinterpret_cast<decltype(GObject)>(gobject_address);
    SDK::UObject::GObjects = reinterpret_cast<SDK::TAntiCheatArray<SDK::UObject*>*>(gobject_address);

    PBYTE gname_address = GetMovAddress<PBYTE>(
        FindPattern("48 8B 05 ? ? ? ? B9 ? ? ? ? 48 8B 0C 0A 48 BA", L"Paladins.exe"));
    InitLog("[Init] gname_address = 0x%p %s\n", gname_address, gname_address ? "(OK)" : "(FAILED - pattern not found)");
    GName = gname_address;
    SDK::FName::GNames = reinterpret_cast<SDK::TAntiCheatArray<SDK::FNameEntry*>*>(gname_address);

    Globals::UEngineAddr = GetMovAddress<DWORD_PTR>(
        FindPattern("48 8B 0D ? ? ? ? 48 85 C9 0F 84 ? ? ? ? 48 39 B9 ? ? ? ?", L"Paladins.exe"));
    InitLog("[Init] UEngineAddr = 0x%p %s\n", (void*)Globals::UEngineAddr, Globals::UEngineAddr ? "(OK)" : "(FAILED - pattern not found)");

    ProcessEventOriginal = GetCallAddress<tProcessEvent>(
        FindPattern("E8 ? ? ? ? 8D 4E ? 41 3B CD", L"Paladins.exe"));
    InitLog("[Init] ProcessEventOriginal = 0x%p %s\n", (void*)ProcessEventOriginal, ProcessEventOriginal ? "(OK)" : "(FAILED - pattern not found)");

    Globals::xorFunc = GetCallAddress<void *>(
        FindPattern("E8 ? ? ? ? 85 C0 75 0F 48 8B 03", L"Paladins.exe"));
    InitLog("[Init] xorFunc = 0x%p %s\n", Globals::xorFunc, Globals::xorFunc ? "(OK)" : "(FAILED - pattern not found)");

    if (Globals::xorFunc) {
        xorKey = (uintptr_t) GetAndValue<void *>((void *) ((DWORD64) Globals::xorFunc + 0x63));
        InitLog("[Init] xorKey = 0x%p\n", (void*)xorKey);
    } else {
        InitLog("[Init] SKIPPED xorKey (xorFunc was null, would have crashed here otherwise)\n");
    }

    InitLog("[Init] HookKeyState() = %s\n", HookKeyState() ? "true" : "false");

    if (!ProcessEventOriginal) {
        InitLog("[Init] ABORTING hook attach — ProcessEventOriginal is null, DetourAttach would crash.\n");
        return;
    }

    if (DetourTransactionBegin() != NO_ERROR) { InitLog("[Init] DetourTransactionBegin FAILED\n"); return; }
    if (DetourUpdateThread(GetCurrentThread()) != NO_ERROR) { InitLog("[Init] DetourUpdateThread FAILED\n"); DetourTransactionAbort(); return; }
    DetourAttach(&(LPVOID&)ProcessEventOriginal, (PBYTE)HookedProcessEvent);
    LONG result = DetourTransactionCommit();
    InitLog("[Init] DetourTransactionCommit result = %ld %s\n", result, result == NO_ERROR ? "(OK)" : "(FAILED)");

    // CRASH FIX ("Illegal call to StaticFindObject() while serializing
    // object data or garbage collecting!"): every ::StaticClass() call is
    // cached on FIRST use (a local static pointer inside each one), but that
    // first use happens lazily, whenever a feature first actually runs — at
    // some random moment during live gameplay. If that first lookup happens
    // to land while the engine's GC is running, it's fatal (a hard engine
    // stop, not a catchable access violation — SEH can't help here). Fixed by
    // forcing every one we use to resolve HERE, right at injection, before
    // you're ever in a match and long before any GC cycle could plausibly be
    // running — so none of them ever do a "cold" lookup during gameplay again.
    InitLog("[Init] Pre-warming class lookups...\n");
    SDK::ATgPawn::StaticClass();
    SDK::ATgPawn_Character::StaticClass();
    SDK::UUIHudDecks::StaticClass();
    SDK::UUIChampion::StaticClass();
    SDK::UUIRadialMenuEquip::StaticClass();
    InitLog("[Init] Pre-warming done.\n");

    InitLog("[Init] Main() finished.\n");
}

// HOOK WATCHDOG.
//
// The install itself no longer risks a deadlock (see the big comment on the
// manual hook in kiero.cpp), but nothing stops some OTHER piece of software
// from overwriting our patched bytes again LATER, well after we've already
// installed cleanly - e.g. its own periodic self-healing re-assert cycle
// simply runs again and doesn't know or care that PHAROAH's jmp is sitting
// there now. This thread just keeps checking and, if that ever happens,
// silently writes our jmp back - a plain memcpy, same as install, never a
// thread-suspending transaction, so it can't reintroduce the deadlock this
// was built to get away from.
DWORD WINAPI HookWatchdogThread(LPVOID) {
    for (;;) {
        Sleep(300);
        kiero::reassertHooks();
    }
}

bool TryBindKiero(kiero::RenderType::Enum type, const char* name) {
    kiero::Status::Enum status = kiero::init(type);
    InitLog("[Init]   %-8s -> status=%d %s\n", name, (int)status, status == kiero::Status::Success ? "SUCCESS" : "");
    if (status == kiero::Status::Success) {
        kiero::bind(8, (void**)&oPresent, hkPresent);
        kiero::bind(13, (void**)&oResizeBuffers, hkResizeBuffers);
        InitLog("[Init]   kiero::bind done for %s. Overlay should render on next Present.\n", name);

        // Also cover flip-model swapchains that call Present1 instead of
        // Present - see the big comment above hkPresent1 for the full story.
        // Slot 205 only exists in the D3D11 methods table (kiero.cpp), and is
        // left at 0 there if this system's DXGI runtime couldn't hand back an
        // IDXGISwapChain1 interface, in which case bind() harmlessly fails
        // here rather than hooking anything bogus.
        if (type == kiero::RenderType::D3D11) {
            kiero::Status::Enum p1status = kiero::bind(205, &oPresent1Unused, hkPresent1);
            InitLog("[Init]   Present1 (flip-model) hook: %s\n",
                   p1status == kiero::Status::Success ? "bound OK - covers flip-model swapchains too"
                                                       : "not available on this system (classic Present hook above still covers the normal case)");
            // Diagnostic for the "resolved address never actually gets called"
            // theory - see FindRealGameWindow in kiero.cpp. If this says YES
            // and hkPresent still never fires, that theory is dead and we
            // need a different one; if it says NO (no suitable window found),
            // that's the next thing to fix before this test is even valid.
            InitLog("[Init]   D3D11 dummy device used the REAL game window: %s",
                    kiero::usedRealWindowForDummyDevice() ? "YES" : "no (fell back to kiero's own throwaway window)");
        }
        CreateThread(nullptr, 0, HookWatchdogThread, nullptr, 0, nullptr);
        return true;
    }
    return false;
}

void InitKiero() {
    // Loop the DLL check + every render type for up to ~60 seconds, in case
    // injection happened before the game finished creating its graphics device
    // (e.g. injected during a loading screen rather than once already in-match).
    for (int round = 0; round < 120; round++) {
        if (round % 10 == 0) {
            InitLog("[Init] --- round %d: graphics DLLs currently loaded ---\n", round);
            InitLog("[Init] d3d9.dll=%s d3d10.dll=%s d3d11.dll=%s d3d12.dll=%s dxgi.dll=%s opengl32.dll=%s\n",
                GetModuleHandleA("d3d9.dll") ? "YES" : "no",
                GetModuleHandleA("d3d10.dll") ? "YES" : "no",
                GetModuleHandleA("d3d11.dll") ? "YES" : "no",
                GetModuleHandleA("d3d12.dll") ? "YES" : "no",
                GetModuleHandleA("dxgi.dll") ? "YES" : "no",
                GetModuleHandleA("opengl32.dll") ? "YES" : "no");

            InitLog("[Init] --- trying every kiero RenderType directly ---\n");
            if (TryBindKiero(kiero::RenderType::D3D9,  "D3D9"))  return;
            if (TryBindKiero(kiero::RenderType::D3D10, "D3D10")) return;
            if (TryBindKiero(kiero::RenderType::D3D11, "D3D11")) return;
            if (TryBindKiero(kiero::RenderType::D3D12, "D3D12")) return;
        }
        Sleep(500);
    }

    InitLog("[Init] GAVE UP after ~60 seconds. None of D3D9/10/11/12 succeeded via kiero.\n");
    InitLog("[Init] This means either: (a) none of those DLLs were ever loaded in this process,\n");
    InitLog("[Init] or (b) kiero's hook-point signatures don't match this game's actual build.\n");
    InitLog("[Init] Send this whole log back — the DLL-loaded lines above are the key diagnostic.\n");
}

// ============================================================================
// INIT LOG  —  so a crash on inject is not a silent one
// ============================================================================
// AllocConsole gives a console, but it dies with the game: when the DLL takes
// the process down during startup there is nothing left to read, which is why
// "it just crashed, no message" was all we had to go on.
//
// This writes the same milestones to PHAROAH_init.log next to the game exe,
// flushing after every line. The file survives the crash, so the LAST line
// tells you exactly which stage died.
static void InitLog(const char* fmt, ...) {
    char msg[512];
    va_list ap;
    va_start(ap, fmt);
    _vsnprintf_s(msg, sizeof(msg), _TRUNCATE, fmt, ap);
    va_end(ap);

    // console (may not exist yet, harmless)
    printf("%s\n", msg);

    FILE* lf = nullptr;
    if (fopen_s(&lf, "PHAROAH_init.log", "a") == 0 && lf) {
        SYSTEMTIME st; GetLocalTime(&st);
        fprintf(lf, "[%02d:%02d:%02d.%03d] %s\n",
                st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, msg);
        fflush(lf);          // flush every line - a crash must not lose it
        fclose(lf);
    }
}

// ============================================================================
// KNOWN OVERLAY MODULE SCAN
// ============================================================================
// A second, independent real-world cause of "kiero::bind reports SUCCESS but
// hkPresent never fires": another program already has ITS OWN Present hook
// installed in this same process (Steam overlay, GeForce Experience/
// ShadowPlay, RTSS/MSI Afterburner, Discord overlay, Xbox Game Bar, etc - all
// of these commonly auto-inject into every D3D11 game, whether or not you
// ever open them). If one of them hooks Present AFTER us, or re-patches the
// vtable after we already patched it, our hook can end up silently replaced
// - kiero has no way to detect that, since patching a vtable slot never
// "fails" just because something else touches it again afterward.
//
// This can't be fixed generically (we'd have to specifically chain-detect and
// cooperate with each one), but it CAN be diagnosed for free: just list which
// of these well-known overlay-hook DLLs are already loaded in this process at
// injection time. That turns "ask the user to disable things one at a time
// and retest" into "read one log line."
static void LogKnownOverlayModules() {
    struct KnownModule { const wchar_t* name; const char* owner; };
    static const KnownModule known[] = {
        { L"gameoverlayrenderer64.dll", "Steam overlay" },
        { L"rtsshooks64.dll",           "RTSS / MSI Afterburner" },
        { L"nvspcap64.dll",             "NVIDIA ShadowPlay / GeForce Experience" },
        { L"nvSCPAPI64.dll",            "NVIDIA overlay API" },
        { L"discordhook64.dll",         "Discord overlay" },
        { L"discord_hook64.dll",        "Discord overlay" },
        { L"gamebaroverlay.dll",        "Xbox Game Bar" },
        { L"asushookinput64.dll",       "ASUS Aura/Armoury overlay" },
    };

    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, GetCurrentProcessId());
    if (snap == INVALID_HANDLE_VALUE) {
        InitLog("[Init] Overlay module scan: could not snapshot modules (non-fatal).");
        return;
    }

    bool foundAny = false;
    MODULEENTRY32W me{};
    me.dwSize = sizeof(me);
    if (Module32FirstW(snap, &me)) {
        do {
            for (const auto& k : known) {
                if (_wcsicmp(me.szModule, k.name) == 0) {
                    InitLog("[Init] Overlay module scan: FOUND %ls (%s) already loaded in this process - "
                            "it has its own Present hook and can silently override ours. If the menu/F9 "
                            "still fail after this build, try disabling this specific overlay and re-testing.",
                            me.szModule, k.owner);
                    foundAny = true;
                }
            }
        } while (Module32NextW(snap, &me));
    }
    CloseHandle(snap);

    if (!foundAny) {
        InitLog("[Init] Overlay module scan: none of the known overlay-hook DLLs are loaded. "
                "Not ruling this class of conflict out entirely (the list above isn't exhaustive), "
                "but nothing obvious found.");
    }
}

// ============================================================================
// VBS / HVCI CHECK
// ============================================================================
// Every failing report so far has been Windows PRO. Pro (unlike Home) commonly
// runs Virtualization-Based Security with Memory Integrity (HVCI) either by
// IT policy on a work machine or turned on directly in Windows Security ->
// Device security -> Core isolation. HVCI is a well-documented real-world
// cause of exactly this symptom: an inline hook (like kiero's old MinHook
// based Present hook) can install without any reported error yet never
// actually redirect execution, because HVCI enforces which code pages are
// allowed to run. Plain registry read, no COM, nothing that can hang or
// conflict with anything else on this thread.
static void LogVbsHvciStatus() {
    DWORD vbs = 0, hvci = 0, size = sizeof(DWORD);
    RegGetValueW(HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\DeviceGuard",
                 L"EnableVirtualizationBasedSecurity", RRF_RT_REG_DWORD, nullptr, &vbs, &size);
    size = sizeof(DWORD);
    RegGetValueW(HKEY_LOCAL_MACHINE,
                 L"SYSTEM\\CurrentControlSet\\Control\\DeviceGuard\\Scenarios\\HypervisorEnforcedCodeIntegrity",
                 L"Enabled", RRF_RT_REG_DWORD, nullptr, &hvci, &size);
    InitLog("[Init] VBS/HVCI check: VirtualizationBasedSecurity=%lu, HVCI/MemoryIntegrity=%lu%s",
            vbs, hvci,
            hvci ? " - Memory Integrity is ON, a known cause of silent inline-hook failures" : "");
}

// ============================================================================
// CRASH HANDLER — so a crash is a log line, not nothing
// ============================================================================
// A real crash just happened in the wild (hkResizeBuffers) and the ONLY
// reason it was diagnosable at all is that the user happened to have a
// debugger/crash tool attached and could read a stack frame off it by hand.
// Most testers do not have that. Without this handler, a future crash on
// someone else's machine produces nothing but "it crashed" - no address, no
// faulting module, no way to tell PHAROAH's code from the game's own code,
// nothing to go on at all.
//
// This logs, for any unhandled exception anywhere in the process:
//   - the exception code (access violation, stack overflow, etc.) and
//     whether it was a read or write fault
//   - the faulting address, AND its offset from PHAROAH.dll's own base if
//     the crash was inside this DLL (module-relative offsets survive ASLR
//     and can be matched back to a specific line with the matching build's
//     .pdb, whereas a raw address by itself is useless once the DLL loads
//     at a different base next time)
//   - the first several return addresses on the stack (CaptureStackBackTrace
//     - no symbol server needed, just raw addresses, same ASLR-survivable
//     module+offset idea applies to each one)
// Then lets the exception continue exactly as before (EXCEPTION_CONTINUE_
// SEARCH) - this only ever adds a log line, it never changes whether or how
// the process crashes.
static LONG WINAPI PharoahCrashHandler(EXCEPTION_POINTERS* ep) {
    if (!ep || !ep->ExceptionRecord) return EXCEPTION_CONTINUE_SEARCH;

    DWORD code = ep->ExceptionRecord->ExceptionCode;
    void* addr = ep->ExceptionRecord->ExceptionAddress;

    HMODULE self = nullptr;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
                        (LPCWSTR)&PharoahCrashHandler, &self);

    char moduleInfo[160] = "outside PHAROAH.dll (likely the game or another module - not our code)";
    if (self) {
        MODULEINFO mi{};
        if (K32GetModuleInformation(GetCurrentProcess(), self, &mi, sizeof(mi))) {
            uintptr_t base = (uintptr_t)mi.lpBaseOfDll;
            uintptr_t a = (uintptr_t)addr;
            if (a >= base && a < base + mi.SizeOfImage) {
                wsprintfA(moduleInfo, "INSIDE PHAROAH.dll at offset 0x%llX", (unsigned long long)(a - base));
            }
        }
    }

    const char* accessType = "unknown";
    if (code == EXCEPTION_ACCESS_VIOLATION && ep->ExceptionRecord->NumberParameters >= 1) {
        accessType = ep->ExceptionRecord->ExceptionInformation[0] == 1 ? "WRITE" :
                     ep->ExceptionRecord->ExceptionInformation[0] == 8 ? "DEP/execute" : "READ";
    }

    InitLog("[CRASH] ==== UNHANDLED EXCEPTION ====");
    InitLog("[CRASH] code=0x%08lX (%s) at address 0x%p - %s",
            code,
            code == EXCEPTION_ACCESS_VIOLATION ? "ACCESS_VIOLATION" :
            code == EXCEPTION_STACK_OVERFLOW ? "STACK_OVERFLOW" :
            code == EXCEPTION_ILLEGAL_INSTRUCTION ? "ILLEGAL_INSTRUCTION" : "other",
            addr, moduleInfo);
    if (code == EXCEPTION_ACCESS_VIOLATION) {
        InitLog("[CRASH] access type: %s", accessType);
    }

    void* frames[16] = {};
    USHORT n = CaptureStackBackTrace(0, 16, frames, nullptr);
    for (USHORT i = 0; i < n; i++) {
        uintptr_t a = (uintptr_t)frames[i];
        if (self) {
            MODULEINFO mi{};
            if (K32GetModuleInformation(GetCurrentProcess(), self, &mi, sizeof(mi))) {
                uintptr_t base = (uintptr_t)mi.lpBaseOfDll;
                if (a >= base && a < base + mi.SizeOfImage) {
                    InitLog("[CRASH]   frame %d: PHAROAH.dll+0x%llX", i, (unsigned long long)(a - base));
                    continue;
                }
            }
        }
        InitLog("[CRASH]   frame %d: 0x%p (outside PHAROAH.dll)", i, frames[i]);
    }
    InitLog("[CRASH] ==== end of crash report - send this whole log back ====");

    return EXCEPTION_CONTINUE_SEARCH;
}

// ============================================================================
// SYSTEM INFO — logged once so a report is self-contained, no separate
// "what are your specs" round trip needed.
// ============================================================================
static void LogSystemInfo() {
    // True OS build number - GetVersionEx/VerifyVersionInfo both lie on
    // modern Windows unless the exe carries a matching manifest, which this
    // DLL does not. RtlGetVersion (ntdll) is the one API that still tells
    // the truth regardless of manifest.
    typedef LONG(WINAPI* RtlGetVersionFn)(PRTL_OSVERSIONINFOW);
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (ntdll) {
        auto fn = (RtlGetVersionFn)GetProcAddress(ntdll, "RtlGetVersion");
        if (fn) {
            RTL_OSVERSIONINFOW vi{};
            vi.dwOSVersionInfoSize = sizeof(vi);
            if (fn(&vi) == 0) {
                InitLog("[Init] OS: Windows %lu.%lu build %lu", vi.dwMajorVersion, vi.dwMinorVersion, vi.dwBuildNumber);
            }
        }
    }

    char cpuName[256] = {0};
    DWORD cpuNameSize = sizeof(cpuName);
    RegGetValueA(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0",
                 "ProcessorNameString", RRF_RT_REG_SZ, nullptr, cpuName, &cpuNameSize);
    if (cpuName[0]) InitLog("[Init] CPU: %s", cpuName);

    SYSTEM_INFO si{};
    GetNativeSystemInfo(&si);
    InitLog("[Init] Logical processors: %lu", si.dwNumberOfProcessors);
}

// ============================================================================
// FULL LOADED-MODULE DUMP
// ============================================================================
// LogKnownOverlayModules only flags names already on our suspect list. If a
// future report turns out to be caused by something NOT on that list, this
// is the difference between "we have no idea what else was loaded" and
// "here's the full list, go look" - no second round trip needed to ask for
// it. Kept separate from the known-overlay scan (which stays short and
// readable) since this one can run to 100+ lines.
static void LogAllLoadedModules() {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, GetCurrentProcessId());
    if (snap == INVALID_HANDLE_VALUE) return;

    InitLog("[Init] --- full loaded-module list (for cross-checking against anything not on the known-overlay list above) ---");
    MODULEENTRY32W me{};
    me.dwSize = sizeof(me);
    std::string line;
    int count = 0;
    if (Module32FirstW(snap, &me)) {
        do {
            char narrow[128] = {0};
            WideCharToMultiByte(CP_ACP, 0, me.szModule, -1, narrow, sizeof(narrow), nullptr, nullptr);
            line += narrow;
            line += ", ";
            count++;
            if (line.size() > 400) { InitLog("[Init]   %s", line.c_str()); line.clear(); }
        } while (Module32NextW(snap, &me));
    }
    if (!line.empty()) InitLog("[Init]   %s", line.c_str());
    InitLog("[Init] --- %d modules total ---", count);
    CloseHandle(snap);
}

// ============================================================================
// RHI PROBE - root-cause investigation, not a fix yet.
// ============================================================================
// EVERY render-hook fix tried so far (Present1, manual hook, freeze-safe
// watchdog, real-window dummy device) addressed HOW we install a hook. All
// verified correct in isolation. NONE changed the actual symptom on a
// confirmed-affected machine: hkPresent never fires. The working theory
// (see the D3D11 PROXY MODE comment below) is that kiero's core assumption -
// any throwaway D3D11 device resolves the SAME Present implementation the
// real game uses - is false on that machine, because its NVIDIA driver does
// its own presentation-pipeline interception. The proxy-DLL fix WORKS
// (verified end-to-end) but needs a file placed next to the game, which
// isn't acceptable as a general solution.
//
// This is a different way to get the REAL swapchain without either problem:
// find it from data the game ITSELF already holds, instead of guessing via
// a dummy device or intercepting the original creation call (which by
// injection time already happened, minutes ago - too late to hook).
//
// UEngine::GameViewport->Viewport (SDK: PL_Engine_classes.hpp, offset 0x0070
// of UGameViewportClient, typed FPointer - a raw native pointer UnrealScript
// reflection doesn't know the C++ type of) is UE3's FViewport* - the base
// class of the platform-specific viewport implementation. On D3D11 that's an
// FD3D11Viewport, which is NOT reflected in this SDK (FViewport is a native
// engine class, not a UObject, so SDK dumpers that only walk UObject
// reflection never see it or its members) - meaning there's no known field
// offset for its IDXGISwapChain*/ID3D11Device* members to read directly.
//
// So: don't guess the offset. WALK the object's first bytes and test each
// 8-byte slot - does it look like a live pointer, and does ITS first 8 bytes
// (a COM object's vtable pointer) point into a module we can name? A real
// IDXGISwapChain/ID3D11Device's vtable lives inside d3d11.dll, dxgi.dll, or
// (the actual suspect here) the NVIDIA driver's own D3D11 implementation
// (nvd3dumx.dll/nvwgf2umx.dll) - any hit naming one of those is a genuine
// candidate for the real swapchain, found without needing to already know
// UE3's exact FD3D11Viewport layout for this game's specific engine fork.
//
// This is a DIAGNOSTIC, not a hook. It only logs candidates. The next step,
// once a log shows which offset is real, is to actually read that pointer
// and feed it into kiero::initFromRealSwapChain() (already written, unused
// since the proxy-DLL path that used it was shelved - see kiero.h) instead
// of the dummy-device guess. Not done yet because guessing the offset
// without a real log to confirm it risks reading garbage and crashing -
// exactly the mistake this whole project has been paying for all session.
// Set by ProbeRealViewport - EVERY candidate landing outside Paladins.exe,
// not just the first. A live test proved "just take the first one" isn't
// safe to rely on: the SAME walk can reach several genuinely different
// modules (Windows' own MSCTF.dll turned up right alongside the actual
// Intel graphics driver in one run), and "first in scan order" has nothing
// to do with "actually the swapchain." PerformRHIFallbackAttempt (below)
// tries these in order, skipping any that fail pre-flight validation,
// instead of betting everything on whichever one happened to be found
// first. Read by TryBindRealRHI()/PerformRHIFallbackAttempt. Left empty
// (and everything here stays inert) on any run that finds nothing.
struct RHICandidate { void* ptr; char modName[MAX_PATH]; };
static const int kMaxRHICandidates = 16;
static RHICandidate g_RHIProbeCandidates[kMaxRHICandidates];
static int g_RHIProbeCandidateCount = 0;
// Convenience alias for anything that only ever wants "the best guess" -
// same as g_RHIProbeCandidates[0] once ranking (below) has run.
static void* g_RHIProbeCandidate = nullptr;

// Ranks a candidate's module - lower is more likely to actually be the
// swapchain. Graphics driver DLLs are the whole point of this search;
// everything else (MSCTF.dll, or anything else Windows happens to hang off
// an engine object for unrelated reasons) is presumptively irrelevant, but
// still worth trying AFTER every graphics-looking one, since "definitely
// not graphics" is a much weaker signal than "definitely not Paladins.exe"
// was to begin with.
static int RankRHIModule(const char* modName) {
    if (strstr(modName, "DriverStore")) return 0; // GPU driver package path - strongest signal there is
    if (strstr(modName, "d3d11") || strstr(modName, "dxgi") || strstr(modName, "d3d10") || strstr(modName, "d3d12")) return 0;
    if (strstr(modName, "igd") || strstr(modName, "nvd3d") || strstr(modName, "nvwgf") || strstr(modName, "nvidia") ||
        strstr(modName, "aticfx") || strstr(modName, "atidxx") || strstr(modName, "amdxx")) return 1;
    return 2; // everything else - not impossible, just no reason to try it first
}

static void ProbeRealViewport() {
    if (!Globals::Engine) {
        InitLog("[RHIProbe] Engine is null - too early, skipping this pass.");
        return;
    }
    SDK::UGameViewportClient* gvc = Globals::Engine->GameViewport;
    if (!gvc) {
        InitLog("[RHIProbe] Engine->GameViewport is null - too early, skipping this pass.");
        return;
    }

    void* viewportPtr = nullptr;
    __try {
        viewportPtr = *(void**)&gvc->Viewport; // FPointer is just an 8-byte native pointer slot
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        InitLog("[RHIProbe] Reading GameViewport->Viewport faulted (code 0x%08lX).", GetExceptionCode());
        return;
    }
    if (!viewportPtr) {
        InitLog("[RHIProbe] GameViewport->Viewport is null - too early, skipping this pass.");
        return;
    }
    char ownModulePath[MAX_PATH] = {0};
    GetModuleFileNameA(nullptr, ownModulePath, MAX_PATH);

    InitLog("[RHIProbe] FViewport* = %p - scanning for a real D3D11/DXGI COM pointer, up to 6 levels deep...", viewportPtr);

    // V2 of this scan. First pass (3 levels) found 102 candidates - EVERY
    // ONE of them still landing inside Paladins.exe itself, none reaching a
    // real driver module. Not a dead end: it means the actual
    // IDXGISwapChain*/ID3D11Device* is nested behind MORE than 3 layers of
    // engine-side wrapper objects than assumed (UE3's RHI commonly layers
    // TRefCountPtr<FRHIResource> -> concrete FD3D11-side wrapper -> the raw
    // COM pointer, and FViewport -> FD3D11Viewport -> BackBuffer -> texture
    // -> resource -> device/swapchain can easily be 4-5 hops). Two changes
    // from V1: (1) depth raised to 6, (2) dedup by VTABLE not just pointer -
    // V1's 102 hits were mostly a handful of distinct wrapper CLASSES
    // repeated across many per-resource instances (same vtable address over
    // and over). Only exploring each distinct vtable once keeps the deeper
    // scan's total work bounded instead of exploding with depth. Also
    // broadened "interesting" from a hardcoded driver-DLL name list to "any
    // module that is not Paladins.exe itself" - GPU driver DLL names vary
    // by vendor and version (Intel/NVIDIA/AMD all differ), so this machine
    // finding one that isn't in the original guess list would otherwise
    // still get missed silently.
    struct WorkItem { void* ptr; int depth; char path[80]; };
    const int kMaxItems = 4000;
    static WorkItem queue[kMaxItems]; // static: this struct array is ~340KB, too big for the thread stack
    int queueCount = 0;
    static void* visitedPtr[kMaxItems];
    int visitedPtrCount = 0;
    static void* visitedVtable[kMaxItems];
    int visitedVtableCount = 0;

    queue[queueCount++] = { viewportPtr, 0, "Viewport" };

    int hits = 0;
    int realHits = 0;
    for (int qi = 0; qi < queueCount; qi++) {
        WorkItem item = queue[qi];
        if (item.depth >= 6) continue;

        int scanBytes = (item.depth == 0) ? 0x300 : 0x180;
        for (int off = 0; off < scanBytes && queueCount < kMaxItems; off += 8) {
            void* candidate = nullptr;
            void* vtable = nullptr;
            __try {
                candidate = *(void**)((unsigned char*)item.ptr + off);
                if (!candidate) continue;
                vtable = *(void**)candidate; // a COM/virtual object's first member is its vtable pointer
                if (!vtable) continue;
            } __except (EXCEPTION_EXECUTE_HANDLER) {
                continue; // not a valid pointer at this offset - expected for most slots, not an error
            }

            HMODULE mod = nullptr;
            if (!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                                     (LPCSTR)vtable, &mod)) {
                continue; // vtable pointer doesn't land inside ANY loaded module - not a real object
            }

            bool alreadyVisitedPtr = false;
            for (int v = 0; v < visitedPtrCount; v++) { if (visitedPtr[v] == candidate) { alreadyVisitedPtr = true; break; } }
            if (alreadyVisitedPtr) continue;
            if (visitedPtrCount < kMaxItems) visitedPtr[visitedPtrCount++] = candidate;

            char modName[MAX_PATH] = {0};
            GetModuleFileNameA(mod, modName, MAX_PATH);
            bool isOwnModule = (_stricmp(modName, ownModulePath) == 0);
            bool isRealTarget = !isOwnModule;

            // Logged in full ONLY for real hits now - the first version logged
            // all ~100+ candidates every run (mostly repeated instances of a
            // handful of wrapper classes still inside Paladins.exe), which
            // made every log huge for no benefit once the walk itself was
            // already proven correct. Non-real candidates are still counted
            // (hits++) and still recursed into, just not printed one by one.
            if (isRealTarget) {
                InitLog("[RHIProbe] depth=%d path=%s+0x%03X: candidate=%p vtable=%p -> module: %s  <<<<< "
                        "REAL, OUTSIDE PALADINS.EXE - LIKELY CANDIDATE",
                        item.depth, item.path, off, candidate, vtable, modName);
            }
            hits++;
            if (isRealTarget) {
                realHits++;
                if (g_RHIProbeCandidateCount < kMaxRHICandidates) {
                    RHICandidate& rc = g_RHIProbeCandidates[g_RHIProbeCandidateCount++];
                    rc.ptr = candidate;
                    _snprintf_s(rc.modName, sizeof(rc.modName), _TRUNCATE, "%s", modName);
                }
                continue; // left the game's own code - this IS the interesting kind of hit, nothing more to find past it
            }

            // Same wrapper CLASS already explored once (same vtable) - skip
            // recursing into another instance of it. This is what makes
            // depth=6 tractable instead of exploding: V1's 102 hits at
            // depth<=3 were mostly repeats of a handful of vtables.
            bool alreadyVisitedVtable = false;
            for (int v = 0; v < visitedVtableCount; v++) { if (visitedVtable[v] == vtable) { alreadyVisitedVtable = true; break; } }
            if (alreadyVisitedVtable) continue;
            if (visitedVtableCount < kMaxItems) visitedVtable[visitedVtableCount++] = vtable;

            if (queueCount < kMaxItems) {
                WorkItem next;
                next.ptr = candidate;
                next.depth = item.depth + 1;
                _snprintf_s(next.path, sizeof(next.path), _TRUNCATE, "%s->+0x%03X", item.path, off);
                queue[queueCount++] = next;
            }
        }
    }
    // Rank so graphics-driver-looking candidates get tried FIRST - a live
    // test found Windows' own MSCTF.dll sitting right alongside the actual
    // Intel driver in the same scan, and "first found" had picked MSCTF.
    // Simple insertion sort - at most 16 entries, this runs once per
    // injection, not worth anything fancier.
    for (int i = 1; i < g_RHIProbeCandidateCount; i++) {
        RHICandidate key = g_RHIProbeCandidates[i];
        int keyRank = RankRHIModule(key.modName);
        int j = i - 1;
        while (j >= 0 && RankRHIModule(g_RHIProbeCandidates[j].modName) > keyRank) {
            g_RHIProbeCandidates[j + 1] = g_RHIProbeCandidates[j];
            j--;
        }
        g_RHIProbeCandidates[j + 1] = key;
    }
    if (g_RHIProbeCandidateCount > 0) g_RHIProbeCandidate = g_RHIProbeCandidates[0].ptr;

    InitLog("[RHIProbe] scan done - %d total candidate(s) logged, %d landing outside Paladins.exe (marked "
            "<<<<< above - that's what matters, not the count). Ranked by module (graphics driver DLLs "
            "first) - PerformRHIFallbackAttempt will try them in that order, skipping any that fail "
            "pre-flight validation, until one works or all %d are exhausted.",
            hits, realHits, g_RHIProbeCandidateCount);
}

// OPT-IN EXPERIMENT, gated behind PHAROAH_TRY_REAL_RHI.flag - see InitThread.
// Left completely untouched (and calls nothing here) unless that file exists
// next to the DLL, same convention as PHAROAH_CANVAS_ONLY.flag. Normal
// startup (no flag file) is byte-for-byte unaffected by any of this.
//
// g_RHIProbeCandidate (set by ProbeRealViewport, above) is a pointer found
// by walking real engine memory - not a device or swapchain confirmed by
// type, just an address whose vtable happens to resolve into a real
// graphics-driver DLL rather than Paladins.exe's own code. It might be the
// swapchain. It might be the device, an immediate context, or some other
// COM interface the driver hands back. kiero::initFromRealSwapChain()
// (kiero.cpp) treats whatever it's given AS an IDXGISwapChain and reads
// vtable slots 8 (Present) and 13 (ResizeBuffers) straight off it - if the
// candidate genuinely is a swapchain, those slots are correct and hooking
// them works exactly like the proxy-DLL path already proved end-to-end. If
// it's something else, those slots hold WHATEVER that other type's vtable
// has there instead - hooking a wrong function is a real risk, not a
// theoretical one, which is exactly why this only ever runs with the flag
// file present, never by default.
//
// The test itself is simple and needs no external tooling: try it, then
// watch the SAME hkPresent heartbeat log this whole project already trusts.
// If "hkPresent CALLED for the first time" appears and keeps incrementing,
// the candidate was correct. If it doesn't, no harm done - remove the flag
// file and behavior reverts to the normal dummy-device path next launch.
// Forward-declared: defined below, shared with the automatic/manual
// fallback paths. TryBindRealRHI calls it directly - at this point in
// InitThread, InitKiero() hasn't run yet, so there IS no working hook to
// tear down (kiero::unbind/shutdown are safe no-ops when nothing is
// bound), and this gets the same multi-candidate ranking + pre-flight
// validation as F6/F7/the button for free instead of duplicating it.
static void PerformRHIFallbackAttempt(const char* trigger);

static void TryBindRealRHI() {
    if (g_RHIProbeCandidateCount == 0) {
        InitLog("[RHIProbe] PHAROAH_TRY_REAL_RHI.flag present, but no candidates were found this run - "
                "falling back to the normal D3D11 init path instead.");
        InitKiero();
        return;
    }

    InitLog("[RHIProbe] PHAROAH_TRY_REAL_RHI.flag present - trying the %d candidate(s) found instead of "
            "kiero's dummy-device guess. Not falling back to the normal path automatically if this doesn't "
            "work (unlike the other test paths, kiero may already be bound here, which InitKiero() can't "
            "cleanly re-enter) - remove the flag file and relaunch for the normal guaranteed-working path.",
            g_RHIProbeCandidateCount);
    PerformRHIFallbackAttempt("PHAROAH_TRY_REAL_RHI.flag");
    CreateThread(nullptr, 0, HookWatchdogThread, nullptr, 0, nullptr);
}

// PRE-FLIGHT VALIDATION - a real, live test proved this necessary: the
// first manual trigger of this attempt tore down a WORKING hook, then
// kiero::bind() failed (status -1) on both Present and ResizeBuffers for
// the candidate, leaving NOTHING hooked - no Present hook means no ImGui
// rendering at all, which is also what draws ImGui's software cursor, and
// once rendering stopped, ImGui's io.WantCaptureMouse froze at whatever it
// last was and the WndProc click-swallow guard (main.cpp, "no clicking
// through") kept honoring that frozen answer forever after - every future
// click, including the game's own UI, silently eaten. Not a crash, but a
// real stuck state, and entirely avoidable: MH_CreateHook fails cleanly on
// a target that isn't real, executable code, which can be checked BEFORE
// ever touching the working hook, not discovered after tearing it down.
static bool IsPlausibleHookTarget(void* addr) {
    if (!addr) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (VirtualQuery(addr, &mbi, sizeof(mbi)) == 0) return false;
    if (mbi.State != MEM_COMMIT) return false;
    const DWORD execMask = PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    if (!(mbi.Protect & execMask)) return false;
    // Must belong to a loaded module, not raw/JIT memory - same check
    // ProbeRealViewport already used to find this candidate in the first
    // place, applied again here to what it would actually try to hook.
    HMODULE mod = nullptr;
    return GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                               (LPCSTR)addr, &mod) != FALSE;
}

// SHARED RETRY SEQUENCE - validates the candidate FIRST, and only tears
// down the currently-installed (working or not) Present/ResizeBuffers/
// Present1 hooks if that validation passes. Used by BOTH the automatic
// fallback thread below AND the manual "TEST RHI FALLBACK" button
// (RecoverySuite.h) - same sequence either way, just triggered differently.
// None of kiero::unbind/shutdown/initFromRealSwapChain/bind/VirtualQuery
// are scripted ProcessEvent calls - they only read/patch memory - so this
// is safe to run from any thread, same distinction this whole project
// already relies on elsewhere (raw field/memory writes vs scripted calls).
static void PerformRHIFallbackAttempt(const char* trigger) {
    if (g_RHIProbeCandidateCount == 0) {
        InitLog("[RHIProbe] %s: no real-RHI candidates were found this run - nothing to try.", trigger);
        return;
    }

    // Try each ranked candidate (graphics-driver-looking ones first - see
    // RankRHIModule) until one passes pre-flight validation. A live test
    // proved "just take the first hit found" isn't reliable - the same
    // scan can surface several genuinely unrelated modules (Windows' own
    // MSCTF.dll turned up right alongside the real Intel driver in one
    // run) - so this no longer bets everything on a single guess.
    void* chosen = nullptr;
    const char* chosenMod = nullptr;
    for (int i = 0; i < g_RHIProbeCandidateCount; i++) {
        void* candidate = g_RHIProbeCandidates[i].ptr;
        const char* modName = g_RHIProbeCandidates[i].modName;

        void* presentTarget = nullptr;
        void* resizeTarget = nullptr;
        bool readOk = true;
        __try {
            uint64_t* vtable = *(uint64_t**)candidate;
            presentTarget = (void*)vtable[8];
            resizeTarget  = (void*)vtable[13];
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            readOk = false;
            InitLog("[RHIProbe] %s: candidate %d/%d (%s) - reading its vtable faulted (code 0x%08lX), skipping.",
                    trigger, i + 1, g_RHIProbeCandidateCount, modName, GetExceptionCode());
        }
        if (!readOk) continue;

        bool presentOk = IsPlausibleHookTarget(presentTarget);
        bool resizeOk = IsPlausibleHookTarget(resizeTarget);
        if (!presentOk || !resizeOk) {
            InitLog("[RHIProbe] %s: candidate %d/%d (%s) FAILED pre-flight validation (Present valid=%d, "
                    "ResizeBuffers valid=%d) - skipping, trying the next one.",
                    trigger, i + 1, g_RHIProbeCandidateCount, modName, presentOk ? 1 : 0, resizeOk ? 1 : 0);
            continue;
        }

        InitLog("[RHIProbe] %s: candidate %d/%d (%s) passed pre-flight validation - using it.",
                trigger, i + 1, g_RHIProbeCandidateCount, modName);
        chosen = candidate;
        chosenMod = modName;
        break;
    }

    if (!chosen) {
        InitLog("[RHIProbe] %s: all %d candidate(s) failed pre-flight validation - NOT touching the working "
                "hook. Nothing usable was found this run.", trigger, g_RHIProbeCandidateCount);
        return;
    }

    kiero::unbind(8);
    kiero::unbind(13);
    kiero::unbind(205);
    kiero::shutdown();

    kiero::Status::Enum status = kiero::initFromRealSwapChain(chosen, nullptr);
    if (status != kiero::Status::Success) {
        InitLog("[RHIProbe] %s: initFromRealSwapChain failed (status=%d) for %s after validation passed - "
                "the working hook is ALREADY torn down at this point. Re-run the normal init path if the "
                "menu doesn't come back on its own.", trigger, (int)status, chosenMod);
        return;
    }
    kiero::Status::Enum presentStatus = kiero::bind(8, (void**)&oPresent, hkPresent);
    kiero::Status::Enum resizeStatus = kiero::bind(13, (void**)&oResizeBuffers, hkResizeBuffers);
    if (kiero::getRenderType() == kiero::RenderType::D3D11) {
        kiero::bind(205, &oPresent1Unused, hkPresent1);
    }
    InitLog("[RHIProbe] %s: re-bound from %s (Present=%d, ResizeBuffers=%d) - watch the next few seconds of "
            "log for 'hkPresent CALLED for the first time'.",
            trigger, chosenMod, (int)presentStatus, (int)resizeStatus);
}

// AUTOMATIC FALLBACK - no flag file, no manual step, nothing for anyone to
// do differently at all. This is what actually matters for getting this
// tested by someone who isn't going to create a specifically-named empty
// file in the right folder: inject exactly the same way as always, and if
// the normal dummy-device hook turns out to be one of the ones that never
// fires, PHAROAH tries the RHI-probe candidate itself, live, in the same
// session, and logs which one ended up working. Nothing to ask anyone to
// do beyond what they already do every time.
//
// Runs on its own thread, starts ~6 seconds after normal startup (past the
// same grace window RenderBoxesViaCanvas already waits before deciding the
// real hook is dead - see VisibilityBoxes.h) so it never fires on a machine
// where the normal hook just hasn't had its first Present yet. Checks
// EXACTLY the same g_D3D11RenderHookConfirmedWorking flag as everything
// else in this project already trusts for that distinction. On a working
// machine (the overwhelming majority, including every dev machine that's
// tested this so far) this thread wakes up once, sees the flag already
// true, and does nothing else ever - zero behavior change there.
DWORD WINAPI RHIAutoFallbackThread(LPVOID) {
    Sleep(6000);
    if (g_D3D11RenderHookConfirmedWorking) return 0; // normal hook is fine - nothing to do, ever
    PerformRHIFallbackAttempt("auto-fallback (6s, hook was silent)");
    return 0;
}

// MANUAL TEST BUTTON - "TEST RHI FALLBACK" in the real menu (RecoverySuite.h,
// next to POTATO MODE). Lets someone with a WORKING D3D11 hook force the
// same retry the auto-fallback only ever runs when the hook is silent - so
// the mechanism itself can be verified without depending on a second
// person's broken machine at all. Real risk, stated plainly where the
// button is: this REPLACES the hook that's currently working. If the
// candidate is wrong, the menu goes silent exactly like a genuinely broken
// machine (same as normal - kiero::bind never raises, a wrong target either
// never gets called or, worse, IS called for something unrelated and takes
// the game down when hkPresent tries to treat its arguments as a swapchain).
// That's a real, not theoretical, risk - which is exactly the point of
// testing it deliberately, on a machine already known to have SOMETHING
// working, rather than only ever finding out on Spider's.
DWORD WINAPI ManualRHITestThread(LPVOID) {
    PerformRHIFallbackAttempt("manual test button");
    return 0;
}

DWORD WINAPI InitThread(LPVOID lpParam) {
    SetUnhandledExceptionFilter(PharoahCrashHandler);
    AllocConsole();
    FILE* f;
    freopen_s(&f, "CONOUT$", "w", stdout);
    freopen_s(&f, "CONOUT$", "w", stderr);

    // Start a fresh log each injection, so what you read is THIS run.
    { FILE* lf = nullptr; if (fopen_s(&lf, "PHAROAH_init.log", "w") == 0 && lf) fclose(lf); }

    InitLog("[Init] ==== PHAROAH injected, InitThread running ====");
    InitLog("[Init] build: " __DATE__ " " __TIME__);

    LogSystemInfo();
    LogKnownOverlayModules();
    LogVbsHvciStatus();
    LogAllLoadedModules();

    InitLog("[Init] stage 1/3: Main() - SDK init, ProcessEvent detour");
    Main();
    InitLog("[Init] stage 2/3: Main() returned OK");

    // Root-cause D3D11 investigation - see the big comment on ProbeRealViewport.
    // Runs BEFORE InitKiero() and doesn't touch it - purely diagnostic, logs
    // candidates, changes nothing about how the real hook is installed yet.
    Globals::initObjects(); // just needs the Engine assignment at its top - the false return (no match yet) doesn't matter here
    ProbeRealViewport();

    // CANVAS-ONLY TEST MODE. If a file named PHAROAH_CANVAS_ONLY.flag exists
    // next to the DLL, the D3D11 render hook is skipped ENTIRELY - meaning
    // the ImGui menu/walls will not appear, on purpose, even on a machine
    // where they normally would. This exists purely to get an unambiguous
    // answer to "did the new Canvas box system actually draw that, or did
    // the old D3D11 path do it anyway?" - on a machine where the D3D11 hook
    // already works, seeing boxes proves nothing on its own, since either
    // path could be responsible. With the D3D11 hook forced off, ANY box
    // that still appears can only have come from RenderBoxesViaCanvas - a
    // clean, isolated test, no log-reading required to trust the result.
    // Delete the file (or don't create it) for completely normal operation.
    if (GetFileAttributesA("PHAROAH_CANVAS_ONLY.flag") != INVALID_FILE_ATTRIBUTES) {
        InitLog("[Init] PHAROAH_CANVAS_ONLY.flag found - SKIPPING the D3D11 render hook entirely on purpose.");
        InitLog("[Init] Menu/walls-via-ImGui will NOT appear. Only Canvas-drawn enemy boxes (if any) are real now.");
        InitLog("[Init] ==== setup complete (Canvas-only test mode - D3D11 hook intentionally skipped) ====");
    } else if (GetFileAttributesA("PHAROAH_TRY_REAL_RHI.flag") != INVALID_FILE_ATTRIBUTES) {
        // OPT-IN EXPERIMENT - see the big comment on TryBindRealRHI above.
        // Same flag-file convention as PHAROAH_CANVAS_ONLY.flag: create the
        // file, this branch runs instead of the normal one; delete it (or
        // never create it) and nothing here ever executes.
        InitLog("[Init] stage 3/3: TryBindRealRHI() - experimental real-swapchain bind");
        TryBindRealRHI();
        InitLog("[Init] ==== setup complete (real-RHI experiment) ====");
    } else {
        InitLog("[Init] stage 3/3: InitKiero() - D3D11 Present hook");
        InitKiero();
        InitLog("[Init] ==== setup complete, everything hooked ====");
        // Automatic fallback to the RHI-probe candidate if the normal hook
        // turns out to be silent - see the big comment on
        // RHIAutoFallbackThread. No flag file, no extra step, runs on every
        // normal injection; does nothing at all on a machine where the
        // normal hook already works (the common case).
        CreateThread(nullptr, 0, RHIAutoFallbackThread, nullptr, 0, nullptr);
    }
    return 0;
}

// EJECT CRASH FIX: there was no DLL_PROCESS_DETACH handling at all before —
// the ProcessEvent Detour and the kiero Present/ResizeBuffers hooks stayed
// installed, redirecting into this DLL's code, even after the DLL's pages
// were unmapped on unload. The next Present() or scripted function call then
// jumped into freed memory — instant, silent access violation, no dialog.
// Fix: remove every hook before the module actually unloads.
void UnhookEverything() {
    if (ProcessEventOriginal) {
        DetourTransactionBegin();
        DetourUpdateThread(GetCurrentThread());
        DetourDetach(&(LPVOID&)ProcessEventOriginal, (PBYTE)HookedProcessEvent);
        DetourTransactionCommit();
    }
    kiero::unbind(8);   // Present
    kiero::unbind(13);  // ResizeBuffers
    kiero::unbind(205); // Present1 (flip-model) - no-op if it was never bound
    kiero::shutdown();
}

// ============================================================================
// D3D11 PROXY MODE
// ============================================================================
// WHY THIS EXISTS - every render-hook fix so far (Present1, the manual hook,
// the freeze-safe watchdog, even using the REAL game window for the dummy
// device) addressed HOW we install a hook. All of them were verified working
// correctly in isolation. NONE of them changed the actual symptom on the one
// real machine we have full diagnostics for: hkPresent still never fires,
// not once, even using the real window. That only makes sense if kiero's
// core assumption - any throwaway D3D11 device resolves the SAME Present
// implementation the real game uses - is simply false there, because that
// machine's NVIDIA driver (nvd3dumx.dll IS NVIDIA's own D3D11 driver, not
// Microsoft's) does its own interception of the presentation pipeline.
//
// The fix: stop guessing at the address entirely. Catch the REAL swapchain
// the instant the game creates it. This works by loading PHAROAH as a
// disguised d3d11.dll placed next to Paladins.exe (same technique ReShade
// uses at massive scale, reliably, alongside Steam/NVIDIA overlays). Every
// real export d3d11.dll has gets forwarded straight through to the genuine
// system DLL so the game behaves completely normally - except
// D3D11CreateDeviceAndSwapChain, which we let through to the real
// implementation FIRST, then read the vtable of the swapchain OBJECT IT
// ACTUALLY RETURNED. That object is correct by construction - not a guess,
// literally the one the game is about to call Present on.
//
// SETUP (one-time, replaces manual injection entirely once done):
//   1. Copy the user's own C:\Windows\System32\d3d11.dll to
//      <Paladins folder>\d3d11_pharoah_original.dll (so forwarding always
//      matches their exact Windows/driver version, never a bundled one that
//      could go stale).
//   2. Copy PHAROAH.dll itself to <Paladins folder>\d3d11.dll.
//   3. Fully close and relaunch Paladins once - proxy loading only works at
//      process START, not on an already-running process. From then on it
//      loads automatically every session, no injector needed at all.
//
// The classic late-injection path (InitThread via DllMain) is UNCHANGED and
// still works exactly as before if someone loads this DLL under any other
// name - this is purely additive. Mode is detected automatically from which
// name the OS resolved us as; nothing here can break the existing workflow.

static bool g_pharoahAlreadyStarted = false; // guards double-init between the two paths

struct ProxyStartupParams { void* realSwapChain; void* realSwapChain1; };

DWORD WINAPI ProxyModeInitThread(LPVOID lpParam) {
    ProxyStartupParams* params = (ProxyStartupParams*)lpParam;
    void* realSwapChain = params->realSwapChain;
    void* realSwapChain1 = params->realSwapChain1;
    delete params;

    if (g_pharoahAlreadyStarted) return 0; // only ever act on the first real swapchain created
    g_pharoahAlreadyStarted = true;

    SetUnhandledExceptionFilter(PharoahCrashHandler);
    AllocConsole();
    FILE* f;
    freopen_s(&f, "CONOUT$", "w", stdout);
    freopen_s(&f, "CONOUT$", "w", stderr);
    { FILE* lf = nullptr; if (fopen_s(&lf, "PHAROAH_init.log", "w") == 0 && lf) fclose(lf); }

    InitLog("[Init] ==== PHAROAH loaded as a D3D11 PROXY DLL, InitThread running ====");
    InitLog("[Init] (real swapchain captured directly at creation time - no dummy-device guessing)");
    InitLog("[Init] build: " __DATE__ " " __TIME__);

    LogSystemInfo();
    LogKnownOverlayModules();
    LogVbsHvciStatus();
    LogAllLoadedModules();

    InitLog("[Init] stage 1/3: Main() - SDK init, ProcessEvent detour");
    Main();
    InitLog("[Init] stage 2/3: Main() returned OK");

    InitLog("[Init] stage 3/3: kiero::initFromRealSwapChain() - D3D11 Present hook from the REAL swapchain");
    kiero::Status::Enum status = kiero::initFromRealSwapChain(realSwapChain, realSwapChain1);
    InitLog("[Init]   initFromRealSwapChain -> status=%d %s", (int)status, status == kiero::Status::Success ? "SUCCESS" : "");
    if (status == kiero::Status::Success) {
        kiero::bind(8, (void**)&oPresent, hkPresent);
        kiero::bind(13, (void**)&oResizeBuffers, hkResizeBuffers);
        InitLog("[Init]   kiero::bind done from the real swapchain. Overlay should render on next Present.");
        if (realSwapChain1) {
            kiero::Status::Enum p1status = kiero::bind(205, &oPresent1Unused, hkPresent1);
            InitLog("[Init]   Present1 (flip-model) hook from real swapchain: %s",
                    p1status == kiero::Status::Success ? "bound OK" : "not available (real object has no IDXGISwapChain1)");
        }
        CreateThread(nullptr, 0, HookWatchdogThread, nullptr, 0, nullptr);
    }

    InitLog("[Init] ==== setup complete, everything hooked (proxy mode) ====");
    return 0;
}

typedef HRESULT(WINAPI* D3D11CreateDeviceAndSwapChain_t)(
    IDXGIAdapter*, D3D_DRIVER_TYPE, HMODULE, UINT,
    const D3D_FEATURE_LEVEL*, UINT, UINT,
    const DXGI_SWAP_CHAIN_DESC*, IDXGISwapChain**,
    ID3D11Device**, D3D_FEATURE_LEVEL*, ID3D11DeviceContext**);
typedef HRESULT(WINAPI* D3D11CreateDevice_t)(
    IDXGIAdapter*, D3D_DRIVER_TYPE, HMODULE, UINT,
    const D3D_FEATURE_LEVEL*, UINT, UINT,
    ID3D11Device**, D3D_FEATURE_LEVEL*, ID3D11DeviceContext**);

static HMODULE g_realD3D11 = nullptr;
static D3D11CreateDeviceAndSwapChain_t g_realCreateDeviceAndSwapChain = nullptr;
static D3D11CreateDevice_t g_realCreateDevice = nullptr;

// Loads the user's OWN real system d3d11.dll by absolute path - bypasses
// normal DLL search order entirely (which would just find this same proxy
// again, since it sits in the game folder that takes priority), and always
// matches their exact Windows/driver version rather than anything bundled.
static void EnsureRealD3D11Loaded() {
    if (g_realD3D11) return;
    wchar_t sysDir[MAX_PATH];
    GetSystemDirectoryW(sysDir, MAX_PATH);
    std::wstring path = std::wstring(sysDir) + L"\\d3d11.dll";
    g_realD3D11 = LoadLibraryW(path.c_str());
    if (g_realD3D11) {
        g_realCreateDeviceAndSwapChain = (D3D11CreateDeviceAndSwapChain_t)GetProcAddress(g_realD3D11, "D3D11CreateDeviceAndSwapChain");
        g_realCreateDevice = (D3D11CreateDevice_t)GetProcAddress(g_realD3D11, "D3D11CreateDevice");
    }
}

// SEPARATE-CALL CREATION PATTERN.
//
// D3D11CreateDeviceAndSwapChain is ONE common way games create their render
// target, but plenty of modern D3D11 titles (anything wanting explicit
// control over flip-model swapchains, multi-adapter setups, etc.) instead
// call D3D11CreateDevice (device only) and THEN IDXGIFactory2::
// CreateSwapChainForHwnd (or the older IDXGIFactory::CreateSwapChain)
// separately. Whether Paladins/UE3 uses the combined call or this
// two-step pattern isn't something that can be confirmed without their
// binary - so both paths are covered. Any app creating a D3D11 device at
// all, by EITHER pattern, must call D3D11CreateDevice or
// D3D11CreateDeviceAndSwapChain to get one - both already routed through
// this proxy - so hooking the swapchain-creation methods on the resulting
// device's OWN DXGI factory from inside those two entry points catches the
// separate-call pattern too, entirely within this same proxy, no second
// dxgi.dll proxy needed.
typedef HRESULT(STDMETHODCALLTYPE* CreateSwapChain_t)(IDXGIFactory*, IUnknown*, DXGI_SWAP_CHAIN_DESC*, IDXGISwapChain**);
typedef HRESULT(STDMETHODCALLTYPE* CreateSwapChainForHwnd_t)(IDXGIFactory2*, IUnknown*, HWND, const DXGI_SWAP_CHAIN_DESC1*, const DXGI_SWAP_CHAIN_FULLSCREEN_DESC*, IDXGIOutput*, IDXGISwapChain1**);

static CreateSwapChain_t oCreateSwapChain = nullptr;
static CreateSwapChainForHwnd_t oCreateSwapChainForHwnd = nullptr;
static bool g_factoryHooked = false; // only ever needs hooking once - factories are effectively per-adapter singletons

static void StartProxyFromRealSwapChain(IDXGISwapChain* realSwapChain) {
    if (g_pharoahAlreadyStarted) return;
    IDXGISwapChain1* swapChain1 = nullptr;
    realSwapChain->QueryInterface(__uuidof(IDXGISwapChain1), (void**)&swapChain1);
    ProxyStartupParams* params = new ProxyStartupParams();
    params->realSwapChain = realSwapChain;
    params->realSwapChain1 = swapChain1; // not released - read once, synchronously, before anything else touches it
    CreateThread(nullptr, 0, ProxyModeInitThread, params, 0, nullptr);
}

HRESULT STDMETHODCALLTYPE hkCreateSwapChain(IDXGIFactory* self, IUnknown* pDevice, DXGI_SWAP_CHAIN_DESC* pDesc, IDXGISwapChain** ppSwapChain) {
    HRESULT hr = oCreateSwapChain(self, pDevice, pDesc, ppSwapChain);
    if (SUCCEEDED(hr) && ppSwapChain && *ppSwapChain) StartProxyFromRealSwapChain(*ppSwapChain);
    return hr;
}

HRESULT STDMETHODCALLTYPE hkCreateSwapChainForHwnd(IDXGIFactory2* self, IUnknown* pDevice, HWND hWnd, const DXGI_SWAP_CHAIN_DESC1* pDesc, const DXGI_SWAP_CHAIN_FULLSCREEN_DESC* pFullscreenDesc, IDXGIOutput* pRestrictToOutput, IDXGISwapChain1** ppSwapChain) {
    HRESULT hr = oCreateSwapChainForHwnd(self, pDevice, hWnd, pDesc, pFullscreenDesc, pRestrictToOutput, ppSwapChain);
    if (SUCCEEDED(hr) && ppSwapChain && *ppSwapChain) StartProxyFromRealSwapChain(*ppSwapChain);
    return hr;
}

// Called right after a real device is created (either proxy entry point) -
// walks device -> IDXGIDevice -> IDXGIAdapter -> IDXGIFactory2 and hooks
// CreateSwapChain (IDXGIFactory, vtable slot 10) and CreateSwapChainForHwnd
// (IDXGIFactory2, vtable slot 15) via the same non-thread-suspending
// MinHook approach as the render hook itself (MH_CreateHook + the
// MH_EnableHookNoFreeze added for exactly this project - see kiero.cpp).
static void HookFactoryFromDevice(ID3D11Device* device) {
    if (g_factoryHooked || !device) return;

    MH_Initialize(); // idempotent - may not have run yet if this fires before kiero::initFromRealSwapChain does

    IDXGIDevice* dxgiDevice = nullptr;
    if (FAILED(device->QueryInterface(__uuidof(IDXGIDevice), (void**)&dxgiDevice)) || !dxgiDevice) return;
    IDXGIAdapter* adapter = nullptr;
    HRESULT hrAdapter = dxgiDevice->GetAdapter(&adapter);
    dxgiDevice->Release();
    if (FAILED(hrAdapter) || !adapter) return;
    IDXGIFactory2* factory = nullptr;
    HRESULT hrFactory = adapter->GetParent(__uuidof(IDXGIFactory2), (void**)&factory);
    adapter->Release();
    if (FAILED(hrFactory) || !factory) return;

    void** vtbl = *(void***)factory;
    if (MH_CreateHook(vtbl[10], (void*)hkCreateSwapChain, (void**)&oCreateSwapChain) == MH_OK) {
        MH_EnableHookNoFreeze(vtbl[10]);
    }
    if (MH_CreateHook(vtbl[15], (void*)hkCreateSwapChainForHwnd, (void**)&oCreateSwapChainForHwnd) == MH_OK) {
        MH_EnableHookNoFreeze(vtbl[15]);
    }
    g_factoryHooked = true;
    factory->Release();
}

// Named differently from the real API on purpose - d3d11.h already declares
// D3D11CreateDeviceAndSwapChain/D3D11CreateDevice as dllimport (since this
// same file consumes them normally for the classic-mode dummy device path
// in kiero.cpp), and redeclaring the same names as dllexport is a hard
// linkage conflict. Exported under the REAL names via the linker pragmas
// below instead, which sidesteps the header collision entirely.
extern "C" __declspec(dllexport) HRESULT WINAPI PharoahD3D11CreateDeviceAndSwapChain(
    IDXGIAdapter* pAdapter, D3D_DRIVER_TYPE DriverType, HMODULE Software, UINT Flags,
    const D3D_FEATURE_LEVEL* pFeatureLevels, UINT FeatureLevels, UINT SDKVersion,
    const DXGI_SWAP_CHAIN_DESC* pSwapChainDesc, IDXGISwapChain** ppSwapChain,
    ID3D11Device** ppDevice, D3D_FEATURE_LEVEL* pFeatureLevel, ID3D11DeviceContext** ppImmediateContext)
{
    EnsureRealD3D11Loaded();
    if (!g_realCreateDeviceAndSwapChain) return E_FAIL; // should never happen - if it does, nothing we can safely do

    HRESULT hr = g_realCreateDeviceAndSwapChain(pAdapter, DriverType, Software, Flags,
        pFeatureLevels, FeatureLevels, SDKVersion, pSwapChainDesc, ppSwapChain,
        ppDevice, pFeatureLevel, ppImmediateContext);

    if (SUCCEEDED(hr) && ppDevice && *ppDevice) HookFactoryFromDevice(*ppDevice);
    if (SUCCEEDED(hr) && ppSwapChain && *ppSwapChain) StartProxyFromRealSwapChain(*ppSwapChain);
    return hr;
}

extern "C" __declspec(dllexport) HRESULT WINAPI PharoahD3D11CreateDevice(
    IDXGIAdapter* pAdapter, D3D_DRIVER_TYPE DriverType, HMODULE Software, UINT Flags,
    const D3D_FEATURE_LEVEL* pFeatureLevels, UINT FeatureLevels, UINT SDKVersion,
    ID3D11Device** ppDevice, D3D_FEATURE_LEVEL* pFeatureLevel, ID3D11DeviceContext** ppImmediateContext)
{
    // Device-only - no swapchain from this call itself, but this is exactly
    // the entry point the SEPARATE-CALL creation pattern uses (see the big
    // comment above HookFactoryFromDevice): the game creates its device
    // here, then calls CreateSwapChainForHwnd on the device's own factory
    // afterward. Hooking that factory from here catches it either way.
    EnsureRealD3D11Loaded();
    if (!g_realCreateDevice) return E_FAIL;
    HRESULT hr = g_realCreateDevice(pAdapter, DriverType, Software, Flags,
        pFeatureLevels, FeatureLevels, SDKVersion, ppDevice, pFeatureLevel, ppImmediateContext);
    if (SUCCEEDED(hr) && ppDevice && *ppDevice) HookFactoryFromDevice(*ppDevice);
    return hr;
}

// Every other real d3d11.dll export (Windows 10/11, verified via dumpbin),
// forwarded transparently at the LINKER level - zero runtime code, so it
// doesn't matter that most of these are undocumented/unknown signatures.
// Requires d3d11_pharoah_original.dll (the renamed real system DLL - see
// the setup steps above) to be present alongside; harmless if this DLL is
// loaded under any other name; these forwards are simply never resolved
// unless something actually calls them.
#pragma comment(linker, "/export:D3D11CreateDeviceAndSwapChain=PharoahD3D11CreateDeviceAndSwapChain")
#pragma comment(linker, "/export:D3D11CreateDevice=PharoahD3D11CreateDevice")
#pragma comment(linker, "/export:CreateDirect3D11DeviceFromDXGIDevice=d3d11_pharoah_original.CreateDirect3D11DeviceFromDXGIDevice")
#pragma comment(linker, "/export:CreateDirect3D11SurfaceFromDXGISurface=d3d11_pharoah_original.CreateDirect3D11SurfaceFromDXGISurface")
#pragma comment(linker, "/export:D3D11CoreCreateDevice=d3d11_pharoah_original.D3D11CoreCreateDevice")
#pragma comment(linker, "/export:D3D11CoreCreateLayeredDevice=d3d11_pharoah_original.D3D11CoreCreateLayeredDevice")
#pragma comment(linker, "/export:D3D11CoreGetLayeredDeviceSize=d3d11_pharoah_original.D3D11CoreGetLayeredDeviceSize")
#pragma comment(linker, "/export:D3D11CoreRegisterLayers=d3d11_pharoah_original.D3D11CoreRegisterLayers")
#pragma comment(linker, "/export:D3D11CreateDeviceForD3D12=d3d11_pharoah_original.D3D11CreateDeviceForD3D12")
#pragma comment(linker, "/export:D3D11On12CreateDevice=d3d11_pharoah_original.D3D11On12CreateDevice")
#pragma comment(linker, "/export:D3DKMTCloseAdapter=d3d11_pharoah_original.D3DKMTCloseAdapter")
#pragma comment(linker, "/export:D3DKMTCreateAllocation=d3d11_pharoah_original.D3DKMTCreateAllocation")
#pragma comment(linker, "/export:D3DKMTCreateContext=d3d11_pharoah_original.D3DKMTCreateContext")
#pragma comment(linker, "/export:D3DKMTCreateDevice=d3d11_pharoah_original.D3DKMTCreateDevice")
#pragma comment(linker, "/export:D3DKMTCreateSynchronizationObject=d3d11_pharoah_original.D3DKMTCreateSynchronizationObject")
#pragma comment(linker, "/export:D3DKMTDestroyAllocation=d3d11_pharoah_original.D3DKMTDestroyAllocation")
#pragma comment(linker, "/export:D3DKMTDestroyContext=d3d11_pharoah_original.D3DKMTDestroyContext")
#pragma comment(linker, "/export:D3DKMTDestroyDevice=d3d11_pharoah_original.D3DKMTDestroyDevice")
#pragma comment(linker, "/export:D3DKMTDestroySynchronizationObject=d3d11_pharoah_original.D3DKMTDestroySynchronizationObject")
#pragma comment(linker, "/export:D3DKMTEscape=d3d11_pharoah_original.D3DKMTEscape")
#pragma comment(linker, "/export:D3DKMTGetContextSchedulingPriority=d3d11_pharoah_original.D3DKMTGetContextSchedulingPriority")
#pragma comment(linker, "/export:D3DKMTGetDeviceState=d3d11_pharoah_original.D3DKMTGetDeviceState")
#pragma comment(linker, "/export:D3DKMTGetDisplayModeList=d3d11_pharoah_original.D3DKMTGetDisplayModeList")
#pragma comment(linker, "/export:D3DKMTGetMultisampleMethodList=d3d11_pharoah_original.D3DKMTGetMultisampleMethodList")
#pragma comment(linker, "/export:D3DKMTGetRuntimeData=d3d11_pharoah_original.D3DKMTGetRuntimeData")
#pragma comment(linker, "/export:D3DKMTGetSharedPrimaryHandle=d3d11_pharoah_original.D3DKMTGetSharedPrimaryHandle")
#pragma comment(linker, "/export:D3DKMTLock=d3d11_pharoah_original.D3DKMTLock")
#pragma comment(linker, "/export:D3DKMTOpenAdapterFromHdc=d3d11_pharoah_original.D3DKMTOpenAdapterFromHdc")
#pragma comment(linker, "/export:D3DKMTOpenResource=d3d11_pharoah_original.D3DKMTOpenResource")
#pragma comment(linker, "/export:D3DKMTPresent=d3d11_pharoah_original.D3DKMTPresent")
#pragma comment(linker, "/export:D3DKMTQueryAdapterInfo=d3d11_pharoah_original.D3DKMTQueryAdapterInfo")
#pragma comment(linker, "/export:D3DKMTQueryAllocationResidency=d3d11_pharoah_original.D3DKMTQueryAllocationResidency")
#pragma comment(linker, "/export:D3DKMTQueryResourceInfo=d3d11_pharoah_original.D3DKMTQueryResourceInfo")
#pragma comment(linker, "/export:D3DKMTRender=d3d11_pharoah_original.D3DKMTRender")
#pragma comment(linker, "/export:D3DKMTSetAllocationPriority=d3d11_pharoah_original.D3DKMTSetAllocationPriority")
#pragma comment(linker, "/export:D3DKMTSetContextSchedulingPriority=d3d11_pharoah_original.D3DKMTSetContextSchedulingPriority")
#pragma comment(linker, "/export:D3DKMTSetDisplayMode=d3d11_pharoah_original.D3DKMTSetDisplayMode")
#pragma comment(linker, "/export:D3DKMTSetDisplayPrivateDriverFormat=d3d11_pharoah_original.D3DKMTSetDisplayPrivateDriverFormat")
#pragma comment(linker, "/export:D3DKMTSetGammaRamp=d3d11_pharoah_original.D3DKMTSetGammaRamp")
#pragma comment(linker, "/export:D3DKMTSetVidPnSourceOwner=d3d11_pharoah_original.D3DKMTSetVidPnSourceOwner")
#pragma comment(linker, "/export:D3DKMTSignalSynchronizationObject=d3d11_pharoah_original.D3DKMTSignalSynchronizationObject")
#pragma comment(linker, "/export:D3DKMTUnlock=d3d11_pharoah_original.D3DKMTUnlock")
#pragma comment(linker, "/export:D3DKMTWaitForSynchronizationObject=d3d11_pharoah_original.D3DKMTWaitForSynchronizationObject")
#pragma comment(linker, "/export:D3DKMTWaitForVerticalBlankEvent=d3d11_pharoah_original.D3DKMTWaitForVerticalBlankEvent")
#pragma comment(linker, "/export:D3DPerformance_BeginEvent=d3d11_pharoah_original.D3DPerformance_BeginEvent")
#pragma comment(linker, "/export:D3DPerformance_EndEvent=d3d11_pharoah_original.D3DPerformance_EndEvent")
#pragma comment(linker, "/export:D3DPerformance_GetStatus=d3d11_pharoah_original.D3DPerformance_GetStatus")
#pragma comment(linker, "/export:D3DPerformance_SetMarker=d3d11_pharoah_original.D3DPerformance_SetMarker")
#pragma comment(linker, "/export:EnableFeatureLevelUpgrade=d3d11_pharoah_original.EnableFeatureLevelUpgrade")
#pragma comment(linker, "/export:OpenAdapter10=d3d11_pharoah_original.OpenAdapter10")
#pragma comment(linker, "/export:OpenAdapter10_2=d3d11_pharoah_original.OpenAdapter10_2")

// True if this DLL was loaded under the name "d3d11.dll" - i.e. as the
// proxy, not via classic late injection under any other name.
static bool IsLoadedAsD3D11Proxy(HMODULE hModule) {
    wchar_t path[MAX_PATH];
    if (!GetModuleFileNameW(hModule, path, MAX_PATH)) return false;
    wchar_t* name = wcsrchr(path, L'\\');
    name = name ? name + 1 : path;
    return _wcsicmp(name, L"d3d11.dll") == 0;
}

BOOL WINAPI DllMain(HMODULE hModule, DWORD dwReason) {
    if (dwReason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        // Proxy mode does NOT spawn InitThread here - DLL_PROCESS_ATTACH for
        // a statically-imported DLL fires far too early (before the game's
        // own engine has initialized anything), so Main()'s SDK pattern
        // scanning would fail. Proxy mode instead starts everything from
        // ProxyModeInitThread, triggered by D3D11CreateDeviceAndSwapChain
        // above, which naturally happens at the right point in the engine's
        // own startup sequence - no polling/guessing needed for timing.
        if (!IsLoadedAsD3D11Proxy(hModule)) {
            CreateThread(NULL, 0, InitThread, NULL, 0, NULL);
        }
    } else if (dwReason == DLL_PROCESS_DETACH) {
        UnhookEverything();
    }
    return TRUE;
}