#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "menus/Gating.h"   // per-group charity gate
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include "menus/DirectFire.h"
#include "menus/ClientValues.h"
#include "menus/VisibilityBoxes.h"
#include "menus/Language.h"
using Language::Tm;
#include <Windows.h>

bool RecoverySuite_DeveloperMode(); // defined in RecoverySuite.h - forward declared, same pattern FireModeMenu.h uses
#include <cmath>

// ============================================================================
// CARD SUITE  —  a device-fire/triggerbot implementation, reverse-engineered
// independently from studying a third-party tool's runtime behaviour
// ============================================================================
// Kept deliberately SEPARATE from PHAROAH's own tools. Nothing in here changes
// or replaces an existing PHAROAH feature; this is a parallel section with its
// own tabs so the two can be compared side by side and neither can break the
// other.
//
// Source of every fact here: internal reverse-engineering notes (not shipped).
//
// WHAT THE ANALYSIS ACTUALLY ESTABLISHED
//
//   * 38 game functions are resolved and called through a shared ProcessEvent
//     trampoline. 36 are cosmetic - Engine.Canvas.* drawing and TgClient UI -
//     which together are its cooldown overlay HUD.
//
//   * Exactly TWO are gameplay:
//         Function TgGame.TgDevice.StartFire
//         Function TgGame.TgDevice.StopFire
//     Both called bare: ATgDevice as the object, empty params buffer.
//
//   * It NEVER writes a cooldown field. An exhaustive search for writes to
//     ATgDevice's timer block (0x43C-0x458) came back empty across the entire
//     binary, in every addressing encoding.
//
//   * Target selection walks the world pawn list:
//         AWorldInfo::PawnList   0x05B4   (verified against our SDK)
//         APawn::NextPawn        0x02AC   (verified against our SDK)
//     ...to find the nearest enemy under the crosshair, caches it, snaps the
//     local pawn's rotation toward it, then fires.
//
//   * The device it fires is a SINGLE CACHED GLOBAL, never chosen per key.
//     Config.bin's VK keys gate WHETHER it runs (hold-to-activate), not WHICH
//     device it picks. So it is a triggerbot/aimbot that fires whatever is
//     equipped - not a per-slot "key N fires card N" dispatcher.
//
// WHAT IS STILL UNKNOWN
//   Two middle hops in its device-resolution chain (root -> +104 -> +1176 ->
//   +1252) could not be matched to any named field in our SDK dump. Our own
//   route (InvManager -> GetInventoryByEquipPoint -> s_Device) is arguably more
//   correct for "fire the card the user picked", since its data flow has no
//   equip-point concept at all.
// ============================================================================

namespace CardSuite {

    enum Page { PAGE_FIRE = 0, PAGE_AUTO = 1, PAGE_TP = 2, PAGE_RESPAWN = 3, PAGE_CV = 4, PAGE_NOTES = 5 };
    inline int g_Page = PAGE_FIRE;

    // ---- Auto-aim / triggerbot -----------------------------------------
    inline bool  g_AutoEnabled   = false;
    inline bool  g_AutoFire      = true;    // StartFire when on target
    inline bool  g_HoldToUse     = true;    // hold a key, like Config.bin's VK gate
    inline int   g_HoldKey       = VK_XBUTTON2;
    inline float g_FireInterval  = 0.05f;
    inline float g_FireTimer     = 0.0f;
    inline int   g_Shots         = 0;
    inline char  g_AutoStatus[200] = "Idle.";

    inline bool HoldKeyDown() {
        if (!g_HoldToUse) return true;
        if (ImGui::GetCurrentContext() && ImGui::GetIO().WantTextInput) return false;
        return (GetAsyncKeyState(g_HoldKey) & 0x8000) != 0;
    }

    // ======================================================================
    // TELEPORT  (report Addendum 6 - third hotkey mechanism)
    // ======================================================================
    inline bool  g_TpOn        = false;
    inline int   g_TpKey       = 'T';
    inline float g_TpDistance  = 1000.0f;   // forward from where you look
    inline bool  g_TpPlayFx    = true;
    inline bool  g_TpSafeSpot  = false;     // true = engine may refuse
    inline bool  g_TpWasDown   = false;
    inline int   g_TpCount     = 0;
    inline char  g_TpStatus[200] = "Idle.";
    inline bool  g_PendingTp      = false;
    inline bool  g_PendingRespawn = false;
    inline bool  g_PendingAutoFire= false;
    inline int   g_HpCur = 0, g_HpMax = 0;
    inline int   g_PosX = 0, g_PosY = 0, g_PosZ = 0;

    // UE3 rotators are 16-bit-ish angles: 65536 units = 360 degrees.
    inline void ForwardFromRotation(int pitch, int yaw, float* fx, float* fy, float* fz) {
        const float kToRad = 3.14159265f / 32768.0f;
        float p = (float)((pitch % 65536)) * kToRad;
        float y = (float)((yaw   % 65536)) * kToRad;
        float cp = cosf(p);
        *fx = cp * cosf(y);
        *fy = cp * sinf(y);
        *fz = sinf(p);
    }

    inline bool DoTeleportForward() {
        float x, y, z; int pp, py, pr;
        if (!SafeCalls::GetPawnPosRot(&x, &y, &z, &pp, &py, &pr)) {
            lstrcpynA(g_TpStatus, "No pawn.", 190);
            return false;
        }
        int vp = pp, vy = py, vr = pr;
        SafeCalls::GetViewRotation(&vp, &vy, &vr);   // pitch comes from the view

        float fx, fy, fz;
        ForwardFromRotation(vp, vy, &fx, &fy, &fz);
        float dx = x + fx * g_TpDistance;
        float dy = y + fy * g_TpDistance;
        float dz = z + fz * g_TpDistance;

        bool ok = SafeCalls::PawnTeleport(dx, dy, dz, g_TpPlayFx, g_TpSafeSpot);
        if (ok) g_TpCount++;
        wsprintfA(g_TpStatus, "%s -> %d,%d,%d  (%d total)",
                  ok ? "Teleported" : "Teleport REFUSED",
                  (int)dx, (int)dy, (int)dz, g_TpCount);
        return ok;
    }

    // ======================================================================
    // AUTO-RESPAWN  (report Addendum 6 - second mechanism)
    // ======================================================================
    inline bool  g_ResOn       = false;
    inline float g_ResHpPct    = 5.0f;      // its threshold was <=5%
    inline float g_ResRevive   = 0.0f;      // what to claim as time remaining
    inline float g_ResCooldown = 1.0f;
    inline float g_ResTimer    = 0.0f;
    inline int   g_ResCount    = 0;
    inline char  g_ResStatus[200] = "Idle.";

    inline void RunRespawnChain() {
        bool a = SafeCalls::UpdateReviveTimeRemaining(g_ResRevive);
        bool b = SafeCalls::ServerSetReadyToPlay();
        bool c = SafeCalls::ClientSetReadyState(true);
        bool d = SafeCalls::EnterStartState();
        g_ResCount++;
        wsprintfA(g_ResStatus, "chain #%d: revive=%s ready=%s state=%s start=%s",
                  g_ResCount, a ? "ok" : "X", b ? "ok" : "X", c ? "ok" : "X", d ? "ok" : "X");
    }

    // Per-frame. Runs from main.cpp's always-run block, so it works with the
    // menu closed - same as everything else that has to keep working in play.
    inline void Tick() {
        // Suppressed while typing - see the note in main.cpp on the grayscale key.
        const bool typing = ImGui::GetCurrentContext() && ImGui::GetIO().WantTextInput;

        // --- teleport hotkey, edge-triggered ---
        if (g_TpOn && g_TpKey && !typing) {
            bool down = (GetAsyncKeyState(g_TpKey) & 0x8000) != 0;
            if (down && !g_TpWasDown) g_PendingTp = true;
            g_TpWasDown = down;
        }

        // --- auto-respawn at low health ---
        if (g_ResOn) {
            g_ResTimer += 0.016f;
            if (g_ResTimer >= g_ResCooldown) {
                int cur = 0, mx = 0;
                if (SafeCalls::GetPawnHealth(&cur, &mx) && mx > 0) {
                    float pct = (float)cur * 100.0f / (float)mx;
                    if (cur <= 0 || pct <= g_ResHpPct) {
                        g_ResTimer = 0.0f;
                        g_PendingRespawn = true;
                    }
                }
            }
        }

        if (!g_AutoEnabled) return;
        if (!HoldKeyDown()) return;
        if (!Globals::LocalPawn || !Globals::LocalWeapon) return;

        // Reuse PHAROAH's existing target state rather than duplicating the
        // pawn walk - VisibilityBoxes already walks WorldInfo->PawnList, which
        // is the same traversal this style of triggerbot uses.
        if (!VisibilityBoxes::enabled) {
            lstrcpynA(g_AutoStatus, "Needs Highlights boxes ON - that is where targets come from.", 190);
            return;
        }

        bool onTarget = VisibilityBoxes::g_ReticleOnEnemy
                     || VisibilityBoxes::g_ReticleOnPredictionBox;
        if (!onTarget) { lstrcpynA(g_AutoStatus, "Active - no target under crosshair.", 190); return; }

        if (g_AutoFire) {
            g_FireTimer += 0.016f;
            if (g_FireTimer >= g_FireInterval) {
                g_FireTimer = 0.0f;
                g_PendingAutoFire = true;
            }
        } else {
            lstrcpynA(g_AutoStatus, "Target acquired (fire disabled).", 190);
        }
    }

    // ================= SAFE THREAD ONLY =================
    // Teleport, the respawn chain and StartFire are all scripted (ProcessEvent).
    // Calling them from the render thread crashed the tool on menu transitions,
    // when the game is destroying and rebuilding objects underneath us. Every
    // game call in this file happens here and nowhere else.
    inline void ProcessPending() {
        if (!Globals::LocalPawn) { g_HpMax = 0; return; }

        // cached readouts for the UI - the draw path must never call the game
        int cur = 0, mx = 0;
        if (SafeCalls::GetPawnHealth(&cur, &mx)) { g_HpCur = cur; g_HpMax = mx; }
        float x, y, z; int pp, py, pr;
        if (SafeCalls::GetPawnPosRot(&x, &y, &z, &pp, &py, &pr)) {
            g_PosX = (int)x; g_PosY = (int)y; g_PosZ = (int)z;
        }

        ClientValues::ProcessPending();
        if (g_PendingTp)      { g_PendingTp = false;      DoTeleportForward(); }
        if (g_PendingRespawn) { g_PendingRespawn = false; RunRespawnChain(); }
        if (g_PendingAutoFire) {
            g_PendingAutoFire = false;
            SDK::ATgDevice* d = Globals::LocalWeapon;
            if (d && SafeCalls::DeviceStartFire(d)) {
                SafeCalls::DeviceStopFire(d);
                g_Shots++;
                wsprintfA(g_AutoStatus, "FIRING - %d shots via StartFire", g_Shots);
            }
        }
    }

    inline void DrawAutoPage(bool inMatch) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.5f, 1.0f, 0.6f, 1.0f)));
        ImGui::TextUnformatted(Tm("AUTO-FIRE  /  TRIGGERBOT", "AUTO-FEUGO  /  TRIGGERBOT"));
        ImGui::PopStyleColor();
        ImGui::Separator();

        ImGui::TextWrapped(Tm("Finds the nearest enemy under the crosshair, then calls "
            "TgDevice.StartFire on whatever is equipped. It never touches cooldowns and never "
            "picks a device per key.",
            "Encuentra al enemigo más cercano bajo el crosshair, luego llama a "
            "TgDevice.StartFire en lo que esté equipado. Nunca toca cooldowns y nunca "
            "elige un dispositivo por tecla."));
        ImGui::Spacing();

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.72f, 0.3f, 1.0f)));
        ImGui::TextWrapped(Tm("Separate from PHAROAH's own trigger bot in the Reticle Manager tab. "
            "Neither affects the other. Run whichever you prefer - or compare them.",
            "Separado del trigger bot propio de PHAROAH en la pestaña Reticle Manager. "
            "Ninguno afecta al otro. Ejecuta el que prefieras - o compáralos."));
        ImGui::PopStyleColor();

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::Checkbox(Tm("ENABLE", "HABILITAR"), &g_AutoEnabled);
        ImGui::SameLine();
        ImGui::Checkbox(Tm("auto-fire", "auto-fuego"), &g_AutoFire);
        ImGui::SameLine();
        ImGui::Checkbox(Tm("hold key to activate", "mantener tecla para activar"), &g_HoldToUse);

        if (g_HoldToUse) {
            ImGui::SetNextItemWidth(140);
            ImGui::InputInt(Tm("hold key (VK code)", "tecla held (código VK)"), &g_HoldKey);
            ImGui::SameLine();
            ImGui::TextDisabled(Tm("%s", "%s"), HoldKeyDown() ? Tm("HELD", "HELD") : Tm("up", "arriba"));
            ImGui::TextDisabled(Tm("VK codes: 0x01 LMB, 0x02 RMB, 0x05 MB4, 0x06 MB5, 0x10 Shift",
                "Códigos VK: 0x01 LMB, 0x02 RMB, 0x05 MB4, 0x06 MB5, 0x10 Shift"));
        }

        ImGui::SetNextItemWidth(200);
        ImGui::SliderFloat(Tm("fire interval", "intervalo de fuego"), &g_FireInterval, 0.0f, 0.5f, Tm("%.3f s", "%.3f s"));

        ImGui::Spacing();
        if (!VisibilityBoxes::enabled) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.55f, 0.45f, 1.0f)));
            ImGui::TextWrapped(Tm("Highlights boxes are OFF. Targets come from that system's pawn "
                "walk, so this cannot fire until it is on.",
                "Los cuadros Highlights están OFF. Los objetivos vienen del recorrido pawn de ese sistema, "
                "así que esto no puede disparar hasta que esté encendido."));
            ImGui::PopStyleColor();
        }

        ImGui::Spacing();
        ImGui::TextWrapped(Tm("%s", "%s"), g_AutoStatus);
        ImGui::SameLine();
        if (ImGui::SmallButton(Tm("reset count", "reiniciar conteo"))) g_Shots = 0;
    }

    inline void DrawTpPage(bool inMatch) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.5f, 1.0f, 0.6f, 1.0f)));
        ImGui::TextUnformatted(Tm("TELEPORT   (TgGame.TgPawn.Teleport)", "TELEPORTAR   (TgGame.TgPawn.Teleport)"));
        ImGui::PopStyleColor();
        ImGui::Separator();
        ImGui::TextWrapped(Tm("Its third hotkey mechanism. Teleports you along your view direction. "
            "Press the key or the button below.",
            "Su tercer mecanismo de hotkey. Teleporta junto a tu dirección de vista. "
            "Presiona la tecla o el botón de abajo."));

        ImGui::Spacing();
        ImGui::Checkbox(Tm("ENABLE hotkey", "HABILITAR hotkey"), &g_TpOn);
        ImGui::SameLine();
        ImGui::SetNextItemWidth(80);
        ImGui::InputInt(Tm("key##tp", "tecla##tp"), &g_TpKey);
        ImGui::SameLine();
        ImGui::TextDisabled(Tm("%s", "%s"), (g_TpKey && (GetAsyncKeyState(g_TpKey) & 0x8000)) ? Tm("HELD", "HELD") : Tm("up", "arriba"));

        ImGui::SetNextItemWidth(220);
        ImGui::SliderFloat(Tm("distance", "distancia"), &g_TpDistance, 100.0f, 6000.0f, Tm("%.0f units", "%.0f unidades"));
        ImGui::Checkbox(Tm("play teleport FX", "reproducir FX de teleport"), &g_TpPlayFx);
        ImGui::SameLine();
        ImGui::Checkbox(Tm("only safe spots", "solo puntos seguros"), &g_TpSafeSpot);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            Tm("On: the engine refuses any destination it cannot validate, which\\n"
            "is most of the interesting ones. Off by default.",
            "On: el motor se niega a cualquier destino que no pueda validar, lo que\\n"
            "es la mayoría de los interesantes. Desactivado por defecto."));

        ImGui::Spacing();
        if (ImGui::Button(Tm(">>> TELEPORT NOW <<<", ">>> TELEPORTAR AHORA <<<"), ImVec2(220, 32))) g_PendingTp = true;

        ImGui::Spacing();
        ImGui::TextWrapped("%s", g_TpStatus);

        ImGui::TextDisabled(Tm("you are at %d, %d, %d", "estás en %d, %d, %d"), g_PosX, g_PosY, g_PosZ);
    }

    inline void DrawRespawnPage(bool inMatch) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.5f, 1.0f, 0.6f, 1.0f)));
        ImGui::TextUnformatted(Tm("AUTO-RESPAWN   (low-health chain)", "AUTO-RESPAWN   (cadena de baja salud)"));
        ImGui::PopStyleColor();
        ImGui::Separator();
        ImGui::TextWrapped(Tm("At or below the health threshold it runs this four-call chain:",
            "Al o bajo el umbral de salud ejecuta esta cadena de cuatro llamadas:"));
        ImGui::BulletText(Tm("UpdateReviveTimeRemaining(t)", "UpdateReviveTimeRemaining(t)"));
        ImGui::BulletText(Tm("ServerSetReadyToPlay()", "ServerSetReadyToPlay()"));
        ImGui::BulletText(Tm("ClientSetReadyState(true)", "ClientSetReadyState(true)"));
        ImGui::BulletText(Tm("EnterStartState()", "EnterStartState()"));

        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.72f, 0.3f, 1.0f)));
        ImGui::TextWrapped(Tm("ServerSetReadyToPlay is a SERVER call. Whether the server honours it "
            "is not something the client decides - the per-step result is shown below so you can "
            "see which one is refused, if any.",
            "ServerSetReadyToPlay es una llamada de SERVIDOR. Si el servidor la honra "
            "no es algo que el cliente decide - el resultado por paso se muestra abajo para que veas "
            "cuál es rechazado, si alguno."));
        ImGui::PopStyleColor();

        ImGui::Spacing();
        ImGui::Checkbox(Tm("ENABLE auto-respawn", "HABILITAR auto-respawn"), &g_ResOn);
        ImGui::SetNextItemWidth(200);
        ImGui::SliderFloat(Tm("health threshold", "umbral de salud"), &g_ResHpPct, 0.0f, 100.0f, Tm("%.0f %%", "%.0f %%"));
        ImGui::SetNextItemWidth(200);
        ImGui::SliderFloat(Tm("revive time to claim", "tiempo de revive a reclamar"), &g_ResRevive, 0.0f, 10.0f, Tm("%.1f s", "%.1f s"));
        ImGui::SetNextItemWidth(200);
        ImGui::SliderFloat(Tm("retry cooldown", "enfriamiento de reintento"), &g_ResCooldown, 0.25f, 10.0f, Tm("%.2f s", "%.2f s"));

        ImGui::Spacing();
        if (ImGui::Button(Tm("RUN CHAIN ONCE (test)", "EJECUTAR CADENA UNA VEZ (prueba)"), ImVec2(240, 30))) g_PendingRespawn = true;

        if (g_HpMax > 0)
            ImGui::TextDisabled(Tm("health: %d / %d  (%.0f%%)", "salud: %d / %d  (%.0f%%)"), g_HpCur, g_HpMax,
                                (float)g_HpCur * 100.0f / (float)g_HpMax);
        else
            ImGui::TextDisabled(Tm("health: unreadable (no pawn)", "salud: no legible (sin peón)"));

        ImGui::Spacing();
        ImGui::TextWrapped(Tm("%s", "%s"), g_ResStatus);
    }

    inline void DrawNotesPage() {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted(Tm("HOW THIS DEVICE-FIRE METHOD WORKS", "CÓMO FUNCIONA ESTE MÉTODO DE DISPARO DE DISPOSITIVO"));
        ImGui::PopStyleColor();
        ImGui::Separator();

        ImGui::TextWrapped(Tm("Full write-up kept in internal reverse-engineering notes (not shipped).",
            "Escritura completa mantenida en notas internas de reverse-engineering (no distribuidas)."));
        ImGui::Spacing();

        ImGui::TextColored(Ink(ImVec4(0.5f, 1.0f, 0.6f, 1.0f)), Tm("CONFIRMED - and implemented here", "CONFIRMADO - y implementado aquí"));
        ImGui::BulletText(Tm("TgGame.TgDevice.StartFire / StopFire, called bare on an ATgDevice",
            "TgGame.TgDevice.StartFire / StopFire, llamado bare en un ATgDevice"));
        ImGui::BulletText(Tm("Target = nearest enemy under crosshair, via WorldInfo->PawnList walk",
            "Objetivo = enemigo más cercano bajo crosshair, via recorrido WorldInfo->PawnList"));
        ImGui::BulletText(Tm("AWorldInfo::PawnList 0x05B4 and APawn::NextPawn 0x02AC - both verified",
            "AWorldInfo::PawnList 0x05B4 y APawn::NextPawn 0x02AC - ambos verificados"));
        ImGui::BulletText(Tm("Config.bin VK keys gate WHETHER it runs, not which device",
            "Teclas VK de Config.bin habilitan SI corre, no qué dispositivo"));

        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.72f, 0.3f, 1.0f)), Tm("CONFIRMED NEGATIVE - do not chase these", "CONFIRMADO NEGATIVO - no persigas estos"));
        ImGui::BulletText(Tm("It does NOT zero cooldowns. No write to ATgDevice 0x43C-0x458 exists",
            "NO zeroea cooldowns. No existe escritura a ATgDevice 0x43C-0x458"));
        ImGui::BulletText(Tm("It does NOT pick a device per key - one cached global, always",
            "NO elige un dispositivo por tecla - un global cacheado, siempre"));
        ImGui::BulletText(Tm("36 of its 38 game calls are Canvas drawing / UI. Cosmetic overlay",
            "36 de sus 38 llamadas de juego son Canvas drawing / UI. Overlay cosmético"));

        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(0.85f, 0.55f, 0.55f, 1.0f)), Tm("STILL UNKNOWN", "AÚN DESCONOCIDO"));
        ImGui::BulletText(Tm("Two hops in its device chain (+1176, +1252) match no named SDK field",
            "Dos hops en su cadena de dispositivo (+1176, +1252) no coinciden con ningún campo SDK nombrado"));
        ImGui::BulletText(Tm("Whether a separate per-card path exists that analysis has not reached",
            "Si existe un camino per-card separado que el análisis no ha alcanzado"));

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextWrapped(Tm("If you believe it has features beyond the above, the thing to ask for "
            "is a full list of every function it calls that is NOT one of the 38 trampoline "
            "callers - a second dispatch mechanism would not have shown up in that sweep.",
            "Si crees que tiene características más allá de lo anterior, lo que pedir es una lista completa "
            "de cada función que llama que NO sea uno de los 38 llamadores trampoline "
            "- un segundo mecanismo de dispatch no habría aparecido en ese sweep."));
    }

    // Direct Fire is the page that matters - it is the device sweep, and it is
    // what makes cards work in a real match. The other five are the rest of the
    // reverse-engineering work and they were crowding it out, so they are behind
    // a single toggle now.
    inline bool g_ShowOtherPages = false;

    inline void DrawControls(bool inMatch) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted(Tm("CARDS", "CARTAS"));
        ImGui::PopStyleColor();
        ImGui::TextDisabled(Tm("Separate section. Nothing here touches PHAROAH's own tools.", "Sección separada. Nada de esto toca las propias herramientas de PHAROAH."));
        Gating::DrawBlockedBannerFor(Gating::Gated::Cards);
        ImGui::Separator();

        struct Btn { const char* label; int page; };
        static const Btn kBtns[] = {
            { Tm("Direct Fire", "Fuego Directo"), PAGE_FIRE },
            { Tm("Auto-Fire", "Auto-Fuego"),   PAGE_AUTO },
            { Tm("Teleport", "Teleportar"),    PAGE_TP },
            { Tm("Auto-Respawn", "Auto-Respawn"),PAGE_RESPAWN },
            { Tm("Wall/3P/Aim", "Pared/3P/Aim"), PAGE_CV },
            { Tm("What it is", "Qué es"),  PAGE_NOTES },
        };

        // Direct Fire always shows. The rest appear only when asked for.
        const int shown = g_ShowOtherPages ? 6 : 1;
        // Sub-page switcher hidden behind dev mode - a cleaner default for
        // normal users, who never need anything but Direct Fire here. Force
        // it off (and snap back to Direct Fire) whenever dev mode isn't on,
        // so nobody can get stranded on a page they can no longer reach the
        // toggle for.
        if (!RecoverySuite_DeveloperMode()) g_ShowOtherPages = false;
        if (!g_ShowOtherPages) g_Page = PAGE_FIRE;   // can't be stranded on a hidden page

        float spacing = ImGui::GetStyle().ItemSpacing.x;
        float avail   = ImGui::GetContentRegionAvail().x;
        // Direct Fire plus the toggle share the first line when collapsed.
        float w = g_ShowOtherPages
                    ? (avail - spacing * 5) / 6.0f
                    : 160.0f;

        for (int i = 0; i < shown; i++) {
            bool on = (g_Page == kBtns[i].page);
            if (on) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.55f, 0.40f, 1.0f));
            if (ImGui::Button(kBtns[i].label, ImVec2(w, 26))) g_Page = kBtns[i].page;
            if (on) ImGui::PopStyleColor();
            if (i < shown - 1) ImGui::SameLine();
        }
        if (RecoverySuite_DeveloperMode()) {
            if (!g_ShowOtherPages) ImGui::SameLine();
            ImGui::Checkbox(Tm("show other tabs", "mostrar otras pestañas"), &g_ShowOtherPages);
        }

        ImGui::Separator();
        ImGui::Spacing();

        switch (g_Page) {
            case PAGE_FIRE:  DirectFire::DrawControls(inMatch); break;
            case PAGE_AUTO:  DrawAutoPage(inMatch);             break;
            case PAGE_TP:      DrawTpPage(inMatch);             break;
            case PAGE_RESPAWN: DrawRespawnPage(inMatch);        break;
            case PAGE_CV:      ClientValues::DrawControls(inMatch); break;
            default:         DrawNotesPage();                   break;
        }
    }
}
