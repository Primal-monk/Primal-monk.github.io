#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include "menus/TalentDatabase.h"
#include "menus/MeshSkin.h"   // CopyClip
#include "menus/Language.h"
using Language::Tm;
#include <Windows.h>

// ============================================================================
// CARDS & TALENTS — the Anubis Tm("Loadout Cards", "Cartas de Equipo") / "Talent Unlocker" method
//
// WHAT IS ACTUALLY NEW HERE (stated carefully, because it's easy to get wrong):
//
// It is tempting to blame the failed card work on CheatManager gating, the way
// Set3p (third person) and SetMountSkin are gated. That explanation is WRONG, and
// we have direct evidence: the Octavia Commander buffs go through
// UTgBattleCheatManager::TestServerRequestCard and they demonstrably WORK in real
// matches — instantly filling the ult meter, dropping cooldowns. So card requests
// do reach the server through that path.
//
// Which means the card path was never the problem. What the server refuses is
// specifically raising a card's LEVEL. Requesting a card's EFFECT works (Octavia),
// requesting a card at a high RANK does not. That is consistent with Anubis, who
// list "Loadout Cards — access DR, Self-Heal, Ult Charge, CD modifiers" — effects,
// exactly like Octavia — and never mention card maxing anywhere.
//
// So the genuinely new thing in this tab is the TALENT pathway, which we have
// never tried at all:
//
//   ATgPlayerController::ServerRequestDeckAndTalent(nTalentId, nDeckId, bTemplate)
//
// That is the RPC the game's own loadout screen uses to pick a talent. Combined
// with the 246 talent ids in message(1).txt — many of them removed for being far
// too strong — this is the most promising untried lead in the project.
//
// The card controls below use the non-CheatManager equivalents for completeness:
//   ATgPlayerController::ServerRequestCard(nDeviceId, nRank)
//   ATgPlayerController::ServerAllocateDevicePoint(nDeviceId)
//
// HOW IT FITS THE MODEL:
// This is the client REQUESTING through the game's genuine pathway, not asserting
// a stat. The server still decides. But a removed or hidden talent's DEVICE
// usually still exists in the game data — that is why the ids in
// message(1).txt are still meaningful. The server honours the id; the live UI
// simply never offers it.
//
// HONEST EXPECTATION: talents are normally chosen at the loadout screen, so
// mid-match application may be rejected even through the correct RPC. Every
// button reports what it sent so a failure is legible instead of silent. This is
// a genuine lead, not a promise.
//
// THROTTLING: these are RELIABLE RPCs. Bursting reliable RPCs overflows the
// channel and closes the connection — that is the "booted back to menu" failure
// seen repeatedly in this project. So bulk operations go through a paced queue,
// never a loop of direct sends.
// ============================================================================

namespace CardsTab {
    // Inventory / card-level enumeration state (see the INVENTORY section in
    // DrawControls). Read-first: enumerate before writing anything.
    inline SafeCalls::InvRow g_Inv[64] = {};
    inline int  g_InvCount = 0;
    inline int  g_InvSetLevel = 5;
    inline bool g_InvUseSetter = false;
    inline char g_InvStatus[192] = "";


    // ---- talent state ----
    inline int  talentId = 0;
    inline int  deckId = 0;
    inline bool templateDeck = false;
    inline int  championFilter = 0;     // 0 = all
    inline bool showHiddenOnly = false;

    // ---- card state ----
    inline int  cardDeviceId = 0;
    inline int  cardRank = 5;
    inline int  allocateRepeats = 5;

    // ---- pending flags (all sends happen on the ProcessEvent thread) ----
    inline bool g_PendingTalent = false;
    inline int  g_PendingTalentId = 0;
    inline bool g_PendingCard = false;
    inline bool g_PendingAllocate = false;
    inline int  g_AllocateRemaining = 0;

    inline int  g_TalentsSent = 0;
    inline int  g_CardsSent = 0;
    inline int  g_AllocatesSent = 0;
    inline ULONGLONG g_LastSendMs = 0;
    inline int  sendIntervalMs = 250;   // paced; see the throttling note above

    inline char g_LastAction[128] = "(nothing sent yet)";

    // Champion list, derived from the database so it can never drift out of sync
    // with the talent entries themselves.
    inline const char* g_Champions[96] = { "(all champions)" };
    inline int  g_ChampionCount = 1;
    inline bool g_ChampionsBuilt = false;

    inline void BuildChampionList() {
        if (g_ChampionsBuilt) return;
        g_ChampionsBuilt = true;
        for (int i = 0; i < TalentDB::kTalentCount; ++i) {
            const char* c = TalentDB::kTalents[i].champion;
            bool seen = false;
            for (int j = 1; j < g_ChampionCount; ++j) {
                if (lstrcmpA(g_Champions[j], c) == 0) { seen = true; break; }
            }
            if (!seen && g_ChampionCount < 96) g_Champions[g_ChampionCount++] = c;
        }
    }

    inline void QueueTalent(int id) {
        g_PendingTalentId = id;
        g_PendingTalent = true;
        wsprintfA(g_LastAction, "queued talent %d (deck %d, template %s)",
                  id, deckId, templateDeck ? "yes" : "no");
    }

    // ProcessEvent thread. One send per tick at most — see the throttling note.
    inline void ProcessPending() {
        ULONGLONG now = GetTickCount64();
        if (now - g_LastSendMs < (ULONGLONG)sendIntervalMs) return;

        if (g_PendingTalent) {
            g_PendingTalent = false;
            g_LastSendMs = now;
            if (SafeCalls::ServerRequestDeckAndTalent(g_PendingTalentId, deckId, templateDeck)) {
                g_TalentsSent++;
                wsprintfA(g_LastAction, "SENT talent %d (deck %d)", g_PendingTalentId, deckId);
            } else {
                wsprintfA(g_LastAction, "FAILED talent %d", g_PendingTalentId);
            }
            return;
        }

        if (g_PendingCard) {
            g_PendingCard = false;
            g_LastSendMs = now;
            if (SafeCalls::ServerRequestCard(cardDeviceId, cardRank)) {
                g_CardsSent++;
                wsprintfA(g_LastAction, "SENT card %d rank %d", cardDeviceId, cardRank);
            } else {
                wsprintfA(g_LastAction, "FAILED card %d", cardDeviceId);
            }
            return;
        }

        // Allocation is drained one per tick rather than looped, because looping
        // reliable RPCs is what closes the connection.
        if (g_PendingAllocate && g_AllocateRemaining > 0) {
            g_LastSendMs = now;
            g_AllocateRemaining--;
            if (g_AllocateRemaining <= 0) g_PendingAllocate = false;
            if (SafeCalls::ServerAllocateDevicePoint(cardDeviceId)) {
                g_AllocatesSent++;
                wsprintfA(g_LastAction, "SENT allocate on %d (%d left)",
                          cardDeviceId, g_AllocateRemaining);
            }
        }
    }

    inline void DrawControls(bool inMatch) {
        BuildChampionList();

        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)), Tm("CARDS & TALENTS", "CARTAS Y TALENTOS"));
        ImGui::TextWrapped(Tm("What's new here is the TALENT pathway - we have never tried it. "
            "Note the card path was never actually broken: the Octavia buffs prove card requests "
            "reach the server fine. What the server refuses is raising a card's LEVEL. Requesting "
            "a card's EFFECT works, requesting a high RANK doesn't - which matches Anubis listing "
            "card effects and never mentioning card maxing.",
            "Lo nuevo aquí es la vía de TALENTOS - nunca la hemos intentado. "
            "Nota que la vía de cartas nunca estuvo rota: los buffs de Octavia prueban que las "
            "peticiones de cartas llegan bien al servidor. Lo que el servidor rechaza es subir el "
            "NIVEL de una carta. Peticionar el EFECTO de una carta funciona, pedir un RANK alto "
            "no - lo que coincide con Anubis listando efectos de cartas y nunca mencionando "
            "maximizar cartas."));

        if (!inMatch) { ImGui::TextDisabled(Tm("Join a match first.", "Únete a una partida primero.")); return; }

        // ================= INVENTORY / CARD-LEVEL (NEW SURFACE) =============
        // Different mechanism from everything above. The note above is about
        // REQUESTING a card level from the server (refused). This instead reads
        // and writes the CLIENT's own inventory objects directly:
        //   UTgInventoryObject_Device::m_nStackCount @0x00B8 = card LEVEL.
        // No request, no server round-trip. Whether the EFFECT follows the number
        // is the open question — enumerate first, then test one write.
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.9f, 0.4f, 1.0f)), Tm("INVENTORY / CARD LEVEL  (new - raw client objects)", "INVENTARIO / NIVEL DE CARTA  (nuevo - objetos de cliente sin procesar)"));
        ImGui::TextWrapped(Tm("Reads the pawn's own inventory objects via "
            "InvManager->GetInventoryByEquipPoint(). m_nStackCount is the card's LEVEL. This is a "
            "direct field write, NOT a server request - so it bypasses the path that refuses level "
            "raises. Enumerate first: if nothing lists, the objects aren't reachable and we stop.",
            "Lee los objetos de inventario propios del peón a través de "
            "InvManager->GetInventoryByEquipPoint(). m_nStackCount es el NIVEL de la carta. Esto es una "
            "escritura directa en el campo, NO una petición al servidor - así que evita la vía que "
            "rechaza subidas de nivel. Enumere primero: si no lista nada, los objetos no son "
            "alcanzables y paramos."));

        if (ImGui::Button(Tm("ENUMERATE INVENTORY", "ENUMERAR INVENTARIO"), ImVec2(220, 26))) {
            g_InvCount = 0;
            // Equip points: 0..20 covers CARD(5) and BURN_CARD(8..11).
            for (int ep = 0; ep <= 20 && g_InvCount < 64; ++ep) {
                for (int it = 0; it <= 3 && g_InvCount < 64; ++it) {
                    SDK::UTgInventoryObject* o = SafeCalls::GetInvByEquipPoint(ep, it);
                    if (!o) continue;
                    bool dup = false;
                    for (int k = 0; k < g_InvCount; ++k)
                        if (g_Inv[k].obj == (void*)o) { dup = true; break; }
                    if (dup) continue;
                    SafeCalls::InvRow r{};
                    if (!SafeCalls::ReadInvObject((void*)o, &r)) continue;
                    r.equipPoint = ep; r.itemType = it;
                    g_Inv[g_InvCount++] = r;
                }
            }
            wsprintfA(g_InvStatus, "Found %d inventory objects.", g_InvCount);
        }
        ImGui::SameLine();
        if (ImGui::Button(Tm("COPY INVENTORY", "COPIAR INVENTARIO"), ImVec2(180, 26))) {
            static char big[64 * 200 + 256];
            big[0] = '\0';
            lstrcatA(big, Tm("===== INVENTORY / CARD DUMP =====\r\n", "===== DUMP DE INVENTARIO / CARTA =====\r\n"));
            for (int i = 0; i < g_InvCount; ++i) {
            char line[200];
            wsprintfA(line, "eqp=%-2d type=%d  class=%-34s refId=%-6d STACK(level)=%-3d "
                            "instId=%-6d acquired=%-3d temp=%d\r\n",
                      g_Inv[i].equipPoint, g_Inv[i].itemType, g_Inv[i].name,
                      g_Inv[i].refData, g_Inv[i].stackCount, g_Inv[i].instanceId,
                      g_Inv[i].nbrAcquired, g_Inv[i].temporary ? 1 : 0);
            lstrcatA(big, line);
            }
            if (g_InvCount == 0) lstrcatA(big, Tm("(nothing found - objects not reachable)\r\n", "(nada encontrado - objetos no alcanzables)\r\n"));
            lstrcatA(big, Tm("===== END =====\r\n", "===== FIN =====\r\n"));
            MeshSkin::CopyClip(big);
        }
        ImGui::Text("%s", g_InvStatus);

        if (g_InvCount > 0) {
            ImGui::SetNextItemWidth(110);
            ImGui::InputInt(Tm("set level to", "establecer nivel a"), &g_InvSetLevel);
            ImGui::SameLine();
            ImGui::Checkbox("use engine SetInstanceCount instead of raw write", &g_InvUseSetter);
            ImGui::BeginChild("invlist", ImVec2(0, 200), true);
            for (int i = 0; i < g_InvCount; ++i) {
                char lbl[240];
                wsprintfA(lbl, "eqp%-2d t%d  %-30s  id=%-6d  LEVEL=%-3d  acq=%d##inv%d",
                          g_Inv[i].equipPoint, g_Inv[i].itemType, g_Inv[i].name,
                          g_Inv[i].refData, g_Inv[i].stackCount, g_Inv[i].nbrAcquired, i);
                if (ImGui::Selectable(lbl)) {
                    bool ok = g_InvUseSetter
                        ? SafeCalls::CallSetInstanceCount(g_Inv[i].obj, g_InvSetLevel)
                        : SafeCalls::SetCardStack(g_Inv[i].obj, g_InvSetLevel);
                    // read back immediately — did it stick?
                    SafeCalls::InvRow after{};
                    SafeCalls::ReadInvObject(g_Inv[i].obj, &after);
                    wsprintfA(g_InvStatus, "%s -> wrote %d, reads back %d %s",
                              ok ? "OK" : "FAILED", g_InvSetLevel, after.stackCount,
                              (after.stackCount == g_InvSetLevel) ? "(STUCK)" : "(REVERTED)");
                    g_Inv[i].stackCount = after.stackCount;
                }
            }
            ImGui::EndChild();
            ImGui::TextWrapped("Click a row to write the level. The status line says whether it STUCK "
                "or REVERTED - that alone tells us if the client owns this value.");
        }

        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), Tm("TALENT UNLOCKER", "DESBLOQUEADOR DE TALENTOS"));
        ImGui::TextWrapped(Tm("246 talents from message(1).txt, including removed and hidden ones. "
            "A removed talent's device usually still exists, so the server still honours the id - "
            "the live UI just never offers it. Hidden ones are marked and are the interesting ones, "
            "since they were usually removed for being too strong.",
            "246 talentos de message(1).txt, incluyendo quitados y ocultos. "
            "El dispositivo de un talento quitado usualmente sigue existiendo, así que el servidor "
            "todavía honra el id - la interfaz en vivo simplemente nunca lo ofrece. Los ocultos "
            "están marcados y son los interesantes, ya que usualmente se quitó por ser demasiado "
            "potente."));

        ImGui::PushItemWidth(150);
        ImGui::Combo(Tm("Champion", "Campeón"), &championFilter, g_Champions, g_ChampionCount);
        ImGui::PopItemWidth();
        ImGui::SameLine();
        ImGui::Checkbox(Tm("Hidden only", "Solo ocultos"), &showHiddenOnly);

        ImGui::PushItemWidth(110);
        ImGui::InputInt(Tm(Tm("Deck ID", "ID de Mazo"), "ID de Mazo"), &deckId);
        ImGui::PopItemWidth();
        ImGui::SameLine();
        ImGui::Checkbox(Tm("Template deck", "Mazo plantilla"), &templateDeck);

        ImGui::Spacing();
        ImGui::BeginChild("talentlist", ImVec2(0, 220), true);
        int shown = 0;
        for (int i = 0; i < TalentDB::kTalentCount; ++i) {
            const TalentDB::Entry& e = TalentDB::kTalents[i];
            if (championFilter > 0 && lstrcmpA(e.champion, g_Champions[championFilter]) != 0) continue;
            if (showHiddenOnly && !e.hidden) continue;
            shown++;

            char label[128];
            wsprintfA(label, "%s  %d  %s##t%d",
                      e.hidden ? "[HIDDEN]" : "        ", e.id, e.name, i);
            // Hidden entries are tinted so they stand out at a glance.
            if (e.hidden) ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.8f, 0.45f, 1.0f)));
            if (ImGui::Selectable(label)) { talentId = e.id; QueueTalent(e.id); }
            if (e.hidden) ImGui::PopStyleColor();
            if (ImGui::IsItemHovered() && championFilter == 0) {
                ImGui::SetTooltip("%s", e.champion);
            }
        }
        if (shown == 0) ImGui::TextDisabled("Nothing matches that filter.");
        ImGui::EndChild();
        ImGui::TextDisabled("Click any talent to apply it immediately.");

        ImGui::PushItemWidth(110);
        ImGui::InputInt(Tm("Talent ID", "ID de Talentо"), &talentId);
        ImGui::PopItemWidth();
        ImGui::SameLine();
        if (ImGui::Button(Tm("Apply Talent", "Aplicar Talento"), ImVec2(120, 24))) QueueTalent(talentId);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), "LOADOUT CARDS");
        ImGui::TextWrapped("ServerRequestCard asks the server for a card at a given rank. "
            "ServerAllocateDevicePoint spends a loadout point on it - call it repeatedly to stack. "
            "Card IDs live in 02_REFERENCE_DATA/Paladins_Ids(1).txt.");

        ImGui::PushItemWidth(110);
        ImGui::InputInt(Tm("Card/Device ID", "ID de Carta/Dispositivo"), &cardDeviceId);
        ImGui::SliderInt(Tm("Rank", "Rango"), &cardRank, 1, 5);
        ImGui::PopItemWidth();

        ImGui::Button(Tm("Request Card", "Pedir Carta"), ImVec2(130, 24)) {
            g_PendingCard = true;
            wsprintfA(g_LastAction, "queued card %d rank %d", cardDeviceId, cardRank);
        }
        ImGui::SameLine();
        ImGui::Button(Tm("Allocate Points", "Asignar Puntos"), ImVec2(140, 24)) {
            g_AllocateRemaining = allocateRepeats;
            g_PendingAllocate = true;
            wsprintfA(g_LastAction, "queued %d allocates on %d", allocateRepeats, cardDeviceId);
        }
        ImGui::PushItemWidth(110);
        ImGui::SliderInt(Tm("Allocate count", "Cantidad de asignación"), &allocateRepeats, 1, 10);
        ImGui::PopItemWidth();

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text(\"%s\", g_LastAction);
        ImGui::Text(Tm("Talents sent: %d   Cards: %d   Allocates: %d",
                    "Talentos enviados: %d   Cartas: %d   Asignaciones: %d"),
                    g_TalentsSent, g_CardsSent, g_AllocatesSent);
        ImGui::SliderInt(Tm("Send interval (ms)", "Intervalo de envío (ms)"), &sendIntervalMs, 120, 1000);

        if (ImGui::TreeNode(Tm("Why sends are paced, and what to expect", "Por qué los envíos están pautados y qué esperar"))) {
            ImGui::TextWrapped(
                Tm("These are RELIABLE RPCs. Bursting reliable RPCs overflows the channel and closes "
                "the connection - that is the 'booted back to the menu' failure this project hit "
                "before. So bulk operations drain one per tick instead of looping.\n\n"
                "Honest expectation: talents are normally chosen at the loadout screen, so a "
                "mid-match request may still be refused even through the correct RPC. Every button "
                "reports what it sent, so if this doesn't work you will see SENT with no effect "
                "rather than silence - and that distinction is what tells us where to look next. "
                "Try it in the loadout/spawn phase first, before the gates open.",
                "Estas son RPC fiables. Exceder las RPC fiables rebasa el canal y cierra la "
                "conexión - esa es la falla de 'volver al menú' que este proyecto sufrió antes. "
                "Así que las operaciones en bulk drenan una por tick en lugar de hacer un bucle.\n\n"
                "Expectativa honesta: los talentos normalmente se eligen en la pantalla de loadout, "
                "así que una petición en medio de la partida aún puede ser rechazada aunque sea por "
                "la RPC correcta. Cada botón reporta lo que envió, así que si esto no funciona verás "
                "SENT sin efecto en lugar de silencio - y esa distinción es lo que nos dice dónde "
                "buscar después. Prueba en la fase de loadout/spawn primero, antes de que se abran "
                "las puertas."));
            ImGui::TreePop();
        }
    }
}
