#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "menus/VisibilityBoxes.h"
#include "Utils/SafeCalls.h"
#include <cmath>
#include <Windows.h>

// ============================================================================
// SPEEDEN — movement speed manipulation
//
// WHY THIS CAN WORK (the same principle that made respawn and fire modes work):
// UE3 movement is CLIENT-PREDICTED. The client simulates its own movement and
// then TELLS the server where it ended up:
//
//     ServerMove(TimeStamp, InAccel, ClientLoc, MoveFlags, ClientRoll, View)
//
// The server validates loosely but fundamentally trusts the client's reported
// position. So movement is another case of "the client declares something about
// itself", which is the category that works — unlike account state (cards,
// currency, entitlements), which is server-owned and never works.
//
// That is almost certainly how the other modder's speed feature works, and it's
// why speed hacks are historically easy in UE3 games while currency edits aren't.
//
// The fields are on APawn and are plain floats, so writing them is a RAW FIELD
// WRITE — no ProcessEvent call, safe from any thread, no crash surface:
//     GroundSpeed   0x036C (Net)
//     WaterSpeed    0x0370 (Net)
//     AirSpeed      0x0374 (Net)
//     AccelRate     0x037C (Net)
//
// They're marked (Net), i.e. replicated, so the server MAY correct them. Two
// mitigations: we re-apply every frame (so a correction gets overwritten again),
// and the multiplier is kept modest by default because a large value is the
// fastest way to trip server-side movement validation and get disconnected.
// ============================================================================

namespace Speeden {

    inline bool enabled = false;
    inline float speedMultiplier = 1.35f;   // deliberately modest default
    inline bool affectGround = true;
    inline bool affectAir = false;
    inline bool affectAccel = false;
    inline bool holdKeyOnly = false;        // only while SHIFT is held
    inline int  holdKey = VK_SHIFT;

    // Captured ONCE per pawn so we always scale from the champion's true base
    // rather than compounding our own previous multiplication.
    inline SDK::APawn* g_BasePawn = nullptr;
    inline float g_BaseGround = 0.0f;
    inline float g_BaseAir = 0.0f;
    inline float g_BaseAccel = 0.0f;
    inline bool  g_HaveBase = false;

    inline float g_LiveGround = 0.0f;   // for the UI readout
    inline int   g_ApplyCount = 0;

    // ---- JUMP HEIGHT ----
    // ServerSetJumpZ(float) is a SERVER RPC about YOUR OWN pawn, which is the
    // category that actually works (same as respawn readiness / fire mode).
    // Contrast with ServerSetServerFlags, which changes a MATCH RULE and is
    // therefore authority-gated and dead in real matches.
    inline bool  jumpEnabled = false;
    inline float jumpMultiplier = 1.5f;
    inline float g_BaseJumpZ = 0.0f;
    inline bool  g_PendingJumpApply = false;
    inline bool  g_PendingJumpReset = false;

    inline float TryGetJumpZ() {
        __try {
            if (!Globals::LocalPawn) return 0.0f;
            return Globals::LocalPawn->JumpZ;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0.0f; }
    }

    // ---- NO SPREAD / ACCURACY ----
    // ATgDevice::m_AccuracySettings (0x08D0, FAccuracySettings):
    //     bUsesAdvancedAccuracy, fMaxAccuracy, fMinAccuracy,
    //     fAccuracyLossPerShot, fAccuracyGainPerSec, fAccuracyGainDelay,
    //     nNumFreeShots
    //
    // Why this is reachable: the CLIENT computes where its shot went and reports
    // the trace/impact to the server (ServerInstantFire / ServerProjectileFire
    // both take the impact data as parameters). Spread is applied client-side
    // before that, so zeroing it is the client declaring its own shot — the
    // working category again.
    //
    // Pinning min == max accuracy and zeroing loss-per-shot removes both standing
    // spread growth and the midair inaccuracy penalty, since both are expressed
    // through the same accuracy value.
    inline bool  noSpreadEnabled = true; // ON by default - this is the recoil/spread fix that actually works
    inline bool  g_HaveAccuracyBase = false;
    inline SDK::ATgDevice* g_AccuracyDevice = nullptr;
    inline float g_BaseMinAcc = 0.0f, g_BaseMaxAcc = 0.0f, g_BaseLossPerShot = 0.0f;
    inline int   g_BaseFreeShots = 0;
    inline float g_LiveMinAcc = 0.0f;

    inline bool TryCaptureAccuracy(SDK::ATgDevice* d) {
        __try {
            g_BaseMinAcc      = d->m_AccuracySettings.fMinAccuracy;
            g_BaseMaxAcc      = d->m_AccuracySettings.fMaxAccuracy;
            g_BaseLossPerShot = d->m_AccuracySettings.fAccuracyLossPerShot;
            g_BaseFreeShots   = d->m_AccuracySettings.nNumFreeShots;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryApplyNoSpread(SDK::ATgDevice* d) {
        __try {
            // Pin accuracy at its best value and stop it ever degrading.
            d->m_AccuracySettings.fMinAccuracy = g_BaseMaxAcc;
            d->m_AccuracySettings.fMaxAccuracy = g_BaseMaxAcc;
            d->m_AccuracySettings.fAccuracyLossPerShot = 0.0f;
            d->m_AccuracySettings.nNumFreeShots = 9999; // every shot is a "free" (unpenalised) shot
            g_LiveMinAcc = d->m_AccuracySettings.fMinAccuracy;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryRestoreAccuracy(SDK::ATgDevice* d) {
        __try {
            d->m_AccuracySettings.fMinAccuracy = g_BaseMinAcc;
            d->m_AccuracySettings.fMaxAccuracy = g_BaseMaxAcc;
            d->m_AccuracySettings.fAccuracyLossPerShot = g_BaseLossPerShot;
            d->m_AccuracySettings.nNumFreeShots = g_BaseFreeShots;
            g_LiveMinAcc = d->m_AccuracySettings.fMinAccuracy;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ================= TIME DILATION SPEEDHACK =================
    // WHY THIS EXISTS: writing GroundSpeed worked in the shooting range and did
    // NOTHING in real matches (tested). But Anubis ships a working "Speedhack,
    // range -2 to +10" — and that RANGE is the tell. -2..+10 is not a speed in
    // world units, it's a MULTIPLIER. Which points at time dilation, not speed.
    //
    //   AActor::CustomTimeDilation   (0x00B8)  <- NOT marked Net
    //   WorldInfo::TimeDilation      (0x04E4)  (Net) - server owned, avoid
    //
    // CustomTimeDilation is PER-ACTOR and not replicated: it scales how fast that
    // one actor's simulation advances. Set it on our own pawn and we move, fire
    // and animate faster while everything else runs at normal speed. Because the
    // pawn then genuinely simulates further per frame, the position it reports via
    // ServerMove is self-consistent — which is exactly why this survives where a
    // raw GroundSpeed write doesn't.
    inline bool  timeDilationEnabled = false;
    inline float timeDilationValue = 1.4f;
    inline float g_BaseCustomDilation = 1.0f;
    inline bool  g_HaveDilationBase = false;
    inline float g_LiveDilation = 1.0f;

    inline bool TryCaptureDilation(SDK::APawn* p) {
        __try {
            g_BaseCustomDilation = p->CustomTimeDilation;
            if (g_BaseCustomDilation <= 0.01f) g_BaseCustomDilation = 1.0f;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryApplyDilation(SDK::APawn* p, float v) {
        __try {
            p->CustomTimeDilation = v;
            g_LiveDilation = p->CustomTimeDilation;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryRestoreDilation(SDK::APawn* p) {
        __try {
            p->CustomTimeDilation = g_BaseCustomDilation;
            g_LiveDilation = p->CustomTimeDilation;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ================= HIDE AMMO =================
    // Anubis lists: "Hide Ammo — Prevents client/server desync during rapid fire."
    // That single line explains why our fire-rate boost didn't work: firing faster
    // than the server expects breaks the AMMO TRANSACTION ledger, the server sees
    // an inconsistency, and it rejects the shots.
    //
    // The relevant machinery on ATgDevice:
    //   r_nAmmoClipCount             (Net)   server's authoritative count
    //   c_nSimLocalAmmoClipCount             client's simulated count (NOT Net)
    //   m_AmmoTransactions / m_Delayed...    the ledger the server verifies
    //   DesyncAmmoTransactionID(int)         shifts the transaction id
    //
    // Keeping the CLIENT-side simulated count topped up stops the client
    // generating the deficit transactions that trip verification. This is what
    // makes a fire-rate increase actually land, so it belongs next to it.
    inline bool  hideAmmoEnabled = false;
    inline int   hideAmmoTopUp = 0;      // 0 = hold at max clip
    inline int   g_LiveSimAmmo = -1, g_LiveNetAmmo = -1;
    inline int   g_AmmoWrites = 0;

    inline bool TryTopUpAmmo(SDK::ATgDevice* d, int target) {
        __try {
            g_LiveNetAmmo = d->r_nAmmoClipCount;
            g_LiveSimAmmo = d->c_nSimLocalAmmoClipCount;
            // Only the CLIENT-side simulated count is touched. r_nAmmoClipCount is
            // (Net) — writing that is the GroundSpeed mistake again.
            if (target > 0) d->c_nSimLocalAmmoClipCount = target;
            else {
                int mode = (int)d->CurrentFireMode;
                int count = (int)d->m_FireMode.Num();
                if (mode >= 0 && mode < count) {
                    SDK::UTgDeviceFire* fm = d->m_FireMode[mode];
                    if (fm && fm->m_nAmmoClipSize > 0)
                        d->c_nSimLocalAmmoClipCount = fm->m_nAmmoClipSize;
                }
            }
            g_LiveSimAmmo = d->c_nSimLocalAmmoClipCount;
            g_AmmoWrites++;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ================= NO RECOIL =================
    // ATgDevice::m_RecoilSettings[5] — one FRecoilSettings per fire mode:
    //     bUsesRecoil (bit), fRecoilReductionPerSec,
    //     fRecoilCenterDelay, fRecoilSmoothRate
    //
    // Clearing bUsesRecoil switches recoil off outright. This is the same
    // category as no-spread: recoil kicks the CLIENT's view, and the client then
    // reports where it was aiming — so it shapes the shot event we declare, not a
    // stat the server holds about us.
    //
    // Note r_nRecoilMultiCenti (0x09C0) and r_nRecoilSeed (0x09D4) ARE marked
    // (Net) and are deliberately left alone; writing those would just be
    // overwritten, the GroundSpeed mistake again.
    inline bool  noRecoilEnabled = true; // ON by default alongside no-spread - harmless to run even though no-spread is the one that actually changes shot placement
    inline SDK::ATgDevice* g_RecoilDevice = nullptr;
    inline bool  g_HaveRecoilBase = false;
    inline int   g_BaseUsesRecoil[5] = {};
    inline float g_BaseSmoothRate[5] = {};
    inline int   g_RecoilModesTouched = 0;

    inline bool TryCaptureRecoil(SDK::ATgDevice* d) {
        __try {
            for (int i = 0; i < 5; i++) {
                g_BaseUsesRecoil[i] = d->m_RecoilSettings[i].bUsesRecoil ? 1 : 0;
                g_BaseSmoothRate[i] = d->m_RecoilSettings[i].fRecoilSmoothRate;
            }
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryApplyNoRecoil(SDK::ATgDevice* d) {
        __try {
            int touched = 0;
            for (int i = 0; i < 5; i++) {
                d->m_RecoilSettings[i].bUsesRecoil = 0;
                // Instant recentre as well, so any recoil already applied when
                // you toggled this doesn't linger.
                d->m_RecoilSettings[i].fRecoilReductionPerSec = 10000.0f;
                d->m_RecoilSettings[i].fRecoilCenterDelay = 0.0f;
                touched++;
            }
            g_RecoilModesTouched = touched;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryRestoreRecoil(SDK::ATgDevice* d) {
        __try {
            for (int i = 0; i < 5; i++) {
                d->m_RecoilSettings[i].bUsesRecoil = g_BaseUsesRecoil[i] ? 1 : 0;
                d->m_RecoilSettings[i].fRecoilSmoothRate = g_BaseSmoothRate[i];
            }
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ================= ULT CHARGE RATE (experiment) =================
    // Instant ultimate is NOT achievable the way it's usually described:
    //     ATgRepInfo_Player::r_nUltimateCharge          (Net)
    //     ATgRepInfo_Player::r_nRequiredUltimateCharge  (Net)
    // Both replicated, i.e. server-owned stats — writing them locally just gets
    // overwritten, exactly like GroundSpeed and health.
    //
    // ONE thing is worth a single test though: ATgPawn::m_fEnergyChargeMultiplier
    // (0x2CB4) is NOT marked Net. If ult charge accrual is computed client-side
    // and reported, raising this would work. If the server computes it (my
    // expectation), it won't. Cheap to find out, so it's exposed as a clearly
    // labelled experiment rather than a promised feature.
    inline bool  ultChargeExperiment = false;
    inline float ultChargeMultiplier = 3.0f;
    inline float g_BaseEnergyMult = 0.0f;
    inline bool  g_HaveEnergyBase = false;
    inline float g_LiveEnergyMult = 0.0f;

    inline bool TryCaptureEnergyMult(SDK::ATgPawn* p) {
        __try { g_BaseEnergyMult = p->m_fEnergyChargeMultiplier; return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryApplyEnergyMult(SDK::ATgPawn* p, float mult) {
        __try {
            p->m_fEnergyChargeMultiplier = (g_BaseEnergyMult > 0.01f ? g_BaseEnergyMult : 1.0f) * mult;
            g_LiveEnergyMult = p->m_fEnergyChargeMultiplier;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryRestoreEnergyMult(SDK::ATgPawn* p) {
        __try {
            if (g_BaseEnergyMult > 0.0f) p->m_fEnergyChargeMultiplier = g_BaseEnergyMult;
            g_LiveEnergyMult = p->m_fEnergyChargeMultiplier;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ================= FIRE RATE (attack speed) =================
    // This is the strongest-fitting feature for the EVENT model, and the user's
    // Hair Trigger observation is what pointed at it.
    //
    // Evidence it's client-declared rather than a server-owned stat:
    //   ServerStartFire(..., float fAttackSpeedPercChange)
    //   StartFiringOnServer(..., float fAttackSpeedPercChange)
    // The client SENDS its attack speed as a PARAMETER OF THE FIRE EVENT. The
    // server doesn't look it up — it's told.
    //
    // And this field exists:
    //   ATgDevice::s_fAttackSpeedPercChangeLeniency   // 0x09E8
    // A "leniency" value only makes sense if the server deliberately TOLERATES
    // client-reported attack speed within a margin. So modest changes should be
    // accepted and large ones rejected — start small.
    //
    // Also explains why Hair Trigger keeps working after a Barik fire-mode swap:
    // it's a stat multiplier carried with the shot, not mode-specific code.
    //
    // We write m_fSimulatedAttackSpeedPercChange (the client-predicted value,
    // 0x09E4) rather than r_fAttackSpeedPercChange (0x09E0, marked Net and thus
    // server-owned — writing that would just be overwritten, the GroundSpeed
    // mistake again).
    inline bool  fireRateEnabled = false;
    inline float fireRatePercent = 30.0f;   // Hair Trigger itself is +30%
    inline bool  alsoWriteCached = true;    // m_fCachedAttackSpeedPercChange too
    inline SDK::ATgDevice* g_FireRateDevice = nullptr;
    inline float g_BaseSimAttack = 0.0f, g_BaseCachedAttack = 0.0f;
    inline bool  g_HaveFireRateBase = false;
    inline float g_LiveSimAttack = 0.0f, g_LiveLeniency = 0.0f;

    inline bool TryCaptureFireRate(SDK::ATgDevice* d) {
        __try {
            g_BaseSimAttack    = d->m_fSimulatedAttackSpeedPercChange;
            g_BaseCachedAttack = d->m_fCachedAttackSpeedPercChange;
            g_LiveLeniency     = d->s_fAttackSpeedPercChangeLeniency;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryApplyFireRate(SDK::ATgDevice* d, float pct) {
        __try {
            d->m_fSimulatedAttackSpeedPercChange = g_BaseSimAttack + pct;
            if (alsoWriteCached) d->m_fCachedAttackSpeedPercChange = g_BaseCachedAttack + pct;
            g_LiveSimAttack = d->m_fSimulatedAttackSpeedPercChange;
            g_LiveLeniency  = d->s_fAttackSpeedPercChangeLeniency;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryRestoreFireRate(SDK::ATgDevice* d) {
        __try {
            d->m_fSimulatedAttackSpeedPercChange = g_BaseSimAttack;
            d->m_fCachedAttackSpeedPercChange = g_BaseCachedAttack;
            g_LiveSimAttack = d->m_fSimulatedAttackSpeedPercChange;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ================= PROJECTILE SPEED =================
    // AProjectile carries Speed (0x0280) and MaxSpeed (0x0284), both (Net).
    // They're stats, BUT projectiles are different from GroundSpeed in one
    // decisive way: the client SPAWNS SIMULATED PROJECTILES itself
    // (SpawnSimulatedProjectile) and reports the impact
    // (ServerProjectileFire carries the trace). So the projectile's flight is
    // part of the shot EVENT the client describes, not a capability the server
    // looks up about you — which is the category that works.
    //
    // Implementation: projectiles are spawned per shot and die quickly, so we
    // scan GObjects for LIVE ones and boost them. Only projectiles whose Owner
    // is our pawn are touched — boosting someone else's would be changing
    // another player's state, which never replicates anyway.
    inline bool  projSpeedEnabled = false;
    inline float projSpeedMultiplier = 1.5f;
    inline int   g_ProjBoosted = 0;
    inline int   g_ProjSeen = 0;

    inline bool TryIsOurProjectile(SDK::UObject* obj, SDK::UClass* projCls) {
        __try {
            if (!obj || !projCls || !obj->IsA(projCls)) return false;
            SDK::AActor* a = (SDK::AActor*)obj;
            if (a->bDeleteMe || a->bPendingDelete) return false;
            // Ours only — Owner or Instigator points back at our pawn.
            if (a->Owner == (SDK::AActor*)Globals::LocalPawn) return true;
            if (a->Instigator == Globals::LocalPawn) return true;
            return false;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryBoostProjectile(SDK::UObject* obj, float mult) {
        __try {
            SDK::AProjectile* p = (SDK::AProjectile*)obj;
            if (p->Speed <= 1.0f) return false;      // already handled / not moving
            if (p->Speed > 100000.0f) return false;  // sanity, don't compound forever
            p->Speed *= mult;
            if (p->MaxSpeed > 1.0f) p->MaxSpeed *= mult;
            // Velocity is the live vector actually moving it — scaling Speed
            // alone does nothing for an already-launched projectile.
            p->Velocity.X *= mult;
            p->Velocity.Y *= mult;
            p->Velocity.Z *= mult;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline SDK::UObject* TryGetObj(SDK::TAntiCheatArray<SDK::UObject*>& arr, size_t i) {
        __try {
            if (!arr.IsValidIndex(i)) return nullptr;
            return arr[i];
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // Each projectile is boosted ONCE — tracked by pointer, because this runs
    // every frame and repeatedly multiplying the same projectile would send it
    // to infinity within a few frames.
    inline SDK::UObject* g_BoostedProj[64] = {};
    inline int g_BoostedProjCursor = 0;

    inline bool AlreadyBoosted(SDK::UObject* o) {
        for (int i = 0; i < 64; i++) if (g_BoostedProj[i] == o) return true;
        return false;
    }
    inline void MarkBoosted(SDK::UObject* o) {
        g_BoostedProj[g_BoostedProjCursor % 64] = o;
        g_BoostedProjCursor++;
    }

    inline void UpdateProjectiles() {
        if (!projSpeedEnabled || !Globals::LocalPawn) return;
        SDK::UClass* projCls = nullptr;
        __try { projCls = SDK::ATgProjectile::StaticClass(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { projCls = nullptr; }
        if (!projCls) return;

        auto& objects = SDK::UObject::GetGlobalObjects();
        size_t count = 0;
        __try { count = objects.Num(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return; }

        int seen = 0;
        for (size_t i = 0; i < count; i++) {
            SDK::UObject* o = TryGetObj(objects, i);
            if (!TryIsOurProjectile(o, projCls)) continue;
            seen++;
            if (AlreadyBoosted(o)) continue;
            if (TryBoostProjectile(o, projSpeedMultiplier)) {
                MarkBoosted(o);
                g_ProjBoosted++;
            }
        }
        g_ProjSeen = seen;
    }

    // ================= TELEPORT =================
    // AActor::SetLocation is the engine's own move primitive; it returns false
    // when the destination is blocked, so it won't stuff you inside geometry.
    // Position is genuinely client-declared (ServerMove reports where you ended
    // up), so this is in the working category — but a LARGE instant jump is
    // exactly what server movement validation looks for, so expect rubber-band
    // or disconnect if you go far.
    inline bool  teleportToTargetEnabled = false;
    inline float teleportStandoff = 150.0f;   // horizontal stop-short distance
    inline float teleportZLift = 40.0f;       // arrive slightly ABOVE, so we settle onto ground
    // Default changed OFF MOUSE5 — that's commonly already bound in-game, so it
    // would fire a teleport at the same time as an ability. T is unbound by
    // default in Paladins and is fully rebindable below.
    inline int   teleportKey = 'T';
    inline bool  teleportOnKeyOnly = true;
    inline bool  teleportAutoOnTarget = false; // fire the moment the reticle lands on someone
    inline bool  g_BindingTeleportKey = false; // "click to bind" listening state
    inline ULONGLONG g_LastAutoTeleportMs = 0;
    inline float teleportAutoCooldownSec = 2.0f;

    // Readable name for whatever is bound, so the UI isn't showing raw numbers.
    inline const char* KeyName(int vk) {
        switch (vk) {
            case VK_LBUTTON:  return "Mouse1";
            case VK_RBUTTON:  return "Mouse2";
            case VK_MBUTTON:  return "Mouse3";
            case VK_XBUTTON1: return "Mouse4";
            case VK_XBUTTON2: return "Mouse5";
            case VK_SHIFT:    return "Shift";
            case VK_CONTROL:  return "Ctrl";
            case VK_MENU:     return "Alt";
            case VK_SPACE:    return "Space";
            case VK_TAB:      return "Tab";
            case VK_CAPITAL:  return "CapsLock";
            case VK_OEM_3:    return "`";
            default: break;
        }
        static char buf[16];
        if (vk >= 'A' && vk <= 'Z') { buf[0] = (char)vk; buf[1] = 0; return buf; }
        if (vk >= '0' && vk <= '9') { buf[0] = (char)vk; buf[1] = 0; return buf; }
        if (vk >= VK_F1 && vk <= VK_F24) { snprintf(buf, sizeof(buf), "F%d", vk - VK_F1 + 1); return buf; }
        snprintf(buf, sizeof(buf), "VK 0x%02X", vk);
        return buf;
    }

    // While "binding" is active, grab the first key/button actually pressed.
    // Escape cancels so you can't get stuck in listening mode.
    inline void PollKeyBinding() {
        if (!g_BindingTeleportKey) return;
        if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) { g_BindingTeleportKey = false; return; }
        for (int vk = 1; vk < 256; vk++) {
            if (vk == VK_ESCAPE) continue;
            if (vk == VK_LBUTTON) continue; // reserved: that's the click on the button itself
            if (GetAsyncKeyState(vk) & 0x8000) {
                teleportKey = vk;
                g_BindingTeleportKey = false;
                return;
            }
        }
    }
    inline int   g_TeleportCount = 0;
    inline bool  g_LastTeleportOk = false;
    inline char  g_TeleportTargetName[32] = {};

    // Teleports to whoever the reticle is currently on. Reuses the target the
    // reticle already resolves (enemy-only, LOS-gated) instead of doing its own
    // target selection — so it can only send you where you were already
    // deliberately looking.
    inline void UpdateTeleport() {
        g_TeleportTargetName[0] = 0;
        if (!teleportToTargetEnabled || !Globals::LocalPawn) return;
        if (!VisibilityBoxes::g_ReticleOnEnemy) return;
        SDK::ATgPawn* target = VisibilityBoxes::g_ReticleTargetPawn;
        if (!target) return;

        strncpy_s(g_TeleportTargetName, sizeof(g_TeleportTargetName),
                  VisibilityBoxes::g_ReticleTargetName, _TRUNCATE);

        // Never continuous. Two ways to fire, both rate-limited:
        //  - key: edge-triggered, so holding it teleports exactly once
        //  - auto: fires when the reticle lands on someone, with a cooldown
        // Holding/repeating would send a teleport every frame and guarantee a
        // disconnect, so both paths are guarded.
        bool fire = false;
        static bool wasDown = false;
        bool down = (GetAsyncKeyState(teleportKey) & 0x8000) != 0;
        if (down && !wasDown) fire = true;
        wasDown = down;

        if (!fire && teleportAutoOnTarget) {
            ULONGLONG now = GetTickCount64();
            if (now - g_LastAutoTeleportMs > (ULONGLONG)(teleportAutoCooldownSec * 1000.0f)) {
                g_LastAutoTeleportMs = now;
                fire = true;
            }
        }
        if (!fire) return;

        float tx = 0, ty = 0, tz = 0;
        __try {
            tx = target->Location.X; ty = target->Location.Y; tz = target->Location.Z;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return; }

        float mx = 0, my = 0, mz = 0;
        if (!SafeCalls::GetPawnLocation(&mx, &my, &mz)) return;

        // Stop short along the line between us, so we land NEXT to them rather
        // than inside their collision (which SetLocation would refuse anyway).
        // The standoff is applied on the HORIZONTAL plane only — pulling back
        // along the full 3D vector would drag us downward when the target is
        // below us, which is how you end up inside the floor.
        float dx = tx - mx, dy = ty - my, dz = tz - mz;
        float flatLen = sqrtf(dx * dx + dy * dy);
        if (flatLen < 1.0f) return;
        float flatScale = (flatLen - teleportStandoff) / flatLen;
        if (flatScale < 0.0f) flatScale = 0.0f;

        float destX = mx + dx * flatScale;
        float destY = my + dy * flatScale;
        // Match their height, then lift slightly. Arriving a little ABOVE the
        // destination lets the engine settle us onto the surface instead of
        // risking a spawn inside it — clipping through the map is the main way
        // this goes wrong.
        float destZ = tz + teleportZLift;

        g_LastTeleportOk = SafeCalls::SetPawnLocation(destX, destY, destZ);

        // CONFIRM TO THE SERVER.
        // SetLocation only moves us locally. The server learns our position from
        // the next ServerMove, which the engine sends on its own schedule — so a
        // teleport can be corrected before it's ever reported. Zeroing velocity
        // stops the movement code from treating the jump as a violent impulse
        // (which is what triggers the rubber-band), and gives the next ServerMove
        // a clean, stationary position to report.
        if (g_LastTeleportOk) {
            __try {
                Globals::LocalPawn->Velocity.X = 0.0f;
                Globals::LocalPawn->Velocity.Y = 0.0f;
                Globals::LocalPawn->Velocity.Z = 0.0f;
                // Keep the replicated location field in step with the real one,
                // so whatever reads it next sees the new position.
                Globals::LocalPawn->Location.X = destX;
                Globals::LocalPawn->Location.Y = destY;
                Globals::LocalPawn->Location.Z = destZ;
            }
            __except (EXCEPTION_EXECUTE_HANDLER) { }
            g_TeleportCount++;
        }
    }

    inline bool TryCaptureBase(SDK::APawn* pawn) {
        __try {
            g_BaseGround = pawn->GroundSpeed;
            g_BaseAir    = pawn->AirSpeed;
            g_BaseAccel  = pawn->AccelRate;
            return (g_BaseGround > 1.0f); // sanity: a real champion has a real speed
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryApply(SDK::APawn* pawn, float mult) {
        __try {
            if (affectGround) pawn->GroundSpeed = g_BaseGround * mult;
            if (affectAir)    pawn->AirSpeed    = g_BaseAir * mult;
            if (affectAccel)  pawn->AccelRate   = g_BaseAccel * mult;
            g_LiveGround = pawn->GroundSpeed;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryRestore(SDK::APawn* pawn) {
        __try {
            if (g_BaseGround > 1.0f) pawn->GroundSpeed = g_BaseGround;
            if (g_BaseAir > 0.0f)    pawn->AirSpeed    = g_BaseAir;
            if (g_BaseAccel > 0.0f)  pawn->AccelRate   = g_BaseAccel;
            g_LiveGround = pawn->GroundSpeed;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Raw field writes only — safe to call every frame from the render thread.
    //
    // includeTeleportAndKeybind=false SKIPS PollKeyBinding()/UpdateTeleport()
    // (the one part of this function that touches SafeCalls, i.e. a scripted
    // ProcessEvent call) so the rest — speed, no-spread, no-recoil, fire
    // rate, hide-ammo, time dilation, energy experiment, all pure struct-
    // field writes — can also run from HookedProcessEvent, on machines where
    // hkPresent (the only place this was EVER called before) never fires at
    // all. See the g_SafeThreadSpeedenApplied logging at the HookedProcessEvent
    // call site for how this gets confirmed rather than assumed.
    inline void Update(bool includeTeleportAndKeybind = true) {
        SDK::APawn* pawn = Globals::LocalPawn;
        if (!pawn) { g_HaveBase = false; g_BasePawn = nullptr; return; }

        // Re-capture the base whenever the pawn changes (respawn, champion swap).
        // Without this, the multiplier would compound on an already-boosted value.
        if (pawn != g_BasePawn || !g_HaveBase) {
            g_BasePawn = pawn;
            g_HaveBase = TryCaptureBase(pawn);
            if (!g_HaveBase) return;
        }

        bool active = enabled;
        if (active && holdKeyOnly && !(GetAsyncKeyState(holdKey) & 0x8000)) active = false;

        // *** WARP FIX ***
        // The old code called TryRestore(pawn) EVERY FRAME while disabled, which
        // wrote GroundSpeed/AirSpeed/AccelRate from a baseline captured at spawn.
        // Those fields are (Net). In a real match your speed legitimately changes
        // constantly — Prowl, buffs, slows, cripples — so every frame we were
        // stomping the server's current value back to the spawn value, the server
        // corrected us, and the result was WARPY MOVEMENT *with the feature off*.
        //
        // Now: only write while ACTIVE, and restore exactly ONCE on the
        // active->inactive transition. When off, we touch nothing.
        static bool s_WasActive = false;
        if (active) {
            // Re-applied every frame on purpose: these fields are replicated, so
            // a server correction would otherwise stick.
            if (TryApply(pawn, speedMultiplier)) g_ApplyCount++;
            s_WasActive = true;
        } else if (s_WasActive) {
            TryRestore(pawn);      // one-shot cleanup, then hands off
            s_WasActive = false;
        }

        // ---- accuracy / no-spread ----
        // Re-captured per weapon, since each device has its own accuracy profile
        // and fire modes can differ.
        SDK::ATgDevice* wep = Globals::LocalWeapon;
        if (wep) {
            if (wep != g_AccuracyDevice || !g_HaveAccuracyBase) {
                g_AccuracyDevice = wep;
                g_HaveAccuracyBase = TryCaptureAccuracy(wep);
            }
            if (g_HaveAccuracyBase) {
                // Same one-shot-restore rule as speed above: never write while off.
                static bool s_SpreadWasActive = false;
                if (noSpreadEnabled) { TryApplyNoSpread(wep); s_SpreadWasActive = true; }
                else if (s_SpreadWasActive) { TryRestoreAccuracy(wep); s_SpreadWasActive = false; }
            }
            // Fire rate, captured per weapon for the same reason as accuracy.
            if (wep != g_FireRateDevice || !g_HaveFireRateBase) {
                g_FireRateDevice = wep;
                g_HaveFireRateBase = TryCaptureFireRate(wep);
            }
            if (g_HaveFireRateBase) {
                // One-shot restore, same reason as speed/accuracy above.
                static bool s_FireRateWasActive = false;
                if (fireRateEnabled) { TryApplyFireRate(wep, fireRatePercent); s_FireRateWasActive = true; }
                else if (s_FireRateWasActive) { TryRestoreFireRate(wep); s_FireRateWasActive = false; }
            }
            // Hide Ammo — keeps the client-side simulated clip topped up so rapid
            // fire doesn't generate the deficit transactions the server rejects.
            if (hideAmmoEnabled) TryTopUpAmmo(wep, hideAmmoTopUp);

            // Recoil, also per weapon.
            if (wep != g_RecoilDevice || !g_HaveRecoilBase) {
                g_RecoilDevice = wep;
                g_HaveRecoilBase = TryCaptureRecoil(wep);
            }
            if (g_HaveRecoilBase) {
                if (noRecoilEnabled) TryApplyNoRecoil(wep);
                else                 TryRestoreRecoil(wep);
            }
        } else {
            g_HaveAccuracyBase = false;
            g_AccuracyDevice = nullptr;
        }

        if (g_BaseJumpZ <= 0.0f) g_BaseJumpZ = TryGetJumpZ();

        // Time dilation — pawn-level.
        if (!g_HaveDilationBase) g_HaveDilationBase = TryCaptureDilation(pawn);
        if (g_HaveDilationBase) {
            bool dilActive = timeDilationEnabled;
            if (dilActive && holdKeyOnly && !(GetAsyncKeyState(holdKey) & 0x8000)) dilActive = false;
            if (dilActive) TryApplyDilation(pawn, timeDilationValue);
            else           TryRestoreDilation(pawn);
        }

        // Ult charge experiment — pawn-level, so it lives here not in the weapon block.
        if (!g_HaveEnergyBase) g_HaveEnergyBase = TryCaptureEnergyMult((SDK::ATgPawn*)pawn);
        if (g_HaveEnergyBase) {
            if (ultChargeExperiment) TryApplyEnergyMult((SDK::ATgPawn*)pawn, ultChargeMultiplier);
            else                     TryRestoreEnergyMult((SDK::ATgPawn*)pawn);
        }

        UpdateProjectiles();
        if (includeTeleportAndKeybind) {
            PollKeyBinding();   // must run before UpdateTeleport so a new bind applies immediately
            UpdateTeleport();   // uses SafeCalls (scripted) - stays render-thread-only, unchanged
        }
    }

    inline void DrawControls(bool inMatch) {
        ImGui::TextColored(Ink(ImVec4(0.5f, 1.0f, 0.9f, 1.0f)), "SPEEDEN — movement speed");
        ImGui::TextWrapped("Works on the same principle as instant respawn and fire modes: UE3 "
            "movement is CLIENT-PREDICTED. The client simulates its own movement and reports its "
            "position to the server via ServerMove, so movement is something the client DECLARES "
            "about itself — the category that actually works. That's why speed is achievable while "
            "currency and card levels never were.");
        ImGui::Separator();

        if (!inMatch) { ImGui::TextDisabled("Join a match first."); return; }

        ImGui::Checkbox("Enable", &enabled);
        ImGui::SameLine();
        ImGui::Checkbox("Only while holding SHIFT", &holdKeyOnly);

        ImGui::SliderFloat("Speed multiplier", &speedMultiplier, 1.0f, 3.0f, "%.2fx");
        if (speedMultiplier > 1.8f) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.6f, 0.4f, 1.0f)),
                "Above ~1.8x is where server movement validation tends to notice.");
            ImGui::TextWrapped("If you get rubber-banded back or disconnected, that's the server "
                "rejecting the reported positions — lower this.");
        }

        ImGui::Checkbox("Ground speed", &affectGround);
        ImGui::SameLine();
        ImGui::Checkbox("Air speed", &affectAir);
        ImGui::SameLine();
        ImGui::Checkbox("Acceleration", &affectAccel);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Base ground speed : %.1f", g_BaseGround);
        ImGui::Text("Live ground speed : %.1f", g_LiveGround);
        ImGui::Text("Applies this session: %d", g_ApplyCount);
        ImGui::TextDisabled("Base is captured once per pawn, so the multiplier can't compound on");
        ImGui::TextDisabled("itself. It re-captures automatically on respawn or champion change.");
        ImGui::TextDisabled("Re-applied every frame because these fields are replicated — a server");
        ImGui::TextDisabled("correction would otherwise overwrite it.");

        // ---- JUMP ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), "JUMP HEIGHT");
        ImGui::TextWrapped("Uses ServerSetJumpZ() — a server RPC about YOUR OWN pawn, which is the "
            "category that works. (Compare ServerSetServerFlags, which changes a match rule and is "
            "dead in real matches.)");
        ImGui::SliderFloat("Jump multiplier", &jumpMultiplier, 1.0f, 3.0f, "%.2fx");
        if (ImGui::Button("Apply Jump Height", ImVec2(170, 26))) g_PendingJumpApply = true;
        ImGui::SameLine();
        if (ImGui::Button("Reset Jump")) g_PendingJumpReset = true;
        ImGui::Text("Base JumpZ: %.1f   |   Live: %.1f", g_BaseJumpZ, TryGetJumpZ());

        // ---- NO SPREAD ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), "NO SPREAD / NO MIDAIR INACCURACY");
        ImGui::TextWrapped("Pins accuracy at its best value and stops it degrading. This covers both "
            "standing spread growth AND the midair penalty, since both run through the same accuracy "
            "value. Reachable because the CLIENT computes its own shot trace and reports it to the "
            "server (ServerInstantFire takes the impact as a parameter).");
        ImGui::Checkbox("Enable no-spread", &noSpreadEnabled);
        ImGui::Text("Base accuracy min/max: %.3f / %.3f", g_BaseMinAcc, g_BaseMaxAcc);
        ImGui::Text("Live min accuracy    : %.3f", g_LiveMinAcc);
        ImGui::TextDisabled("Captured per weapon, so it restores correctly on weapon/mode change.");
        if (!g_HaveAccuracyBase) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)), "No weapon accuracy data yet.");
        }

        // ---- TIME DILATION (the likely real speedhack) ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)), "TIME DILATION  (fire rate, NOT movement)");
        ImGui::TextWrapped("TESTED: this applies, but not to movement. Reported result was firing "
            "MUCH faster with no change in movement speed. That is not a failure - it proves "
            "CustomTimeDilation is being written and is taking effect, because the weapon's local "
            "fire timers sped up visibly.");
        ImGui::TextWrapped("What it tells us: movement speed does NOT come from the actor's local "
            "time scale. It comes from the replicated GroundSpeed, which the server evaluates "
            "independently of how fast our actor ticks. So we get faster timers while the server "
            "still moves us at the normal rate.");
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.7f, 1.0f)),
            "So: use this as a FIRE RATE hack (it works), not a speedhack.");
        ImGui::TextWrapped("Pair it with Hide Ammo below - firing faster is exactly what generates "
            "the ammo desync the Anubis dev named. For actual movement speed, the route is chained "
            "small teleport hops, which change reported POSITION (something the client may declare) "
            "rather than asking for a faster SPEED (a stat it may not).");
        ImGui::Checkbox("Enable time dilation", &timeDilationEnabled);
        ImGui::SliderFloat("Dilation", &timeDilationValue, 0.2f, 3.0f, "%.2fx");
        ImGui::Text("Base: %.2f   |   Live: %.2f", g_BaseCustomDilation, g_LiveDilation);
        ImGui::TextDisabled("Respects the hold-key option above.");

        // ---- HIDE AMMO ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)), "HIDE AMMO  (makes fire rate actually land)");
        ImGui::TextWrapped("Anubis lists 'Hide Ammo - prevents client/server desync during rapid "
            "fire'. That one line explains why the fire-rate boost didn't work: firing faster than "
            "expected breaks the ammo TRANSACTION ledger, the server sees the inconsistency, and "
            "rejects the shots. Keeping the client-side simulated clip topped up stops those deficit "
            "transactions being generated. Turn this ON together with fire rate.");
        ImGui::Checkbox("Enable hide ammo", &hideAmmoEnabled);
        ImGui::PushItemWidth(120);
        ImGui::InputInt("Force clip to (0 = max)", &hideAmmoTopUp);
        ImGui::PopItemWidth();
        ImGui::Text("Sim (client): %d   |   Net (server): %d", g_LiveSimAmmo, g_LiveNetAmmo);
        ImGui::Text("Writes: %d", g_AmmoWrites);
        ImGui::TextDisabled("Only c_nSimLocalAmmoClipCount is touched. r_nAmmoClipCount is (Net) —");
        ImGui::TextDisabled("writing that would just be overwritten.");

        // ---- FIRE RATE ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)), "FIRE RATE  (best-fitting lead)");
        ImGui::TextWrapped("Barik's Hair Trigger (+30% Blunderbuss) keeps working even after you "
            "switch him to slug — which means it's a STAT MULTIPLIER, not mode-specific code. And "
            "the client SENDS that multiplier with every shot: ServerStartFire takes "
            "fAttackSpeedPercChange as a parameter. The server is told, not asked.");
        ImGui::Checkbox("Enable fire rate boost", &fireRateEnabled);
        ImGui::SliderFloat("Attack speed %", &fireRatePercent, 5.0f, 200.0f, "+%.0f%%");
        ImGui::TextDisabled("Hair Trigger is +30%. Start there — it's a value the game itself uses.");
        ImGui::Checkbox("Also write the cached value", &alsoWriteCached);
        ImGui::Text("Base sim attack : %.2f", g_BaseSimAttack);
        ImGui::Text("Live sim attack : %.2f", g_LiveSimAttack);
        ImGui::Text("Server leniency : %.2f", g_LiveLeniency);
        ImGui::TextWrapped("That leniency field is the interesting one — a tolerance value only "
            "exists because the server deliberately ACCEPTS client-reported attack speed within a "
            "margin. Stay near it and it should stick; go far past it and expect rejection.");
        if (!g_HaveFireRateBase) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)), "No weapon fire-rate data yet.");
        }

        // NO RECOIL now lives in the Reticle Manager tab, where it belongs
        // alongside the other aim tools. The implementation (noRecoilEnabled,
        // TryApplyNoRecoil, the per-weapon restore) stays HERE and is unchanged -
        // only the controls moved, so nothing that already worked was touched.

        // ---- ULT CHARGE (experiment) ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.75f, 0.45f, 1.0f)), "ULT CHARGE RATE  (experiment, expect failure)");
        ImGui::TextWrapped("Instant ultimate as usually described is NOT reachable: "
            "r_nUltimateCharge and r_nRequiredUltimateCharge are both (Net) — server-owned stats, "
            "same as health and speed. Writing them locally just gets overwritten.");
        ImGui::TextWrapped("The one untested angle: ATgPawn::m_fEnergyChargeMultiplier is NOT marked "
            "Net. If charge accrual is computed client-side, raising it works. If the server computes "
            "it (my expectation), it won't. One quick test settles it.");
        ImGui::Checkbox("Try ult charge multiplier", &ultChargeExperiment);
        ImGui::SliderFloat("Charge multiplier", &ultChargeMultiplier, 1.0f, 10.0f, "%.1fx");
        ImGui::Text("Base: %.2f   |   Live: %.2f", g_BaseEnergyMult, g_LiveEnergyMult);
        ImGui::TextDisabled("Watch your ult meter while shooting. No change = server-side, as expected.");

        // ---- PROJECTILE SPEED ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.5f, 0.45f, 1.0f)), "PROJECTILE SPEED  (confirmed dead - kept for reference)");
        ImGui::TextWrapped("The Anubis dev settled this directly: \"the projectile is only simulated "
            "in your client and actually only lives at the server, therefore nothing i can do about "
            "it.\" So visually your projectile speeds up and the server's copy does not — the shot "
            "still resolves at the original speed. My earlier reasoning here was wrong.");
        ImGui::TextDisabled("Left in because the visual change is real and harmless to look at, but");
        ImGui::TextDisabled("do not expect it to affect whether you actually hit anything.");
        ImGui::Checkbox("Enable faster projectiles", &projSpeedEnabled);
        ImGui::SliderFloat("Projectile multiplier", &projSpeedMultiplier, 1.1f, 4.0f, "%.2fx");
        ImGui::Text("Live projectiles: %d   |   boosted total: %d", g_ProjSeen, g_ProjBoosted);
        ImGui::TextDisabled("Each projectile is boosted ONCE (tracked by pointer) — repeating it");
        ImGui::TextDisabled("every frame would multiply it to infinity in a few frames.");
        ImGui::TextDisabled("Only projectiles owned by your pawn are touched.");

        // ---- TELEPORT ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.75f, 0.35f, 1.0f)), "TELEPORT TO TARGET");
        ImGui::TextWrapped("Point at an enemy (needs the Target Reticle enabled in Highlights) and "
            "press the key to jump next to them. Uses AActor::SetLocation, the engine's own move "
            "primitive — it REFUSES blocked destinations, so it won't stuff you inside geometry.");
        ImGui::Checkbox("Enable teleport to target", &teleportToTargetEnabled);
        ImGui::SliderFloat("Stop short by (units)", &teleportStandoff, 50.0f, 400.0f, "%.0f");
        ImGui::SliderFloat("Arrive above by (units)", &teleportZLift, 0.0f, 200.0f, "%.0f");
        ImGui::TextDisabled("Standoff is HORIZONTAL only — pulling back along the full 3D line");
        ImGui::TextDisabled("would drag you downward when the target is below, i.e. into the floor.");
        ImGui::TextDisabled("The lift makes you settle ONTO ground rather than spawn inside it.");
        if (g_TeleportTargetName[0]) {
            ImGui::TextColored(Ink(ImVec4(0.5f, 1.0f, 0.6f, 1.0f)), "Target: %s", g_TeleportTargetName);
        } else {
            ImGui::TextDisabled("No target — aim at an enemy with the reticle on.");
        }
        ImGui::Text("Teleports: %d   |   last: %s", g_TeleportCount, g_LastTeleportOk ? "OK" : "blocked/failed");

        // ---- rebindable key ----
        ImGui::Spacing();
        ImGui::Text("Teleport key:");
        ImGui::SameLine();
        if (g_BindingTeleportKey) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.9f, 0.3f, 1.0f)), "[ press any key... ESC cancels ]");
        } else {
            ImGui::TextColored(Ink(ImVec4(0.5f, 1.0f, 0.7f, 1.0f)), "%s", KeyName(teleportKey));
        }
        ImGui::SameLine();
        if (ImGui::Button(g_BindingTeleportKey ? "Cancel" : "Bind key")) {
            g_BindingTeleportKey = !g_BindingTeleportKey;
        }
        ImGui::TextDisabled("Default is T, not Mouse5 — Mouse5 is usually already bound in-game,");
        ImGui::TextDisabled("so it would fire a teleport at the same time as an ability.");

        ImGui::Spacing();
        ImGui::Checkbox("Auto-teleport when reticle lands on an enemy (no key)", &teleportAutoOnTarget);
        if (teleportAutoOnTarget) {
            ImGui::SliderFloat("Auto cooldown (sec)", &teleportAutoCooldownSec, 0.5f, 10.0f, "%.1f");
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.7f, 0.4f, 1.0f)),
                "Cooldown exists so this can't fire every frame and disconnect you.");
        }
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.6f, 0.4f, 1.0f)), "Expect rubber-band or disconnect on LONG jumps —");
        ImGui::TextWrapped("position is client-declared, but a large instant jump is exactly what "
            "server movement validation is built to catch. Short hops are far likelier to stick.");

        // ---- RANGE TRICK (moved here for organisation) ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.9f, 0.4f, 1.0f)), "EFFECTIVE RANGE OVERRIDE");
        ImGui::TextWrapped("Enemy border colour is driven by whether the target is inside your "
            "weapon's effective range (in = red, out = yellow). That's why Drogoz's fire mode 2 "
            "shows yellow at all distances. We intercept the range check and overwrite its answer.");
        ImGui::Checkbox("Force IN range (red borders + no damage falloff)", &VisibilityBoxes::forceInRangeBorders);
        if (VisibilityBoxes::forceInRangeBorders) VisibilityBoxes::forceOutOfRangeBorders = false;
        ImGui::TextDisabled("This is the interesting direction: if the same check drives damage");
        ImGui::TextDisabled("falloff, forcing IN range means full damage at any distance.");
        ImGui::Checkbox("Force OUT of range (yellow borders)", &VisibilityBoxes::forceOutOfRangeBorders);
        if (VisibilityBoxes::forceOutOfRangeBorders) VisibilityBoxes::forceInRangeBorders = false;
        ImGui::TextDisabled("Cosmetic only — and may REDUCE your damage for the same reason.");
        ImGui::Text("Range checks intercepted: %d", VisibilityBoxes::g_RangeHookHits);
        if (VisibilityBoxes::g_RangeHookHits == 0 &&
            (VisibilityBoxes::forceInRangeBorders || VisibilityBoxes::forceOutOfRangeBorders)) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)),
                "0 intercepts — IsWithinEffectiveRange isn't being called under that name.");
        }
    }
}
