#pragma once
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "menus/FireModeMenu.h"
#include "menus/VisibilityBoxes.h"
#include "menus/Silhouette.h"
#include "menus/ColorGrading.h"
#include "menus/Testing.h"
#include "menus/CallLogger.h"
#include "menus/HealthBarColor.h"
#include "menus/Speeden.h"
#include "menus/SkinSwap.h"
#include "menus/VisualEffects.h"
#include "menus/InstantReload.h"
#include "menus/VGSSpam.h"
#include "menus/CameraTools.h"
#include "menus/Crosshair.h"
#include "menus/CardsTab.h"
#include "menus/SelfHeal.h"
#include "menus/MeshSkin.h"
#include "menus/DevSkin.h"
#include "menus/LogoTexture.h"
#include "menus/Perf.h"
#include "menus/TestReport.h"
#include "menus/Gating.h"
#include "menus/Unlocker.h"
#include "menus/LeaveMatch.h"
#include "menus/DirectFire.h"
#include "menus/KnownExploits.h"
#include "menus/DeviceNames.h"
#include "menus/CardSuite.h"
#include "menus/Recolours.h"
#include "menus/Persist.h"
#include "menus/FeatureIdeas.h"
#include "Utils/SafeCalls.h"
#include "Utils/Helper.h"         // 4th-talent live picker backend (Helpers::g_talent) - already ran every frame, just never had a window
#include "menus/EquipEmoteMenu.h" // cross-character emote picker - from a third-party EmoteTalent tool

// RecoverySuite — one embedded window, tabs switch content in place (nothing
// pops out into separate windows). F3 shows/hides it, F4 resets everything
// below back to defaults (see ResetAllToDefaults()).

extern bool g_bShowMenu; // declared in main.cpp — must be outside the namespace below
extern bool g_ShowFPS;
extern bool g_RealLButtonHeld; // same rule — main.cpp's globals are global-scope, not RecoverySuite::-scope
extern bool g_LButtonClickedThisFrame; // tracks button press events (not just hold state)
extern ULONG_PTR kAutoFireExtraInfoTag;
// Same file-scope rule as above — these live at global scope in main.cpp, so the
// extern must NOT sit inside the namespace or the mangled name won't match.
extern float g_UIScale;
extern void ApplyUIScale(float newScale);
extern float g_PendingWindowScaleRatio;   // set by ApplyUIScale, consumed in Render()

namespace RecoverySuite {

    // Character projectile speeds (u/s)
    struct CharProjectileData {
        const char* name;
        float speed;  // 0 = hitscan
    };

    inline const CharProjectileData g_CharSpeeds[] = {
        {"Ash", 300}, {"Azaan", 400}, {"Inara", 350}, {"Makoa", 250}, {"Terminus", 300},
        {"Yagorath", 200}, {"BettyLaBomba", 300}, {"BombKing", 300}, {"Cassie", 630},
        {"Dredge", 350}, {"Drogoz", 250}, {"Imani", 420}, {"Saati", 0}, {"ShaLin", 300},
        {"Tiberius", 350}, {"Willo", 300}, {"Grover", 350}, {"Io", 350}, {"Lillith", 300},
        {"MalDamba", 240}, {"Pip", 300}, {"Rei", 250}, {"Seris", 150}, {"Caspian", 400},
        {"Evie", 200}, {"Maeve", 400}, {"Moji", 350}, {"Nyx", 300}, {"Vatu", 400}, {"Vora", 302.5f},
        {"Talus", 0}, {"Skye", 0}, {"Omen", 0}, {"Koga", 0}, {"Buck", 0}, {"Androxus", 0},
        {"Grohk", 0}, {"Furia", 0}, {"Corvus", 0}, {"Octavia", 0}, {"Kasumi", 0},
        {"Ruckus", 0}, {"Raum", 0}, {"Barik", 0}, {"Atlas", 0}, {"Vii", 0}, {"Lex", 0},
        {"Ying", 0}, {"Jenos", 0}, {"Vivian", 0}, {"Viktor", 0}, {"Tyra", 0}, {"Strix", 0},
        {"Lian", 0}, {"Kinessa", 0}, {"Khan", 0}
    };

    inline float GetCharacterProjectileSpeed(const char* chamionName) {
        if (!chamionName) return 0.0f;
        for (const auto& data : g_CharSpeeds) {
            if (_stricmp(data.name, chamionName) == 0) return data.speed;
        }
        return 0.0f;
    }

    // Check if character is a healer with right-click heal (exclude Grohk, Grover, Pip - they don't use right-click)
    inline bool IsHealer(const char* champName) {
        if (!champName) return false;
        // Exclude: Grohk, Grover, Pip (their heals don't use right-click)
        // Include all others: Corvus, Furia, Io, Jenos, Lillith, Mal'Damba, Moji, Rei, Seris, Ying
        if (_stricmp(champName, "Grohk") == 0 || _stricmp(champName, "Grover") == 0 || _stricmp(champName, "Pip") == 0) {
            return false;
        }
        // Check if it's one of the healer classes
        return (_stricmp(champName, "Corvus") == 0 || _stricmp(champName, "Furia") == 0 ||
                _stricmp(champName, "Io") == 0 || _stricmp(champName, "Jenos") == 0 ||
                _stricmp(champName, "Lillith") == 0 || _stricmp(champName, "MalDamba") == 0 ||
                _stricmp(champName, "Moji") == 0 || _stricmp(champName, "Rei") == 0 ||
                _stricmp(champName, "Seris") == 0 || _stricmp(champName, "Ying") == 0);
    }

    inline bool activateFireMode = true;   // ON by default - the tab opened empty otherwise
    inline bool activateCustomMode = false;
    inline bool activateAimAssist = false;

    // Outline/aim-assist state lives here so F4 can revert it, not just hide the UI.
    inline bool outlineFriendly = false;
    inline bool outlineEnemy = false;
    // ========================================================================
    // SKINS MASTER SWITCH — ON by default (the input bug was traced elsewhere).
    //
    // Kept as an isolation tool, not a workaround: unticking it stops ALL skin
    // code dead — the per-frame MeshSkin::Update on the render thread, the three
    // ProcessPending handlers, and the ProcessEvent capture hooks. That gives a
    // clean A/B when something misbehaves: untick, play a match, and if the
    // problem persists the skin system is definitively not the cause.
    //
    // Previously all of that ran every frame whether or not the Skins tab was
    // ever opened, which made it impossible to rule out. Now it's one click.
    // ========================================================================
    inline bool g_SkinsSystemEnabled = true;

    // DEVELOPER MODE. Declared up here because tabs drawn early in this file
    // gate their research-only controls on it.
    inline bool g_DeveloperMode = false;

    // ---- CDO-BASED NO RECOIL (device-class-default route) ------------------
    // ATgDevice::r_nRecoilMultiCenti (0x09C0) is the recoil multiplier in
    // hundredths. Zero it and there is no kick.
    //
    // Rather than write the live weapon, this writes the CLASS DEFAULT for
    // every in-hand device, exactly like the third person that already works.
    // One application covers every champion and survives a weapon swap.
    //
    // SetClientValue is scripted, so these are FLAGS - the work happens on the
    // safe thread. Never call it from the draw path.
    inline bool g_CardsNoRecoil        = false;
    inline bool g_CardsNoRecoilApply   = false;
    inline bool g_CardsNoRecoilRestore = false;
    inline bool g_CardsRecoilApplied   = false;
    inline char g_CardsRecoilStatus[160] = "not applied";

    inline bool aimAssistEnabled = false;
    inline float aimAssistX = 1.0f;
    inline float aimAssistY = 1.0f;
    // Aim assist modes
    inline bool triggerBotEnabled = false;
    inline bool triggerBotPredictionBox = false;
    // V2: independent, from-scratch fallback trigger bot. Separate flag, separate
    // timer, separate detection code from the main one above — a bug in one can't
    // touch the other, and either can be disabled without affecting the other.
    inline bool triggerBotV2Enabled = false;
    inline bool headLockEnabled = false;           // fire-gated (only locks when shooting)
    inline bool headLockAlwaysOnEnabled = false;   // always-on (locks anytime)
    inline bool bodyLockEnabled = false;           // fire-gated (only locks when shooting)
    inline bool bodyLockAlwaysOnEnabled = false;   // always-on (locks anytime)
    inline bool magnetAimEnabled = false;
    // Published by ProcessAimAssist() (render thread) every frame the fire-gated
    // lock has a target, so AimFeatures::ProcessAimHook_Isolated (main.cpp, runs
    // on the game's own script thread via the GetAdjustedAimNative ProcessEvent
    // hook) can aim at the SAME enemy instead of independently walking the pawn
    // list and grabbing whichever one happens to be first — which is what was
    // actually causing "locks a different enemy the moment I fire": that second,
    // separate hook was picking its own (wrong, arbitrary-order) target the whole
    // time, fully independent of the screen-distance fix already made here. Plain
    // pointer, no lock — same convention this codebase already uses for
    // Globals::LocalPawn etc. across threads, and pointer-sized reads/writes are
    // atomic on x64 regardless.
    inline SDK::ATgPawn* g_FireGatedLockedTarget = nullptr;
    inline bool autoHealEnabled = false;
    inline bool autoHealSkipCaut = false;  // don't heal allies who have caut (grievous wound)
    inline int autoHealMode = 0;  // 0 = hold on any ally, 1 = auto-flick low health allies
    inline float autoHealHealthThreshold = 0.5f;  // right-click allies below X% health

    // User-configurable keybinds (0/ImGuiKey_None = unbound). Separate from
    // the tool's own reserved controls (Insert/F3/F4/F9, hardcoded in
    // main.cpp) — these are player-assignable convenience binds, requested
    // for instant respawn, cards spam, and aim.
    inline ImGuiKey g_BindInstantRespawn  = ImGuiKey_None;
    inline ImGuiKey g_BindCardsAutoToggle = ImGuiKey_None;
    inline ImGuiKey g_BindAimToggle       = ImGuiKey_None;   // toggles magnetic aim specifically
    // Grayscale used to be hardcoded to F9 with no way to change it, which
    // clashes with Steam's own F9/F12-style FPS overlay bind on some
    // setups (a "known and unfixed" issue). Defaults to F9 so behaviour is
    // unchanged out of the box — rebind it here if it conflicts.
    inline ImGuiKey g_BindGrayscaleKey    = ImGuiKey_F9;
    inline ImGuiKey* g_CapturingBindTarget = nullptr;

    // Draws one "Label: KeyName [Bind]" row. Click Bind, then press any key —
    // Escape clears it instead of binding to Escape. Only one row can be
    // capturing at a time (clicking a different Bind button just switches
    // which one is listening).
    inline void DrawKeybindRow(const char* label, ImGuiKey* bindVar) {
        ImGui::Text("%s:", label);
        ImGui::SameLine();
        if (g_CapturingBindTarget == bindVar) {
            ImGui::TextColored(ImVec4(1.0f, 0.8f, 0.2f, 1.0f), "press any key... (Esc clears)");
            for (int k = ImGuiKey_NamedKey_BEGIN; k < ImGuiKey_NamedKey_END; k++) {
                if (ImGui::IsKeyPressed((ImGuiKey)k, false)) {
                    *bindVar = (k == ImGuiKey_Escape) ? ImGuiKey_None : (ImGuiKey)k;
                    g_CapturingBindTarget = nullptr;
                    break;
                }
            }
        } else {
            const char* keyName = (*bindVar == ImGuiKey_None) ? "unbound" : ImGui::GetKeyName(*bindVar);
            ImGui::TextColored(ImVec4(0.6f, 0.85f, 1.0f, 1.0f), "%s", keyName);
            ImGui::SameLine();
            char btnId[80];
            snprintf(btnId, sizeof(btnId), "Bind##%s", label);
            if (ImGui::Button(btnId)) {
                g_CapturingBindTarget = bindVar;
            }
        }
    }

    // Aim assist settings
    // Default tightened 150 -> 90 per PRIMAL_MONKE ("tolerates too much
    // variance... make it tighter"). Still adjustable 50-400 via the slider.
    inline float magnetAimRadius = 90.0f;
    inline float aimLockStrength = 0.40f;   // 0.020 was too weak once the jitter was
                                            // fixed - the shake was the constant-push
                                            // bug, not the strength. 0.4 tracks properly.

    // Helper: check if a pawn has caut/heal mitigation
    inline bool HasCaut(SDK::ATgPawn* pawn) {
        if (!pawn) return false;
        // Read s_PawnHealMitigators at offset 0x28C0 (TArray<FPawnHealMitigator>).
        // MUST be SEH-guarded: pawn can be a stale/freed pointer (ally left the
        // match, match tearing down) and this is a raw memory read with no
        // validity check of its own — without __try/__except this is an
        // unguarded access violation that kills the whole process instantly,
        // with no error dialog and no log: exactly a silent "empty" crash.
        __try {
            uintptr_t pawnAddr = (uintptr_t)pawn;
            uintptr_t mitigatorsAddr = pawnAddr + 0x28C0;

            // TArray: pointer at +0, count at +8
            int count = *(int*)(mitigatorsAddr + 0x8);

            // Sanity check: count should be 0-64
            if (count < 0 || count > 64) return false;

            return count > 0;  // healing is reduced if any mitigators exist
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }


    // File-scope (not a local static inside the tab function) so the "9" hotkey
    // and the death/respawn re-apply logic in main.cpp can both reach it.
    inline bool grayscaleOn = false;

    // GAP THAT CAUSED "toggled off/on -> instant crash": ApplyGrayscale used
    // to call SafeCalls::SetDesaturation directly — but it gets called from
    // the "9" hotkey handler AND the UI checkbox, BOTH of which run on
    // hkPresent (the render thread), the exact same unsafe cross-thread call
    // site already fixed for the periodic reapply below. This one slipped
    // through because it "felt" like just a toggle, not a periodic thing.
    // Fixed the same way: ApplyGrayscale now ONLY sets plain flags (no
    // scripted call, safe from any thread) and requests an immediate apply;
    // ForceGrayscaleIfEnabled (called from HookedProcessEvent, the safe
    // thread) is the ONLY place that actually calls SetDesaturation now,
    // whether that's the periodic reapply or an immediate on/off request.
    inline bool g_GrayscalePendingImmediate = false;

    // TURNS OUT (confirmed by testing): grayscale isn't a separate custom
    // effect — it's piggybacking on the game's OWN round-end slow-mo fade,
    // which behaves like a selectable colorblind-style mode internally. That
    // explains "muted but not fully reset" after toggling: our instant snap
    // can land in the middle of the game's own in-progress fade instead of
    // cleanly overriding it.
    //
    // DIALED BACK: the original fix was a sustained burst of reapplies
    // (every 300ms for 1.5s = up to 5 extra scripted calls right after a
    // toggle). That's a real spike in call volume clustered exactly when the
    // user takes an action — a plausible contributor to "toggled it, crashed
    // almost immediately" reports. Now just ONE follow-up call ~400ms after
    // the initial one — enough to usually win against a stuck fade, without
    // stacking several extra risky calls in a tight window.
    inline ULONGLONG g_GrayscaleFollowUpAtMs = 0;
    inline bool g_GrayscaleFollowUpPending = false;

    inline void ApplyGrayscale(bool on) {
        grayscaleOn = on;
        g_GrayscalePendingImmediate = true;
        g_GrayscaleFollowUpAtMs = GetTickCount64() + 400;
        g_GrayscaleFollowUpPending = true;
    }

    // Widened from 300ms to 1500ms after a crash during active combat —
    // combat generates a lot of the game's OWN script activity (damage/
    // health/kill events), which raises the odds of our scripted call
    // landing badly mid-dispatch on the engine's side. Fewer calls/sec
    // means fewer chances to collide, at the cost of grayscale taking
    // slightly longer to "win" if the game just reset it. An immediate
    // toggle (on or off) still applies right away via the pending flag,
    // bypassing only the throttle — not the safe-thread requirement.
    // Set false the moment HookedProcessEvent sees we're no longer in a match.
    // Checking Globals::LocalController alone was NOT enough: at match end that
    // pointer stays non-null while the object is being torn down, so a scripted
    // SetDesaturation call would land on a dying controller. SEH can't catch
    // that (it's corruption, not an access violation) — it surfaces later on the
    // engine's own next ProcessEvent dispatch, which is the main.cpp:L375 crash.
    inline bool g_EffectsSafe = false;
    // Route grayscale's periodic reapply through the ProcessEvent thread instead
    // of the render thread. OFF keeps the historical behaviour (render thread),
    // which WORKS but is the confirmed source of the mid-match / match-end crash:
    // SetDesaturation is a scripted ProcessEvent call and calling those from the
    // render thread corrupts object state. An earlier attempt to move it was
    // abandoned because it "stopped working" — but that's exactly what a stalled
    // ProcessEvent path looks like, so it's worth retesting alongside the
    // heartbeat counter now that we can actually measure that path.
    // NOW ON BY DEFAULT - this is the grayscale crash fix.
    //
    // ForceGrayscaleIfEnabled() is called from hkPresent, i.e. the RENDER
    // thread. With this false it called SafeCalls::SetDesaturation directly
    // from there - a scripted ProcessEvent call on the wrong thread, every
    // 1.5 seconds, for as long as grayscale was on. That is the crash people
    // hit while using it, and it is the same rule this whole tool is built
    // around: scripted calls belong on the ProcessEvent thread.
    //
    // It was left off because routing it correctly once "stopped working" -
    // but that was a stalled safe thread, and the safe thread demonstrably
    // runs now (the card sweep goes through it every few seconds).
    //
    // The render-thread path is kept, off, for anyone who wants to compare.
    inline bool grayscaleUseSafeThread = true;
    inline bool g_GrayscaleSafePending = false;
    inline int  g_GrayscaleSafeApplyCount = 0;

    inline void ForceGrayscaleIfEnabled() {
        // Require the FULL in-match state. LocalPawn/LocalWeapon go null before
        // the controller does during teardown, so they're the early warning.
        if (!g_EffectsSafe) return;
        if (!Globals::LocalController || !Globals::LocalPawn || !Globals::LocalWeapon) return;
        static ULONGLONG lastApplyMs = 0;
        ULONGLONG now = GetTickCount64();

        if (g_GrayscalePendingImmediate) {
            if (!grayscaleOn) {
                // Hard reset of the composite low-health/near-death effect,
                // not just desaturation — this is what was leaving a stuck
                // "muted brownish" state that toggling didn't clear.
                SafeCalls::UpdateLowHealthEffect(0.0f, 1.0f, 0.0f, false);
            }
            SafeCalls::SetDesaturation(grayscaleOn ? 1.0f : 0.0f, 0.0f);
            lastApplyMs = now;
            g_GrayscalePendingImmediate = false;
            return;
        }

        if (g_GrayscaleFollowUpPending && now >= g_GrayscaleFollowUpAtMs) {
            if (!grayscaleOn) {
                SafeCalls::UpdateLowHealthEffect(0.0f, 1.0f, 0.0f, false);
            }
            SafeCalls::SetDesaturation(grayscaleOn ? 1.0f : 0.0f, 0.0f);
            lastApplyMs = now;
            g_GrayscaleFollowUpPending = false;
            return;
        }

        if (!grayscaleOn) return;
        if (now - lastApplyMs < 1500) return;
        lastApplyMs = now;
        if (grayscaleUseSafeThread) {
            g_GrayscaleSafePending = true; // ProcessEvent side will do the call
            return;
        }
        SafeCalls::SetDesaturation(1.0f, 0.0f);
    }

    // Consumed on the ProcessEvent thread (see ProcessPendingSafeResets).
    //
    // BUG FOUND wiring the Canvas fallback menu: ForceGrayscaleIfEnabled()
    // (the only thing that ever consumed g_GrayscalePendingImmediate /
    // g_GrayscaleFollowUpPending) is called ONLY from hkPresent. On a machine
    // where hkPresent never fires, pressing the grayscale hotkey still sets
    // those flags fine (ApplyGrayscale() is a plain field write, runs from
    // the hotkey handler regardless of hkPresent) but nothing was ever there
    // to read them - grayscale silently never applied, same shape of bug as
    // the Speeden one above. Fixed the same way: this function ALREADY runs
    // unconditionally from HookedProcessEvent on every machine (via
    // ProcessPendingSafeResets), and it ALREADY proved a direct
    // SafeCalls::SetDesaturation call from exactly this spot works correctly
    // in production (the periodic g_GrayscaleSafePending path below,
    // shipped and working before this pass) - so the immediate/follow-up
    // cases are handled here too now, not just the periodic one.
    // ForceGrayscaleIfEnabled() itself is UNCHANGED and still runs from
    // hkPresent on a working machine - on that machine both this function and
    // that one may race to consume the same flag on a given tick; whichever
    // wins applies the identical value, so the redundancy is harmless, same
    // as ProcessPendingTurn's existing dual-call pattern.
    inline void ProcessPendingGrayscaleSafe() {
        if (!g_EffectsSafe) return;

        if (g_GrayscalePendingImmediate) {
            if (!grayscaleOn) {
                SafeCalls::UpdateLowHealthEffect(0.0f, 1.0f, 0.0f, false);
            }
            SafeCalls::SetDesaturation(grayscaleOn ? 1.0f : 0.0f, 0.0f);
            g_GrayscalePendingImmediate = false;
            g_GrayscaleSafeApplyCount++;
            return;
        }

        if (g_GrayscaleFollowUpPending && GetTickCount64() >= g_GrayscaleFollowUpAtMs) {
            if (!grayscaleOn) {
                SafeCalls::UpdateLowHealthEffect(0.0f, 1.0f, 0.0f, false);
            }
            SafeCalls::SetDesaturation(grayscaleOn ? 1.0f : 0.0f, 0.0f);
            g_GrayscaleFollowUpPending = false;
            g_GrayscaleSafeApplyCount++;
            return;
        }

        if (!g_GrayscaleSafePending) return;
        g_GrayscaleSafePending = false;
        SafeCalls::SetDesaturation(grayscaleOn ? 1.0f : 0.0f, 0.0f);
        g_GrayscaleSafeApplyCount++;
    }

    // Same fix as grayscale: F4 runs from the render thread (hkPresent), so
    // this can't call SetOutlines directly — that's the scripted call, deferred
    // to the safe thread via this flag instead. See ProcessPendingSafeResets().
    inline bool g_PendingOutlineReset = false;
    // Set by the "reset size" button; consumed next frame by the window-size
    // override so it can put the window back without deleting imgui.ini.
    inline bool g_PendingSizeReset = false;

    // FULL SWEEP: every scripted call triggered by a UI button/checkbox in
    // this file runs from the render thread (hkPresent) unless deferred —
    // same category as the grayscale/F4 bugs above, just lower exposure
    // (one-shot clicks vs. periodic calls) rather than zero risk. Since the
    // whole point is "never again," all of them get the same treatment: set
    // a flag from the UI, apply for real only from ProcessAllPendingSafeActions()
    // (called from HookedProcessEvent, the safe thread).
    inline bool g_PendingMaxLevel = false;

    // Real UTgBattleCheatManager entry points — same class/pattern as MaxLevel.
    inline bool g_PendingGainCredits = false;
    inline int g_CreditsAmount = 5000;
    inline bool g_PendingAddGold = false;
    inline int g_GoldAmount = 500;
    inline bool g_PendingGainXP = false;
    inline int g_XPAmount = 5000;
    inline bool g_PendingCardCooldown = false;
    inline float g_CardCooldownIncrease = -0.5f; // negative = faster cooldowns
    inline bool g_PendingFillEnergy = false;
    inline float g_FillEnergyPct = 1.0f;
    inline bool g_PendingGiveCard = false;
    inline int g_GiveCardDeviceId = 0;

    // TestServerRequestCard — sends a real request to the server, unlike
    // direct field writes. Most promising card-leveling lead found so far.
    inline bool g_PendingServerRequestCard = false;
    inline int g_ServerRequestCardDeviceId = 0;
    inline int g_ServerRequestCardLevel = 10;

    // Octavia's 4 real "Commander" team-buff cards, found via the reference
    // data — same TestServerRequestCard mechanism, just fixed IDs. Unknown
    // yet: whether the server accepts a card request for a card that isn't
    // part of your currently-played champion's own kit (same restriction
    // pattern as normal hidden-talent swapping) — this is exactly what
    // testing will answer.
    inline bool g_PendingOctaviaShield = false;   // 26883
    inline bool g_PendingOctaviaCredit = false;   // 27051
    inline bool g_PendingOctaviaUltimate = false; // 27052
    inline bool g_PendingOctaviaCooldown = false; // 27053
    inline bool g_PendingTeamSkinBooster = false; // 23849
    inline bool g_PendingInstantRespawn = false;
    inline bool autoInstantRespawn = true;        // ON by default — "die and respawn" should just work
    inline ULONGLONG g_LastRespawnTryMs = 0;

    // Isolated so the SEH here never shares a scope with std::string (C2712).
    //
    // Two ways to be dead, and we need BOTH because they happen at different
    // moments: the pawn can go null (fully despawned / spectating), or the pawn
    // still exists with zero health during the death cam. Checking only for a
    // null pawn would miss the entire death-cam window, which is exactly when
    // you want the respawn request to fire.
    inline bool IsLocalPawnDead() {
        __try {
            if (!Globals::LocalController) return false;
            SDK::APawn* p = Globals::LocalController->AcknowledgedPawn;
            if (!p) return true;                 // despawned
            if (p->bDeleteMe || p->bPendingDelete) return true;
            // APawn::Health is the engine-level replicated health and is a more
            // reliable death signal than the PRI copy, which can lag or hold a
            // stale value through the death cam. Check it FIRST.
            if (p->Health <= 0) return true;
            SDK::ATgPawn* tg = (SDK::ATgPawn*)p;
            if (!tg->PlayerReplicationInfo) return false;
            SDK::ATgRepInfo_Player* pri = (SDK::ATgRepInfo_Player*)tg->PlayerReplicationInfo;
            return pri->r_nHealthCurrent <= 0;   // dead but pawn still around (death cam)
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Live status for the UI so you can see what it thinks without dying first.
    inline bool g_LastDeadState = false;
    inline int  g_RespawnSendCount = 0;
    inline int  g_RespawnRetries = 0;
    inline int  g_RespawnBlockedStale = 0; // sends suppressed because the object chain was stale
    inline bool zeroClientRespawnTimer = true;  // write c_fRespawnTime = 0 before the RPC
    inline bool holdClientRespawnAtZero = false; // keep forcing it to 0 while dead
    // Diagnostic: proves whether the ProcessEvent-side path runs at all. If this
    // number is frozen while the game is running, nothing driven from
    // HookedProcessEvent is executing — which would explain a stale banner AND
    // a dead "Respawn Now" button at the same time, since both live there.
    inline int  g_SafeResetTickCount = 0;
    // Set from main.cpp — tells us whether the PostRender anchor was found at
    // all, and whether it had to fall back to name matching. If this is false,
    // nothing deferred can ever run.
    inline bool g_PostRenderResolved = false;
    inline bool g_PostRenderByName = false;
    inline int  g_PostRenderVariants = 0; // how many DISTINCT PostRender functions exist

    // DEATH DIAGNOSTIC — dumps every candidate death signal at once, as plain
    // numbers, so we can see which one ACTUALLY changes when you die instead of
    // guessing. Isolated (POD only) so it's SEH-legal; the caller formats it.
    struct DeathProbe {
        int  hasController;
        int  hasAckPawn;
        int  hasLocalPawn;
        int  hasLocalWeapon;
        int  pawnHealth;        // APawn::Health (engine-level, replicated)
        int  bDeleteMe;
        int  bPendingDelete;
        int  hasPRI;
        int  priHealthCur;
        int  priHealthMax;
        int  pawnIsValidRead;   // 0 if reading the pawn threw
    };

    inline void ProbeDeathState(DeathProbe* out) {
        out->hasController = 0; out->hasAckPawn = 0; out->hasLocalPawn = 0;
        out->hasLocalWeapon = 0; out->pawnHealth = -999; out->bDeleteMe = -1;
        out->bPendingDelete = -1; out->hasPRI = 0; out->priHealthCur = -999;
        out->priHealthMax = -999; out->pawnIsValidRead = 0;
        __try {
            out->hasController  = Globals::LocalController ? 1 : 0;
            out->hasLocalPawn   = Globals::LocalPawn ? 1 : 0;
            out->hasLocalWeapon = Globals::LocalWeapon ? 1 : 0;
            if (!Globals::LocalController) return;
            SDK::APawn* p = Globals::LocalController->AcknowledgedPawn;
            out->hasAckPawn = p ? 1 : 0;
            if (!p) return;
            out->bDeleteMe      = p->bDeleteMe ? 1 : 0;
            out->bPendingDelete = p->bPendingDelete ? 1 : 0;
            out->pawnHealth     = p->Health;
            out->pawnIsValidRead = 1;
            SDK::ATgPawn* tg = (SDK::ATgPawn*)p;
            if (!tg->PlayerReplicationInfo) return;
            out->hasPRI = 1;
            SDK::ATgRepInfo_Player* pri = (SDK::ATgRepInfo_Player*)tg->PlayerReplicationInfo;
            out->priHealthCur = pri->r_nHealthCurrent;
            out->priHealthMax = pri->r_nHealthMaximum;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
    }
    inline bool g_PendingRefillAmmo = false;
    inline bool g_PendingSpeedBoost = false;
    inline bool g_PendingSpeedReset = false;
    inline bool g_PendingDamageBoost = false;
    inline bool g_PendingDamageReset = false;
    inline int g_SpawnDeployableId = 0;
    inline bool g_PendingSpawnDeployable = false;

    // ===== THROTTLED RPC QUEUE =====
    // Root cause of "clicked Auto-Max Cards and got booted to menu": the old
    // code fired ServerRequestCard + 5x ServerAllocateDevicePoint per card
    // across up to 21 equip points — 90+ RELIABLE RPCs in a single frame. UE3's
    // reliable channel has a bounded send buffer; overflowing it makes the
    // engine close the connection, which looks exactly like being kicked to
    // menu. Being booted actually proved the RPCs were REACHING the server.
    // Fix: queue them and drain ONE per ProcessEvent tick so the channel never
    // overflows. Slower (a full card set takes a couple seconds) but survivable.
    enum RpcKind { RPC_None = 0, RPC_RequestCard, RPC_AllocatePoint, RPC_SelectTempPassive, RPC_EquipPassive };
    struct QueuedRpc { int kind; int a; int b; };
    inline QueuedRpc g_RpcQueue[256] = {};
    inline int g_RpcQueueHead = 0;   // next slot to write
    inline int g_RpcQueueTail = 0;   // next slot to send
    inline int g_RpcSentCount = 0;

    inline void EnqueueRpc(int kind, int a, int b) {
        int next = (g_RpcQueueHead + 1) % 256;
        if (next == g_RpcQueueTail) return; // full — drop rather than overwrite
        g_RpcQueue[g_RpcQueueHead].kind = kind;
        g_RpcQueue[g_RpcQueueHead].a = a;
        g_RpcQueue[g_RpcQueueHead].b = b;
        g_RpcQueueHead = next;
    }

    inline int PendingRpcCount() {
        return (g_RpcQueueHead - g_RpcQueueTail + 256) % 256;
    }

    inline void ClearRpcQueue() {
        g_RpcQueueHead = g_RpcQueueTail = 0;
    }

    // Drains exactly ONE queued RPC. Called from HookedProcessEvent.
    inline void DrainOneRpc() {
        if (g_RpcQueueTail == g_RpcQueueHead) return;
        QueuedRpc q = g_RpcQueue[g_RpcQueueTail];
        g_RpcQueueTail = (g_RpcQueueTail + 1) % 256;
        // Mark it on the recorder timeline so the report reads as cause->effect.
        switch (q.kind) {
            case RPC_RequestCard:       CallLogger::Mark("[us] ServerRequestCard"); break;
            case RPC_AllocatePoint:     CallLogger::Mark("[us] ServerAllocateDevicePoint"); break;
            case RPC_SelectTempPassive: CallLogger::Mark("[us] ServerRequestSelectTempPassive"); break;
            case RPC_EquipPassive:      CallLogger::Mark("[us] ServerRequestEquipPassive"); break;
            default: break;
        }
        switch (q.kind) {
            case RPC_RequestCard:       SafeCalls::ServerRequestCard(q.a, q.b); break;
            case RPC_AllocatePoint:     SafeCalls::ServerAllocateDevicePoint(q.a); break;
            case RPC_SelectTempPassive: SafeCalls::ServerRequestSelectTempPassive(q.a); break;
            case RPC_EquipPassive:      SafeCalls::ServerRequestEquipPassive(); break;
            default: return;
        }
        g_RpcSentCount++;
    }

    // --- Real server RPC pending flags (the promising mechanism) ---
    inline int  g_PendingTempPassiveId = 0;      // 0 = nothing queued

    // ===== OCTAVIA AUTO-REPEATER =====
    // Confirmed working by hand: standing IN SPAWN (the only place the game lets
    // you change loadout) and rapidly re-clicking Commander's Shield keeps
    // applying team shields to allies. This automates that click.
    //
    // The interval is deliberately exposed and floored. These are RELIABLE RPCs,
    // and hammering reliable RPCs is what overflowed the channel and booted us to
    // the menu during card maxing. 0.15s (~7/sec) is what worked manually; going
    // much faster is asking for a disconnect.
    inline bool  autoOctaviaShield = false;
    inline bool  autoOctaviaAll = false;
    inline float octaviaRepeatSec = 0.06f;   // the rate that actually works
    inline ULONGLONG g_LastOctaviaFireMs = 0;
    inline int   g_OctaviaFireCount = 0;
    inline int   g_OctaviaAllCursor = 0;
    static const int kOctaviaIds[4] = { 26883, 27051, 27052, 27053 };

    // Runs on the safe thread. Enqueues rather than calling directly, so it
    // shares the same one-per-tick drain that keeps the channel from flooding.
    inline void ProcessOctaviaAutoRepeat() {
        if (!autoOctaviaShield && !autoOctaviaAll) return;
        if (!g_EffectsSafe) return;   // stale object chain — don't fire into the void
        ULONGLONG now = GetTickCount64();
        ULONGLONG gap = (ULONGLONG)(octaviaRepeatSec * 1000.0f);
        if (gap < 60) gap = 60;       // hard floor, protects the reliable channel
        if (now - g_LastOctaviaFireMs < gap) return;
        g_LastOctaviaFireMs = now;

        if (autoOctaviaAll) {
            // Round-robin one buff per tick rather than all four at once —
            // four reliable RPCs in the same frame is exactly the burst pattern
            // that got the connection closed before.
            int id = kOctaviaIds[g_OctaviaAllCursor % 4];
            g_OctaviaAllCursor++;
            EnqueueRpc(RPC_SelectTempPassive, id, 0);
            EnqueueRpc(RPC_EquipPassive, 0, 0);
        } else {
            EnqueueRpc(RPC_SelectTempPassive, 26883, 0); // Commander's Shield
            EnqueueRpc(RPC_EquipPassive, 0, 0);
        }
        g_OctaviaFireCount++;
    }
    inline bool g_PendingEquipPassive = false;
    inline bool g_PendingAutoAddItems = false;
    inline bool g_PendingPurchaseAllItems = false;
    inline bool g_PendingServerFlagsBoost = false;
    inline bool g_PendingServerFlagsReset = false;
    inline bool g_PendingServerExecTest = false;
    inline bool g_PendingServerSetValueTest = false;
    inline bool g_PendingOutlinesToggle = false; // uses outlineFriendly/outlineEnemy below
    inline bool g_PendingOutlineColorApply = false;
    inline float g_PendingOutlineColorRGBA[4] = { 1.0f, 0.2f, 0.2f, 1.0f };
    inline bool g_PendingColorBlind = false;
    inline bool g_PendingColorBlindEnable = false;
    inline int g_PendingColorBlindType = 0;
    inline float g_PendingColorBlindIntensity = 1.0f;
    inline bool g_PendingOutlineEffectOn = false;
    inline bool g_PendingOutlineEffectOff = false;

    // Third person — a real feature already in the game, just gated out of
    // the in-match menu for bot matches. One-shot toggle, so the safe-thread
    // deferred pattern works fine here — this isn't periodic like grayscale.
    inline bool thirdPersonOn = false;
    inline bool g_PendingThirdPersonToggle = false;

    inline void ToggleThirdPerson(bool on) {
        thirdPersonOn = on;
        g_PendingThirdPersonToggle = true;
    }

    // Isolated, SEH-only (no C++ objects in scope) — the raw, unwrapped
    // m_OutlineMaterial write from the "Apply Color" experimental button
    // never even had SEH protection before; fixed that here too.
    inline bool TryApplyOutlineColorRaw(SDK::ATgPawn* pawn, const float* rgba) {
        __try {
            if (!pawn->m_OutlineMaterial) return false;
            SDK::FLinearColor c;
            c.R = rgba[0]; c.G = rgba[1]; c.B = rgba[2]; c.A = rgba[3];
            pawn->m_OutlineMaterial->SetVectorParameterValue(SDK::FName("Color"), &c);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // Called from HookedProcessEvent (the safe thread), alongside ForceGrayscaleIfEnabled.
    // ORDER-INDEPENDENCE. Each subsystem is wrapped separately so a fault in one
    // cannot silently kill the ones after it. That exact coupling is what made
    // health bars AND the skeleton both report 0 simultaneously: a fault inside
    // the health bar pass aborted everything after it, bone resolution included —
    // while the heartbeat (incremented earlier) kept climbing, so it looked like
    // the whole path was healthy.
    //
    // Lives in its own function because ProcessPendingSafeResets builds
    // std::string, and MSVC forbids __try in a function requiring object
    // unwinding (the recurring C2712 in this project). POD/void calls only here.
    // ServerSetJumpZ is a scripted call, so it belongs on this thread.
    inline void ProcessPendingJump() {
        if (Speeden::g_PendingJumpApply) {
            Speeden::g_PendingJumpApply = false;
            if (Speeden::g_BaseJumpZ > 0.0f)
                SafeCalls::ServerSetJumpZ(Speeden::g_BaseJumpZ * Speeden::jumpMultiplier);
        }
        if (Speeden::g_PendingJumpReset) {
            Speeden::g_PendingJumpReset = false;
            if (Speeden::g_BaseJumpZ > 0.0f)
                SafeCalls::ServerSetJumpZ(Speeden::g_BaseJumpZ);
        }
    }

    inline void RunSafeThreadSubsystems() {
        __try { ProcessPendingJump(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        __try { ProcessOctaviaAutoRepeat(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        __try { ProcessPendingGrayscaleSafe(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        __try { HealthBarColor::ProcessPending(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        // SKINS MASTER SWITCH — everything skin-related is gated behind
        // g_SkinsSystemEnabled (default OFF). These handlers used to run EVERY
        // frame whether or not you ever opened the Skins tab, so any bug in them
        // affected normal play. Off = this code does not execute at all.
        if (g_SkinsSystemEnabled) {
            __try { SkinSwap::ProcessPending(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { }
        }
        __try { InstantReload::ProcessPending(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        __try { VGSSpam::ProcessPending(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        __try { CardsTab::ProcessPending(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        // Self-heal: scripted cheat-manager calls, so safe thread only.
        __try { SelfHeal::ProcessPending(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        if (g_SkinsSystemEnabled) {
            __try { MeshSkin::ProcessPending(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { }
            __try { DevSkin::ProcessPending(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { }
        }
        __try { VisibilityBoxes::ResolveBonesOnSafeThread(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }

        // CardSuite. StartFire/StopFire, GetDeviceByEqPoint, Teleport and the
        // respawn chain are ALL scripted, so they belong here and nowhere else.
        // Calling any of them from the render thread is what crashed the tool.
        __try { DirectFire::ProcessPending(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        __try { CardSuite::ProcessPending(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        __try { Recolours::ProcessPending(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { }

        // CDO-based no recoil. Applied once on enable, restored once on
        // disable - a CDO write is permanent for the session, so re-writing it
        // every pass would be pointless work.
        //
        // Wrapped, unlike the first version of this block: it calls
        // SetClientValue 87 times and one bad object took the game down
        // through HookedProcessEvent.
        __try {
            if (g_CardsNoRecoil && !g_CardsRecoilApplied) g_CardsNoRecoilApply = true;
            if (!g_CardsNoRecoil && g_CardsRecoilApplied) g_CardsNoRecoilRestore = true;

            if (g_CardsNoRecoilApply) {
                g_CardsNoRecoilApply = false;
                int ok = 0, bad = 0;
                for (int i = 0; i < ClientValues::kDeviceCDOCount; ++i) {
                    if (SafeCalls::SetClientValue(ClientValues::kDeviceCDOs[i],
                                                  L"r_nRecoilMultiCenti", L"0")) ok++;
                    else bad++;
                }
                g_CardsRecoilApplied = true;
                wsprintfA(g_CardsRecoilStatus, "applied to %d device classes (%d refused)", ok, bad);
            }
            if (g_CardsNoRecoilRestore) {
                g_CardsNoRecoilRestore = false;
                int ok = 0, bad = 0;
                for (int i = 0; i < ClientValues::kDeviceCDOCount; ++i) {
                    if (SafeCalls::SetClientValue(ClientValues::kDeviceCDOs[i],
                                                  L"r_nRecoilMultiCenti", L"100")) ok++;
                    else bad++;
                }
                g_CardsRecoilApplied = false;
                wsprintfA(g_CardsRecoilStatus, "restored on %d device classes (%d refused)", ok, bad);
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            g_CardsNoRecoilApply = g_CardsNoRecoilRestore = false;
            lstrcpynA(g_CardsRecoilStatus, "faulted and was caught - recoil left alone", 150);
        }
    }

    inline void ProcessPendingSafeResets() {
        g_SafeResetTickCount++; // heartbeat — see the note on this variable
        RunSafeThreadSubsystems();
        if (g_PendingOutlineReset && Globals::LocalController) {
            SafeCalls::SetOutlines(false, false);
            g_PendingOutlineReset = false;
        }
        if (g_PendingMaxLevel) {
            SafeCalls::MaxLevel();
            g_PendingMaxLevel = false;
        }
        if (g_PendingGainCredits) {
            SafeCalls::GainCredits(g_CreditsAmount);
            g_PendingGainCredits = false;
        }
        if (g_PendingAddGold) {
            SafeCalls::AddGold(g_GoldAmount);
            g_PendingAddGold = false;
        }
        if (g_PendingGainXP) {
            SafeCalls::GainXP(g_XPAmount);
            g_PendingGainXP = false;
        }
        if (g_PendingCardCooldown) {
            SafeCalls::SetCardCooldownIncrease(g_CardCooldownIncrease);
            g_PendingCardCooldown = false;
        }
        if (g_PendingFillEnergy) {
            SafeCalls::FillEnergyAll(g_FillEnergyPct);
            g_PendingFillEnergy = false;
        }
        if (g_PendingGiveCard) {
            SafeCalls::GiveCard(g_GiveCardDeviceId);
            g_PendingGiveCard = false;
        }
        if (g_PendingServerRequestCard) {
            SafeCalls::TestServerRequestCard(g_ServerRequestCardDeviceId, g_ServerRequestCardLevel);
            g_PendingServerRequestCard = false;
        }
        if (g_PendingOctaviaShield) {
            SafeCalls::TestServerRequestCard(26883, 1);
            g_PendingOctaviaShield = false;
        }
        if (g_PendingOctaviaCredit) {
            SafeCalls::TestServerRequestCard(27051, 1);
            g_PendingOctaviaCredit = false;
        }
        if (g_PendingOctaviaUltimate) {
            SafeCalls::TestServerRequestCard(27052, 1);
            g_PendingOctaviaUltimate = false;
        }
        if (g_PendingOctaviaCooldown) {
            SafeCalls::TestServerRequestCard(27053, 1);
            g_PendingOctaviaCooldown = false;
        }
        if (g_PendingTeamSkinBooster) {
            SafeCalls::TestServerRequestCard(23849, 1);
            g_PendingTeamSkinBooster = false;
        }
        if (g_PendingInstantRespawn) {
            g_PendingInstantRespawn = false;
            // WHY THIS GATE EXISTS — the decisive observation.
            // Instant respawn worked exactly once: the run where g_EffectsSafe
            // (== Globals::initObjects()) was 1. In every failing run it was 0.
            //
            // initObjects() resolves Engine -> LocalPlayer -> LocalController ->
            // LocalPawn -> LocalWeapon and bails at the first null. It assigns
            // LocalController BEFORE it can fail on the pawn/weapon, so when it
            // fails we still hold a NON-NULL but STALE controller — typically one
            // left over from a previous match. Firing ServerSetReadyToPlay() at a
            // dead controller dispatches happily and reaches nobody, which is
            // exactly the "196 requests, no effect" signature.
            //
            // So: only send when the object chain is fully valid.
            if (!g_EffectsSafe) {
                g_RespawnBlockedStale++;
            } else {
            CallLogger::Mark("[us] ServerSetReadyToPlay");
            // Zero the CLIENT-side respawn countdown first. If the client is
            // what gates the request until the timer expires, this opens the
            // gate; the RPC that follows is the one the game itself sends.
            if (zeroClientRespawnTimer) SafeCalls::SetClientRespawnTime(0.0f);
            SafeCalls::ServerSetReadyToPlay();
            g_RespawnSendCount++;
            }
        }
        // Auto mode: while dead, re-send once a second. Throttled because this
        // is a reliable RPC — spamming it would overflow the channel and close
        // the connection (that's what booted us during the card-maxer bursts).
        // NOTE: the dead-check lives in its own function (IsLocalPawnDead) — this
        // one builds std::string elsewhere, and MSVC forbids __try sharing a
        // scope with anything requiring unwinding. That's the C2712 build error.
        if (Globals::LocalController) {
            ULONGLONG now = GetTickCount64();
            if (now - g_LastRespawnTryMs > 500) {
                g_LastRespawnTryMs = now;
                g_LastDeadState = IsLocalPawnDead(); // tracked even when auto is off, so the UI can show it
                if (autoInstantRespawn && g_LastDeadState) {
                    SafeCalls::ServerSetReadyToPlay();
                    g_RespawnSendCount++;
                }
            }
        }
        if (g_PendingRefillAmmo) {
            SafeCalls::RefillAmmo();
            g_PendingRefillAmmo = false;
        }
        if (g_PendingSpeedBoost) {
            SafeCalls::SetGroundSpeedMultiplier(1.5f);
            g_PendingSpeedBoost = false;
        }
        if (g_PendingSpeedReset) {
            SafeCalls::SetGroundSpeedMultiplier(1.0f);
            g_PendingSpeedReset = false;
        }
        if (g_PendingDamageBoost) {
            SafeCalls::SetDamageMultiplier(1.5f);
            g_PendingDamageBoost = false;
        }
        if (g_PendingDamageReset) {
            SafeCalls::SetDamageMultiplier(1.0f);
            g_PendingDamageReset = false;
        }
        if (g_PendingSpawnDeployable) {
            SafeCalls::SpawnDeployable(g_SpawnDeployableId);
            g_PendingSpawnDeployable = false;
        }

        // Drain the throttled RPC queue — exactly one per tick so we never
        // overflow the reliable channel and get the connection closed.
        DrainOneRpc();

        // --- Real server RPCs ---
        if (g_PendingTempPassiveId != 0) {
            int id = g_PendingTempPassiveId;
            g_PendingTempPassiveId = 0;
            EnqueueRpc(RPC_SelectTempPassive, id, 0);
            EnqueueRpc(RPC_EquipPassive, 0, 0); // select then equip, spaced across ticks
        }
        if (g_PendingEquipPassive) {
            g_PendingEquipPassive = false;
            EnqueueRpc(RPC_EquipPassive, 0, 0);
        }
        if (g_PendingAutoAddItems) {
            g_PendingAutoAddItems = false;
            SafeCalls::ServerRequestAutoAddTempItems();
        }
        if (g_PendingPurchaseAllItems) {
            g_PendingPurchaseAllItems = false;
            SafeCalls::ServerRequestPurchaseAllTempItems();
        }
        if (g_PendingServerFlagsBoost) {
            g_PendingServerFlagsBoost = false;
            // sprint on, minimap team vis on, 2x server-side damage, out-of-combat sprint on
            SafeCalls::ServerSetServerFlags(true, true, 2.0f, false, false, true);
        }
        if (g_PendingServerFlagsReset) {
            g_PendingServerFlagsReset = false;
            SafeCalls::ServerSetServerFlags(false, false, 1.0f, false, false, false);
        }
        if (g_PendingServerSetValueTest) {
            g_PendingServerSetValueTest = false;
            // Harmless probe: ask the server to set our own controller's damage
            // multiplier. If ServerSetValue is unlocked, this proves it.
            CallLogger::Mark("[us] PROBE ServerSetValue");
            bool ok = SafeCalls::ServerSetValue(L"TgPlayerController", L"m_fDamageMultiplier", L"2.0");
            Testing::SetOutput(std::string(
                "=== PROBE: ServerSetValue ===\n"
                "Sent: object=TgPlayerController  var=m_fDamageMultiplier  value=2.0\n"
                "Call dispatched: ") + (ok ? "YES (no crash)" : "NO (threw, caught safely)") + "\n\n"
                "IMPORTANT: \"dispatched\" only means the RPC left our process. It does NOT mean the\n"
                "server accepted it. To find out whether the server actually reacted:\n"
                "  1. Go to the Call Log tab\n"
                "  2. Click the \"Client (server replies)\" preset, turn Logging ON\n"
                "  3. Come back and press this probe again\n"
                "  4. Build Report. Any Client*-prefixed function appearing = the server responded.\n"
                "     Nothing appearing = it silently ignored us.\n\n"
                "Then shoot something and see if your damage is actually doubled.\n");
        }
        if (g_PendingServerExecTest) {
            g_PendingServerExecTest = false;
            CallLogger::Mark("[us] PROBE ServerExec");
            bool haveCm = Globals::LocalController && Globals::LocalController->CheatManager;
            bool ok = haveCm ? SafeCalls::ServerExec(L"MaxLevel") : false;
            Testing::SetOutput(std::string(
                "=== PROBE: ServerExec ===\n"
                "CheatManager present: ") + (haveCm ? "yes" : "NO — cannot send, this probe needs it") + "\n"
                "Sent command: MaxLevel\n"
                "Call dispatched: " + (ok ? "YES (no crash)" : "NO") + "\n\n"
                "Same caveat as the other probe: dispatched != accepted. Use the Call Log with the\n"
                "\"Client (server replies)\" filter to see whether the server answered.\n\n"
                "ServerExec is the single most valuable thing to land — it runs an arbitrary command\n"
                "server-side, so if this works, most other blocked features become reachable.\n");
        }
        if (g_PendingOutlinesToggle && Globals::LocalController) {
            SafeCalls::SetOutlines(outlineFriendly, outlineEnemy);
            g_PendingOutlinesToggle = false;
        }
        if (g_PendingOutlineColorApply) {
            if (Globals::LocalPawn) {
                TryApplyOutlineColorRaw((SDK::ATgPawn*)Globals::LocalPawn, g_PendingOutlineColorRGBA);
            }
            g_PendingOutlineColorApply = false;
        }
        if (g_PendingColorBlind && Globals::LocalController) {
            SafeCalls::EnableColorBlindEffect(g_PendingColorBlindEnable, g_PendingColorBlindType, g_PendingColorBlindIntensity);
            g_PendingColorBlind = false;
        }
        if (g_PendingOutlineEffectOn && Globals::LocalPlayer) {
            SafeCalls::EnableOutlineEffect(true);
            g_PendingOutlineEffectOn = false;
        }
        if (g_PendingOutlineEffectOff && Globals::LocalPlayer) {
            SafeCalls::EnableOutlineEffect(false);
            g_PendingOutlineEffectOff = false;
        }
        if (g_PendingThirdPersonToggle && Globals::LocalController && Globals::LocalController->CheatManager) {
            // Switched from PushCameraPosture to the CheatManager's own
            // Set3p/Set1p — PushCameraPosture didn't actually work in bot
            // matches even though the real escape-menu option proves the
            // feature itself works there; direct dev commands are much more
            // likely to bypass whatever UI-only gating hid the menu button.
            SafeCalls::Set3p(thirdPersonOn);
            g_PendingThirdPersonToggle = false;
        }
    }

    inline void ResetAllToDefaults() {
        activateFireMode = false;
        activateCustomMode = false;
        activateAimAssist = false;

        // Revert any live changes back to neutral, not just uncheck boxes.
        g_PendingOutlineReset = true;
        outlineFriendly = false;
        outlineEnemy = false;
        triggerBotEnabled = false;
        triggerBotPredictionBox = false;
        triggerBotV2Enabled = false;
        headLockEnabled = false;
        headLockAlwaysOnEnabled = false;
        bodyLockEnabled = false;
        bodyLockAlwaysOnEnabled = false;
        magnetAimEnabled = false;
        autoHealEnabled = false;
        autoHealMode = 0;
        autoHealHealthThreshold = 1.0f;  // heal anything below 100%
        magnetAimRadius = 90.0f;
        aimLockStrength = 0.40f;   // matches the declared default above

        if (thirdPersonOn) {
            ToggleThirdPerson(false); // properly pops the posture, not just flips the flag
        }

        g_ManualDevice = nullptr;
        g_ScanResults.clear();
    }

    inline void DrawStatusBanner(bool inMatch) {
        if (ImGui::SmallButton("Hide (F3)")) {
            ::g_bShowMenu = false; // ::  forces the real global, not a namespace-local one
        }
        ImGui::SameLine();
        if (inMatch) {
            ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.6f, 1.0f)), "In a match — tools below are ready to use.");
        } else {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)), "Not in a match yet — join a match first.");
        }
        Gating::DrawStatusLine();
        ImGui::TextDisabled("F3 = show/hide this window   |   F4 = reset everything below");
    }

    // ========================================================================
    // CONFIRMED EXPLOITS FOR WHOEVER YOU ARE PLAYING
    // ========================================================================
    // These live in the Cards tab as part of a twenty-row sweep. That is the
    // right place to FIND them and the wrong place to USE them - mid-match you
    // want the one that applies to your champion, not a list.
    //
    // So Fire Modes shows only what matches the champion you are actually on,
    // and fires it through the same eq-point path the sweep uses. If the sweep
    // has not run yet the button says so rather than silently doing nothing.
    inline void DrawChampionExploits(bool inMatch) {
        if (!inMatch) return;

        // Which champion are we? The box gather already resolves this every
        // frame for the prediction table, so reuse it rather than adding
        // another scripted read.
        const char* champ = VisibilityBoxes::g_MyChampInternal;
        if (!champ || !champ[0]) return;

        const KnownExploits::Exploit* mine[8];
        int count = KnownExploits::ForChampion(champ, mine, 8);
        if (count == 0) return;

        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.80f, 0.25f, 1.0f)));
        ImGui::Text("CONFIRMED EXPLOITS  -  %s", champ);
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Found by hand and verified in real matches. Firing goes through the "
            "same equip-point route the Cards tab uses.");

        for (int i = 0; i < count; ++i) {
            const KnownExploits::Exploit* ex = mine[i];

            ImGui::Spacing();
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.45f, 1.00f, 0.60f, 1.0f)));
            ImGui::TextUnformatted(ex->label);
            ImGui::PopStyleColor();
            ImGui::TextDisabled("%s", ex->note);

            // One toggle per required device. For the BOTH-REQUIRED ones a
            // single button would be a lie, since one alone does nothing - so
            // there is a row per step and a header saying they must run together.
            if (ex->needsAll && ex->stepCount > 1) {
                ImGui::TextColored(Ink(ImVec4(1.0f, 0.72f, 0.30f, 1.0f)),
                                   "BOTH must be spamming at once.");
            }

            for (int s = 0; s < ex->stepCount; ++s) {
                int eq  = ex->steps[s].eq;
                int dev = ex->steps[s].deviceId;

                // Find this device in the live sweep.
                int row = -1;
                for (int r = 0; r < DirectFire::g_EqCount; ++r) {
                    if (DirectFire::g_Eq[r].eq == eq && DirectFire::g_Eq[r].deviceId == dev) {
                        row = r; break;
                    }
                }
                // Fall back to matching on device id alone - equip points have
                // shifted between builds before.
                if (row < 0) {
                    for (int r = 0; r < DirectFire::g_EqCount; ++r) {
                        if (DirectFire::g_Eq[r].deviceId == dev) { row = r; break; }
                    }
                }

                char id[64];
                wsprintfA(id, "FIRE##fmx%d_%d", i, s);
                if (row >= 0) {
                    if (ImGui::Button(id, ImVec2(64, 22))) DirectFire::g_PendingFireEq = row;
                    ImGui::SameLine();
                    char sp[64]; wsprintfA(sp, "spam##fmx%d_%d", i, s);
                    ImGui::Checkbox(sp, &DirectFire::g_Eq[row].spam);
                    ImGui::SameLine();
                    ImGui::TextDisabled("eq%d  %s  x%d",
                        DirectFire::g_Eq[row].eq, DeviceNames::NameOf(dev),
                        DirectFire::g_Eq[row].shots);
                } else {
                    ImGui::BeginDisabled();
                    ImGui::Button(id, ImVec2(64, 22));
                    ImGui::EndDisabled();
                    ImGui::SameLine();
                    ImGui::TextDisabled("eq%d  %s  -  not in the sweep yet", eq, DeviceNames::NameOf(dev));
                }
            }
        }

        if (DirectFire::g_EqCount == 0) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.72f, 0.30f, 1.0f)),
                "Device sweep is empty - it auto-runs a moment after you spawn.");
            ImGui::SameLine();
            if (ImGui::SmallButton("sweep now")) DirectFire::g_PendingEqSweep = true;
        }

        ImGui::Spacing();
        ImGui::Separator();
    }

    inline void DrawFireModesTab(bool inMatch) {
        // CHARITY GATE, per group now - see Gating.h.
        Gating::DrawBlockedBannerFor(Gating::Gated::FireModes);

        // INSTANT RESPAWN at the very top, per PRIMAL_MONKE - it's one of the
        // most-used things and belongs where people can reach it instantly.
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.4f, 1.0f, 0.6f, 1.0f)));
        ImGui::TextUnformatted("INSTANT RESPAWN");
        ImGui::PopStyleColor();
        ImGui::Checkbox("Auto-respawn the instant you die", &autoInstantRespawn);
        ImGui::SameLine();
        if (ImGui::Button("Respawn now")) g_PendingInstantRespawn = true;
        ImGui::TextDisabled("Fires the game's own 'ready to play' the moment you're dead. Private/practice only.");
        if (g_RespawnBlockedStale > 0 && g_RespawnSendCount == 0)
            ImGui::TextDisabled("(waiting for a valid match - it only sends once you're fully in)");
        ImGui::Separator();

        // The champion-specific exploits go next - they are the reason to open
        // this tab in a match.
        DrawChampionExploits(inMatch);
        // Sits above the "Turn on" gate on purpose: instant reload auto-detects the
        // champion and is independent of fire-mode switching, so hiding it behind
        // that checkbox would just make it look broken on Damba/Dredge.
        // Removed from the visible tab: it drew on every champion whether it
        // applied or not, and it did not work. Implementation untouched.
        // InstantReload (Damba/Dredge) - REMOVED from this tab completely.
        // It was asked to be removed and I only hid it behind developer mode,
        // which is not the same thing. InstantReload.h is untouched on disk.

        ImGui::Checkbox("Turn on", &activateFireMode);
        ImGui::TextDisabled("Lets you check if a weapon/ability has a hidden second mode, and switch to it.");
        ImGui::Separator();
        if (!activateFireMode) return;
        if (!inMatch) { ImGui::TextDisabled("Join a match first."); return; }
        RenderFireModeMenu();
    }

    // ========================================================================
    // 4TH TALENT + EMOTES
    // ------------------------------------------------------------------------
    // The 4th-talent backend (Helpers::CacheTalentInfos / Helpers::g_talent)
    // was ALREADY in this codebase and already running every frame the menu
    // is open - there was even an orphaned "Talent Selection Panel" checkbox
    // in an old dev-only Control Panel window that nothing ever read. It just
    // never had anything reading the snapshot. DrawTalentsTab() below is
    // that missing piece - originally a separate floating window (matching
    // a third-party tool's original drawTalentSelection()), moved into the tab
    // body itself per feedback ("I thought I asked you to make it inside the
    // 4th talent tab instead of a seperate popup").
    //
    // Emotes went a similar route but further: the original port
    // (menus/EquipEmoteMenu.h, RenderEquipEmoteMenu()) targeted the in-match
    // radial emote wheel and was never actually called from anywhere - dead
    // code, no button. Once wired up it turned out that screen is too fiddly
    // to reliably reach at all, so DrawEmotesTab() below was rebuilt from
    // scratch on the SAME emote database but targeting the champion detail
    // page's own Emotes tab instead - ordinary main-menu navigation, no
    // wheel. The old radial-wheel file is left on disk, just unwired from
    // main.cpp.
    //
    // Both tabs are now normal embedded tab content, same as every other tab
    // in this file - no floating windows.
    // ========================================================================

    // Was a separate floating window (matching a third-party tool's original
    // drawTalentSelection()) — moved into the tab body per PRIMAL_MONKE's
    // feedback ("I thought I asked you to make it inside the 4th talent tab
    // instead of a seperate popup"). No behavior change beyond that: same
    // snapshot read, same use-after-free fix (reads labels off snap.talents[n]
    // directly rather than the dangling snap.talent_labels pointers).
    // TalentDatabase.h's hidden/visible flag (kTalents[], transitively
    // included via menus/CardsTab.h) is per champion+id - the SAME data that
    // already answers "is this one of the game's normal 3, or a removed/
    // replaced one you can't normally pick." Unknown talent -> treated as
    // not-hidden rather than guessed either way.
    inline bool IsHiddenTalentId(const std::string& champion, int id) {
        for (const auto& e : TalentDB::kTalents) {
            if (e.id == id && champion == e.champion) return e.hidden;
        }
        return false;
    }

    inline void DrawTalentsTab(bool inMatch) {
        ImGui::TextWrapped(
            "Pick ANY of a champion's talents live - including ones the game "
            "doesn't give you a button for - instead of just the 3 tiles the "
            "loadout screen offers.");
        ImGui::Separator();
        // TextWrapped (not TextDisabled, which runs off the edge) so the whole
        // instruction stays on screen. Muted colour to keep it a note.
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.62f, 0.62f, 0.66f, 1.0f)));
        ImGui::TextWrapped(
            "How to use:\n"
            "1. On the Champion Select / Loadout / Cards screen, first pick one of "
            "your normal 3 base talents (in the game's own menu).\n"
            "2. THEN, on that same screen and BEFORE you confirm/lock your loadout, "
            "pick a talent here from the list below. It applies right away.\n"
            "The BLUE ones are the hidden 4th talents the game never gives you a "
            "button for - that's the whole point of this tab.\n"
            "Order matters: base talent first, then your 4th talent, then confirm.");
        ImGui::PopStyleColor();
        ImGui::Spacing();
        ImGui::Separator();

        Helpers::TalentSnapshot snap{};
        bool locked = Helpers::g_talent.mtx.try_lock();
        if (locked) {
            snap = Helpers::g_talent.snapshot;
            Helpers::g_talent.mtx.unlock();
        }

        if (!locked) {
            ImGui::TextDisabled("Status: busy, try again next frame.");
            return;
        }
        if (!snap.has_deck) {
            ImGui::TextDisabled("Status: waiting - open your loadout screen.");
            return;
        }
        if (snap.talents.empty()) {
            ImGui::TextDisabled("Status: loadout screen open, but no talent data found for this champion.");
            return;
        }
        if (snap.step_num != 1) {
            ImGui::TextDisabled("Status: loadout screen open, but not on the talent step.");
            return;
        }

        ImGui::TextColored(ImVec4(0.4f, 0.85f, 0.4f, 1.0f), "Status: live - pick a talent below.");
        ImGui::Spacing();

        int selected_index = snap.selected_index;
        if (selected_index < 0 || selected_index >= (int)snap.talents.size()) selected_index = 0;

        int itemCount = static_cast<int>(snap.talents.size());
        std::string champion = GetCurrentChampionName();

        // Sort order only - never reorders snap.talents itself (that would
        // desync selected_index from snap.selected_index every frame).
        // Hidden ones surface first since that's the actual reason to have
        // this tab open at all; a small button, not a dropdown, per
        // feedback that the old combo box was too small/cramped to use.
        static int order[64];
        int hiddenCount = 0, normalCount = 0;
        for (int n = 0; n < itemCount && n < 64; n++) {
            if (IsHiddenTalentId(champion, snap.talents[n].id)) order[hiddenCount++] = n;
        }
        int firstNormal = hiddenCount;
        for (int n = 0; n < itemCount && n < 64; n++) {
            if (!IsHiddenTalentId(champion, snap.talents[n].id)) order[firstNormal + normalCount++] = n;
        }
        int orderedCount = hiddenCount + normalCount;

        // Read labels straight off snap.talents[n].name, which THIS copy of
        // the snapshot genuinely owns (std::string deep-copies on snapshot
        // assignment). Deliberately NOT using snap.talent_labels - that field
        // stores raw const char* pointers into a DIFFERENT TalentSnapshot's
        // strings (the one still sitting in Helpers::g_talent.snapshot),
        // which go dangling the instant the safe thread's next
        // CacheTalentInfos() call replaces it - a real, reliably reproducible
        // use-after-free that crashed on the very first BeginCombo() click.
        // Same latent bug exists in the original third-party code this was
        // ported from; just never got exercised.
        ImGui::BeginChild("TalentBigList", ImVec2(0, 300), true);

        // HIDDEN / 4th talents: big dark-blue BUTTONS (not tiny yellow text),
        // each with its description right under it - the "big buttons, easy to
        // read, says what it does" ask. Blue instead of the old hard-to-read
        // yellow. The equipped one glows brighter blue with a checkmark.
        if (hiddenCount > 0) {
            // Ink() so this heading darkens to a readable navy on the light
            // (Egyptian Sand) theme instead of vanishing as pale blue.
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.20f, 0.42f, 0.80f, 1.0f)));
            ImGui::TextUnformatted("HIDDEN / 4TH TALENTS");
            ImGui::PopStyleColor();
            ImGui::Spacing();
        }
        for (int k = 0; k < hiddenCount; k++) {
            int n = order[k];
            const bool is_selected = (selected_index == n);
            ImVec4 base   = is_selected ? ImVec4(0.20f, 0.45f, 0.85f, 1.0f) : ImVec4(0.11f, 0.20f, 0.42f, 1.0f);
            ImGui::PushStyleColor(ImGuiCol_Button, base);
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.40f, 0.78f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.26f, 0.52f, 0.92f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_Text,          ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
            char label[300];
            snprintf(label, sizeof(label), "%s%s##talent%d",
                     is_selected ? "\xE2\x9C\x93 " : "", snap.talents[n].name.c_str(), n);
            if (ImGui::Button(label, ImVec2(-1.0f, 46.0f))) {
                selected_index = n;
                int newTalentId = snap.talents[n].id;
                std::lock_guard<std::mutex> lock(Helpers::g_talent.mtx);
                Helpers::g_talent.pending.new_selected_talent_id = newTalentId;
            }
            ImGui::PopStyleColor(4);
            // Description INSIDE a dark box with WHITE text - readable on EVERY
            // theme (the old pale-blue text was invisible on the light theme).
            const char* desc = snap.talents[n].description.c_str();
            float availW = ImGui::GetContentRegionAvail().x;
            float wrapW  = availW - 16.0f; if (wrapW < 40.0f) wrapW = 40.0f;
            ImVec2 tsz = ImGui::CalcTextSize(desc, nullptr, false, wrapW);
            char cid[24]; snprintf(cid, sizeof(cid), "desc%d", n);
            ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.08f, 0.14f, 0.28f, 1.0f));
            ImGui::BeginChild(cid, ImVec2(0.0f, tsz.y + 14.0f), false, ImGuiWindowFlags_NoScrollbar);
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
            ImGui::PushTextWrapPos(0.0f);
            ImGui::TextUnformatted(desc);
            ImGui::PopTextWrapPos();
            ImGui::PopStyleColor();
            ImGui::EndChild();
            ImGui::PopStyleColor();
            ImGui::Spacing();
        }

        // STANDARD talents: sectioned off, compact and dimmed, still clickable
        // but not competing for attention with the hidden ones.
        if (normalCount > 0) {
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextDisabled("Standard talents");
            for (int k = hiddenCount; k < orderedCount; k++) {
                int n = order[k];
                const bool is_selected = (selected_index == n);
                ImGui::PushStyleColor(ImGuiCol_Text, is_selected ? Ink(ImVec4(0.30f, 0.55f, 0.95f, 1.0f))
                                                                  : Ink(ImVec4(0.62f, 0.62f, 0.66f, 1.0f)));
                char label[300];
                snprintf(label, sizeof(label), "%s##talent%d", snap.talents[n].name.c_str(), n);
                if (ImGui::Selectable(label, is_selected, 0, ImVec2(0, 22))) {
                    selected_index = n;
                    int newTalentId = snap.talents[n].id;
                    std::lock_guard<std::mutex> lock(Helpers::g_talent.mtx);
                    Helpers::g_talent.pending.new_selected_talent_id = newTalentId;
                }
                ImGui::PopStyleColor();
                if (ImGui::IsItemHovered())
                    ImGui::SetTooltip("%s", snap.talents[n].description.c_str());
            }
        }
        ImGui::EndChild();

        // A bigger, always-visible readout of whichever one is CURRENTLY
        // equipped, in place of an image this data set doesn't have (no
        // icon/asset path exists anywhere in TalentMapping.h or
        // TalentDatabase.h to draw from - would need a new source, not
        // something to fake).
        if (selected_index >= 0 && selected_index < itemCount) {
            ImGui::Spacing();
            ImGui::Separator();
            bool curHidden = IsHiddenTalentId(champion, snap.talents[selected_index].id);
            ImGui::TextColored(curHidden ? Ink(ImVec4(0.30f, 0.55f, 0.95f, 1.0f)) : Ink(ImVec4(0.35f, 0.55f, 0.9f, 1.0f)),
                "SELECTED: %s%s", curHidden ? "\xE2\x9C\x93 " : "", snap.talents[selected_index].name.c_str());
            ImGui::TextWrapped("%s", snap.talents[selected_index].description.c_str());
        }
    }

    // Isolated (POD-only) accessors for the emote scene/pointer chain below -
    // same reasoning and same __try/std::string-can't-mix constraint as
    // Utils/Helper.h's Safe* functions for the talent chain. Reads the
    // selected emote ID ONCE per frame into a plain int instead of
    // dereferencing skinComp->m_pSelectedEmote->m_nId on every row of a
    // ~190-entry list, which is both safer (one guarded read instead of
    // ~190 unguarded ones) and cheaper.
    inline SDK::UUIComponent_ChampionSkins* SafeGetEmoteSkinComp() {
        SDK::UUIScene* scene = Globals::containsScene(SDK::UUIChampion::StaticClass());
        if (!scene) return nullptr;
        __try {
            auto* championScene = static_cast<SDK::UUIScene_UIChampion*>(scene);
            if (!championScene || championScene->m_eState != SDK::EUICHAMPION_STATE::UICS_EMOTES) return nullptr;
            return championScene->m_pSkins;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline bool SafeReadSelectedEmoteId(SDK::UUIComponent_ChampionSkins* skinComp, int* out_id) {
        if (!skinComp) return false;
        __try {
            if (!skinComp->m_pSelectedEmote) return false;
            *out_id = skinComp->m_pSelectedEmote->m_nId;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool SafeSetSelectedEmoteId(SDK::UUIComponent_ChampionSkins* skinComp, int id) {
        if (!skinComp) return false;
        __try {
            if (!skinComp->m_pSelectedEmote) return false;
            skinComp->m_pSelectedEmote->m_nId = id;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Rebuilt from scratch on top of a third-party emote database
    // (all_emotes / emoteChampions in Utils/EquipHandler.h) after the
    // original radial-wheel version proved too fiddly to even reach in
    // practice ("his emotes method is really weird to use"). This version
    // targets a completely different, much more reliably reachable game
    // screen: the champion detail page's own Emotes tab (the normal one you
    // already use in the main menu to pick emotes) - EUICHAMPION_STATE::
    // UICS_EMOTES on UUIScene_UIChampion, writing straight to
    // m_pSkins->m_pSelectedEmote->m_nId. That field write (not a
    // ProcessEvent call) is safe from the render thread, and it is the
    // SAME field Helpers::resetFirstEmoteToDefault() already resets on F1 -
    // that existing safety net keeps working here for free.
    inline void DrawEmotesTab(bool inMatch) {
        ImGui::TextWrapped(
            "Pick ANY champion's emote for whoever you're playing right now "
            "(e.g. Ruckus's emotes on Evie) - straight from this list, no "
            "wheel, no double-clicking.");
        ImGui::Separator();
        ImGui::TextDisabled(
            "How to use: from the main menu, open the champion you want, go "
            "to its Emotes tab the way you normally would, and select the "
            "slot you want to change. With that screen open, search or "
            "browse below and click any emote to swap it in. If something "
            "looks wrong, press F1 while still on that screen to reset back "
            "to the champion's own default.");
        ImGui::Spacing();
        ImGui::Separator();

        InitializeEmotes();

        SDK::UUIComponent_ChampionSkins* skinComp = SafeGetEmoteSkinComp();
        int currentEmoteId = -1;
        if (!skinComp || !SafeReadSelectedEmoteId(skinComp, &currentEmoteId)) {
            ImGui::TextDisabled("Status: waiting - open a champion's Emotes tab in the main menu.");
            return;
        }
        ImGui::TextColored(ImVec4(0.4f, 0.85f, 0.4f, 1.0f), "Status: live - pick an emote below.");
        ImGui::Spacing();

        static char emoteSearchBuffer[128] = "";
        static std::string emoteChampFilter = "";

        {
            float fullWidth   = ImGui::GetContentRegionAvail().x;
            float searchWidth = fullWidth * 0.55f;
            float comboWidth  = fullWidth - searchWidth - ImGui::GetStyle().ItemSpacing.x;

            ImGui::PushItemWidth(searchWidth);
            ImGui::InputText("##EmotesTabSearch", emoteSearchBuffer, IM_ARRAYSIZE(emoteSearchBuffer));
            ImGui::PopItemWidth();
            ImGui::SameLine();

            const char* currentLabel = emoteChampFilter.empty() ? "All champions" : emoteChampFilter.c_str();
            ImGui::PushItemWidth(comboWidth);
            if (ImGui::BeginCombo("##EmotesTabChampFilter", currentLabel)) {
                if (ImGui::Selectable("All champions", emoteChampFilter.empty())) emoteChampFilter.clear();
                ImGui::Separator();
                for (const auto& champName : emoteChampions) {
                    if (ImGui::Selectable(champName.c_str(), emoteChampFilter == champName)) emoteChampFilter = champName;
                }
                ImGui::EndCombo();
            }
            ImGui::PopItemWidth();
        }

        std::string searchStr(emoteSearchBuffer);
        std::transform(searchStr.begin(), searchStr.end(), searchStr.begin(),
            [](unsigned char c) { return static_cast<char>(std::tolower(c)); });

        ImGui::BeginChild("EmotesTabList", ImVec2(0, 220), true);
        for (const auto& emote : all_emotes) {
            if (!emoteChampFilter.empty() && emote.champion != emoteChampFilter) continue;

            std::string nameLower = emote.name;
            std::transform(nameLower.begin(), nameLower.end(), nameLower.begin(),
                [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
            if (!searchStr.empty() && nameLower.find(searchStr) == std::string::npos) continue;

            char label[256];
            snprintf(label, sizeof(label), "[%s] %s", emote.champion.c_str(), emote.name.c_str());
            bool isCurrent = (currentEmoteId == emote.id);
            if (ImGui::Selectable(label, isCurrent)) {
                SafeSetSelectedEmoteId(skinComp, emote.id);
            }
        }
        ImGui::EndChild();
    }

    // ============================================================================
    // ANTI-CHEAT  —  research + a starting proof-of-concept, per PRIMAL_MONKE.
    // ------------------------------------------------------------------------
    // Three questions drove this: (1) can a cheater be removed from a match,
    // for everyone or just themselves, (2) can the whole roster be seen
    // before/during a match to identify them at all, (3) what actually
    // happened in the Cassie-ult-then-disconnect report (see
    // ModdificationMapping.md, category 5, for the full writeup).
    //
    // FINDINGS, SDK-confirmed this session:
    //   - AGameInfo::Kick / ForceKickPlayer exist, but AGameInfo is a
    //     SERVER-ONLY actor in UE3's networking model — a client never has a
    //     valid instance of it to call through. No path found to kick a
    //     specific player from here.
    //   - ATgPlayerController::ServerSurrender(bool) is a REAL, sanctioned,
    //     client-callable RPC — the same one the game's own surrender-vote
    //     UI uses. It is team-wide (ends the match for EVERYONE once your
    //     team's votes clear the server's threshold), not aimed at one
    //     player. Whether that threshold is actually enforced correctly, or
    //     trusts a client's vote count too far, is untested — wired up below
    //     so it can be.
    //   - CONFIRMED by PRIMAL_MONKE's own live testing: ServerSurrender does
    //     NOT visibly end/affect a match, even in a bot match. Dead end as
    //     the primary method - kept wired up below since it's still a real,
    //     legitimate RPC and costs nothing to leave available.
    //   - NEW LEAD: UTgBattleCheatManager::EndGame() / QuickEndGame(bool) —
    //     reached via APlayerController::CheatManager, a real, non-Net,
    //     genuinely client-side field every controller has (unlike
    //     AGameInfo/ATgGame_Mission). Both dumped as "(Defined, Exec,
    //     Public)" straight from the shipped binary. Untested past this -
    //     see SafeCalls::CheatManagerEndGame() for the full caveat.
    //   - No mechanism found yet for per-player removal (phase B). Every
    //     function that plausibly does this (AGameInfo::Kick/ForceKickPlayer,
    //     the bot-swap chain) lives on a server-only actor. If one exists
    //     client-side, it has not surfaced in the SDK yet.
    //
    // The roster below reads from the SAME cached gather Highlights/aim-lock
    // already use every frame (VisibilityBoxes::g_CachedGather) — no new
    // scanning, no new risk, just displaying data already being collected.
    // It only covers players CURRENTLY LOADED as pawns, i.e. once a match
    // has actually started — the "see who I'm queued against before it
    // starts" ask needs the matchmaking/lobby scene instead, not yet found.

    // r_nSurrenderVote and r_bIsSurrendering are (Net) - real, server-
    // replicated fields, unlike the availability flag (m_bSurrenderAvailable
    // lives on ATgGame_Mission, which is server-only, same closed door as
    // AGameInfo::Kick — we cannot read WHY it's unavailable, only whether a
    // vote actually registered). Reading these instead of firing the button
    // blind is how "does nothing" turns into an actual answer: if the vote
    // count moves, the RPC reached the server and was accepted; if it never
    // moves, something about the call itself isn't landing.
    inline bool SafeReadSurrenderVote(int* outVote) {
        if (!Globals::LocalPawn) return false;
        __try {
            auto* pri = (SDK::ATgRepInfo_Player*)((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo;
            if (!pri) return false;
            *outVote = (int)pri->r_nSurrenderVote;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline void DrawAntiCheatTab(bool inMatch) {
        ImGui::TextWrapped(
            "Research + a starting point, not a finished tool. Full writeup in "
            "ModdificationMapping.md.");
        ImGui::Separator();

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("MATCH ROSTER");
        ImGui::PopStyleColor();
        if (!inMatch) {
            ImGui::TextDisabled("Not in a match - nothing loaded yet. Pre-match/queue visibility "
                "(seeing opponents before the match starts) needs the lobby/matchmaking scene, "
                "which hasn't been found yet - this list only sees players once a match has "
                "actually begun.");
        } else {
            const VisibilityBoxes::GatherResult& g = VisibilityBoxes::g_CachedGather;
            if (!g.ok || g.count == 0) {
                ImGui::TextDisabled("No players gathered yet this frame.");
            } else {
                int allyCount = 0, enemyCount = 0;
                for (int i = 0; i < g.count; i++) {
                    if (g.entries[i].kind == VisibilityBoxes::BoxKind::Ally) allyCount++;
                    else if (g.entries[i].kind == VisibilityBoxes::BoxKind::Enemy) enemyCount++;
                }
                ImGui::Text("%d ally, %d enemy (deployables/pets excluded)", allyCount, enemyCount);
                ImGui::BeginChild("AntiCheatRoster", ImVec2(0, 160), true);
                for (int i = 0; i < g.count; i++) {
                    const VisibilityBoxes::BoxEntry& e = g.entries[i];
                    if (e.kind == VisibilityBoxes::BoxKind::Other) continue;
                    const char* teamLabel = (e.kind == VisibilityBoxes::BoxKind::Ally) ? "ALLY " : "ENEMY";
                    ImGui::TextColored(
                        e.kind == VisibilityBoxes::BoxKind::Ally ? ImVec4(0.4f, 0.85f, 1.0f, 1.0f)
                                                                  : ImVec4(1.0f, 0.4f, 0.4f, 1.0f),
                        "[%s] %-20s playing %s", teamLabel,
                        e.playerName[0] ? e.playerName : "(unknown)",
                        e.championName[0] ? e.championName : "?");
                }
                ImGui::EndChild();
            }
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("SURRENDER (real vote RPC, team-wide, not per-player)");
        ImGui::PopStyleColor();
        ImGui::TextWrapped(
            "Sends the same ServerSurrender RPC the game's own vote-to-surrender button uses. "
            "Ends the match for EVERYONE, not a specific player, and only if the server actually "
            "requires (and correctly counts) real team votes - untested past this button. Note: "
            "Paladins gates surrender to certain modes and only after a time threshold into the "
            "match (m_bSurrenderAvailable/m_fSurrenderTime exist server-side) - the shooting range "
            "and an early bot match are both plausible reasons for a real vote to still do nothing, "
            "not necessarily a broken call.");
        int voteVal = -1;
        bool haveVote = SafeReadSurrenderVote(&voteVal);
        if (haveVote) {
            ImGui::TextColored(ImVec4(0.4f, 0.85f, 1.0f, 1.0f),
                "Your replicated vote state right now: r_nSurrenderVote = %d", voteVal);
            ImGui::TextDisabled("If this changes after pressing the button, the RPC reached the "
                "server and was accepted - the match just needs more votes/time. If it never "
                "moves, the call itself isn't landing.");
        } else {
            ImGui::TextDisabled("Vote state unreadable right now (not in a match / no PRI yet).");
        }
        if (!inMatch) ImGui::BeginDisabled();
        if (ImGui::Button("Send surrender vote", ImVec2(200, 30))) {
            SafeCalls::ServerSurrender(true);
        }
        if (!inMatch) ImGui::EndDisabled();

        // ------------------------------------------------------------------
        // NEW METHODS — added after PRIMAL_MONKE confirmed via live bot-match
        // testing that surrender does nothing at all, not even there. See the
        // full writeup in ModdificationMapping.md and the comment above
        // SafeCalls::CheatManagerEndGame(). Phase A only (end for everyone) —
        // phase B (remove one specific player) still has no lead; nothing
        // found client-side plays that role, only server-only actors do.
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("END MATCH — new methods (untested, try live)");
        ImGui::PopStyleColor();
        bool haveCM = SafeCalls::HasCheatManager();
        if (haveCM)
            ImGui::TextColored(ImVec4(0.4f, 1.0f, 0.5f, 1.0f),
                "CheatManager reachable — the call below WILL reach the function body. "
                "Whether that body still does anything in a shipped build is what this tests.");
        else
            ImGui::TextColored(ImVec4(1.0f, 0.4f, 0.4f, 1.0f),
                "CheatManager is null right now — nothing below can do anything until this reads "
                "true (try again once fully loaded into a match).");
        ImGui::TextWrapped(
            "UTgBattleCheatManager::EndGame() / QuickEndGame(bWin) — real UFunctions dumped "
            "straight from the shipped client with the Exec flag intact, reached through "
            "CheatManager, which is genuinely client-side (unlike AGameInfo/ATgGame_Mission). "
            "Not proof they still fire once inside — shipped builds commonly gate cheat commands "
            "server-side. Only real way to know is trying it live.");
        if (!inMatch || !haveCM) ImGui::BeginDisabled();
        if (ImGui::Button("EndGame()", ImVec2(160, 30))) {
            SafeCalls::CheatManagerEndGame();
        }
        ImGui::SameLine();
        if (ImGui::Button("QuickEndGame(win)", ImVec2(160, 30))) {
            SafeCalls::CheatManagerQuickEndGame(true);
        }
        ImGui::SameLine();
        if (ImGui::Button("QuickEndGame(lose)", ImVec2(160, 30))) {
            SafeCalls::CheatManagerQuickEndGame(false);
        }
        if (!inMatch || !haveCM) ImGui::EndDisabled();
    }

    // Isolated — no C++ objects in scope (the __try/std::string mixing bug
    // seen a few times now). Walks equip points, reads each device's real ID,
    // fires the server request, and reports back via plain output arrays.
    inline int AutoMaxEquippedCards(SDK::ATgPawn* pawn, int* outPoints, int* outIds, int maxResults) {
        int count = 0;
        for (int point = 0; point <= 20 && count < maxResults; point++) {
            SDK::ATgDevice* d = nullptr;
            __try { d = pawn->GetDeviceByEqPoint(point); }
            __except (EXCEPTION_EXECUTE_HANDLER) { d = nullptr; }
            if (!d) continue;

            int deviceId = 0;
            __try { deviceId = d->r_nDeviceId; }
            __except (EXCEPTION_EXECUTE_HANDLER) { continue; }
            if (deviceId <= 0) continue;

            // QUEUED, not fired immediately — see the RPC queue comment above.
            // Bursting these got the connection closed (booted to menu).
            EnqueueRpc(RPC_RequestCard, deviceId, 10);
            for (int p = 0; p < 5; p++) {
                EnqueueRpc(RPC_AllocatePoint, deviceId, 0);
            }
            outPoints[count] = point;
            outIds[count] = deviceId;
            count++;
        }
        return count;
    }

    // THE verification tool. Everything else in this project has been "click
    // it and squint at the screen" — this reads the actual replicated card
    // state back out of each equipped device, so you can tell definitively
    // whether an attempt landed instead of guessing. Isolated per the usual
    // no-C++-objects-inside-__try rule.
    inline int ReadEquippedCardLevels(SDK::ATgPawn* pawn, int* outPoints, int* outIds,
                                      int* outAllocated, int maxResults) {
        int count = 0;
        for (int point = 0; point <= 20 && count < maxResults; point++) {
            SDK::ATgDevice* d = nullptr;
            __try { d = pawn->GetDeviceByEqPoint(point); }
            __except (EXCEPTION_EXECUTE_HANDLER) { d = nullptr; }
            if (!d) continue;

            int deviceId = 0, allocated = -1;
            __try {
                deviceId = d->r_nDeviceId;
                allocated = d->r_nPointsAllocated;
            }
            __except (EXCEPTION_EXECUTE_HANDLER) { continue; }
            if (deviceId <= 0) continue;

            outPoints[count] = point;
            outIds[count] = deviceId;
            outAllocated[count] = allocated;
            count++;
        }
        return count;
    }

    // ============ TAB: Server RPCs (the promising mechanism) ============
    // ================= CONTROLLER TAB =================
    // Groundwork for controller support. Right-stick aiming needs a way to turn
    // the view programmatically, and nothing in the tool could do that yet —
    // SendInput is ignored because the game reads raw input and re-drives the
    // view through UpdateRotation() every tick.
    //
    // These are MANUAL nudge buttons: one click = one fixed step. Deliberately
    // no tracking, no targeting, no automatic movement — this is the input
    // primitive only, so we can confirm the view can be turned at all before
    // building real stick mapping on top.
    // CALIBRATION. The engine scales turn (yaw) sensitivity far higher than look
    // (pitch), so a single shared value made horizontal ~10x too fast. Measured
    // by testing: 0.12 was a touch too SLOW versus vertical, and +25% matched
    // them — hence 0.15. These constants are the per-axis ratio; the master
    // slider below multiplies both, so changing speed keeps them in step.
    inline const float kHorizontalCalib = 0.15f;
    inline const float kVerticalCalib   = 1.00f;
    inline float g_TurnMaster = 1.0f;   // one control for both axes
    inline float g_TurnTrimH  = 1.0f;   // optional fine-trim if it drifts
    inline float g_TurnSpeedH = 0.15f;  // derived each frame from the above
    inline float g_TurnSpeedV = 1.0f;
    inline bool  g_InvertPitch = true;  // engine pitch is +down; without this UP looked down
    inline bool  g_AlsoWriteRotation = false; // both methods at once = they fight = jitter
    inline float g_TurnSmoothing = 0.35f;     // 0 = instant//jittery, 1 = very smooth
    inline float g_SmoothTurn = 0.0f, g_SmoothLook = 0.0f; // eased values

    inline float g_TurnSpeed = 1.0f;           // legacy, kept so old refs still compile
    inline bool g_UseRawRotationWrite = false; // fallback: write Rotation instead of the axes
    inline bool g_HoldUp = false, g_HoldDown = false, g_HoldLeft = false, g_HoldRight = false;
    inline bool g_LastTurnOk = false;
    inline bool g_HavePlayerInput = false;
    inline int  g_LastReadPitch = 0, g_LastReadYaw = 0;

    // Runs EVERY frame from HookedProcessEvent. The engine consumes and clears
    // aTurn/aLookUp each tick, so continuous turning means rewriting them every
    // frame — which is precisely what hold-to-turn is.
    // FIRE-GATED LOCK: snap to nearest enemy when firing, lock until fire stops
    // ========================================================================
    // WHY THE LOCK JITTERED
    // ========================================================================
    // Every lock did this:
    //
    //     if (len > 2.0f) { speed = aimLockStrength * 3.0f; nudge(dir * speed); }
    //
    // A CONSTANT push, at full strength, right up until you are within 2px. So
    // as it closes on the target it never eases off - it shoves you past, then
    // shoves you back, forever. That is a limit cycle, and it is exactly the
    // constant jitter you get when the snap is raised.
    //
    // This replaces it with a proportional correction: the nudge scales with how
    // far off you actually are, so it fades to nothing as it arrives instead of
    // slamming into the target and bouncing. Plus:
    //
    //   DEADZONE  - inside it, do nothing at all. No micro-corrections, so no
    //               buzz while you are already on target.
    //   RAMP      - full correction only past ~90px of error; nearer than that
    //               it tapers, which is what removes the last of the shake.
    //   CAP       - never move faster than this per frame, so a target across
    //               the map cannot yank the view.
    //
    // Returns false when inside the deadzone, meaning "leave the aim alone".
    // ========================================================================
    // WHERE IS THE HEAD?
    // ========================================================================
    // Head lock kept behaving exactly like body lock. The reason: it used the
    // head BONE position and nothing else, so the moment that read was not
    // available - a failed GetBoneLocation, or a cache slot that had not had its
    // turn yet under the one-read-per-frame throttle - useHead went false and it
    // silently aimed at the chest. Silently is the problem: it looked broken
    // rather than degraded.
    //
    // So there are two sources now, in order:
    //
    //   1. The real head bone, when we have it. Exact, matches the yellow head
    //      box in Highlights precisely.
    //   2. GEOMETRY, when we do not. The top of the collision cylinder is where
    //      the head is, near enough - worldPos is the centre and collisionHeight
    //      is the half-height, so centre + 0.80 of it lands on the head/neck.
    //
    // Either way head lock now aims HIGHER than body lock, always. It can be a
    // little less precise; it can no longer be secretly the same thing.
    inline VisibilityBoxes::PlainVec HeadAimPoint(const VisibilityBoxes::BoxEntry& e) {
        if (e.hasHeadWorldPos) return e.headWorldPos;
        VisibilityBoxes::PlainVec p = e.worldPos;
        p.z += e.collisionHeight * 0.80f;
        return p;
    }

    inline bool ComputeAimNudge(float dx, float dy, float len,
                                float strength, float* outX, float* outY) {
        const float kDeadzonePx = 4.0f;    // already on target
        // Tightened from 90px per PRIMAL_MONKE: "it tolerates too much
        // variance to the left and right... make it tighter." Full
        // correction now kicks in much sooner instead of ramping gently
        // across nearly a third of the screen.
        const float kFullErrPx  = 45.0f;   // error at which correction is full
        const float kMaxSpeed   = 1.20f;   // hard cap on a single frame's move

        if (len <= kDeadzonePx || len < 0.001f) return false;

        // 0..1 by how far off we are, minus the deadzone so it starts from zero
        // rather than jumping the moment we leave it.
        float err = (len - kDeadzonePx) / kFullErrPx;
        if (err > 1.0f) err = 1.0f;

        // Squared response: gentle when close, firm when far. This is what makes
        // it feel like tracking instead of snapping.
        float gain = err * err;

        float speed = strength * 3.0f * gain;
        if (speed > kMaxSpeed) speed = kMaxSpeed;

        *outX = (dx / len) * speed;
        *outY = (dy / len) * speed;
        return true;
    }

    // Sticky reticle target: the enemy the crosshair is CURRENTLY confirmed
    // on, or — for a short window after it leaves — the last one it WAS on.
    // This is the exact same precise screen-capsule hit-test the Reticle
    // Manager itself uses to change the crosshair colour
    // (VisibilityBoxes::RenderTargetReticle / g_ReticleOnEnemy), not a
    // separate closest-to-centre distance search. Per PRIMAL_MONKE: "it
    // changes color when it hovers over an enemy, why not just have it work
    // via that mechanism... just lock onto the last enemy the reticle
    // hovered over." All three lock modes below now try this FIRST and only
    // fall back to a closest-on-screen search when the reticle hasn't
    // touched anyone recently at all.
    inline SDK::ATgPawn* g_LastReticleTarget = nullptr;
    inline ULONGLONG g_LastReticleTargetMs = 0;
    inline SDK::ATgPawn* GetStickyReticleTarget() {
        const ULONGLONG kStickyMs = 250;
        if (VisibilityBoxes::g_ReticleOnEnemy) {
            g_LastReticleTarget = VisibilityBoxes::g_ReticleTargetPawn;
            g_LastReticleTargetMs = GetTickCount64();
            return g_LastReticleTarget;
        }
        if (g_LastReticleTarget && (GetTickCount64() - g_LastReticleTargetMs) < kStickyMs) {
            return g_LastReticleTarget;
        }
        return nullptr;
    }

    inline void ProcessAimAssist() {
        bool fireGatedEnabled = headLockEnabled || bodyLockEnabled;
        bool alwaysOnEnabled = headLockAlwaysOnEnabled || bodyLockAlwaysOnEnabled;

        // Tell the gather we need head bone positions. Without this the gather
        // skips resolving them unless the head box or skeleton happens to be on,
        // and head lock quietly aims at the body instead. Costs one scripted
        // call per enemy per frame, and only while head lock is actually armed.
        VisibilityBoxes::g_ExternalWantsHeadPos =
            headLockEnabled || headLockAlwaysOnEnabled;
        bool anyLockEnabled = fireGatedEnabled || alwaysOnEnabled || magnetAimEnabled;

        if (!anyLockEnabled) return;
        if (!VisibilityBoxes::reticleEnabled) return;

        ImVec2 screenSize = ImGui::GetIO().DisplaySize;
        float ccx = screenSize.x * 0.5f;
        float ccy = screenSize.y * 0.5f;

        const VisibilityBoxes::GatherResult& gathered = VisibilityBoxes::g_CachedGather;
        if (!gathered.ok) return;

        VisibilityBoxes::PlainVec fwd, right, up;
        VisibilityBoxes::RotatorToVectors(gathered.camPitch, gathered.camYaw, fwd, right, up);

        // FIRE-GATED HEAD/BODY LOCK: lock on what you're aiming at when you fire
        //
        // lockedTarget/wasHoldingFire used to be declared SEPARATELY inside the
        // if-branch AND the else-branch below — same names, but two entirely
        // different static variables, since static locals are scoped to their
        // own declaration site, not shared across an if/else. The else branch's
        // "clear on release" reset was touching a dead pair nothing else ever
        // read. Net effect: after your very first shot of a session, the real
        // pair's wasHoldingFire never went back to false, so "only pick a new
        // target when starting fire" never re-triggered again — every later
        // click just kept reapplying lock toward whatever was picked on that
        // very first shot, regardless of where your cursor actually was.
        // Hoisted out here so both branches share the one real pair.
        static SDK::ATgPawn* lockedTarget = nullptr;
        static bool wasHoldingFire = false;

        if (fireGatedEnabled && g_RealLButtonHeld) {
            // Only pick a new target when starting fire (on NEW click, not while held)
            if (!wasHoldingFire) {
                // Primary: whoever the reticle is (or was just) confirmed on.
                // Fallback: closest on screen within radius, for the rare case
                // the reticle hasn't touched anyone recently at all.
                lockedTarget = GetStickyReticleTarget();
                // Sticky window can hand back a pawn that ducked behind cover
                // in the last ~250ms - recheck rather than trust the cache.
                if (lockedTarget && VisibilityBoxes::wallCheckEnabled) {
                    for (int i = 0; i < gathered.count; i++) {
                        if (gathered.entries[i].pawnPtr == lockedTarget && !gathered.entries[i].isVisible) {
                            lockedTarget = nullptr;
                        }
                    }
                }

                if (!lockedTarget) {
                    const float kScreenRadius = 200.0f;   // must be near your crosshair
                    float bestScreenDist = kScreenRadius;

                    for (int i = 0; i < gathered.count; i++) {
                        const VisibilityBoxes::BoxEntry& e = gathered.entries[i];
                        if (e.kind != VisibilityBoxes::BoxKind::Enemy) continue;
                        if (VisibilityBoxes::wallCheckEnabled && !e.isVisible) continue; // don't lock through walls

                        VisibilityBoxes::PlainVec checkPos = e.worldPos;
                        ImVec2 checkScreen;
                        if (!VisibilityBoxes::WorldToScreen(checkPos, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, checkScreen)) continue;

                        float dx = checkScreen.x - ccx;
                        float dy = checkScreen.y - ccy;
                        float screenDist = sqrtf(dx*dx + dy*dy);

                        // Closest box ON SCREEN to the crosshair wins — not world distance.
                        if (screenDist < bestScreenDist) {
                            bestScreenDist = screenDist;
                            lockedTarget    = e.pawnPtr;
                        }
                    }
                }
            }
            wasHoldingFire = true;

            // Lock to the target
            if (lockedTarget != nullptr) {
                for (int i = 0; i < gathered.count; i++) {
                    const VisibilityBoxes::BoxEntry& e = gathered.entries[i];
                    if (e.pawnPtr != lockedTarget) continue;
                    // Target ducked behind cover WHILE held - stop pulling toward them.
                    if (VisibilityBoxes::wallCheckEnabled && !e.isVisible) break;

                    bool isHitscan = (VisibilityBoxes::g_MyTableSpeed <= 0.0f);
                    VisibilityBoxes::PlainVec targetPos = e.worldPos;

                    // Decide target: head or body
                    // Either head variant counts here - this branch has already
                    // decided it is the fire-gated pass.
                    // Head lock ALWAYS aims at the head point - bone when we
                    // have it, top-of-cylinder when we do not. It can never
                    // quietly fall back to the body any more.
                    if (headLockEnabled || headLockAlwaysOnEnabled) {
                        targetPos = HeadAimPoint(e);
                    }

                    // Apply prediction lead for projectiles (EXACT SAME as white box rendering)
                    if (!isHitscan) {
                        VisibilityBoxes::PlainVec relVel = e.velocity;

                        // Match white box calculation exactly
                        if (VisibilityBoxes::predictAccountForOwnVelocity && Globals::LocalPawn) {
                            __try {
                                SDK::FVector mv = ((SDK::ATgPawn*)Globals::LocalPawn)->Velocity;
                                relVel.x -= mv.X; relVel.y -= mv.Y; relVel.z -= mv.Z;
                            }
                            __except (EXCEPTION_EXECUTE_HANDLER) { }
                        }

                        if (VisibilityBoxes::predictIgnoreVertical) relVel.z = 0.0f;

                        float lead = VisibilityBoxes::LeadSecondsForSpeed(VisibilityBoxes::g_MyTableSpeed);
                        if (lead > 0.0f && lead < 3.0f) {
                            targetPos = {targetPos.x + relVel.x * lead,
                                        targetPos.y + relVel.y * lead,
                                        targetPos.z + relVel.z * lead};
                        }
                    }

                    ImVec2 targetScreen;
                    if (!VisibilityBoxes::WorldToScreen(targetPos, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, targetScreen)) break;

                    float dx = targetScreen.x - ccx;
                    float dy = targetScreen.y - ccy;
                    float len = sqrtf(dx*dx + dy*dy);

                    float nx, ny;
                    if (ComputeAimNudge(dx, dy, len, aimLockStrength, &nx, &ny)) {
                        SafeCalls::SetLookAxes(nx, ny);
                    }
                    break;
                }
            }

            // Published for AimFeatures::ProcessAimHook_Isolated (main.cpp) to
            // read — that hook fires the ACTUAL shot's aim adjustment while
            // GetAdjustedAimNative runs, completely separately from the camera
            // nudge above. Without this it independently walked the pawn list
            // and grabbed whichever enemy happened to be first, ignoring the
            // cursor entirely — the real source of "locks a different enemy
            // the moment I fire", even after the screen-distance/statics fixes
            // above.
            g_FireGatedLockedTarget = lockedTarget;
        } else {
            // Not firing — clear so the next click re-picks fresh, and so the
            // other hook doesn't keep aiming at a stale target.
            lockedTarget = nullptr;
            wasHoldingFire = false;  // ready to pick new target on next click
            g_FireGatedLockedTarget = nullptr;
        }

        // ALWAYS-ON LOCK: lock anytime with sticky target (don't switch while moving)
        if (alwaysOnEnabled) {
            static SDK::ATgPawn* alwaysOnLockedTarget = nullptr;

            // Update locked target every 0.3 seconds or when no target
            static ULONGLONG lastTargetUpdateMs = 0;
            ULONGLONG nowMs = GetTickCount64();

            if (alwaysOnLockedTarget == nullptr || nowMs - lastTargetUpdateMs > 300) {
                lastTargetUpdateMs = nowMs;

                // Primary: whoever the reticle is (or was just) confirmed on.
                // Fallback: closest on screen, same as before.
                alwaysOnLockedTarget = GetStickyReticleTarget();
                // Sticky window can hand back a pawn that ducked behind cover
                // in the last ~250ms - recheck rather than trust the cache.
                if (alwaysOnLockedTarget && VisibilityBoxes::wallCheckEnabled) {
                    for (int i = 0; i < gathered.count; i++) {
                        if (gathered.entries[i].pawnPtr == alwaysOnLockedTarget && !gathered.entries[i].isVisible) {
                            alwaysOnLockedTarget = nullptr;
                        }
                    }
                }

                if (!alwaysOnLockedTarget) {
                    float closestDist = 300.0f;

                    for (int i = 0; i < gathered.count; i++) {
                        const VisibilityBoxes::BoxEntry& e = gathered.entries[i];
                        if (e.kind != VisibilityBoxes::BoxKind::Enemy) continue;
                        if (VisibilityBoxes::wallCheckEnabled && !e.isVisible) continue; // don't lock through walls

                        VisibilityBoxes::PlainVec checkPos = e.worldPos;
                        ImVec2 checkScreen;
                        if (!VisibilityBoxes::WorldToScreen(checkPos, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, checkScreen)) continue;

                        float dx = checkScreen.x - ccx;
                        float dy = checkScreen.y - ccy;
                        float dist = sqrtf(dx*dx + dy*dy);

                        if (dist < closestDist) {
                            closestDist = dist;
                            alwaysOnLockedTarget = e.pawnPtr;
                        }
                    }
                }
            }

            // Lock to the target
            if (alwaysOnLockedTarget != nullptr) {
                bool isHitscan = (VisibilityBoxes::g_MyTableSpeed <= 0.0f);
                for (int i = 0; i < gathered.count; i++) {
                    const VisibilityBoxes::BoxEntry& e = gathered.entries[i];
                    if (e.pawnPtr != alwaysOnLockedTarget) continue;
                    // Target ducked behind cover since the last target-update pass.
                    if (VisibilityBoxes::wallCheckEnabled && !e.isVisible) break;

                    // Decide target: head or body
                    VisibilityBoxes::PlainVec targetPos = e.worldPos;
                    // Head lock ALWAYS aims at the head point - bone when we
                    // have it, top-of-cylinder when we do not. It can never
                    // quietly fall back to the body any more.
                    if (headLockEnabled || headLockAlwaysOnEnabled) {
                        targetPos = HeadAimPoint(e);
                    }

                    // Apply prediction lead for projectiles (EXACT SAME as white box rendering)
                    if (!isHitscan) {
                        VisibilityBoxes::PlainVec relVel = e.velocity;

                        // Match white box calculation exactly
                        if (VisibilityBoxes::predictAccountForOwnVelocity && Globals::LocalPawn) {
                            __try {
                                SDK::FVector mv = ((SDK::ATgPawn*)Globals::LocalPawn)->Velocity;
                                relVel.x -= mv.X; relVel.y -= mv.Y; relVel.z -= mv.Z;
                            }
                            __except (EXCEPTION_EXECUTE_HANDLER) { }
                        }

                        if (VisibilityBoxes::predictIgnoreVertical) relVel.z = 0.0f;

                        float lead = VisibilityBoxes::LeadSecondsForSpeed(VisibilityBoxes::g_MyTableSpeed);
                        if (lead > 0.0f && lead < 3.0f) {
                            targetPos = {targetPos.x + relVel.x * lead,
                                        targetPos.y + relVel.y * lead,
                                        targetPos.z + relVel.z * lead};
                        }
                    }

                    ImVec2 targetScreen;
                    if (!VisibilityBoxes::WorldToScreen(targetPos, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, targetScreen)) break;

                    float dx = targetScreen.x - ccx;
                    float dy = targetScreen.y - ccy;
                    float len = sqrtf(dx*dx + dy*dy);

                    float nx, ny;
                    if (ComputeAimNudge(dx, dy, len, aimLockStrength, &nx, &ny)) {
                        SafeCalls::SetLookAxes(nx, ny);
                    }
                    break;
                }
            }
        }

        // MAGNETIC AIM: pull toward nearby enemies with sticky target (white box if projectile, red box if hitscan)
        if (magnetAimEnabled && !VisibilityBoxes::g_ReticleOnEnemy) {
            static SDK::ATgPawn* magneticLockedTarget = nullptr;
            static ULONGLONG lastMagneticUpdateMs = 0;
            ULONGLONG nowMs = GetTickCount64();

            // Update magnetic target every 0.3 seconds to find closest nearby enemy
            if (nowMs - lastMagneticUpdateMs > 300) {
                lastMagneticUpdateMs = nowMs;

                float closestDist = magnetAimRadius;
                magneticLockedTarget = nullptr;

                for (int i = 0; i < gathered.count; i++) {
                    const VisibilityBoxes::BoxEntry& e = gathered.entries[i];
                    if (e.kind != VisibilityBoxes::BoxKind::Enemy) continue;
                    if (VisibilityBoxes::wallCheckEnabled && !e.isVisible) continue; // don't lock through walls

                    bool isHitscan = (VisibilityBoxes::g_MyTableSpeed <= 0.0f);
                    VisibilityBoxes::PlainVec targetPos = e.worldPos;

                    if (!isHitscan) {
                        float lead = VisibilityBoxes::LeadSecondsForSpeed(VisibilityBoxes::g_MyTableSpeed);
                        if (lead > 0.0f && lead < 3.0f) {
                            VisibilityBoxes::PlainVec relVel = e.velocity;
                            if (VisibilityBoxes::predictIgnoreVertical) relVel.z = 0.0f;
                            targetPos = {e.worldPos.x + relVel.x * lead,
                                        e.worldPos.y + relVel.y * lead,
                                        e.worldPos.z + relVel.z * lead};
                        }
                    }

                    ImVec2 centerScreen;
                    if (!VisibilityBoxes::WorldToScreen(targetPos, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, centerScreen)) continue;

                    float dx = centerScreen.x - ccx;
                    float dy = centerScreen.y - ccy;
                    float dist = sqrtf(dx*dx + dy*dy);

                    if (dist < closestDist && dist > 2.0f) {
                        closestDist = dist;
                        magneticLockedTarget = e.pawnPtr;
                    }
                }
            }

            // Pull toward locked target
            if (magneticLockedTarget != nullptr) {
                bool isHitscan = (VisibilityBoxes::g_MyTableSpeed <= 0.0f);

                for (int i = 0; i < gathered.count; i++) {
                    const VisibilityBoxes::BoxEntry& e = gathered.entries[i];
                    if (e.pawnPtr != magneticLockedTarget) continue;
                    // Target ducked behind cover since the last update pass.
                    if (VisibilityBoxes::wallCheckEnabled && !e.isVisible) break;

                    VisibilityBoxes::PlainVec targetPos = e.worldPos;

                    if (!isHitscan) {
                        float lead = VisibilityBoxes::LeadSecondsForSpeed(VisibilityBoxes::g_MyTableSpeed);
                        if (lead > 0.0f && lead < 3.0f) {
                            VisibilityBoxes::PlainVec relVel = e.velocity;
                            if (VisibilityBoxes::predictIgnoreVertical) relVel.z = 0.0f;
                            targetPos = {e.worldPos.x + relVel.x * lead,
                                        e.worldPos.y + relVel.y * lead,
                                        e.worldPos.z + relVel.z * lead};
                        }
                    }

                    ImVec2 centerScreen;
                    if (!VisibilityBoxes::WorldToScreen(targetPos, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, centerScreen)) break;

                    float dx = centerScreen.x - ccx;
                    float dy = centerScreen.y - ccy;
                    float len = sqrtf(dx*dx + dy*dy);

                    float nx, ny;
                    // Half strength: this is the soft pull, not a lock.
                    if (ComputeAimNudge(dx, dy, len, aimLockStrength * 0.5f, &nx, &ny)) {
                        SafeCalls::SetLookAxes(nx, ny);
                    }
                    break;
                }
            }
        }
    }

    inline void ProcessPendingTurn() {
        g_HavePlayerInput = SafeCalls::HasPlayerInput();

        // Derive both axes from the single master, so speed changes keep the
        // horizontal/vertical feel identical instead of drifting apart.
        g_TurnSpeedH = g_TurnMaster * kHorizontalCalib * g_TurnTrimH;
        g_TurnSpeedV = g_TurnMaster * kVerticalCalib;

        // Target axis values from whatever is held right now.
        float targetTurn = 0.0f, targetLook = 0.0f;
        if (g_HoldRight) targetTurn += g_TurnSpeedH;
        if (g_HoldLeft)  targetTurn -= g_TurnSpeedH;
        if (g_HoldUp)    targetLook += g_TurnSpeedV;
        if (g_HoldDown)  targetLook -= g_TurnSpeedV;

        // Engine pitch is positive-DOWN, so without this UP looked down.
        if (g_InvertPitch) targetLook = -targetLook;

        // SMOOTHING: ease toward the target instead of snapping to it. The
        // jitter came from the value slamming between 0 and full magnitude each
        // frame; easing removes that and also gives a natural ramp on press and
        // release, which is what a real stick feels like.
        float a = 1.0f - g_TurnSmoothing;
        if (a < 0.02f) a = 0.02f;
        g_SmoothTurn += (targetTurn - g_SmoothTurn) * a;
        g_SmoothLook += (targetLook - g_SmoothLook) * a;

        // Snap tiny residuals to zero so we stop writing once released.
        if (fabsf(g_SmoothTurn) < 0.0005f) g_SmoothTurn = 0.0f;
        if (fabsf(g_SmoothLook) < 0.0005f) g_SmoothLook = 0.0f;
        if (g_SmoothTurn == 0.0f && g_SmoothLook == 0.0f) return;

        // Axis method ONLY by default. Running both at once made them fight —
        // the axis write moves the view, then the absolute Rotation write (based
        // on an already-stale read) drags it back, which is the other half of
        // the jitter. One method, applied smoothly, is far cleaner.
        bool axisOk = SafeCalls::SetLookAxes(g_SmoothTurn, g_SmoothLook);

        bool rotOk = false;
        int p = 0, y = 0, r = 0;
        if (SafeCalls::GetViewRotation(&p, &y, &r)) { g_LastReadPitch = p; g_LastReadYaw = y; }
        if (g_AlsoWriteRotation && (p || y)) {
            const int unitsPerDeg = 182;                 // 65536 / 360
            int newPitch = p + (int)(g_SmoothLook * unitsPerDeg);
            int newYaw   = y + (int)(g_SmoothTurn * unitsPerDeg);
            const int pitchLimit = 80 * unitsPerDeg;
            if (newPitch > pitchLimit)  newPitch = pitchLimit;
            if (newPitch < -pitchLimit) newPitch = -pitchLimit;
            rotOk = SafeCalls::SetViewRotationRaw(newPitch, newYaw, r);
        }
        g_LastTurnOk = axisOk || rotOk;
    }

    // ================= RESPAWN TAB =================
    // Its own tab because it needs several diagnostics in one place, and because
    // it was previously buried inside the Server RPCs tab where it couldn't be
    // found. Everything respawn-related lives here now.
    inline void DrawRespawnTab(bool inMatch) {
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.6f, 1.0f)), "INSTANT RESPAWN");
        ImGui::Separator();

        if (!Globals::LocalController) {
            ImGui::TextDisabled("No controller — join a match.");
            return;
        }

        // Detection is a RAW FIELD READ (health), safe from any thread, so it
        // can be done live here. Firing the RPC is NOT — that's flag-only.
        bool deadNow = IsLocalPawnDead();
        g_LastDeadState = deadNow;

        // EDGE-TRIGGERED, not repeating. The previous version re-sent once a
        // second for as long as you were dead, which racked up 163 requests in
        // one session. ServerSetReadyToPlay is a RELIABLE RPC — hammering it is
        // a good way to have the server rate-limit or ignore the whole stream,
        // and it's the same class of mistake that overflowed the channel and
        // booted us during card maxing.
        //
        // Now: fire ONCE on the alive->dead transition, then stay quiet. A
        // single retry is allowed after a few seconds in case the first landed
        // during a bad moment.
        static bool wasDead = false;
        if (autoInstantRespawn) {
            ULONGLONG now = GetTickCount64();
            if (deadNow && !wasDead) {
                g_PendingInstantRespawn = true;   // the one real send
                g_LastRespawnTryMs = now;
                g_RespawnRetries = 0;
            } else if (deadNow && g_RespawnRetries < 1 && (now - g_LastRespawnTryMs) > 3000) {
                g_PendingInstantRespawn = true;   // single fallback retry
                g_LastRespawnTryMs = now;
                g_RespawnRetries++;
            }
        }
        wasDead = deadNow;

        // Keep the client countdown pinned at zero for as long as we're dead.
        // Raw field write, safe from any thread.
        if (holdClientRespawnAtZero && deadNow) SafeCalls::SetClientRespawnTime(0.0f);

        // THE thing that predicts whether respawn will work at all.
        ImGui::Text("Object chain valid:");
        ImGui::SameLine();
        if (g_EffectsSafe) {
            ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), "YES - respawn can work");
        } else {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.35f, 0.35f, 1.0f)), "NO - STALE, respawn is blocked");
            ImGui::TextWrapped("Globals::initObjects() is failing, so LocalController is a leftover "
                "pointer from an earlier match. Sending the RPC at it dispatches but reaches nobody "
                "— that was the '196 requests, no effect' case. Respawn worked the run where this "
                "read YES.\n\nFix: re-inject while already inside a live match.");
        }
        if (g_RespawnBlockedStale > 0) {
            ImGui::TextDisabled("Sends suppressed as stale: %d", g_RespawnBlockedStale);
        }

        ImGui::Text("Status:");
        ImGui::SameLine();
        if (deadNow) ImGui::TextColored(Ink(ImVec4(1.0f, 0.4f, 0.4f, 1.0f)), "DEAD");
        else         ImGui::TextColored(Ink(ImVec4(0.5f, 1.0f, 0.5f, 1.0f)), "alive");

        // THE key new diagnostic. If this counts 12 -> 0 while you're dead, the
        // client is genuinely tracking the timer locally and is therefore worth
        // attacking. If it sits at 0 or -1 the whole time, the countdown lives
        // somewhere else and this lead is dead.
        float crt = SafeCalls::GetClientRespawnTime();
        ImGui::Text("c_fRespawnTime (client) : %.2f", crt);
        ImGui::TextDisabled("Watch this while dead. Counting down = the client tracks it locally.");
        ImGui::Checkbox("Zero it before sending respawn", &zeroClientRespawnTimer);
        ImGui::Checkbox("Hold it at zero while dead", &holdClientRespawnAtZero);

        if (ImGui::Button("Respawn Now", ImVec2(150, 30))) g_PendingInstantRespawn = true;
        ImGui::SameLine();
        ImGui::Checkbox("Auto-respawn", &autoInstantRespawn);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.9f, 0.5f, 1.0f)), "DIAGNOSTICS");
        ImGui::Text("Requests queued this session : %d", g_RespawnSendCount);
        ImGui::Text("Safe-thread heartbeat        : %d", g_SafeResetTickCount);
        ImGui::Text("PostRender anchor found      : %s", g_PostRenderResolved ? "YES" : "NO");
        ImGui::Text("Distinct PostRender funcs    : %d", g_PostRenderVariants);
        // The heartbeat FREEZING (rather than sitting at 0) was the tell for the
        // injection-timing bug: we'd bound to a PostRender that stopped being
        // dispatched after a context change.
        {
            static int lastHb = -1;
            static ULONGLONG lastHbMs = 0;
            static bool hbStalled = false;
            ULONGLONG nowMs = GetTickCount64();
            if (g_SafeResetTickCount != lastHb) { lastHb = g_SafeResetTickCount; lastHbMs = nowMs; hbStalled = false; }
            else if (nowMs - lastHbMs > 2000) hbStalled = true;
            if (hbStalled) {
                ImGui::TextColored(Ink(ImVec4(1.0f, 0.35f, 0.35f, 1.0f)),
                    "HEARTBEAT STALLED - deferred features are dead right now.");
            } else {
                ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), "Heartbeat is climbing (healthy).");
            }
        }
        if (g_SafeResetTickCount == 0) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.3f, 0.3f, 1.0f)),
                "HEARTBEAT IS ZERO — the ProcessEvent path is not running at all.");
            ImGui::TextWrapped("That would break EVERY deferred action in the tool, not just "
                "respawn, and would explain a lot of past 'did nothing' results.");
        } else {
            ImGui::TextDisabled("Heartbeat climbing = deferred actions are executing.");
        }

        if (ImGui::Button("Collect Full Respawn Report", ImVec2(260, 30))) {
            DeathProbe d;
            ProbeDeathState(&d);
            std::string r = "=== RESPAWN REPORT ===\n";
            r += "IsLocalPawnDead()      : " + std::string(IsLocalPawnDead() ? "TRUE (dead)" : "FALSE (alive)") + "\n";
            r += "autoInstantRespawn     : " + std::to_string(autoInstantRespawn ? 1 : 0) + "\n";
            r += "requests queued        : " + std::to_string(g_RespawnSendCount) + "\n";
            r += "safe-thread heartbeat  : " + std::to_string(g_SafeResetTickCount) + "\n";
            r += "pending flag set now   : " + std::to_string(g_PendingInstantRespawn ? 1 : 0) + "\n";
            r += "g_EffectsSafe (inMatch): " + std::to_string(g_EffectsSafe ? 1 : 0) + "\n";
            r += "\n-- death fields --\n";
            r += "APawn::Health          : " + std::to_string(d.pawnHealth) + "\n";
            r += "PRI health cur/max     : " + std::to_string(d.priHealthCur) + " / " + std::to_string(d.priHealthMax) + "\n";
            r += "bDeleteMe/bPendingDel  : " + std::to_string(d.bDeleteMe) + " / " + std::to_string(d.bPendingDelete) + "\n";
            r += "hasAckPawn             : " + std::to_string(d.hasAckPawn) + "\n";
            r += "hasLocalPawn/Weapon    : " + std::to_string(d.hasLocalPawn) + " / " + std::to_string(d.hasLocalWeapon) + "\n";
            r += "\nRun this while DEAD. The heartbeat number is the key one —\n"
                 "if it is 0 or frozen, deferred actions are not running at all.\n";
            Testing::SetOutput(r);
        }

        ImGui::Spacing();
        if (ImGui::Button("Copy Output")) ImGui::SetClipboardText(Testing::g_Output);
        ImGui::InputTextMultiline("##RespawnOut", Testing::g_Output, sizeof(Testing::g_Output),
            ImVec2(0, 200), ImGuiInputTextFlags_ReadOnly);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextWrapped("NOTE on inconsistency: an earlier build fired this RPC directly from "
            "the render thread, which corrupts object state (wrong champion's weapon, repeating "
            "models, disconnects). That is fixed — the RPC is now only ever sent from the "
            "ProcessEvent thread. If it still works only intermittently after this, the likely "
            "cause is the server enforcing its own respawn timer rather than our plumbing.");
    }

    inline void DrawControllerTab(bool inMatch) {
        ImGui::TextColored(Ink(ImVec4(0.5f, 0.9f, 1.0f, 1.0f)), "CONTROLLER SUPPORT (draft)");
        ImGui::TextWrapped("HOLD a direction button and the crosshair should keep moving until you "
            "let go. Test it with a mouse — nothing here needs a controller plugged in. It writes "
            "the engine's input axes AND the view rotation every frame, so whichever one the game "
            "is actually reading takes effect.");
        ImGui::Separator();

        if (!inMatch) { ImGui::TextDisabled("Join a match first."); return; }

        ImGui::SliderFloat("Turn speed (both axes)", &g_TurnMaster, 0.1f, 3.0f, "%.2f");
        ImGui::SliderFloat("Smoothing", &g_TurnSmoothing, 0.0f, 0.95f);
        ImGui::Checkbox("Invert pitch", &g_InvertPitch);
        ImGui::TextDisabled("One slider drives both axes and keeps them matched. Horizontal carries");
        ImGui::TextDisabled("a 0.15 calibration factor because the engine scales yaw far higher");
        ImGui::TextDisabled("than pitch — that ratio holds at every speed.");
        if (ImGui::TreeNode("Fine trim (only if they drift apart)")) {
            ImGui::SliderFloat("Horizontal trim", &g_TurnTrimH, 0.5f, 2.0f, "%.2f");
            ImGui::TextDisabled("1.00 = matched. Raise if left/right feels slower than up/down.");
            ImGui::Text("Effective: H=%.3f  V=%.3f", g_TurnSpeedH, g_TurnSpeedV);
            ImGui::TreePop();
        }

        // HOLD-TO-TURN: IsItemActive() stays true while the mouse is held down on
        // a widget, so these behave as held axes rather than one-shot clicks.
        // Cleared every frame, then re-set by whichever button is currently held.
        g_HoldUp = g_HoldDown = g_HoldLeft = g_HoldRight = false;

        float w = 64.0f;
        ImGui::Dummy(ImVec2(w + 8.0f, 0)); ImGui::SameLine();
        ImGui::Button("UP", ImVec2(w, 32));    if (ImGui::IsItemActive()) g_HoldUp = true;
        ImGui::Button("LEFT", ImVec2(w, 32));  if (ImGui::IsItemActive()) g_HoldLeft = true;
        ImGui::SameLine();
        ImGui::Button("DOWN", ImVec2(w, 32));  if (ImGui::IsItemActive()) g_HoldDown = true;
        ImGui::SameLine();
        ImGui::Button("RIGHT", ImVec2(w, 32)); if (ImGui::IsItemActive()) g_HoldRight = true;

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("PlayerInput found: %s", g_HavePlayerInput ? "YES" : "NO  <- axis method cannot work without this");
        ImGui::Text("Write result: %s", g_LastTurnOk ? "succeeded" : "not yet / failed");
        ImGui::Text("Live rotation: pitch=%d  yaw=%d", g_LastReadPitch, g_LastReadYaw);
        ImGui::TextDisabled("Watch 'Live rotation' while holding. If those numbers move at all,");
        ImGui::TextDisabled("it IS working, even if the view snaps back. 65536 units = 360 degrees.");

        ImGui::TextDisabled("Both methods now run together every frame — no toggle needed.");
    }

    inline void DrawServerRpcTab(bool inMatch) {
        // OCTAVIA'S SHIELD AND THE WAY OUT GO FIRST.
        //
        // This tab used to open with a paragraph of RPC theory and a live queue
        // readout, which pushed the shield button - the entire reason anyone
        // opens this tab - below the fold. Those diagnostics now sit further
        // down, in developer mode, where they belong.
        if (!Globals::LocalController) {
            ImGui::TextDisabled("Need a controller — join a match or get to champion select.");
            return;
        }
        // ---- OCTAVIA: COMMANDER'S SHIELD ----
        //
        // Only Commander's Shield is surfaced. The other three passives, the
        // rotating repeater and the confirm/equip step all still EXIST and still
        // work - they are just not drawn outside developer mode, because the
        // shield is the one people actually came here for and four near-identical
        // buttons made it hard to find.
        ImGui::Spacing();
        ImGui::Separator();

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.45f, 0.75f, 1.00f, 1.0f)));
        ImGui::TextUnformatted("COMMANDER'S SHIELD");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("575 team shield on respawn. Re-fired continuously, it stacks.");

        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0.16f, 0.38f, 0.62f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.22f, 0.50f, 0.80f, 1.0f));
        if (ImGui::Button("SELECT COMMANDER'S SHIELD", ImVec2(300, 36))) g_PendingTempPassiveId = 26883;
        ImGui::PopStyleColor(2);
        ImGui::SameLine();
        if (ImGui::Button("Confirm / Equip", ImVec2(160, 36))) g_PendingEquipPassive = true;

        // ---- the auto-repeater, made the obvious thing on the page ----
        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.10f, 0.18f, 0.28f, 0.85f));
        ImGui::BeginChild("octrepeat", ImVec2(0, 132), true);

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.45f, 0.85f, 1.00f, 1.0f)));
        ImGui::TextUnformatted("AUTO-REPEAT COMMANDER'S SHIELD");
        ImGui::PopStyleColor();

        ImGui::Checkbox("ENABLE AUTO-REPEAT", &autoOctaviaShield);
        ImGui::SameLine();
        ImGui::Text("fired: %d   queue: %d", g_OctaviaFireCount, PendingRpcCount());

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.00f, 0.55f, 0.35f, 1.0f)));
        ImGui::TextWrapped("MUST BE IN SPAWN TO USE. DO NOT LEAVE SPAWN OR IT WILL STOP WORKING.");
        ImGui::TextWrapped("Spawn is the only place the game permits a loadout change - that is why "
            "hand-spamming only ever worked there.");
        ImGui::PopStyleColor();

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.00f, 0.82f, 0.45f, 1.0f)));
        ImGui::TextWrapped("AT THE END OF THE MATCH the screen may cut to black - staying in spawn "
            "can get you disconnected. Use LEAVE below before it does.");
        ImGui::PopStyleColor();
        ImGui::EndChild();
        ImGui::PopStyleColor();

        if (!g_EffectsSafe) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.5f, 0.4f, 1.0f)),
                "Object chain STALE - auto-repeat is paused (see Respawn tab).");
        }

        // ---- LEAVE, right here, so you never have to go hunting for it ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("LEAVE THE MATCH");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Same as the LEAVE tab. Here too, because this is where you need it - "
            "shield up, match ends, get out before the disconnect.");
        {
            static bool s_ArmedHere = false;
            if (!s_ArmedHere) {
                if (ImGui::Button("LEAVE MATCH", ImVec2(200, 32))) s_ArmedHere = true;
                ImGui::SameLine();
                ImGui::TextDisabled("(asks once more)");
            } else {
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.62f, 0.16f, 0.14f, 1.0f));
                if (ImGui::Button("CONFIRM - LEAVE NOW", ImVec2(240, 32))) {
                    LeaveMatch::Fire(L"disconnect", "disconnect");
                    s_ArmedHere = false;
                }
                ImGui::PopStyleColor();
                ImGui::SameLine();
                if (ImGui::Button("Cancel##octlv", ImVec2(100, 32))) s_ArmedHere = false;
            }
            ImGui::TextDisabled("%s", LeaveMatch::g_Status);
        }

        // ---- RPC diagnostics, moved down here out of the way ----
        if (g_DeveloperMode) {
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(Ink(ImVec4(0.4f, 0.9f, 1.0f, 1.0f)), "SERVER RPCs — the real network pathway");
            // Live queue readout — RPCs are drained one per tick to avoid
            // overflowing the reliable channel (which was closing the connection
            // and dumping you to the menu).
            int pendingRpcs = PendingRpcCount();
            if (pendingRpcs > 0) {
                ImGui::TextColored(Ink(ImVec4(1.0f, 1.0f, 0.4f, 1.0f)), "Sending... %d RPC(s) queued (1 per tick, don't leave the match)", pendingRpcs);
                ImGui::SameLine();
                if (ImGui::Button("Abort Queue")) ClearRpcQueue();
            } else {
                ImGui::TextDisabled("RPC queue idle. Total sent this session: %d", g_RpcSentCount);
            }
            ImGui::TextWrapped("UnrealScript functions marked `server` are DESIGNED for the client to "
                "call, with the server executing them. That makes these fundamentally different from "
                "the dead ends in the other tab: not admin-gated dev commands, not client-only memory "
                "writes. Whether each one lands depends on whether that specific server handler checks "
                "the caller.");
        }

        // ---- everything else, developer mode only ----
        if (g_DeveloperMode) {
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextDisabled("DEV: the other three passives and the rotating repeater");
            if (ImGui::Button("Commander's Credit (+100 credits / 6 team elims)")) g_PendingTempPassiveId = 27051;
            if (ImGui::Button("Commander's Ultimate (+15% team ult charge)"))      g_PendingTempPassiveId = 27052;
            if (ImGui::Button("Commander's Cooldown (-10% team cooldowns)"))       g_PendingTempPassiveId = 27053;
            ImGui::Checkbox("Auto-repeat ALL FOUR (rotating)", &autoOctaviaAll);
            if (autoOctaviaAll) {
                ImGui::TextDisabled("Cycles one buff per tick instead of firing four at once -");
                ImGui::TextDisabled("four reliable RPCs in one frame is what got us disconnected before.");
            }
            ImGui::SliderFloat("Repeat interval (sec)", &octaviaRepeatSec, 0.06f, 1.0f, "%.2f");
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.5f, 1.0f)),
                "If you get booted to menu, raise the interval - that's channel overflow.");
        }

        // ====================================================================
        // EVERYTHING BELOW IS DEVELOPER MODE ONLY
        // ====================================================================
        // This tab is now OCTAVIA: the shield stack and the way out of the
        // match, which is what it is actually used for. The rest is research
        // that was tested and did not work in real matches - the item-shop
        // RPCs, the server-side match flags (shooting range only, confirmed),
        // the ServerSetValue/ServerExec long shots, the team skin booster, and
        // the instant-respawn probe.
        //
        // NONE OF IT IS DELETED. It is all still here and still runs, because
        // knowing what was tried is worth keeping - it just does not belong in
        // front of someone who opened this tab to stack a shield.
        if (!g_DeveloperMode) return;


        // ---- 1. Cards ----
        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.6f, 1.0f)), "0. INSTANT RESPAWN  <-- best odds in this tab");
        ImGui::TextWrapped("ServerSetReadyToPlay() is the real RPC the death screen itself calls. "
            "It's a `server` function, NOT a CheatManager command, so it isn't admin-gated — this "
            "is the most likely thing here to work at NetMode 3. Press while dead.");
        // Flag only — never call the RPC from here (render thread). See the
        // comment above about the corruption that caused.
        if (ImGui::Button("Respawn Now", ImVec2(160, 30))) {
            g_PendingInstantRespawn = true;
        }
        ImGui::SameLine();
        ImGui::Checkbox("Auto-respawn when dead", &autoInstantRespawn);

        // FIXED: this used to display g_LastDeadState, a cached value refreshed
        // on a 500ms timer from the ProcessEvent side — and that refresh wasn't
        // running, so the banner stayed "alive" even though the probe (which
        // calls IsLocalPawnDead directly) correctly returned dead. Now computed
        // LIVE here, exactly like the enemy boxes read health every frame.
        bool deadNow = IsLocalPawnDead();
        g_LastDeadState = deadNow;

        // DUPLICATE REMOVED. This block used to re-arm the respawn flag every
        // 1000ms while dead — and the Respawn tab ALSO drives it, edge-triggered.
        // Two drivers meant the edge-trigger fix did nothing: this one kept
        // spamming, which is where "requests queued: 196" came from. Spamming a
        // reliable RPC is exactly what gets the stream dropped (and is the likely
        // reason it "worked once then kicked me from the game" early on).
        //
        // The Respawn tab is now the single owner of auto-respawn. This tab only
        // shows status and offers a manual button.

        ImGui::Text("Death detection right now:");
        ImGui::SameLine();
        if (deadNow) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.4f, 0.4f, 1.0f)), "DEAD");
        } else {
            ImGui::TextColored(Ink(ImVec4(0.5f, 1.0f, 0.5f, 1.0f)), "alive");
        }
        ImGui::Text("Respawn requests sent this session: %d", g_RespawnSendCount);
        // If this number is FROZEN while the game runs, the ProcessEvent-side
        // path isn't executing — which would break every deferred action, not
        // just respawn. Worth knowing either way.
        ImGui::Text("Safe-thread heartbeat: %d %s", g_SafeResetTickCount,
            g_SafeResetTickCount > 0 ? "(running)" : "(NOT RUNNING - deferred actions are dead)");

        // Diagnostic: press ALIVE, then press again while DEAD, paste both.
        // Whichever number differs between the two IS the real death signal.
        if (ImGui::Button("Scan Death State -> output box", ImVec2(260, 28))) {
            DeathProbe d;
            ProbeDeathState(&d);
            std::string r = "=== DEATH STATE PROBE ===\n";
            r += "hasController   : " + std::to_string(d.hasController) + "\n";
            r += "hasAckPawn      : " + std::to_string(d.hasAckPawn) + "\n";
            r += "hasLocalPawn    : " + std::to_string(d.hasLocalPawn) + "\n";
            r += "hasLocalWeapon  : " + std::to_string(d.hasLocalWeapon) + "\n";
            r += "pawn read ok    : " + std::to_string(d.pawnIsValidRead) + "\n";
            r += "APawn::Health   : " + std::to_string(d.pawnHealth) + "\n";
            r += "bDeleteMe       : " + std::to_string(d.bDeleteMe) + "\n";
            r += "bPendingDelete  : " + std::to_string(d.bPendingDelete) + "\n";
            r += "hasPRI          : " + std::to_string(d.hasPRI) + "\n";
            r += "PRI health cur  : " + std::to_string(d.priHealthCur) + "\n";
            r += "PRI health max  : " + std::to_string(d.priHealthMax) + "\n";
            r += "\nIsLocalPawnDead() currently returns: ";
            r += (IsLocalPawnDead() ? "TRUE (dead)" : "FALSE (alive)");
            r += "\n\nRun this ALIVE, then again WHILE DEAD, and paste both.\n"
                 "Whichever number changes between the two is the real death signal.\n";
            Testing::SetOutput(r);
        }
        ImGui::TextDisabled("Result appears in the output box at the bottom of this tab.");
        ImGui::TextDisabled("Auto checks twice a second and fires only while dead. Throttled so it");
        ImGui::TextDisabled("cannot overflow the reliable channel (that's what booted you before).");
        ImGui::TextDisabled("Detects BOTH: pawn despawned, and pawn alive-but-0-HP (death cam).");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.7f, 1.0f, 0.7f, 1.0f)), "1. CARD MAXING");
        ImGui::TextWrapped("Auto-detects your equipped cards (reads each device's real ID — no "
            "typing) then fires ServerRequestCard(id, 10) plus 5x ServerAllocateDevicePoint(id) "
            "for each. Two different real RPCs, in case the server honors one but not the other.");
        if (inMatch && Globals::LocalPawn) {
            if (ImGui::Button("Auto-Max My Equipped Cards", ImVec2(240, 30))) {
                int pts[21], ids[21];
                int touched = AutoMaxEquippedCards((SDK::ATgPawn*)Globals::LocalPawn, pts, ids, 21);
                std::string report = "=== Auto-Max Cards (real server RPCs) ===\n";
                for (int i = 0; i < touched; i++) {
                    report += "Point " + std::to_string(pts[i]) + ": device " + std::to_string(ids[i]) + " -> requested rank 10 + 5 points\n";
                }
                report += touched > 0
                    ? ("\nFired for " + std::to_string(touched) + " card(s). NOW CLICK \"Verify Card Levels\" to see if it stuck.\n")
                    : "\nNo equipped devices found.\n";
                Testing::SetOutput(report);
            }
            ImGui::SameLine();
            if (ImGui::Button("Verify Card Levels", ImVec2(160, 30))) {
                int pts[21], ids[21], alloc[21];
                int n = ReadEquippedCardLevels((SDK::ATgPawn*)Globals::LocalPawn, pts, ids, alloc, 21);
                std::string report = "=== VERIFY: actual replicated card state ===\n";
                for (int i = 0; i < n; i++) {
                    report += "Point " + std::to_string(pts[i]) + " | device " + std::to_string(ids[i])
                            + " | r_nPointsAllocated = " + std::to_string(alloc[i]) + "\n";
                }
                report += n > 0
                    ? "\nThis is the REAL replicated value. If these went up after maxing, it worked.\nIf unchanged, the server rejected it — paste this to me either way.\n"
                    : "\nNo devices readable.\n";
                Testing::SetOutput(report);
            }
        } else {
            ImGui::TextDisabled("(Needs a live match with your pawn spawned.)");
        }


        // ---- 3. Item shop ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.7f, 1.0f, 0.7f, 1.0f)), "3. IN-MATCH ITEM SHOP");
        ImGui::TextWrapped("The real shop RPCs — these are what the shop UI itself calls, so they "
            "have decent odds. Auto-add queues recommended items, then purchase commits them.");
        if (ImGui::Button("Auto-Add Recommended Items")) g_PendingAutoAddItems = true;
        ImGui::SameLine();
        if (ImGui::Button("Purchase All Queued")) g_PendingPurchaseAllItems = true;

        // ---- 4. Server flags ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.7f, 1.0f, 0.7f, 1.0f)), "4. SERVER-SIDE MATCH FLAGS");
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.55f, 0.45f, 1.0f)), "TESTED: shooting range ONLY - dead in real matches.");
        ImGui::TextWrapped("In shooting range this zeroes all damage, so the call genuinely lands. "
            "In a real match it does nothing. Reason: DamageMultiplier is a MATCH RULE affecting "
            "everyone, not something you declare about yourself — so the server refuses it unless "
            "you hold authority. Shooting range is NetMode 0 where you ARE the authority, which is "
            "why it appears to work there and nowhere else. Being a Server* RPC is not enough.");
        if (ImGui::Button("Sprint + 2x Damage (server-side)")) g_PendingServerFlagsBoost = true;
        ImGui::SameLine();
        if (ImGui::Button("Reset Flags")) g_PendingServerFlagsReset = true;

        // ---- 5. Long shots ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.9f, 0.5f, 1.0f)), "5. LONG SHOTS — decisive if they land");
        ImGui::TextWrapped("ServerSetValue is a GENERIC server-side variable setter (names an object "
            "+ variable on the server and assigns it). ServerExec runs a command server-side. Both "
            "are probably admin-locked, but if either is open it unlocks essentially everything, so "
            "they're worth one click each. Test these FIRST — a hit here saves all other work.");
        if (ImGui::Button("Probe ServerSetValue (2x damage)")) g_PendingServerSetValueTest = true;
        ImGui::SameLine();
        if (ImGui::Button("Probe ServerExec (MaxLevel)")) g_PendingServerExecTest = true;

        // Results appear right here rather than in a different tab — the probes
        // used to fire silently, which made them impossible to interpret.
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Result / output:");
        if (ImGui::Button("Copy Output")) ImGui::SetClipboardText(Testing::g_Output);
        ImGui::InputTextMultiline("##RpcOut", Testing::g_Output, sizeof(Testing::g_Output),
            ImVec2(0, 200), ImGuiInputTextFlags_ReadOnly);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.6f, 1.0f)), "6. TEAM SKIN BOOSTER — weakest of the set");
        ImGui::TextWrapped("ID 23849 is an account-level inventory entitlement, not a card, so the "
            "card RPCs probably don't reach it. Included for completeness; expect nothing.");
        if (ImGui::Button("Team Skin Booster")) g_PendingTeamSkinBooster = true;
    }

    // ============ TAB: Known dead ends (kept for reference) ============
    inline void DrawDeadEndsTab(bool inMatch) {
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.6f, 0.6f, 1.0f)), "KNOWN NOT WORKING on a server you don't own");
        ImGui::TextWrapped("Kept deliberately, not out of laziness — knowing WHY these fail is what "
            "led to the Server RPC tab. Two reasons things end up here:\n\n"
            "(A) UTgBattleCheatManager commands. Real dev interface, but gated behind admin / "
            "NM_Standalone. They genuinely work in shooting range (which runs standalone) and do "
            "nothing in a real match. This is why the ult pickup worked exactly once, in exactly "
            "one place.\n\n"
            "(B) Raw memory field writes. Client-only by definition — the server never sees them, "
            "so anything it replicates just overwrites your change on the next update.");
        ImGui::Separator();

        bool cmReady = Globals::LocalController && Globals::LocalController->CheatManager;
        if (!cmReady) {
            ImGui::TextDisabled("No CheatManager right now.");
            return;
        }

        ImGui::TextDisabled("Expect these to work ONLY in shooting range / standalone:");
        ImGui::PushItemWidth(120);
        ImGui::InputInt("Credits##CM", &g_CreditsAmount);
        ImGui::SameLine();
        if (ImGui::Button("Gain Credits")) g_PendingGainCredits = true;
        ImGui::InputInt("Gold##CM", &g_GoldAmount);
        ImGui::SameLine();
        if (ImGui::Button("Add Gold")) g_PendingAddGold = true;
        ImGui::InputInt("XP##CM", &g_XPAmount);
        ImGui::SameLine();
        if (ImGui::Button("Gain XP")) g_PendingGainXP = true;
        ImGui::PopItemWidth();

        ImGui::Spacing();
        ImGui::SliderFloat("Cooldown Adjust##CM", &g_CardCooldownIncrease, -1.0f, 1.0f);
        if (ImGui::Button("Apply Cooldown Adjust")) g_PendingCardCooldown = true;
        ImGui::SameLine();
        if (ImGui::Button("MaxLevel")) g_PendingMaxLevel = true;

        ImGui::Spacing();
        ImGui::SliderFloat("Energy %%##CM", &g_FillEnergyPct, 0.0f, 1.0f);
        if (ImGui::Button("Fill Energy")) g_PendingFillEnergy = true;
        ImGui::SameLine();
        if (ImGui::Button("Refill Ammo")) g_PendingRefillAmmo = true;

        ImGui::Spacing();
        if (ImGui::Button("Local Speed 1.5x")) g_PendingSpeedBoost = true;
        ImGui::SameLine();
        if (ImGui::Button("Reset Speed")) g_PendingSpeedReset = true;
    }

    inline void DrawScanTrackerTab(bool inMatch) {
        ImGui::TextWrapped("Progress checking every champion for hidden fire modes is tracked in "
            "a separate file (FIREMODE_SCAN_TRACKER.md) for now.");
        ImGui::Separator();
        ImGui::BeginDisabled();
        ImGui::Text("[Coming later] See that list directly in this window instead.");
        ImGui::Button("Scan Current Champion (not ready yet)");
        ImGui::EndDisabled();
    }

    inline void DrawCustomModeTab(bool inMatch) {
        // Health-bar recolouring MOVED to its own Recolours tab. It never belonged
        // beside boxes and silhouettes - it repaints GFx UI objects, which is a
        // different job entirely. Only the call moved; the implementation in
        // HealthBarColor.h is untouched.
        // FPS TIP up top - the overlays cost frames, so tell people how to buy
        // them back before they blame the tool for being heavy.
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.82f, 0.35f, 1.0f)));
        ImGui::TextWrapped("TIP: for the best FPS, drop your in-game graphics to the MINIMUM "
            "(low quality, low resolution, effects off). These overlays draw every frame, so "
            "lower game settings = more headroom and a smoother tool.");
        ImGui::PopStyleColor();
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::TextDisabled("Health bar colours now live in the Recolours tab.");
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::TextWrapped("Highlights teammates/enemies so they're easier to see. "
            "For private/practice matches only.");
        ImGui::Separator();
        if (!inMatch) { ImGui::TextDisabled("Join a match first."); return; }

        // THIRD PERSON REMOVED FROM THIS TAB.
        //
        // The camera-posture route (TG_CAMERAPOSTURE_Force3P) crashed the game
        // the moment it was toggled, every time. It is not salvageable here.
        //
        // The CARDS tab has a third person that DOES work, by a completely
        // different mechanism: SetClientValue writing m_fForce3PPersistTimer on
        // the device class defaults. If you want third person, use that one.
        // ToggleThirdPerson() is left in the file unused rather than deleted, so
        // the posture-stack approach is still on record as tried and failed.

        // HIGHLIGHT TEAMMATES / HIGHLIGHT ENEMIES — REMOVED.
        // Neither checkbox ever produced an outline. They toggled a flag the
        // game did not act on, so all they did was look like a feature.
        //
        // RECOLOR OUTLINE — REMOVED.
        // Writing 'Color' on m_OutlineMaterial was the prime suspect for the
        // blue-void / broken-asset bug, and it never recoloured anything. The
        // material is shared, so writing to it corrupted rendering client-side.
        //
        // Recolouring enemy outlines is still the one thing I most wanted and
        // never got. The CARDS system can force every outline yellow through walls, so the
        // colour IS reachable by some other route - see the Feature Ideas tab.
        // The dead controls are gone; the lead is written down instead.

        // LINE-OF-SIGHT BOXES ('no through walls') — REMOVED.
        // The LineOfSightTo gate never resolved, so the checkbox drew nothing.
        //
        // SILHOUETTE / outline recolouring — REMOVED for the same reason as the
        // outline colour above: it does not recolour anything.

        // GRAYSCALE FIRST. It is the one screen effect in this whole tab that
        // works, and it was buried at the bottom under four that don't.
        if (ImGui::Checkbox("Grayscale ON/OFF  (also F9)", &grayscaleOn)) {
            ApplyGrayscale(grayscaleOn);
        }
        ImGui::TextDisabled("Real screen desaturation, reused from the game's own near-death effect.");
        ImGui::TextDisabled("Auto-reapplies on death/respawn.");
        if (ImGui::TreeNode("Grayscale - the crash caveat")) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.35f, 0.35f, 1.0f)), "KNOWN CRASH RISK");
            ImGui::TextWrapped("It reapplies every 1.5s via SetDesaturation, a scripted "
                "ProcessEvent call, from the RENDER thread. That is the wrong thread for a "
                "scripted call and it has crashed mid-match and at match end. Use it knowing that.");
            ImGui::Checkbox("Safe-thread mode (ON by default - this is the crash fix)", &grayscaleUseSafeThread);
            if (!grayscaleUseSafeThread)
                ImGui::TextColored(Ink(ImVec4(1.0f, 0.35f, 0.35f, 1.0f)),
                    "OFF = the old render-thread path. It CRASHES. Only for comparison.");
            ImGui::TextWrapped("Routes the reapply through the ProcessEvent thread, where it "
                "belongs. Tried before and 'stopped working' - but that is exactly how a stalled "
                "ProcessEvent path presents, so watch the heartbeat in DEV TOOLS > Respawn while "
                "testing. If the heartbeat climbs and grayscale holds, this is the correct fix.");
            ImGui::Text("Safe-thread applies so far: %d", g_GrayscaleSafeApplyCount);
            ImGui::TreePop();
        }
        ImGui::Separator();

        VisibilityBoxes::DrawControls(inMatch);

        // EVERYTHING THAT USED TO BE BELOW HERE IS GONE.
        //
        //   Vision Modes (Protanope/Deuteranope/Tritanope)  - no visible effect
        //   Colour grading presets (Cold Blue, Warm Sepia, and the rest) - same
        //   Blur / UNBLUR / HOLD unblurred                  - same
        //   Master outline toggle (Enable/Disable All)      - same
        //
        // Four separate screen-effect systems, none of which changed a pixel.
        // Grayscale is the only one that ever worked, so it is now the only one
        // here - and it moved to the TOP of the tab where you can find it.
        //
        // ColorGrading.h and the vision-mode pending flags are untouched on disk.
    }

    // Auto-fire-on-hold: a click repeater for weapons that don't natively
    // support holding the button down (semi-auto, click-per-shot). Fires at
    // the weapon's OWN real fire rate (m_fFireTime on the active fire mode)
    // while you hold left click — completely independent of aim direction or
    // what's under the crosshair. Pure input simulation (mouse_event), no SDK/
    // ProcessEvent calls, safe to run every frame from any thread.
    //
    // Explicitly NOT built: auto-fire triggered by the crosshair being over an
    // enemy's box with no click at all — that's a trigger-bot, automating the
    // fire DECISION based on detected enemy position, not just repeating an
    // input. Same category as aim-lock, declined for the same reason.
    inline bool autoFireOnHold = false;

    // See the note in main.cpp (WndProc) — real hold state now comes from
    // actual window messages, not GetAsyncKeyState, since polling that same
    // key state was getting confused by our own synthetic clicks. (Declared
    // extern at file scope above, not namespace scope — see there for why.)

    // CRASH FIX (RecoverySuite.h:L883). This read was unprotected and running on
    // the RENDER thread every frame, while Globals::LocalWeapon is refreshed on
    // the ProcessEvent thread by initObjects(). So the device could be freed
    // between the null check and the m_FireMode[] access — a classic race. Force-
    // switching fire modes made it far more likely, because that's exactly when
    // the mode array gets touched. Now isolated, SEH-guarded, POD-only.
    // How fast is the equipped weapon ACTUALLY firing, in milliseconds.
    //
    // m_fFireTime is the base interval, but it is not the whole story: every
    // attack-speed buff, talent and card scales it. ATgDevice carries the live
    // modifier as a replicated percentage, so the real interval is
    //
    //     base / (1 + pct)
    //
    // Koga at 0.06s with a 20% attack-speed buff is really firing every 0.05s,
    // and a trigger bot pinned to the base rate is a fifth slower than the gun.
    // Both reads are plain fields - no ProcessEvent - so this stays render-thread
    // safe. Do not "improve" this by calling GetAttackSpeedMod(): that one is
    // scripted and would crash exactly the way the direct-fire experiment did.
    inline float g_LastFireIntervalMs = 0.0f;   // for the UI readout
    inline float g_LastAttackSpeedPct = 0.0f;

    inline float TryReadFireIntervalMs(SDK::ATgDevice* weapon) {
        __try {
            if (!weapon) return 300.0f;
            int mode = (int)weapon->CurrentFireMode;
            int count = (int)weapon->m_FireMode.Num();
            if (mode < 0 || mode >= count) return 300.0f;
            SDK::UTgDeviceFire* fm = weapon->m_FireMode[mode];
            if (!fm) return 300.0f;
            float base = fm->m_fFireTime;
            if (!(base > 0.0f) || base >= 10.0f) return 300.0f;

            // r_fAttackSpeedPercChange @ 0x09E0 (Net). 0.2 = +20% attack speed.
            float pct = *(float*)((unsigned char*)weapon + 0x09E0);
            if (!(pct > -0.95f && pct < 10.0f)) pct = 0.0f;   // garbage guard
            g_LastAttackSpeedPct = pct;

            float ms = (base / (1.0f + pct)) * 1000.0f;
            if (ms < 10.0f)  ms = 10.0f;      // nothing in this game fires faster
            if (ms > 5000.0f) ms = 5000.0f;
            g_LastFireIntervalMs = ms;
            return ms;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return 300.0f;
        }
    }

    // High-resolution clock. GetTickCount64 ticks about every 15.6ms, so at a
    // 60ms fire interval it was introducing up to 25% jitter and quietly
    // dropping shots. QPC is sub-microsecond.
    inline double NowMs() {
        static LARGE_INTEGER freq = {};
        if (!freq.QuadPart) QueryPerformanceFrequency(&freq);
        LARGE_INTEGER c; QueryPerformanceCounter(&c);
        return (double)c.QuadPart * 1000.0 / (double)freq.QuadPart;
    }

    inline float TryReadProjectileSpeed(SDK::ATgDevice* weapon) {
        __try {
            if (!weapon) return 0.0f;
            int mode = (int)weapon->CurrentFireMode;
            int count = (int)weapon->m_FireMode.Num();
            if (mode < 0 || mode >= count) return 0.0f;
            SDK::UTgDeviceFire* fm = weapon->m_FireMode[mode];
            if (!fm) return 0.0f;
            return fm->GetProjectileSpeed();
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return 0.0f;
        }
    }

    // ========================================================================
    // TRIGGER BOT — REBUILT TWICE NOW. THIS IS THE FINAL DESIGN.
    //
    // Attempt 1 (hold-based, no safety net) got stuck across a match boundary.
    // Attempt 2 (hold-based, THREE safety nets — namespace-scope flags,
    // immediate release the instant pawn/weapon go null, a hard 2s cap) got
    // stuck AGAIN regardless. That means the failure mode isn't something a
    // better-timed release can fix — something about this specific hook setup
    // makes any multi-frame "button is down, hasn't been released yet" window
    // unsafe to rely on, no matter how quickly we THINK we can close it.
    //
    // So: no more multi-frame windows, period. Every shot is ONE SendInput
    // call containing both LEFTDOWN and LEFTUP together. There is no frame,
    // ever, where the button is down and the matching up hasn't happened —
    // not one, not even for a millisecond — so there is categorically nothing
    // left to leak, independent of timing, caching, or missed frames during a
    // transition. This doesn't mitigate the bug class, it removes it.
    //
    // Still fires as fast as the weapon allows: each click is gated by the
    // weapon's own real TryReadFireIntervalMs(), back to back, which matches
    // holding for cadence purposes on every weapon type in this game.
    // ========================================================================
    // Fire method for both trigger bots.
    //
    // SendInput was the original approach: synthesise a left click and let the
    // game process it through its normal input path. It works, but it is
    // subject to whatever rate limiting sits on that path, and it needs the
    // window to be accepting input.
    //
    // Reverse engineering a third-party tool of this kind showed the better
    // route, and it is the ONLY gameplay thing that binary does: call
    // TgGame.TgDevice.StartFire on the equipped device directly. No input path, no rate limit, no focus
    // requirement. StopFire is paired with it so each call is a discrete shot
    // rather than a held trigger.
    // DO NOT put a ProcessEvent call in here.
    //
    // This runs from ProcessAimAssist() on the RENDER THREAD. A direct
    // TgDevice.StartFire call was added here once and it crashed the game the
    // moment the trigger bot was switched on - scripted calls must go through
    // RunSafeThreadSubsystems, never this path. SendInput is safe because it is
    // a Win32 call that touches no game object at all.
    //
    // The CARDS tab has its own direct-fire implementation on the safe thread.
    // That is where that experiment belongs. This function stays as it was.
    // Multiplier on the measured fire interval. 1.0 = exactly the weapon's rate.
    // Below 1.0 fires faster than the gun can shoot (harmless, the extra clicks
    // are ignored by the game, but it guarantees you never miss a window).
    inline float triggerBotRateScale = 0.90f;

    // ========================================================================
    // HOLD MODE  —  hold the button instead of clicking at a computed rate
    // ========================================================================
    // The game already auto-fires while left click is held, at exactly the right
    // rate for whatever gun you have, including every attack-speed buff. So the
    // correct trigger bot is not "click every N milliseconds" - it is "hold the
    // button while the reticle is on an enemy, release when it is not". No rate
    // to measure, no jitter, no missed windows, and it is right for every weapon
    // automatically.
    //
    // THE RISK, AND WHY THE RELEASE PATH MATTERS
    // A synthesised LEFTDOWN with no matching LEFTUP leaves your mouse button
    // physically stuck as far as Windows is concerned - you would be firing
    // forever with no way to stop short of alt-tabbing. That is why the original
    // click implementation deliberately sent down+up in a single call.
    //
    // So hold mode keeps ONE piece of state and releases it defensively:
    // whenever the target is lost, the trigger bot is switched off, boxes go
    // off, the pawn disappears, the menu opens, or the match ends. Every path
    // that could strand the button calls ReleaseTriggerHold().
    inline bool triggerBotHoldMode = true;
    inline bool g_TriggerHoldDown  = false;

    inline void PressTriggerHold() {
        if (g_TriggerHoldDown) return;
        INPUT d = {};
        d.type = INPUT_MOUSE;
        d.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
        d.mi.dwExtraInfo = kAutoFireExtraInfoTag;
        SendInput(1, &d, sizeof(INPUT));
        g_TriggerHoldDown = true;
    }

    inline void ReleaseTriggerHold() {
        if (!g_TriggerHoldDown) return;
        INPUT u = {};
        u.type = INPUT_MOUSE;
        u.mi.dwFlags = MOUSEEVENTF_LEFTUP;
        u.mi.dwExtraInfo = kAutoFireExtraInfoTag;
        SendInput(1, &u, sizeof(INPUT));
        g_TriggerHoldDown = false;
    }

    inline void FireTriggerBotClick() {
        INPUT seq[2] = {};
        seq[0].type = INPUT_MOUSE;
        seq[0].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
        seq[0].mi.dwExtraInfo = kAutoFireExtraInfoTag;
        seq[1].type = INPUT_MOUSE;
        seq[1].mi.dwFlags = MOUSEEVENTF_LEFTUP;
        seq[1].mi.dwExtraInfo = kAutoFireExtraInfoTag;
        SendInput(2, seq, sizeof(INPUT)); // one call, both events — nothing ever left half-done
    }

    // Shared by both trigger bots below: is OUR cursor within the given
    // enemy's on-screen box (red = current position, or a caller-supplied
    // predicted/white position)? Pure geometry, no state.
    inline bool CursorWithinProjectedBox(const VisibilityBoxes::PlainVec& center,
                                          float collisionRadius, float collisionHeight,
                                          const VisibilityBoxes::GatherResult& gathered,
                                          const VisibilityBoxes::PlainVec& fwd,
                                          const VisibilityBoxes::PlainVec& right,
                                          const VisibilityBoxes::PlainVec& up,
                                          float ccx, float ccy, float screenW, float screenH) {
        VisibilityBoxes::PlainVec topWorld{ center.x, center.y, center.z + collisionHeight };
        VisibilityBoxes::PlainVec botWorld{ center.x, center.y, center.z - collisionHeight };
        ImVec2 topScreen, botScreen;
        if (!VisibilityBoxes::WorldToScreen(topWorld, gathered.camLoc, fwd, right, up, gathered.fov, screenW, screenH, topScreen)) return false;
        if (!VisibilityBoxes::WorldToScreen(botWorld, gathered.camLoc, fwd, right, up, gathered.fov, screenW, screenH, botScreen)) return false;

        float boxH = botScreen.y - topScreen.y;
        if (boxH < 3.0f) return false;
        float boxW = boxH * (collisionRadius / collisionHeight);
        float boxCx = (topScreen.x + botScreen.x) * 0.5f;
        float boxCy = (topScreen.y + botScreen.y) * 0.5f;

        float dx = ccx - boxCx;
        float dy = ccy - boxCy;
        float halfW = boxW * 0.5f;
        float halfH = boxH * 0.5f;
        return fabsf(dx) <= halfW && fabsf(dy) <= halfH;
    }

    // Computes the predicted (white-box) center for an enemy, EXACT SAME
    // formula as VisibilityBoxes' own white-box rendering, so both trigger
    // bots aim at the identical point the player sees on screen.
    inline VisibilityBoxes::PlainVec PredictedCenterForEnemy(const VisibilityBoxes::BoxEntry& e, float projSpeed) {
        VisibilityBoxes::PlainVec relVel = e.velocity;
        if (VisibilityBoxes::predictAccountForOwnVelocity && Globals::LocalPawn) {
            __try {
                SDK::FVector mv = ((SDK::ATgPawn*)Globals::LocalPawn)->Velocity;
                relVel.x -= mv.X; relVel.y -= mv.Y; relVel.z -= mv.Z;
            }
            __except (EXCEPTION_EXECUTE_HANDLER) { }
        }
        if (VisibilityBoxes::predictIgnoreVertical) relVel.z = 0.0f;

        float lead = VisibilityBoxes::LeadSecondsForSpeed(projSpeed);
        if (lead <= 0.0f || lead >= 3.0f) return e.worldPos;
        return { e.worldPos.x + relVel.x * lead, e.worldPos.y + relVel.y * lead, e.worldPos.z + relVel.z * lead };
    }

    // Auto-heal's right-click hold DOES need to be a genuine hold (some heal
    // kits channel/beam and would break if interrupted every tick like a
    // click-burst would), so it keeps hold semantics — but the flag lives at
    // namespace scope so the early return below can always reach it, same
    // principle as trigger bot's safety nets that didn't fully hold up: catch
    // it at the earliest possible point rather than trusting a later code path
    // to run.
    inline bool g_HealBotHolding = false;

    inline void UpdateAutoFire() {
        if (!Globals::LocalWeapon || !Globals::LocalPawn) {
            // Trigger bot no longer holds anything (atomic clicks — see the
            // block comment above), so there's nothing to release for it. Auto
            // heal still holds, so release that immediately, before anything
            // else, the instant we lose pawn/weapon.
            if (g_HealBotHolding) {
                INPUT up = {}; up.type = INPUT_MOUSE; up.mi.dwFlags = MOUSEEVENTF_RIGHTUP; up.mi.dwExtraInfo = kAutoFireExtraInfoTag;
                SendInput(1, &up, sizeof(INPUT));
                g_HealBotHolding = false;
            }
            return;
        }

        // Note: Magnetic aim is now handled by ProcessAimAssist() using analog input method (like Controller tab)
        // SendInput mouse movement doesn't work in this game; use the analog input mechanism instead.

        float triggerBotFireIntervalMs = TryReadFireIntervalMs(Globals::LocalWeapon);

        // ---- TRIGGER BOT (main) ----
        // Requires the boxes system on (red/white) — if it's off, there is
        // nothing to fire on, and this must not fire at all. Fires strictly
        // off the RETICLE'S OWN colour state: hitscan needs it red, projectile
        // needs it purple. "If reticle is purple, shoot" — nothing more
        // sophisticated than that, and nothing else can trigger a shot.
        // SAFETY FIRST. If any precondition for firing is missing, make sure the
        // button is not left held. This runs before the fire logic so there is no
        // frame in which the trigger bot is off but the button is still down.
        if (!triggerBotEnabled || !VisibilityBoxes::enabled ||
            !Globals::LocalPawn || ::g_bShowMenu) {
            ReleaseTriggerHold();
        }

        if (triggerBotEnabled && VisibilityBoxes::enabled &&
            Globals::LocalPawn && !::g_bShowMenu) {
            static double lastClickMs = 0.0;
            static bool s_WasEnabled = false;
            if (!s_WasEnabled) triggerBotHoldMode = true;   // sane default on every enable
            s_WasEnabled = true;
            bool isHitscan = (VisibilityBoxes::g_MyTableSpeed <= 0.0f);
            bool shouldFire = isHitscan
                ? VisibilityBoxes::g_ReticleOnEnemy          // hitscan: red
                : VisibilityBoxes::g_ReticleOnPredictionBox; // projectile: purple ONLY, red never consulted

            if (triggerBotHoldMode) {
                // Hold the button while on target. The game does the rest.
                if (shouldFire) PressTriggerHold();
                else            ReleaseTriggerHold();
                lastClickMs = 0.0;
            } else if (shouldFire) {
                double now = NowMs();
                double iv  = (double)triggerBotFireIntervalMs * (double)triggerBotRateScale;
                if (iv < 10.0) iv = 10.0;
                if (lastClickMs <= 0.0) lastClickMs = now - iv;   // fire immediately on acquire

                // CATCH-UP. One shot per frame caps the trigger bot at the frame
                // rate: at 60fps that is 16.7ms. If we are more than one interval
                // behind, send the missing clicks now.
                int fired = 0;
                while (now - lastClickMs >= iv && fired < 4) {
                    lastClickMs += iv;
                    FireTriggerBotClick();
                    fired++;
                }
                if (now - lastClickMs > iv * 4.0) lastClickMs = now;
            } else {
                lastClickMs = 0.0;   // released: next acquire fires instantly
            }
        }

        // ---- TRIGGER BOT V2 (independent fallback) ----
        // A genuinely separate implementation: computes its own on-screen box
        // math directly off the cached gather data instead of reading the
        // reticle globals, so a bug in the reticle subsystem can't take this
        // down too. Still requires boxes on, same as the main one — if
        // Highlights boxes are off, V2 does not fire either.
        if (triggerBotV2Enabled && VisibilityBoxes::enabled) {
            static ULONGLONG lastClickMsV2 = 0;
            bool shouldFire = false;

            const VisibilityBoxes::GatherResult& gathered = VisibilityBoxes::g_CachedGather;
            if (gathered.ok) {
                ImVec2 screenSize = ImGui::GetIO().DisplaySize;
                float ccx = screenSize.x * 0.5f, ccy = screenSize.y * 0.5f;
                VisibilityBoxes::PlainVec fwd, right, up;
                VisibilityBoxes::RotatorToVectors(gathered.camPitch, gathered.camYaw, fwd, right, up);

                // ONE speed source for both the hitscan decision and the lead
                // calc — using two different sources here previously (a cached
                // table value for one check, a live weapon read for the other)
                // could disagree and made this fire off the wrong position.
                float myProjSpeed = VisibilityBoxes::GetImmediateProjectileSpeed();
                bool isHitscan = myProjSpeed <= 0.0f;

                for (int i = 0; i < gathered.count; i++) {
                    const VisibilityBoxes::BoxEntry& e = gathered.entries[i];
                    if (e.kind != VisibilityBoxes::BoxKind::Enemy) continue;

                    // Hitscan: red (current) position. Projectile: white
                    // (predicted) position ONLY — red is never consulted for
                    // a projectile target, matching the main bot above.
                    VisibilityBoxes::PlainVec aimAt = isHitscan
                        ? e.worldPos
                        : PredictedCenterForEnemy(e, myProjSpeed);

                    if (CursorWithinProjectedBox(aimAt, e.collisionRadius, e.collisionHeight,
                                                  gathered, fwd, right, up, ccx, ccy, screenSize.x, screenSize.y)) {
                        shouldFire = true;
                        break;
                    }
                }
            }

            if (shouldFire) {
                ULONGLONG now = GetTickCount64();
                if ((double)now - (double)lastClickMsV2 >= (double)triggerBotFireIntervalMs * (double)triggerBotRateScale) {
                    lastClickMsV2 = now;
                    FireTriggerBotClick();
                }
            }
        }

        // AUTO HEAL: hold right-click while cursor is on any ally below 100% health
        if (!autoHealEnabled && g_HealBotHolding) {
            // User turned it off mid-hold — release immediately rather than
            // waiting for the next enabled pass to notice.
            INPUT up = {}; up.type = INPUT_MOUSE; up.mi.dwFlags = MOUSEEVENTF_RIGHTUP; up.mi.dwExtraInfo = kAutoFireExtraInfoTag;
            SendInput(1, &up, sizeof(INPUT));
            g_HealBotHolding = false;
        }
        if (autoHealEnabled) {
            bool shouldHeal = false;

            const VisibilityBoxes::GatherResult& gathered = VisibilityBoxes::g_CachedGather;
            if (gathered.ok) {
                ImVec2 screenSize = ImGui::GetIO().DisplaySize;
                float ccx = screenSize.x * 0.5f;
                float ccy = screenSize.y * 0.5f;

                VisibilityBoxes::PlainVec fwd, right, up;
                VisibilityBoxes::RotatorToVectors(gathered.camPitch, gathered.camYaw, fwd, right, up);

                // Check if cursor is on any ally box
                for (int i = 0; i < gathered.count; i++) {
                    const VisibilityBoxes::BoxEntry& e = gathered.entries[i];
                    if (e.kind != VisibilityBoxes::BoxKind::Ally) continue;

                    VisibilityBoxes::PlainVec topWorld{ e.worldPos.x, e.worldPos.y, e.worldPos.z + e.collisionHeight };
                    VisibilityBoxes::PlainVec botWorld{ e.worldPos.x, e.worldPos.y, e.worldPos.z - e.collisionHeight };
                    ImVec2 topScreen, botScreen;

                    if (!VisibilityBoxes::WorldToScreen(topWorld, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, topScreen)) continue;
                    if (!VisibilityBoxes::WorldToScreen(botWorld, gathered.camLoc, fwd, right, up, gathered.fov, screenSize.x, screenSize.y, botScreen)) continue;

                    float h = botScreen.y - topScreen.y;
                    if (h < 3.0f) continue;

                    float w = h * (e.collisionRadius / e.collisionHeight);
                    float cx = (topScreen.x + botScreen.x) * 0.5f;
                    float cy = (topScreen.y + botScreen.y) * 0.5f;
                    float dx = cx - ccx;
                    float dy = cy - ccy;
                    float distFromCenter = sqrtf(dx*dx + dy*dy);
                    float boxRadius = (w + h) * 0.3f;

                    // Only heal if cursor is on ally AND ally is not at full health AND (no caut filter OR ally doesn't have caut)
                    bool hasDebuff = autoHealSkipCaut && HasCaut(e.pawnPtr);
                    if (distFromCenter < boxRadius && e.healthPct < 1.0f && e.healthPct >= 0.0f && !hasDebuff) {
                        shouldHeal = true;
                        break;
                    }
                }
            }

            if (shouldHeal) {
                if (!g_HealBotHolding) {
                    INPUT down = {};
                    down.type = INPUT_MOUSE;
                    down.mi.dwFlags = MOUSEEVENTF_RIGHTDOWN;
                    down.mi.dwExtraInfo = kAutoFireExtraInfoTag;
                    SendInput(1, &down, sizeof(INPUT));
                    g_HealBotHolding = true;
                }
            } else {
                if (g_HealBotHolding) {
                    INPUT up = {};
                    up.type = INPUT_MOUSE;
                    up.mi.dwFlags = MOUSEEVENTF_RIGHTUP;
                    up.mi.dwExtraInfo = kAutoFireExtraInfoTag;
                    SendInput(1, &up, sizeof(INPUT));
                    g_HealBotHolding = false;
                }
            }
        }

        // REGULAR AUTO-FIRE: fires while holding left click
        if (!autoFireOnHold) return;
        if (!g_RealLButtonHeld) return;

        SDK::ATgDevice* weapon = Globals::LocalWeapon;
        float fireIntervalMs = TryReadFireIntervalMs(weapon);

        static ULONGLONG lastFireMs = 0;
        ULONGLONG now = GetTickCount64();
        if (now - lastFireMs < (ULONGLONG)fireIntervalMs) return;
        lastFireMs = now;

        INPUT down = {}; down.type = INPUT_MOUSE; down.mi.dwFlags = MOUSEEVENTF_LEFTDOWN; down.mi.dwExtraInfo = kAutoFireExtraInfoTag;
        INPUT up = {};   up.type = INPUT_MOUSE;   up.mi.dwFlags = MOUSEEVENTF_LEFTUP;     up.mi.dwExtraInfo = kAutoFireExtraInfoTag;
        SendInput(1, &down, sizeof(INPUT));
        SendInput(1, &up, sizeof(INPUT));
    }

    inline void DrawAimAssistTab(bool inMatch) {
        ImGui::TextColored(Ink(ImVec4(0.5f, 1.0f, 0.8f, 1.0f)), "TARGET RETICLE (display-only)");
        ImGui::TextWrapped("Crosshair that changes color based on what's under it: grey = nothing, "
            "yellow = enemy body, red = enemy head. Display only — you still aim and shoot yourself.");
        ImGui::Checkbox("Enable target reticle", &VisibilityBoxes::reticleEnabled);
        if (VisibilityBoxes::reticleEnabled) {
            ImGui::Combo("Style", &VisibilityBoxes::reticleStyle, "Dot\0Circle\0Crosshair\0");
            ImGui::SliderFloat("Size", &VisibilityBoxes::reticleSize, 2.0f, 20.0f);
            ImGui::Checkbox("Distinct colour for headshots", &VisibilityBoxes::reticleHeadDistinct);
            // "Only react to enemies actually visible (LOS)" - REMOVED.
            //
            // It was ON by default, and the line-of-sight test never resolved
            // reliably, so the reticle simply ignored enemies it should have
            // reacted to. A default-on option that silently breaks the feature
            // it belongs to is the worst kind. The flag is forced off below.
            if (VisibilityBoxes::g_ReticleOnEnemy) {
                ImGui::TextColored(VisibilityBoxes::g_ReticleOnHead ? ImVec4(1.0f, 0.3f, 0.3f, 1.0f) : ImVec4(1.0f, 0.9f, 0.2f, 1.0f),
                    "ON TARGET: %s%s", VisibilityBoxes::g_ReticleTargetName,
                    VisibilityBoxes::g_ReticleOnHead ? "  (HEAD)" : "  (body)");
            } else {
                ImGui::TextDisabled("Not on a target.");
            }
        }

        ImGui::Spacing();
        ImGui::Separator();
        if (!inMatch) { ImGui::TextDisabled("Join a match first."); return; }

        // AUTO HEAL sits with the trigger bot because that is what it IS - a
        // trigger bot for healers. It used to be buried near the bottom.
        ImGui::TextColored(Ink(ImVec4(0.2f, 1.0f, 0.8f, 1.0f)), "HEAL TRIGGER BOT (right-click)");
        ImGui::TextWrapped("Holds right-click on any ally your cursor is over. "
            "ONLY TRIGGERS IF ALLY UNDER 100% HEALTH.");
        ImGui::Checkbox("Enable auto heal", &autoHealEnabled);
        if (autoHealEnabled) {
            ImGui::Indent();
            ImGui::Checkbox("Skip healing if ally has Caut", &autoHealSkipCaut);
            if (autoHealSkipCaut)
                ImGui::TextDisabled("Won't heal allies with Grievous Wound active.");
            ImGui::Unindent();
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Checkbox("Don't lock/fire through walls", &VisibilityBoxes::wallCheckEnabled);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Governs EVERYTHING below and the reticle above: trigger bot, magnet aim,\n"
            "head lock, body lock. An enemy has to actually be rendered on your\n"
            "screen (not hidden behind a wall) before any of them will react to,\n"
            "lock onto, or fire on them.\n\n"
            "Reads the engine's own render timestamp on the enemy's mesh (a plain\n"
            "field, no scripted call) - a different, independent method from the\n"
            "old LineOfSightTo-based LOS test elsewhere in this tool, which was\n"
            "found unreliable. Leave this ON; only turn it off to compare behaviour\n"
            "if something seems to be refusing to fire on a target you CAN see.");
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)), "TRIGGER BOT");
        ImGui::TextWrapped("Clicks at the weapon's real fire rate for as long as the crosshair matches the "
            "reticle colour for your weapon type: hitscan fires on RED, projectile fires on PURPLE ONLY (never "
            "red, even if red and purple would both apply to the same enemy at once — purple always wins). "
            "Every shot presses and releases in one instant call, so the mouse button can never be left "
            "physically down across a match boundary. Requires boxes enabled in Highlights.");
        // ================= NO RECOIL =================
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), "NO RECOIL / NO SPREAD");

        // THE ONE THAT WORKS IS NO-SPREAD.
        //
        // "Enable no recoil" clears bUsesRecoil on the weapon's recoil profiles.
        // It reads as if it should work and it does not. No-spread does: it pins
        // accuracy at its best value and stops it degrading, covering both
        // standing spread growth and the midair penalty, because both run
        // through the same accuracy value.
        //
        // It is reachable at all because the CLIENT computes its own shot trace
        // and reports the impact to the server (ServerInstantFire takes it as a
        // parameter) - so pinning accuracy client-side genuinely changes where
        // your shots land.
        //
        // So no-spread is the headline switch here now. It lived in the Speeden
        // tab, which is dev-only, where nobody would ever find it.
        ImGui::Checkbox("Enable no-spread  (THIS is the one that works)",
                        &Speeden::noSpreadEnabled);
        ImGui::TextWrapped("Pins accuracy at its best value and stops it degrading - covers standing "
            "spread AND the midair penalty. Captured per weapon, so it restores correctly when you "
            "switch weapon or fire mode.");
        ImGui::Text("Base accuracy min/max: %.3f / %.3f", Speeden::g_BaseMinAcc, Speeden::g_BaseMaxAcc);
        ImGui::Text("Live min accuracy    : %.3f", Speeden::g_LiveMinAcc);
        if (!Speeden::g_HaveAccuracyBase)
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)), "No weapon accuracy data yet.");

        ImGui::Spacing();
        ImGui::Checkbox("Enable no recoil (recoil profiles)", &Speeden::noRecoilEnabled);
        ImGui::SameLine();
        ImGui::TextDisabled("profiles cleared: %d / 5", Speeden::g_RecoilModesTouched);
        ImGui::TextDisabled("Kept because it is harmless to run alongside, but no-spread above is");
        ImGui::TextDisabled("the one that changes where your shots go.");

        // This route writes r_nRecoilMultiCenti onto every in-hand device
        // class default. It did not reduce recoil in testing, so it is behind
        // developer mode rather than presented as a working option.
        ImGui::Spacing();
        if (g_DeveloperMode) {
        ImGui::Checkbox("Enable no recoil (device-class-default version)  [dev - does not work]", &g_CardsNoRecoil);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "A different route to the same result.\n\n"
            "PHAROAH's version edits the recoil profiles on the weapon you are\n"
            "holding right now. This one writes r_nRecoilMultiCenti = 0 onto every\n"
            "in-hand device CLASS DEFAULT, so it covers every champion at once and\n"
            "survives a weapon swap without needing a per-weapon restore.\n\n"
            "Uses SetClientValue - the same mechanism as the third person that\n"
            "works. It touches recoil and nothing else.");
        ImGui::SameLine();
        if (ImGui::Button("apply now##cardsrec", ImVec2(110, 0))) g_CardsNoRecoilApply = true;
        ImGui::SameLine();
        if (ImGui::Button("restore##cardsrec", ImVec2(100, 0))) g_CardsNoRecoilRestore = true;
        ImGui::TextDisabled("%s", g_CardsRecoilStatus);
        }   // end developer-mode-only no-recoil block

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Checkbox("Enable trigger bot", &triggerBotEnabled);
        ImGui::SameLine();
        ImGui::Checkbox("HOLD mode", &triggerBotHoldMode);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Holds left click while the reticle is on an enemy and releases when\n"
            "it is not, instead of clicking at a measured rate.\n\n"
            "The game already auto-fires at the correct rate for every weapon,\n"
            "including attack-speed buffs - so this is exact for every gun with\n"
            "no rate to measure. Turn it off only for a weapon that genuinely\n"
            "needs separate clicks.");
        if (g_TriggerHoldDown)
            ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), "   button HELD");
        else
            ImGui::TextDisabled("   button released");
        if (!triggerBotHoldMode) {
        ImGui::SetNextItemWidth(200);
        ImGui::SliderFloat("rate scale", &triggerBotRateScale, 0.50f, 1.50f, "%.2f x");
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "1.00 = exactly the weapon fire rate that was measured.\n"
            "Below 1.00 fires slightly faster than the gun can shoot, which\n"
            "costs nothing and guarantees no window is ever missed.");
        if (g_LastFireIntervalMs > 0.0f)
            ImGui::TextDisabled("measured: %.0f ms/shot  (attack speed %+.0f%%)  -> firing every %.0f ms",
                                g_LastFireIntervalMs, g_LastAttackSpeedPct * 100.0f,
                                g_LastFireIntervalMs * triggerBotRateScale);
        else
            ImGui::TextDisabled("measured: no weapon read yet");
        }
        if (triggerBotEnabled) {
            if (!VisibilityBoxes::enabled) {
                ImGui::TextColored(Ink(ImVec4(1.0f, 0.6f, 0.2f, 1.0f)), "Boxes are OFF in Highlights — trigger bot has nothing to fire on.");
            } else {
                bool isHitscanNow = (VisibilityBoxes::g_MyTableSpeed <= 0.0f);
                bool readyNow = isHitscanNow ? VisibilityBoxes::g_ReticleOnEnemy : VisibilityBoxes::g_ReticleOnPredictionBox;
                ImGui::TextColored(Ink(ImVec4(1.0f, 0.3f, 0.3f, 1.0f)),
                    readyNow ? "READY TO FIRE (on target)" : "WAITING (not on target)");
                ImGui::TextDisabled(isHitscanNow ? "Hitscan — waiting for RED reticle." : "Projectile — waiting for PURPLE reticle.");
            }
        }

        // TRIGGER BOT V2 — REMOVED from the UI. It was a fallback for when the
        // main one misbehaved; the main one does not misbehave any more, so two
        // trigger bots is just two things to explain. Implementation untouched;
        // triggerBotV2Enabled stays false so its tick is a no-op.

        // ================= MAGNET AIM =================
        // This used to be FIVE separate sections: head lock fire-gated, head
        // lock always-on, body lock fire-gated, body lock always-on, and a
        // "magnetic aim" checkbox underneath them that did the same job again.
        //
        // It is one thing with two choices: WHAT to aim at (head or body), and
        // WHETHER it only engages while you are shooting. So that is what it
        // looks like now. Head and body are mutually exclusive - you cannot aim
        // at two points on the same enemy - and picking one deselects the other.
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.6f, 0.2f, 1.0f)), "MAGNET AIM");
        ImGui::TextWrapped("Pulls your aim toward an enemy. Pick head OR body, then choose whether "
            "it only engages while you hold left click.");

        // Derive the two visible checkboxes from the four underlying flags.
        bool headOn = headLockEnabled || headLockAlwaysOnEnabled;
        bool bodyOn = bodyLockEnabled || bodyLockAlwaysOnEnabled;
        bool headGated = headLockEnabled;      // gated variant is the fire-gated one
        bool bodyGated = bodyLockEnabled;

        if (ImGui::Checkbox("HEAD LOCK", &headOn)) {
            if (headOn) { bodyOn = false; }    // one target point only
        }
        ImGui::SameLine();
        ImGui::BeginDisabled(!headOn);
        ImGui::Checkbox("fire gated##head", &headGated);
        ImGui::EndDisabled();
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("On  = only locks while you HOLD left click.\nOff = locks continuously.");

        if (ImGui::Checkbox("BODY LOCK", &bodyOn)) {
            if (bodyOn) { headOn = false; bodyGated = true; }  // turning body lock on defaults to fire-gated, per PRIMAL_MONKE
        }
        ImGui::SameLine();
        ImGui::BeginDisabled(!bodyOn);
        ImGui::Checkbox("fire gated##body", &bodyGated);
        ImGui::EndDisabled();
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("On  = only locks while you HOLD left click.\nOff = locks continuously.");

        // Write the four real flags back from the two choices.
        headLockEnabled         = headOn &&  headGated;
        headLockAlwaysOnEnabled = headOn && !headGated;
        bodyLockEnabled         = bodyOn &&  bodyGated;
        bodyLockAlwaysOnEnabled = bodyOn && !bodyGated;
        // The old standalone "magnetic aim" switch is gone; head/body lock IS
        // the magnet. Keep the underlying flag off so nothing double-applies.
        magnetAimEnabled = false;

        if (headOn || bodyOn) {
            ImGui::Spacing();
            ImGui::SliderFloat("Aim radius (how far to search)", &magnetAimRadius, 50.0f, 400.0f);
            ImGui::SliderFloat("Lock snap speed (0.01=slowest, 1.0=instant)", &aimLockStrength, 0.005f, 1.0f, "%.3f");
            ImGui::TextDisabled("0.40 is the default. It no longer jitters at high values - the shake");
            ImGui::TextDisabled("was a constant-push bug, not the strength. Raise it if the lock");
            ImGui::TextDisabled("cannot keep up when you jump.");
            if (headOn && !VisibilityBoxes::showHeadBox) {
                ImGui::TextColored(Ink(ImVec4(1.0f, 0.72f, 0.30f, 1.0f)),
                    "Head lock uses the same head bone as the yellow head box in Highlights.");
            }
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("AUTO-FIRE ON HOLD");
        ImGui::TextWrapped("Fires at weapon's real rate while you hold left click. For semi-auto weapons.");
        ImGui::Checkbox("Enable auto-fire on hold##AutoFire", &autoFireOnHold);
    }

    // Labelled THEMES in the UI. It is still the fixes tab underneath - the
    // "Fix My Character" button lives here too - but themes are what people
    // actually open it for, so that is what it is called.
    inline void DrawDiagnosticsTab() {
        // POTATO MODE moved to the header row (next to DEV MODE / NOTES) so it
        // is visible without opening this tab. The frame-time readout is still
        // useful here for anyone actually chasing a stutter, so it stays.
        Perf::DrawControls();
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::TextWrapped("If your character's model looks wrong after quickly switching "
            "champions, try this button. It might not fully fix it, but it's worth a try.");
        ImGui::Separator();
        if (ImGui::Button("Fix My Character")) {
            Globals::initObjects();
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Checkbox("Show FPS counter (top-left, always visible)", &g_ShowFPS);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Keybinds:");
        DrawKeybindRow("Grayscale toggle", &g_BindGrayscaleKey);
        ImGui::TextDisabled("Defaults to F9. Rebind if it clashes with Steam's own overlay bind.");
        DrawKeybindRow("Instant respawn", &g_BindInstantRespawn);
        DrawKeybindRow("Cards auto-spam toggle", &g_BindCardsAutoToggle);
        DrawKeybindRow("Magnetic aim toggle", &g_BindAimToggle);
        ImGui::TextDisabled("These fire from anywhere in-game, same as the buttons on their own tabs.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Look / Theme (60% major / 30% mid / 10% accent):");

        // ONE LIST, ONE CODE PATH.
        //
        // These buttons used to call ApplyThemeColors directly and set the two
        // theme flags by hand, while the PHAROAH wordmark went through
        // ApplyPharoahThemeByIndex. So picking a theme HERE never updated
        // g_PharoahThemeIndex, and the next wordmark click resumed from a stale
        // index - which is why the theme "half changed" and re-clicking fixed it.
        //
        // Every button below now goes through the same function the wordmark
        // uses, driven off kPharoahThemes in UI/Style.h. Index, colours and the
        // Ink() light/dark flag can no longer drift apart.
        for (int i = 0; i < kPharoahThemeCount; ++i) {
            bool active = (g_PharoahThemeIndex == i);
            if (active) ImGui::PushStyleColor(ImGuiCol_Button, g_MinorColor);
            char lbl[96];
            wsprintfA(lbl, "%s##theme%d", kPharoahThemes[i].name, i);
            if (ImGui::Button(lbl, ImVec2(260, 28))) RequestPharoahTheme(i);
            if (active) ImGui::PopStyleColor();
            if (i == 0)
                ImGui::TextDisabled("Light limestone surfaces, dark ink text, gold + lapis accents.");
        }

        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(0.45f, 0.80f, 1.00f, 1.0f)),
            "Clicking the PHAROAH name at the top of the window cycles these same themes.");
        ImGui::Separator();

        if (ImGui::Checkbox("Rounded/bubbly window style", &g_SoftRoundedStyle)) {
            ApplyRoundingStyle(g_SoftRoundedStyle);
        }

        ImGui::Spacing();
        ImGui::Text("Animated:");
        if (ImGui::Checkbox("RGB Cycle (all colors rotate through hue)", &g_RGBThemeMode)) {
            // no immediate action needed — UpdateRGBThemeIfEnabled() picks it
            // up next frame; leaving it off just freezes on the last theme.
        }
    }

    inline void DrawCallLogTab() {
        std::string report;
        CallLogger::DrawControls(&report);
        if (!report.empty()) Testing::SetOutput(report);
        ImGui::Spacing();
        ImGui::Separator();
        if (ImGui::Button("Copy Output")) ImGui::SetClipboardText(Testing::g_Output);
        ImGui::InputTextMultiline("##CallLogOut", Testing::g_Output, sizeof(Testing::g_Output),
            ImVec2(0, 300), ImGuiInputTextFlags_ReadOnly);
    }

    enum class Section { FireModes, ServerRpc, CallLog, Controller, Respawn, Speeden, Skins, Cards, Misc, DeadEnds, ScanTracker, Highlights, AimAssist, Fixes, Testing, VisualEffects, GatingTab, UnlockerTab, LeaveTab, DirectFireTab, CardSuiteTab, RecoloursTab, IdeasTab, DevTab, Skins2, Talents, Emotes, AntiCheat };
    inline Section activeSection = Section::FireModes;

    // ========================================================================
    // DEVELOPER MODE — off by default.
    // Off: only the finished, user-facing tabs are shown.
    // On : everything, including diagnostics, dead ends and scan tools.
    // ========================================================================

    // ========================================================================
    // NOTES PANEL
    // ========================================================================
    // A scratchpad that lives OUTSIDE the tab system, docked to the left of the
    // main window, so it stays put no matter which tab is open. Write findings
    // while testing, hit copy, paste them straight into a report.
    //
    // It is its own ImGui window rather than a column inside the main one, so it
    // cannot disturb any existing tab layout.
    inline ImVec2 g_MainPos  = ImVec2(15, 15);
    inline ImVec2 g_MainSize = ImVec2(760, 900);
    inline bool g_NotesMode = false;
    inline char g_NotesBuf[8192] = "";
    inline char g_NotesStatus[96] = "";

    // ---- CRASH-PROOF NOTES -------------------------------------------------
    // A report was lost because the game crashed mid-write, and the game's own
    // crash handler then overwrote the clipboard with its stack trace. Both
    // halves of that are outside our control - so the notes simply must not
    // live only in memory.
    //
    // They are flushed to a file next to the DLL a second after you stop typing,
    // and reloaded on startup. A crash costs at most the last second of typing,
    // and nothing at all if you paused. The file is plain text: if the tool
    // never starts again, the notes are still just sitting there.
    inline bool   g_NotesDirty     = false;
    inline double g_NotesSaveAt    = 0.0;
    inline bool   g_NotesLoaded    = false;
    inline int    g_NotesSaveCount = 0;

    inline const char* NotesFilePath() {
        static char path[MAX_PATH] = { 0 };
        if (path[0]) return path;
        HMODULE self = nullptr;
        GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)&NotesFilePath, &self);
        if (self && GetModuleFileNameA(self, path, MAX_PATH)) {
            char* slash = strrchr(path, '\\');
            if (slash) { slash[1] = 0; lstrcatA(path, "pharoah_notes.txt"); return path; }
        }
        lstrcpyA(path, "pharoah_notes.txt");
        return path;
    }

    inline void SaveNotesNow() {
        HANDLE h = CreateFileA(NotesFilePath(), GENERIC_WRITE, FILE_SHARE_READ, nullptr,
                               CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (h == INVALID_HANDLE_VALUE) return;
        DWORD written = 0;
        int len = lstrlenA(g_NotesBuf);
        if (len > 0) WriteFile(h, g_NotesBuf, (DWORD)len, &written, nullptr);
        // Flush to disk rather than trusting the OS cache - the whole point is
        // surviving a process that is about to die badly.
        FlushFileBuffers(h);
        CloseHandle(h);
        g_NotesDirty = false;
        g_NotesSaveCount++;
    }

    inline void LoadNotesOnce() {
        if (g_NotesLoaded) return;
        g_NotesLoaded = true;
        HANDLE h = CreateFileA(NotesFilePath(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                               nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (h == INVALID_HANDLE_VALUE) return;
        DWORD read = 0;
        ReadFile(h, g_NotesBuf, sizeof(g_NotesBuf) - 1, &read, nullptr);
        g_NotesBuf[read < sizeof(g_NotesBuf) ? read : sizeof(g_NotesBuf) - 1] = '\0';
        CloseHandle(h);
    }

    // Called every frame from the render loop. Cheap: it only touches the disk
    // when something changed and you have stopped typing for a moment.
    inline void TickNotesAutosave() {
        if (!g_NotesDirty) return;
        double now = ImGui::GetTime();
        if (now < g_NotesSaveAt) return;
        SaveNotesNow();
    }

    inline void DrawNotesPanel() {
        if (!g_NotesMode) return;
        LoadNotesOnce();

        // Sit to the LEFT of the main window and match its height — but only
        // the FIRST time it opens. Position used to be forced every single
        // frame (ImGuiCond_Always), which is exactly why the panel could
        // never actually be dragged: any drag was overwritten before the
        // next frame rendered. Now it follows the main window once, then
        // stays wherever you put it — "Reset Position" below snaps it back.
        ImVec2 mainPos  = g_MainPos;
        ImVec2 mainSize = g_MainSize;
        const float w = 330.0f;
        float x = mainPos.x - w - 8.0f;
        if (x < 4.0f) x = mainPos.x + mainSize.x + 8.0f;   // no room left? go right

        ImGui::SetNextWindowPos(ImVec2(x, mainPos.y), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(w, mainSize.y * 0.55f), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowBgAlpha(0.92f);

        if (ImGui::Begin("PHAROAH - NOTES", nullptr,
                         ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings)) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)), "TESTING NOTES");
            ImGui::TextWrapped("Write as you test. Stays open across every tab.");
            if (ImGui::SmallButton("Reset position")) {
                ImGui::SetWindowPos(ImVec2(x, mainPos.y));
            }
            ImGui::Separator();

            float avail = ImGui::GetContentRegionAvail().y - 84.0f;
            if (avail < 120.0f) avail = 120.0f;
            // WordWrap: this box never wrapped long lines before, forcing
            // horizontal scrolling to read your own notes back.
            if (ImGui::InputTextMultiline("##notes", g_NotesBuf, sizeof(g_NotesBuf),
                                          ImVec2(-1.0f, avail), ImGuiInputTextFlags_WordWrap)) {
                g_NotesDirty  = true;
                g_NotesSaveAt = ImGui::GetTime() + 1.0;   // settle for a second, then flush
            }

            ImGui::Spacing();
            if (ImGui::Button("COPY ALL", ImVec2(110, 30))) {
                ImGui::SetClipboardText(g_NotesBuf);
                lstrcpynA(g_NotesStatus, "Copied to clipboard.", 90);
            }
            ImGui::SameLine();
            if (ImGui::Button("Add timestamp", ImVec2(130, 30))) {
                SYSTEMTIME st; GetLocalTime(&st);
                char stamp[64];
                wsprintfA(stamp, "\r\n[%02d:%02d:%02d] ", st.wHour, st.wMinute, st.wSecond);
                int len = lstrlenA(g_NotesBuf);
                if (len + (int)lstrlenA(stamp) < (int)sizeof(g_NotesBuf) - 1)
                    lstrcatA(g_NotesBuf, stamp);
            }
            ImGui::SameLine();
            if (ImGui::Button("Clear", ImVec2(70, 30))) {
                g_NotesBuf[0] = '\0';
                lstrcpynA(g_NotesStatus, "Cleared.", 90);
            }
            ImGui::SameLine();
            if (ImGui::Button("Save now", ImVec2(90, 30))) {
                SaveNotesNow();
                lstrcpynA(g_NotesStatus, "Saved to disk.", 90);
            }
            ImGui::TextDisabled("%d / %d chars   %s",
                                lstrlenA(g_NotesBuf), (int)sizeof(g_NotesBuf) - 1, g_NotesStatus);
            ImGui::TextDisabled("Auto-saved %d time(s) to:", g_NotesSaveCount);
            ImGui::TextWrapped("%s", NotesFilePath());
            ImGui::TextDisabled("Survives a crash. If the game dies, the file is still there.");
        }
        ImGui::End();
    }

    // The tabs a normal user should see. Everything else is dev-only.
    inline bool IsUserTab(Section s) {
        switch (s) {
            case Section::FireModes:    // the flagship, works in real matches
            case Section::Highlights:   // enemy boxes / names / skeletons
            case Section::AimAssist:    // labelled "Reticle Manager" in the UI
            case Section::Skins:
            case Section::DevTab:       // the button itself is always allowed
            case Section::ServerRpc:    // renamed OCTAVIA - the shield stack lives here
            // Call Log is dev-only: it is a diagnostic recorder, not a feature.
            // Kept because it is the tab that found ATgPawn::GetDeviceByEqPoint.
            case Section::GatingTab:    // charity gate (labelled CHARITY) — users need to reach this
            case Section::LeaveTab:
            case Section::CardSuiteTab:
            case Section::RecoloursTab:
            case Section::Talents:      // ported from a third-party EmoteTalent tool
            // Emotes, Unlocker and Anti-Cheat moved into DEV TOOLS per
            // PRIMAL_MONKE - they're either niche or diagnostic-heavy, and the
            // main rows should stay lean. They live in g_DevTabs now.
                return true;
            default:
                return false;
        }
    }

    struct SectionButton { const char* label; Section section; };

    // ========================================================================
    // THE DEV TAB
    // ========================================================================
    // Developer mode used to reveal ELEVEN extra tabs in the main row, which
    // made the row unusable even for me. They are all still here - nothing was
    // deleted - but they live behind ONE button now, with their own sub-row
    // inside it.
    //
    // The split is by what a thing IS, not by whether it works: diagnostics and
    // recorders in one group, research that was tried and did not pan out in
    // another. Someone reading the source can see at a glance which is which.
    inline Section g_DevSubSection = Section::Testing;

    // ---- LAYOUT --------------------------------------------------------
    // false = tab buttons in rows across the TOP (the original, still default)
    // true  = tab buttons stacked down the LEFT, content to the right
    //
    // The side layout gives the content a taller, narrower column, which suits
    // the long scrolling tabs (Cards, Highlights) far better - and it has room
    // for a proper logo instead of a 28px thumbnail.
    inline bool g_SideLayout = false;

    // Every user tab, in one list, so the side column does not have to know
    // about the row arrays.
    struct NavEntry { const char* label; Section section; };
    static const NavEntry g_Nav[] = {
        { "Fire Modes",      Section::FireModes },
        { "Highlights",      Section::Highlights },
        { "Reticle Manager", Section::AimAssist },
        { "CARDS",           Section::CardSuiteTab },
        { "Skins",           Section::Skins },
        { "OCTAVIA",         Section::ServerRpc },
        { "Recolours",       Section::RecoloursTab },
        { "4TH TALENT",      Section::Talents },
        { "CHARITY",         Section::GatingTab },
        { "LEAVE",           Section::LeaveTab },
    };
    static const int kNavCount = (int)(sizeof(g_Nav) / sizeof(g_Nav[0]));

    struct DevEntry { const char* label; Section section; const char* group; };
    static const DevEntry g_DevTabs[] = {
        // --- diagnostics: things that measure or record ---
        { "Testing",        Section::Testing,      "Diagnostics" },
        { "Call Log",       Section::CallLog,      "Diagnostics" },
        { "Respawn",        Section::Respawn,      "Diagnostics" },
        // --- systems that work but are not for everyday use ---
        { "Speeden",        Section::Speeden,      "Systems" },
        { "Controller",     Section::Controller,   "Systems" },
        { "Unlocker",       Section::UnlockerTab,  "Systems" },
        { "Emotes",         Section::Emotes,       "Systems" },
        // --- research: tried, recorded, did not land ---
        { "Skins2",         Section::Skins2,       "Research" },
        { "Loadout Cards",  Section::Cards,        "Research" },
        { "Anti-Cheat",     Section::AntiCheat,    "Research" },
        { "Dead Ends",      Section::DeadEnds,     "Research" },
        // Direct Fire removed from this list: it is the SAME DrawControls the
        // CARDS tab shows, so it was the identical page under a second name.
        // --- extras ---
        { "Themes",         Section::Fixes,        "Extras" },
        { "Ideas",          Section::IdeasTab,     "Extras" },
    };
    static const int kDevTabCount = (int)(sizeof(g_DevTabs) / sizeof(g_DevTabs[0]));
    // THE MAIN ROWS ARE USER TABS ONLY.
    //
    // Everything diagnostic moved into g_DevTabs above and is reached through
    // the single DEV button. These rows are what someone who just injected the
    // DLL sees, and every one of them does something that works.
    // TWO rows now, five buttons each, per PRIMAL_MONKE ("squeeze them
    // together, drop the third row"). Emotes/Unlocker/Anti-Cheat moved to DEV
    // TOOLS, GATING renamed CHARITY - which freed up exactly enough room to
    // fold the old third row into these two.
    static const SectionButton g_Row1[] = {
        { "Fire Modes", Section::FireModes },
        { "Highlights", Section::Highlights },
        { "Reticle Manager", Section::AimAssist },
        { "CARDS", Section::CardSuiteTab },
        { "Skins", Section::Skins },
    };
    static const SectionButton g_Row2[] = {
        { "OCTAVIA", Section::ServerRpc },
        { "Recolours", Section::RecoloursTab },
        { "4TH TALENT", Section::Talents },
        { "CHARITY", Section::GatingTab },
        { "LEAVE", Section::LeaveTab },
    };

    // ========================================================================
    // SKINS 2  —  the dev methods, restored
    // ========================================================================
    // Methods C and D and the old skin-id route. I folded these into the Skins
    // tab as a collapsible earlier and it made both tabs worse: the Skins tab got
    // longer and these got harder to find. They are a separate tab again.
    //
    // None of them changes a skin in a real match. They are research, kept
    // because the tool is open source and someone may get further than I did.
    inline void DrawSkins2Tab(bool inMatch) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("SKINS 2  -  the other methods (dev)");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("These do not change your skin in a real match. Method A and COMBINED "
            "FULL APPLY in the main Skins tab are the ones that work. Kept for anyone who wants "
            "to push the research further.");
        ImGui::Separator();

        if (ImGui::CollapsingHeader("METHOD C - build by id (the game's own mesh builder)",
                                    ImGuiTreeNodeFlags_DefaultOpen)) {
            DevSkin::DrawMethodCSection(inMatch);
        }
        if (ImGui::CollapsingHeader("METHOD D - pre-match selection injection")) {
            DevSkin::DrawMethodDTab(inMatch);
        }
        if (ImGui::CollapsingHeader("Old skin-id method (server-gated, reference)")) {
            SkinSwap::DrawControls(inMatch);
        }
    }

    // SKINS TAB: mesh swap first (the method with no server involvement), then
    // the older skin-id approach kept below it for reference.
    inline void DrawSkinsTab(bool inMatch) {
        // MASTER SWITCH. While off, NOTHING skin-related runs or draws — not the
        // per-frame mesh writes, not the scanners, not the persistence timers.
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(g_SkinsSystemEnabled
                                                 ? ImVec4(0.4f, 1.0f, 0.5f, 1.0f)
                                                 : ImVec4(1.0f, 0.6f, 0.4f, 1.0f)));
        ImGui::Checkbox("ACTIVATE SKINS SYSTEM (off = completely inactive)",
                        &g_SkinsSystemEnabled);
        ImGui::PopStyleColor();
        if (!g_SkinsSystemEnabled) {
            ImGui::TextWrapped("Skins system is OFF. No skin code runs at all - no per-frame mesh "
                "writes, no scanning, no persistence, no hooks. Leave it off while you play; tick it "
                "only when you want to work on skins. If your binds/WASD still break with this OFF, "
                "the cause is NOT the skin system and I'll look elsewhere.");
            return;
        }
        ImGui::TextWrapped("ACTIVE - skin code is running. Untick to make it fully inactive again.");
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.45f, 0.30f, 1.0f));
        ImGui::TextWrapped("PRONE TO CRASHING - a perfected version will be released soon.");
        ImGui::PopStyleColor();
        ImGui::Separator();

        // Mirror dev mode into the skin sub-namespaces so THEY hide their own
        // diagnostic clutter from a normal user's clean flow.
        DevSkin::g_DevMode  = g_DeveloperMode;
        MeshSkin::g_DevMode = g_DeveloperMode;

        // ---- (DEV) r_nSkinId WATCHER - diagnostic, hidden from normal users ----
        if (g_DeveloperMode) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.9f, 0.4f, 1.0f)));
        ImGui::TextWrapped("r_nSkinId WATCHER  (read this in a REAL match after Combined Full Apply)");
        ImGui::PopStyleColor();
        ImGui::Text("live r_nSkinId = %d      changed-under-us: %d",
                    MeshSkin::g_LiveSkinNow, MeshSkin::g_SkinRevertCount);
        ImGui::Checkbox("watch##skinid", &MeshSkin::g_WatchSkinId);
        ImGui::SameLine();
        ImGui::Checkbox("HOLD every frame", &MeshSkin::g_HoldSkinId);
        ImGui::SameLine();
        ImGui::SetNextItemWidth(110);
        ImGui::InputInt("hold value", &MeshSkin::g_HoldSkinValue);
        ImGui::SameLine();
        if (ImGui::Button("use current##hold")) MeshSkin::g_HoldSkinValue = MeshSkin::g_LiveSkinNow;
        if (ImGui::Button("COPY WATCHER STATE", ImVec2(220, 22))) {
            char buf[512];
            wsprintfA(buf, "===== r_nSkinId WATCHER =====\r\n"
                           "live r_nSkinId        : %d\r\n"
                           "holding value         : %d (hold %s)\r\n"
                           "changed-under-us count: %d\r\n"
                           "champion              : %s\r\n"
                           "weapon family         : %s\r\n"
                           "===== END =====\r\n",
                      MeshSkin::g_LiveSkinNow, MeshSkin::g_HoldSkinValue,
                      MeshSkin::g_HoldSkinId ? "ON" : "off",
                      MeshSkin::g_SkinRevertCount,
                      MeshSkin::g_MyChampion[0] ? MeshSkin::g_MyChampion : "(unknown)",
                      MeshSkin::g_WeaponFamily[0] ? MeshSkin::g_WeaponFamily : "(unknown)");
            MeshSkin::CopyClip(buf);
        }
        ImGui::TextWrapped("If live == your chosen skin id but your body is still default, the write is "
            "FINE and the REBUILD is the problem - which changes everything we work on next.");
        ImGui::Separator();
        }   // end if (g_DeveloperMode) - watcher

        // A force-load in DevSkin sets this; re-scan here so the newly resident
        // meshes appear in the scanner below without the user having to know to
        // press scan again. Cross-namespace on purpose — DevSkin does the loading,
        // MeshSkin does the looking.
        if (DevSkin::g_WantRescan) {
            DevSkin::g_WantRescan = false;
            if (MeshSkin::g_MyChampion[0]) {
                lstrcpynA(MeshSkin::g_Filter, MeshSkin::g_MyChampion,
                          sizeof(MeshSkin::g_Filter));
            }
            MeshSkin::RunScan();
        }

        // ================= THE CLEAN FLOW (rebuilt for ease of use) =========
        // The exact order PRIMAL_MONKE asked for, top to bottom:
        //   1. the big blue LOAD ALL button (loads + scans every skin for you)
        //   2. STEP 1 - PICK A SKIN  (press Re-detect, then click a skin)
        //   3. BODY SKINS (only shown if >1) + the texture boxes, from DrawSimple
        // Everything experimental / raw-mesh / diagnostic is behind DEV mode at
        // the very bottom, so a normal user never has to see it.
        if (!inMatch) {
            ImGui::TextWrapped("Tip: join a match (a bot match works fine) to apply skins to your live "
                "character. The LOAD ALL button below also works from champion select.");
            ImGui::Spacing();
        }
        if (!DevSkin::g_DetectedChamp[0]) DevSkin::AutoDetectChampion();

        DevSkin::DrawLoadAllSection();   // 1. LOAD ALL, at the very top
        DevSkin::DrawStep1PickSkin();    // 2. STEP 1 - PICK A SKIN

        ImGui::Spacing();
        ImGui::Separator();
        MeshSkin::DrawSimple(inMatch);   // 3. BODY SKINS (if >1) + textures + universals

        // ================= ADVANCED (dev only) =============================
        if (g_DeveloperMode) {
            ImGui::Spacing();
            ImGui::Separator();
            if (ImGui::CollapsingHeader("ADVANCED - raw mesh tools + every method (dev)")) {
                DevSkin::DrawControls(inMatch);
                ImGui::Separator();
                ImGui::TextColored(Ink(ImVec4(0.6f, 0.85f, 1.0f, 1.0f)),
                    "RAW MESH / SMART MESH / weapon-swap tools");
                MeshSkin::DrawControls(inMatch);
            }
        }

        // Methods C and D moved OUT to their own Skins2 tab - see DrawSkins2Tab.
        // Folding them in here made this tab longer and made them harder to find.
        /* ---- the methods that DON'T work, all in one collapsible ----------
        // Method C (build-by-id), Method D (pre-match selection injection) and
        // the old skin-id route used to be spread across the tab and a whole
        // second 'Skins2' tab. None of them change a skin in a real match. They
        // are research, not features, so they are folded away behind one header
        // that says exactly that - the code is all still here for anyone who
        // wants to push it further.
        ImGui::Spacing();
        ImGui::Separator();
        if (ImGui::CollapsingHeader("Methods C & D (don't work - other approaches if you're a dev)")) {
            ImGui::TextWrapped("These do not change your skin in a real match. They are kept because "
                "the tool is open source and someone may get further with them than I did.");
            ImGui::Spacing();

            if (ImGui::TreeNode("Method C - build by id (the game's own mesh builder)")) {
                DevSkin::DrawMethodCSection(inMatch);
                ImGui::TreePop();
            }
            if (ImGui::TreeNode("Method D - pre-match selection injection")) {
                DevSkin::DrawMethodDTab(inMatch);
                ImGui::TreePop();
            }
            if (ImGui::TreeNode("Old skin-id method (server-gated, reference)")) {
                SkinSwap::DrawControls(inMatch);
                ImGui::TreePop();
            }
        }
        ---- end of the block that moved to Skins2 ---- */
    }

    // MISC — the Anubis-parity odds and ends that don't belong to a bigger system.
    // Both of these are client-only by nature, which is why they're grouped: FOV is
    // camera-local, and a VGS is an event the client declares about itself.
    inline void DrawMiscTab(bool inMatch) {
        // The custom crosshair section used to open this tab. It is gone: it
        // never drew a usable reticle, and a control that does nothing is worse
        // than no control. Crosshair.h is still in the tree, just not shown.
        CameraTools::DrawControls(inMatch);
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        VGSSpam::DrawControls(inMatch);
    }

    // ========================================================================
    // THE WORDMARK — clickable, and the only place the credit appears
    // ========================================================================
    // Clicking PHAROAH cycles the two Egyptian themes (sand by day, basalt by
    // night). The credit used to be repeated further down the window; it now
    // appears exactly once, right here next to the logo where it belongs.
    //
    // On the font: the styled 'PRIMAL_MONKE' uses Mathematical Bold Sans-Serif and
    // modifier-letter codepoints. ImGui loads Segoe UI with
    // GetGlyphRangesDefault(), which covers Basic Latin and Latin-1 only, so
    // those characters would render as empty boxes. Plain letters it is - the
    // styled version is for pasting into a chat client, not for a font atlas with no glyphs for it.
    // Set each frame once the header controls have been drawn beside the logo,
    // so the fallback path below cannot draw them a second time.
    inline bool g_HeaderControlsDrawn = false;

    // The scale row and the dev-only test report. Lives beside the logo.
    inline void DrawHeaderControls(bool inMatch) {
        if (ImGui::SmallButton(" - ")) {
            float s = g_UIScale * 0.9f;
            if (s < 0.4f) s = 0.4f;
            ApplyUIScale(s);
        }
        ImGui::SameLine();
        ImGui::Text("%d%%", (int)(g_UIScale * 100.0f + 0.5f));
        ImGui::SameLine();
        if (ImGui::SmallButton(" + ")) {
            float s = g_UIScale * 1.1f;
            if (s > 2.5f) s = 2.5f;
            ApplyUIScale(s);
        }
        ImGui::SameLine();
        if (ImGui::SmallButton("100%")) ApplyUIScale(1.0f);

        // COPY TEST REPORT is for sending me output, not a user control.
        if (g_DeveloperMode) {
            ImGui::SameLine();
            TestReport::DrawButton(inMatch);
        }
    }

    inline void DrawWordmarkAndCredit() {
        // Invisible-framed button so it looks like the text it replaced, but
        // takes a click. AlignTextToFramePadding() was already called by the
        // caller, so it lines up with the logo either way.
        // Egyptian lapis with white text, so it reads as a real button and
        // matches the selected-tab styling. NOT run through Ink(): this is a
        // filled dark-blue button on every theme, so white is always correct.
        const ImVec4 kLapis    = ImVec4(0.13f, 0.30f, 0.55f, 1.00f);
        const ImVec4 kLapisHot = ImVec4(0.20f, 0.42f, 0.72f, 1.00f);
        ImGui::PushStyleColor(ImGuiCol_Button,        kLapis);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, kLapisHot);
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.28f, 0.52f, 0.85f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_Text,          ImVec4(1, 1, 1, 1));
        // ImGui has no bold face loaded, so "bold" is done by weight: a wider
        // button with the name spaced out reads heavier than the text around it.
        if (ImGui::Button(" P H A R O A H ")) {
            CyclePharoahTheme();
        }
        ImGui::PopStyleColor(4);
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("Click to switch theme  (now: %s)", PharoahThemeName());
        }

        ImGui::SameLine();
        ImGui::AlignTextToFramePadding();
        ImGui::TextDisabled("Developed by PRIMAL_MONKE");
    }

    // The left-hand nav column. Same sections as the top rows, stacked, sized
    // to the column so a long label never gets clipped.
    inline void DrawSideNav(float width) {
        for (int i = 0; i < kNavCount; ++i) {
            bool on = (activeSection == g_Nav[i].section);
            if (on) {
                ImGui::PushStyleColor(ImGuiCol_Button, g_MinorColor);
                ImGui::PushStyleColor(ImGuiCol_Text,   ImVec4(1, 1, 1, 1));
            }
            if (ImGui::Button(g_Nav[i].label, ImVec2(width, 30)))
                activeSection = g_Nav[i].section;
            if (on) ImGui::PopStyleColor(on ? 2 : 0);
        }
        if (g_DeveloperMode) {
            ImGui::Spacing();
            bool onDev = (activeSection == Section::DevTab);
            if (onDev) {
                ImGui::PushStyleColor(ImGuiCol_Button, g_MinorColor);
                ImGui::PushStyleColor(ImGuiCol_Text,   ImVec4(1, 1, 1, 1));
            }
            if (ImGui::Button("DEV TOOLS", ImVec2(width, 30)))
                activeSection = Section::DevTab;
            if (onDev) ImGui::PopStyleColor(2);
        }
    }

    // The side-tab panel. A real window docked to the LEFT edge of the main one,
    // matching its height exactly - so it never steals width from the content.
    // Same trick the NOTES panel uses, and the reason NOTES does not squeeze the
    // tool either.
    inline void DrawSideNavPanel(bool inMatch) {
        if (!g_SideLayout) return;

        const float navW = 168.0f;
        ImGui::SetNextWindowPos(ImVec2(g_MainPos.x - navW - 8.0f, g_MainPos.y), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(navW, g_MainSize.y), ImGuiCond_Always);

        if (ImGui::Begin("PHAROAH - TABS", nullptr,
                         ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                         ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                         ImGuiWindowFlags_NoScrollbar)) {

            // The logo comes with it, and gets to be big here.
            if (LogoTexture::g_Loaded && LogoTexture::g_SRV) {
                const float box = navW - 24.0f;
                float lw = box, lh = box;
                if (LogoTexture::g_Width > 0 && LogoTexture::g_Height > 0) {
                    if (LogoTexture::g_Width >= LogoTexture::g_Height)
                        lh = box * (float)LogoTexture::g_Height / (float)LogoTexture::g_Width;
                    else
                        lw = box * (float)LogoTexture::g_Width / (float)LogoTexture::g_Height;
                }
                ImGui::SetCursorPosX((navW - lw) * 0.5f);
                ImGui::Image(LogoTexture::GetTextureID(), ImVec2(lw, lh));
            }

            // Slow pulse (period ~2.5s) so the header reads as alive/clickable
            // rather than a static label - shine up, ease back, repeat. Pure
            // visual affordance, no new behavior.
            {
                float t = (float)ImGui::GetTime();
                float pulse = (sinf(t * 2.5133f) + 1.0f) * 0.5f; // 0..1, ~2.5s period
                ImVec4 base(0.89f, 0.93f, 0.94f, 1.0f);
                ImVec4 shine(1.0f, 1.0f, 1.0f, 1.0f);
                ImVec4 col(
                    base.x + (shine.x - base.x) * pulse * 0.6f,
                    base.y + (shine.y - base.y) * pulse * 0.6f,
                    base.z + (shine.z - base.z) * pulse * 0.6f,
                    1.0f);
                ImGui::PushStyleColor(ImGuiCol_Text, Ink(col));
            }
            ImGui::SetCursorPosX(10.0f);
            ImGui::TextUnformatted("PHAROAH");
            ImGui::PopStyleColor();
            ImGui::SetCursorPosX(10.0f);
            ImGui::TextDisabled("PRIMAL_MONKE");
            ImGui::Separator();

            DrawSideNav(navW - 20.0f);

            ImGui::Separator();
            ImGui::SetCursorPosX(10.0f);
            if (ImGui::SmallButton("top tabs")) g_SideLayout = false;
        }
        ImGui::End();
    }

    // Draws one row of tab buttons, ALWAYS inside the window.
    //
    // The old version took a fixed button width from the caller - width/4 - but
    // rows had grown to six buttons. Six buttons at a quarter width each is one
    // and a half times the window, so the last two rendered off the right edge
    // and could not be clicked. That is why new tabs kept 'disappearing'.
    //
    // The width is now derived from how many buttons are actually VISIBLE, and
    // the row wraps onto more lines if they would get too narrow to read. Adding
    // a tab can no longer push another one off the screen.
    inline void DrawSectionButtonRow(const SectionButton* row, int count, float /*unused*/) {
        int visible[16]; int nVis = 0;
        for (int i = 0; i < count && nVis < 16; i++) {
            if (!g_DeveloperMode && !IsUserTab(row[i].section)) continue;
            visible[nVis++] = i;
        }
        if (nVis == 0) return;   // whole row is dev-only

        const float spacing  = ImGui::GetStyle().ItemSpacing.x;
        const float avail    = ImGui::GetContentRegionAvail().x;
        const float minWidth = 86.0f;   // below this a label is unreadable

        // How many fit on one line at the minimum width?
        int perLine = (int)((avail + spacing) / (minWidth + spacing));
        if (perLine < 1)     perLine = 1;
        if (perLine > nVis)  perLine = nVis;

        int drawn = 0;
        while (drawn < nVis) {
            int thisLine = nVis - drawn;
            if (thisLine > perLine) thisLine = perLine;

            float w = (avail - spacing * (thisLine - 1)) / (float)thisLine;

            for (int k = 0; k < thisLine; k++) {
                int i = visible[drawn + k];
                bool isActive = (activeSection == row[i].section);
                // A selected tab gets the accent fill AND white text. Pushing
                // only the fill left the label in the theme's normal ink, which
                // on the sand theme is dark brown on dark blue - unreadable.
                if (isActive) {
                    ImGui::PushStyleColor(ImGuiCol_Button, g_MinorColor);
                    ImGui::PushStyleColor(ImGuiCol_Text,   ImVec4(1, 1, 1, 1));
                }
                if (ImGui::Button(row[i].label, ImVec2(w, 28))) {
                    activeSection = row[i].section;
                }
                if (isActive) ImGui::PopStyleColor(2);
                if (k < thisLine - 1) ImGui::SameLine();
            }
            drawn += thisLine;
        }
    }

    // ---- WHAT GETS REMEMBERED ---------------------------------------------
    // Registered once, on the first frame. Adding a setting is one line here;
    // saving, loading and change detection are all automatic.
    //
    // The charity gate keeps its own separate file on purpose - a gate you can
    // clear by deleting a line from a settings file is not a gate, and "reset my
    // settings" should not silently mean "re-lock the tool".
    inline void RegisterSettings() {
        static bool done = false;
        if (done) return;
        done = true;

        Persist::RegBool ("recolour.enabled",    &HealthBarColor::enabled);
        Persist::RegBool ("recolour.enemies",    &HealthBarColor::recolorEnemies);
        Persist::RegBool ("recolour.allies",     &HealthBarColor::recolorAllies);
        Persist::RegBool ("recolour.multiplier", &HealthBarColor::useMultiplier);
        Persist::RegBool ("recolour.children",   &HealthBarColor::tintChildren);
        Persist::RegBool ("recolour.healthtext", &HealthBarColor::tintHealthText);
        Persist::RegFloat("recolour.enemy.r",    &HealthBarColor::enemyColor[0]);
        Persist::RegFloat("recolour.enemy.g",    &HealthBarColor::enemyColor[1]);
        Persist::RegFloat("recolour.enemy.b",    &HealthBarColor::enemyColor[2]);
        Persist::RegFloat("recolour.ally.r",     &HealthBarColor::allyColor[0]);
        Persist::RegFloat("recolour.ally.g",     &HealthBarColor::allyColor[1]);
        Persist::RegFloat("recolour.ally.b",     &HealthBarColor::allyColor[2]);

        Persist::RegBool ("trigger.enabled",     &triggerBotEnabled);
        Persist::RegBool ("trigger.holdmode",    &triggerBotHoldMode);
        Persist::RegFloat("trigger.ratescale",   &triggerBotRateScale);
        Persist::RegBool ("aimlock.wallcheck",   &VisibilityBoxes::wallCheckEnabled);

        Persist::RegBool ("recoil.cards",         &g_CardsNoRecoil);

        Persist::RegBool ("unlock.enabled",      &Unlocker::g_Enabled);
        Persist::RegBool ("unlock.persist",      &Unlocker::g_Persist);
        Persist::RegInt  ("unlock.mode",         &Unlocker::g_Mode);
        Persist::RegInt  ("unlock.value",        &Unlocker::g_WriteValue);

        Persist::RegBool ("skins.system",        &g_SkinsSystemEnabled);
        Persist::RegBool ("skins.autoscan",      &MeshSkin::g_ContinuousScan);
        Persist::RegBool ("skins.showallmats",   &MeshSkin::g_MatShowAll);

        Persist::RegBool ("cardsuite.autofire",       &CardSuite::g_AutoEnabled);
        Persist::RegInt  ("cardsuite.holdkey",        &CardSuite::g_HoldKey);
        Persist::RegBool ("cardsuite.teleport",       &CardSuite::g_TpOn);
        Persist::RegInt  ("cardsuite.teleportkey",    &CardSuite::g_TpKey);
        Persist::RegFloat("cardsuite.teleportdist",   &CardSuite::g_TpDistance);
        Persist::RegBool ("cardsuite.autorespawn",    &CardSuite::g_ResOn);
        Persist::RegBool ("cardsuite.cardhotkeys",    &DirectFire::g_HotkeysOn);
        Persist::RegFloat("cardsuite.cardspamrate",   &DirectFire::g_EqSpamRate);

        Persist::RegBool ("octavia.autoshield",  &autoOctaviaShield);
        Persist::RegFloat("octavia.interval",    &octaviaRepeatSec);

        Persist::RegBool ("ui.devmode",          &g_DeveloperMode);
        Persist::RegBool ("ui.notes",            &g_NotesMode);

        Persist::LoadOnce();
    }

    // Forward declaration: DrawDevTab dispatches through DrawSection, and
    // DrawSection can route back to DrawDevTab. One dispatch table, used twice.
    inline void DrawSection(Section which, bool inMatch);

    // ========================================================================
    // DEV TOOLS  —  everything diagnostic, behind one button
    // ========================================================================
    // Developer mode used to add eleven buttons to the main tab row. Nothing has
    // been deleted; it all lives here, grouped by what it IS rather than by
    // whether it happens to work:
    //
    //   Diagnostics  measure or record something
    //   Systems      work, but are not everyday tools
    //   Research     tried, written up, did not land
    //
    // The point of the grouping is that someone reading this can tell at a
    // glance which pile a tab belongs to instead of finding out by clicking.
    inline void DrawDevTab(bool inMatch) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.75f, 0.35f, 1.0f)));
        ImGui::TextUnformatted("DEV TOOLS");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Diagnostics, recorders and research. None of this is needed to use "
            "the tool - it is here because the findings are worth keeping.");
        ImGui::Separator();

        // One row per group, each labelled. Buttons size themselves from the
        // group, so adding an entry can never push one off the edge.
        const char* groups[] = { "Diagnostics", "Systems", "Research", "Extras" };
        for (int g = 0; g < 4; ++g) {
            int idx[16]; int cnt = 0;
            for (int i = 0; i < kDevTabCount && cnt < 16; ++i)
                if (lstrcmpA(g_DevTabs[i].group, groups[g]) == 0) idx[cnt++] = i;
            if (cnt == 0) continue;

            ImGui::TextDisabled("%s", groups[g]);
            float spacing = ImGui::GetStyle().ItemSpacing.x;
            float avail   = ImGui::GetContentRegionAvail().x;
            float w = (avail - spacing * (cnt - 1)) / (float)cnt;
            if (w < 70.0f) w = 70.0f;

            for (int k = 0; k < cnt; ++k) {
                const DevEntry& e = g_DevTabs[idx[k]];
                bool on = (g_DevSubSection == e.section);
                if (on) {
                    ImGui::PushStyleColor(ImGuiCol_Button, g_MinorColor);
                    ImGui::PushStyleColor(ImGuiCol_Text,   ImVec4(1, 1, 1, 1));
                }
                if (ImGui::Button(e.label, ImVec2(w, 26))) g_DevSubSection = e.section;
                if (on) ImGui::PopStyleColor(2);
                if (k < cnt - 1) ImGui::SameLine();
            }
            ImGui::Spacing();
        }

        ImGui::Separator();
        ImGui::Spacing();

        // Guard against recursion: the dev tab must never select itself.
        if (g_DevSubSection == Section::DevTab) g_DevSubSection = Section::Testing;
        DrawSection(g_DevSubSection, inMatch);
    }

    // Draws whichever section is asked for. Pulled out of Render() so the DEV
    // tab can reuse it for its sub-pages rather than duplicating every case.
    inline void DrawSection(Section which, bool inMatch) {
        switch (which) {
            case Section::DevTab:        DrawDevTab(inMatch); break;
            case Section::FireModes:     DrawFireModesTab(inMatch); break;
            case Section::Talents:       DrawTalentsTab(inMatch); break;
            case Section::Emotes:        DrawEmotesTab(inMatch); break;
            case Section::AntiCheat:     DrawAntiCheatTab(inMatch); break;
            case Section::ServerRpc:     DrawServerRpcTab(inMatch); break;
            case Section::CallLog:       DrawCallLogTab(); break;
            case Section::Controller:    DrawControllerTab(inMatch); break;
            case Section::Respawn:       DrawRespawnTab(inMatch); break;
            case Section::Speeden:       Speeden::DrawControls(inMatch); break;
            case Section::Skins:         DrawSkinsTab(inMatch); break;
            case Section::Skins2:        DrawSkins2Tab(inMatch); break;
            case Section::Cards:         CardsTab::DrawControls(inMatch); break;
            case Section::DeadEnds:      DrawDeadEndsTab(inMatch); break;
            case Section::Highlights:    DrawCustomModeTab(inMatch); break;
            case Section::AimAssist:     DrawAimAssistTab(inMatch); break;
            case Section::Fixes:         DrawDiagnosticsTab(); break;   // labelled THEMES in the UI
            case Section::Testing:       Testing::DrawControls(inMatch); break;
            case Section::GatingTab:
                Gating::DrawControls(inMatch);
                // DEV MODE lives here now (moved off the header row so normal
                // users don't trip over it). Not gated - just tucked into the
                // one tab a casual user has no reason to poke around in.
                ImGui::Spacing();
                ImGui::Separator();
                ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.55f, 0.55f, 0.58f, 1.0f)));
                ImGui::TextUnformatted("ADVANCED");
                ImGui::PopStyleColor();
                ImGui::PushStyleColor(ImGuiCol_Text, Ink(g_DeveloperMode
                                                         ? ImVec4(1.0f, 0.75f, 0.35f, 1.0f)
                                                         : ImVec4(0.65f, 0.65f, 0.65f, 1.0f)));
                ImGui::Checkbox("DEV MODE  (extra tabs + diagnostics - for advanced users)", &g_DeveloperMode);
                ImGui::PopStyleColor();
                ImGui::TextDisabled("Leave this OFF for the clean tool. Turning it on adds research/"
                                    "diagnostic tabs and options most people don't need.");
                break;
            case Section::UnlockerTab:   Unlocker::DrawControls(inMatch); break;
            case Section::LeaveTab:      LeaveMatch::DrawControls(inMatch); break;
            case Section::CardSuiteTab:       CardSuite::DrawControls(inMatch); break;
            case Section::RecoloursTab:  Recolours::DrawControls(inMatch); break;
            case Section::IdeasTab:      FeatureIdeas::DrawControls(inMatch); break;
        }
    }

    inline void Render(bool inMatch) {
        RegisterSettings();

        ImGui::SetNextWindowPos(ImVec2(15, 15), ImGuiCond_FirstUseEver);
        // Generous default, and FirstUseEver means imgui.ini overrides it once you
        // resize manually. If it still opens tiny, delete imgui.ini next to the
        // game exe — that file remembers the old cramped size.
        // WINDOW SIZE — forced ONCE per session, deliberately not FirstUseEver.
        //
        // FirstUseEver loses to imgui.ini, and the ini still remembered the old
        // cramped size — which is why raising the default alone did nothing and it
        // "was still very small by default". Forcing it for a single frame with
        // ImGuiCond_Always overrides the saved value, and because it only happens
        // on the first frame, manual resizing afterwards still works normally and
        // still gets saved.
        //
        // Default theme: Purple/Orange/Blue (index 0 now). First wordmark click
        // lands on Egyptian Sand (the light theme), per PRIMAL_MONKE.
        static bool s_ForcedInitialLayout = false;
        if (!s_ForcedInitialLayout) {
            s_ForcedInitialLayout = true;
            ImGui::SetNextWindowSize(ImVec2(760, 900), ImGuiCond_Always);
            ApplyPharoahThemeByIndex(0);   // Purple/Orange/Blue by default; click the title for light
        } else {
            ImGui::SetNextWindowSize(ImVec2(760, 900), ImGuiCond_FirstUseEver);
        }

        // Escape hatch: if the window ever ends up an awkward size again, this puts
        // it back without needing to find and delete imgui.ini.
        if (g_PendingSizeReset) {
            g_PendingSizeReset = false;
            ImGui::SetNextWindowSize(ImVec2(760, 900), ImGuiCond_Always);
        }
        // Floor the size so it can never end up too small to use again.
        ImGui::SetNextWindowSizeConstraints(ImVec2(300, 260), ImVec2(FLT_MAX, FLT_MAX));
        ImGui::SetNextWindowBgAlpha(0.85f);

        // Renamed to PHAROAH. Kept the RecoverySuite namespace/filename so the
        // rename is display-only and can't break the ~370 references to it.
        g_HeaderControlsDrawn = false;   // one draw per frame, see DrawHeaderControls
        if (!ImGui::Begin("PHAROAH")) { ImGui::End(); return; }

        // Resize the whole window to match a UI-scale change. Done here because
        // this is the only place that can ask this window how big it currently
        // is. Without it the +/- buttons only shrank the text.
        if (g_PendingWindowScaleRatio > 0.0001f) {
            ImVec2 sz = ImGui::GetWindowSize();
            ImGui::SetWindowSize(ImVec2(sz.x * g_PendingWindowScaleRatio,
                                        sz.y * g_PendingWindowScaleRatio));
            g_PendingWindowScaleRatio = 0.0f;
        }

        // Refresh MENU / SHOOTING RANGE / REAL MATCH once per frame, before any
        // tab asks Gating::Allowed().
        Gating::Poll(inMatch);

        // ---- Drag from ANY edge or corner ----
        // A single top strip wasn't enough — if the window drifts so the top is
        // off-screen there's nothing left to grab. This lays invisible grab
        // bands around all four edges (which also covers the corners, since
        // they overlap), so the window can always be moved from whatever part
        // of it is still reachable. Plus a reset button as a last resort.
        {
            // EDGE-DRAG REMOVED — this is what broke resizing.
            // It claimed a 10px band around ALL FOUR EDGES and, on click, started
            // moving the window. But that band is exactly where ImGui's own resize
            // grips live, so every attempt to drag an edge or corner to resize got
            // swallowed and turned into a move instead. Hence "it's tiny and I
            // can't expand it".
            //
            // The explicit drag bar below is enough to move the window, and
            // "reset pos" covers the lost-off-screen case. Do not reintroduce an
            // edge-band grab here.

            // ---- LOGO + WORDMARK: genuinely first, on its own line ----
            //
            // This USED to be drawn after the scale-button row below, which is why
            // it "wasn't showing" at the top left: in a narrow window that row of
            // SmallButtons consumes the entire first line, pushing the logo down
            // and out of the visible area. Drawing it first guarantees it owns the
            // top-left corner regardless of window width or UI scale.
            //
            // The glyph is a drawn vector approximation of the mask in blue.png —
            // ImGui cannot load a PNG without a texture upload path, so there is no
            // asset to ship and nothing to go missing.
            //
            // Every Y coordinate is a fraction of `s` between 0.04 and 0.96, and
            // the reserved layout box is s + pad — deliberately LARGER than the
            // drawing. The previous version drew ~25px tall inside a 22px reserved
            // box, so the beard fell outside it and was clipped off. Deriving both
            // from the same `s` keeps them from drifting apart again.
            // REAL LOGO if blue.png/blue(1).ico could be loaded as a texture,
            // otherwise the drawn vector fallback below. The image is always
            // preferred — it's the actual artwork — but the header must never
            // disappear just because a file was missing, so the fallback stays.
            // In SIDE TABS mode the logo lives in the side panel, so it must not
            // be drawn here as well - that is the duplicate. It MOVES, it does
            // not appear twice.
            if (g_SideLayout) {
                // Header is just the controls, on one line, no logo.
                DrawHeaderControls(inMatch);
                g_HeaderControlsDrawn = true;
            }
            else if (LogoTexture::g_Loaded && LogoTexture::g_SRV) {
                // 72px: big enough to read as a logo, small enough that the
                // controls beside it still fit on one line at default width.
                const float box = 72.0f;
                float lw = box, lh = box;
                if (LogoTexture::g_Width > 0 && LogoTexture::g_Height > 0) {
                    // Fit inside the box preserving aspect, so it is never squashed
                    // or cropped whatever the source dimensions are.
                    if (LogoTexture::g_Width >= LogoTexture::g_Height) {
                        lh = box * (float)LogoTexture::g_Height / (float)LogoTexture::g_Width;
                    } else {
                        lw = box * (float)LogoTexture::g_Width / (float)LogoTexture::g_Height;
                    }
                }
                ImGui::Image(LogoTexture::GetTextureID(), ImVec2(lw, lh));
                ImGui::SameLine();
                // Everything to the RIGHT of the logo, in a group so it stacks
                // beside it rather than wrapping underneath. Two short lines:
                // wordmark + credit, then the scale row. Both fit in the logo's
                // height, so nothing is pushed down.
                ImGui::BeginGroup();
                DrawWordmarkAndCredit();
                DrawHeaderControls(inMatch);
                ImGui::EndGroup();
                g_HeaderControlsDrawn = true;
            }
            else
            {
                const float s   = 24.0f;   // glyph drawn strictly inside s x s
                const float pad = 4.0f;    // slack so nothing sits on the boundary

                ImDrawList* dl = ImGui::GetWindowDrawList();
                ImVec2 o = ImGui::GetCursorScreenPos();
                const float cx  = o.x + pad * 0.5f + s * 0.5f;
                const float top = o.y + pad * 0.5f;

                const ImU32 teal = IM_COL32(92, 178, 174, 255);
                const ImU32 pale = IM_COL32(226, 236, 240, 255);
                const ImU32 gold = IM_COL32(214, 178, 106, 255);

                // nemes headdress: trapezoid, widening toward the shoulders
                ImVec2 hd[4] = {
                    ImVec2(cx - s * 0.46f, top + s * 0.78f),
                    ImVec2(cx - s * 0.32f, top + s * 0.06f),
                    ImVec2(cx + s * 0.32f, top + s * 0.06f),
                    ImVec2(cx + s * 0.46f, top + s * 0.78f)
                };
                dl->AddConvexPolyFilled(hd, 4, teal);
                // gold browband, so it reads as a mask rather than a plain shape
                dl->AddRectFilled(ImVec2(cx - s * 0.34f, top + s * 0.10f),
                                  ImVec2(cx + s * 0.34f, top + s * 0.17f), gold);
                // face
                ImVec2 fc[4] = {
                    ImVec2(cx - s * 0.19f, top + s * 0.17f),
                    ImVec2(cx + s * 0.19f, top + s * 0.17f),
                    ImVec2(cx + s * 0.12f, top + s * 0.66f),
                    ImVec2(cx - s * 0.12f, top + s * 0.66f)
                };
                dl->AddConvexPolyFilled(fc, 4, pale);
                // eyes
                dl->AddRectFilled(ImVec2(cx - s * 0.13f, top + s * 0.28f),
                                  ImVec2(cx - s * 0.05f, top + s * 0.34f), teal);
                dl->AddRectFilled(ImVec2(cx + s * 0.05f, top + s * 0.28f),
                                  ImVec2(cx + s * 0.13f, top + s * 0.34f), teal);
                // beard — the part that used to be cut off entirely
                dl->AddRectFilled(ImVec2(cx - s * 0.07f, top + s * 0.64f),
                                  ImVec2(cx + s * 0.07f, top + s * 0.96f), gold);

                // Reserve the full drawn area plus padding, never less.
                ImGui::Dummy(ImVec2(s + pad, s + pad));
                ImGui::SameLine();
                ImGui::BeginGroup();
                DrawWordmarkAndCredit();
                DrawHeaderControls(inMatch);
                ImGui::EndGroup();
                g_HeaderControlsDrawn = true;
            }

            // The scale row and the test-report button are drawn INSIDE the
            // group beside the logo now - see DrawHeaderControls. If neither
            // logo branch ran (no texture and no draw list, which should not
            // happen) draw them here so they are never lost.
            if (!g_HeaderControlsDrawn) DrawHeaderControls(inMatch);
        }

        DrawStatusBanner(inMatch);

        // ---- DEVELOPER MODE (always visible, no tab needed) ----
        // OFF = only the tabs that are actually finished and useful show:
        //   Fire Modes, Highlights, Reticle Manager, Skins, Cards, OCTAVIA.
        // ON  = everything, including diagnostics and dead ends.
        // The mode switches sit on the SAME line as each other and directly
        // under the header group, not stacked one per row - space is tight and
        // three checkboxes on three lines pushed the tabs down for no reason.
        // DEV MODE moved OUT of this header row and INTO the CHARITY tab, per
        // PRIMAL_MONKE - too many normal users clicked it here by accident and
        // got a confusing wall of extra tabs/options. The harmless window
        // switches (SIDE TABS / NOTES / POTATO) stay here.
        ImGui::Checkbox("SIDE TABS", &g_SideLayout);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Moves the tab buttons from the top of the window to a column\n"
            "down the left. Everything else stays exactly where it is.");
        ImGui::SameLine();
        ImGui::Checkbox("NOTES", &g_NotesMode);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Opens a scratchpad docked to the left of this window.\n"
            "It stays open on every tab, so you can write findings as you\n"
            "test and copy the lot in one go.");
        ImGui::SameLine();
        // POTATO MODE lives on this row now, next to the other window-wide
        // switches - it used to sit at the top of the Themes tab, which nobody
        // stuck in a stutter would think to open. This is where people actually
        // look when something about the tool itself needs turning off.
        ImGui::Checkbox("POTATO MODE", &Perf::g_PotatoMode);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Stops every background scan (the unlocker re-apply, health-bar\n"
            "recolour, continuous skin scans). Turn this on if the game\n"
            "stutters. Boxes/skeletons/reticle are unaffected - they read a\n"
            "cache, not a fresh scan.");
        ImGui::SameLine();
        // Manual trigger for the same retry the automatic fallback only ever
        // runs when the real D3D11 hook goes silent - lets the mechanism be
        // verified on a machine where the hook ALREADY works, instead of
        // only ever finding out from a second person's broken one. Same
        // action as pressing F7. Real risk, stated in the tooltip: this
        // REPLACES the hook that's currently working with an unverified one.
        if (ImGui::Button("TEST RHI FALLBACK")) {
            InitLog("[Init] TEST RHI FALLBACK button clicked - manually triggering the RHI fallback test.");
            CreateThread(nullptr, 0, ManualRHITestThread, nullptr, 0, nullptr);
        }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Same as pressing F7. Forces the tool to drop the D3D11 hook\n"
            "that's currently working and retry with the candidate found by\n"
            "the RHI probe (root-cause investigation into fixing this on\n"
            "machines where the normal hook silently never fires).\n\n"
            "REAL RISK: if the candidate turns out wrong, the menu can go\n"
            "silent (same as a genuinely broken machine) or, less likely,\n"
            "crash. That's the point of testing it deliberately here first.\n"
            "Watch the log for 'hkPresent CALLED for the first time' right\n"
            "after clicking.");
        // If DEV MODE was turned off (over in the Charity tab) while a dev-only
        // tab is active, fall back to a visible one.
        if (!g_DeveloperMode && !IsUserTab(activeSection)) activeSection = Section::FireModes;
        ImGui::Separator();

        // Auto-scan is gated on this. Cleared every frame and set only by the
        // skins tabs, so the scan cannot run - and cannot cost anything - while
        // you are on any other tab or playing with the menu closed.
        MeshSkin::g_SkinsTabOpen = (activeSection == Section::Skins);

        if (g_SideLayout) {
            // ---- SIDE LAYOUT ----
            // The first version put the nav in a CHILD inside this window, which
            // ate 150px off the content for every tab - the exact complaint. It
            // is a separate window docked to the left edge now, the same way the
            // NOTES panel is, so it takes nothing away from the tool. The tool
            // draws its content full width, as if the buttons were not there.
            //
            // Drawn after End(), next to DrawNotesPanel - see DrawSideNavPanel.
            DrawSection(activeSection, inMatch);
        } else {
            // ---- TOP LAYOUT (default) ----
            // The width argument is ignored - DrawSectionButtonRow sizes each
            // row from how many buttons are visible and wraps if needed.
            DrawSectionButtonRow(g_Row1, 5, 0.0f);
            DrawSectionButtonRow(g_Row2, 5, 0.0f);

            // ONE button for everything diagnostic, not eleven more tabs.
            if (g_DeveloperMode) {
                bool onDev = (activeSection == Section::DevTab);
                if (onDev) {
                    ImGui::PushStyleColor(ImGuiCol_Button, g_MinorColor);
                    ImGui::PushStyleColor(ImGuiCol_Text,   ImVec4(1, 1, 1, 1));
                }
                if (ImGui::Button("DEV TOOLS", ImVec2(ImGui::GetContentRegionAvail().x, 28)))
                    activeSection = Section::DevTab;
                if (onDev) ImGui::PopStyleColor(2);
            }

            ImGui::Separator();
            DrawSection(activeSection, inMatch);
        }

        // A gated tab's banner button (Gating::DrawBlockedBannerFor/Banner)
        // was just clicked this frame if this is set — jump there. Checked
        // once here rather than at each of the three call sites (this file,
        // LeaveMatch.h, CardSuite.h) since none of those can see Section.
        if (Gating::g_JumpToGatingRequested) {
            Gating::g_JumpToGatingRequested = false;
            activeSection = Section::GatingTab;
        }

        // Remember where the main window is, then draw the notes panel AFTER
        // End(). Beginning a second window while the first is still current is
        // legal but fragile, and is the most likely cause of the freeze while
        // typing into it.
        g_MainPos  = ImGui::GetWindowPos();
        g_MainSize = ImGui::GetWindowSize();

        ImGui::End();

        // Both side panels are drawn AFTER End() and positioned from the main
        // window's recorded pos/size, so neither one takes space from it.
        DrawSideNavPanel(inMatch);
        DrawNotesPanel();
    }
}

// Accessor for headers included before this one (FireModeMenu.h). Keeps the
// research-only controls hidden without inverting the include order.
inline bool RecoverySuite_DeveloperMode() { return RecoverySuite::g_DeveloperMode; }
