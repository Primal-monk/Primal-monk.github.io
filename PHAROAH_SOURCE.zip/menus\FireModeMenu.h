#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "menus/Gating.h"
#include "menus/Language.h" // Tm() - see that file's header comment (also reaches here via Gating.h, included explicitly anyway)
#include <string>
#include <vector>

using Language::Tm;

// Draws directly into whatever window is already open (no separate popup).
// Call this from inside an ImGui::Begin/End block.

static int g_EqPointToCheck = 2;
static SDK::ATgDevice* g_ManualDevice = nullptr;
// 1-based position of the selected device within g_ScanResults, used only to
// label its fire modes "ABILITY N" / "ALTERNATIVE ABILITY N" below - the SDK
// doesn't expose a real ability-slot number, so this is inferred from scan
// order (weapon excluded), not a confirmed keybind mapping.
static int g_ManualDeviceAbilityNumber = 0;
static bool g_OnlyShowMultiMode = true; // per request — hide single-mode devices by default

// Defined in RecoverySuite.h. Declared here because this header is included
// first, and pulling the whole suite in just to read one bool would invert the
// include order for no reason.
bool RecoverySuite_DeveloperMode();

// Forcing CurrentFireMode/m_PendingFireMode/m_nDesiredFireMode directly
// bypasses whatever bookkeeping the game normally keeps in sync during a real
// fire-mode switch. g_ForcedDevice tracks whatever we've force-switched so it
// can be put back — see the functions below for exactly when that's safe to
// actually do (answer: NOT at match-end, that was the real bug — see the
// comment on ForceRevertFireModeNow/RevertForcedFireModeIfAny).
static SDK::ATgDevice* g_ForcedDevice = nullptr;
static unsigned char g_ForcedOriginalMode = 0;

// REVISED after a crash pattern that specifically followed "match ended ->
// joined a new match": writing to g_ForcedDevice AT match-end detection is
// itself a likely use-after-free. "Match ended" can be arbitrarily close to
// (or after) the actual moment the engine destroys/pools that device object —
// if our write lands on memory that's already been freed and reused (even if
// still mapped, so no access violation — SEH catches faults, not silent
// corruption), that's exactly the "no crash here, crashes later on the
// engine's own next dispatch" pattern seen repeatedly. The original theory
// (leaving a forced mode causes a crash during ITS OWN object's GC) was never
// confirmed — meanwhile writing to a possibly-already-gone object definitely
// is dangerous. So: only ever WRITE the revert while things are clearly still
// live (the weapon changed but you're still in a match), never at the
// match-end/pawn-change transition itself — there, just drop the pointer.
inline void RevertForcedFireModeIfAny() {
    // No write here anymore — just stop tracking it. If the object's about to
    // be destroyed anyway (which is why we're in this code path), there's
    // nothing left to protect by writing to it, and doing so is the risk.
    g_ForcedDevice = nullptr;
}

// Actually does the write. Only call this from contexts where the device is
// KNOWN to still be live — either "the weapon just changed to something
// else" (called every frame, so the old one was valid a moment ago) or a
// manual user button click while still actively in the match.
inline void ForceRevertFireModeNow() {
    if (!g_ForcedDevice) return;
    __try {
        g_ForcedDevice->CurrentFireMode = g_ForcedOriginalMode;
        g_ForcedDevice->m_PendingFireMode = g_ForcedOriginalMode;
        g_ForcedDevice->m_nDesiredFireMode = g_ForcedOriginalMode;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
    g_ForcedDevice = nullptr;
}

// Call this every frame with a CURRENT, definitely-valid weapon pointer.
// BUG THIS FIXES — "I can switch my weapon's fire mode but not an ability's."
//
// This runs EVERY FRAME and used to revert whenever g_ForcedDevice was not the
// current weapon. That's correct for a forced WEAPON mode (weapon changed =>
// put it back), but it silently destroyed every forced ABILITY mode: an ability
// device is never equal to Globals::LocalWeapon, so the condition was always
// true and the switch was reverted on the very next frame. The click worked; it
// just got undone before you could see it.
//
// Fix: only auto-revert when the forced device IS the weapon we're tracking.
// Forced ability modes are left alone and are reverted by match-end/pawn-change
// or the manual Revert button instead.
inline bool g_ForcedDeviceWasWeapon = false;

inline void RevertForcedFireModeIfWeaponChanged(SDK::ATgDevice* currentWeapon) {
    if (!g_ForcedDevice) return;
    if (!g_ForcedDeviceWasWeapon) return;       // an ability — not ours to revert here
    if (g_ForcedDevice == currentWeapon) return; // same weapon, nothing to do
    ForceRevertFireModeNow();
}

// ============================================================================
// "SUPER DROGOZ" — automates his fire-mode reload dance.
//
// The problem: on fire mode 2 he can loose a barrage of rockets, but CANNOT
// reload in that mode. Normally you must manually switch back to mode 1, wait
// for the reload, then manually switch back to mode 2.
//
// This automates exactly that sequence, and nothing more:
//     mode 2  ->  (you stop firing)  ->  switch to mode 1  ->  wait for reload
//             ->  switch back to mode 2
//
// It is a macro over the fire-mode switching that already exists — no new game
// access. Fire-mode writes are the three raw fields (CurrentFireMode /
// m_PendingFireMode / m_nDesiredFireMode); do NOT route this through the
// engine's SetFireMode(), which silently refuses these hidden modes.
// ============================================================================
// The raw three-field switch. This was previously defined inside the deferred
// SetFireMode experiment, which got removed wholesale during the revert that
// restored working fire modes — taking this helper with it. Redefined here
// standalone, because it IS the known-working switch and Drogoz needs it.
// Do NOT route this through the engine's SetFireMode(); that silently refuses
// these hidden modes and broke every fire mode when it was tried.
inline void ApplyFireModeRaw(SDK::ATgDevice* device, int mode) {
    if (!device) return;
    // CHARITY GATE. Free in the shooting range, locked in real matches until a
    // code is entered. This is the single chokepoint every fire-mode write goes
    // through, so gating it here covers the buttons, the binds and Super Drogoz
    // in one place. The revert helpers below are deliberately NOT gated —
    // putting the weapon back the way you found it must always be allowed.
    if (!Gating::Allowed()) return;
    __try {
        if (g_ForcedDevice != device) {
            g_ForcedDevice = device;
            g_ForcedOriginalMode = device->CurrentFireMode;
            // Record WHICH kind of device this is, so the per-frame weapon-change
            // revert doesn't wipe a forced ability mode (see
            // RevertForcedFireModeIfWeaponChanged).
            g_ForcedDeviceWasWeapon = (device == Globals::LocalWeapon);
        }
        device->CurrentFireMode = (unsigned char)mode;
        device->m_PendingFireMode = (unsigned char)mode;
        device->m_nDesiredFireMode = (unsigned char)mode;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { }
}

inline bool  superDrogozEnabled = false;
inline int   drogozBarrageMode = 2;   // the no-reload burst mode
inline int   drogozReloadMode  = 1;   // the mode that can reload
inline float drogozReloadWaitMs = 1600.0f;
inline int   g_DrogozState = 0;       // 0 idle, 1 waiting-to-swap-to-reload, 2 reloading
inline ULONGLONG g_DrogozStateAtMs = 0;
inline int   g_DrogozCycles = 0;
inline bool  g_DrogozIsDrogoz = false;

inline bool IsPlayingDrogoz() {
    __try {
        if (!Globals::LocalPawn) return false;
        SDK::UClass* cls = ((SDK::ATgPawn*)Globals::LocalPawn)->Class;
        if (!cls || cls->Name.Index == 0) return false;
        auto& names = SDK::FName::GetGlobalNames();
        if (!names.IsValidIndex((size_t)cls->Name.Index)) return false;
        SDK::FNameEntry* entry = names[cls->Name.Index];
        if (!entry) return false;
        const char* ansi = entry->GetAnsiName();
        if (!ansi) return false;
        return (strstr(ansi, "Drogoz") != nullptr);
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}

inline int TryGetCurrentFireMode(SDK::ATgDevice* w) {
    __try { return w ? (int)w->CurrentFireMode : -1; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
}

// r_nAmmoClipCount is the replicated current-clip count on ATgDevice.
// (m_nAmmoCount, which I reached for first, lives on UTgDeviceForm_Inhand —
// a different class entirely.)
inline int TryGetAmmoCount(SDK::ATgDevice* w) {
    __try { return w ? w->r_nAmmoClipCount : -1; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
}

// Max clip size isn't on the device — it's a property of the CURRENT FIRE MODE
// (UTgDeviceFire::m_nAmmoClipSize), which matters here since Drogoz's two modes
// have different clip sizes.
inline int TryGetMaxAmmoCount(SDK::ATgDevice* w) {
    __try {
        if (!w) return -1;
        int mode = (int)w->CurrentFireMode;
        int count = (int)w->m_FireMode.Num();
        if (mode < 0 || mode >= count) return -1;
        SDK::UTgDeviceFire* fm = w->m_FireMode[mode];
        return fm ? fm->m_nAmmoClipSize : -1;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
}

// Drives the cycle. Called every frame; all reads/writes are raw fields, so
// this is safe from the render thread (no ProcessEvent calls anywhere).
inline void UpdateSuperDrogoz() {
    g_DrogozIsDrogoz = IsPlayingDrogoz();
    if (!superDrogozEnabled || !g_DrogozIsDrogoz) { g_DrogozState = 0; return; }

    SDK::ATgDevice* w = Globals::LocalWeapon;
    if (!w) { g_DrogozState = 0; return; }

    int mode = TryGetCurrentFireMode(w);
    int ammo = TryGetAmmoCount(w);
    int maxAmmo = TryGetMaxAmmoCount(w);
    if (mode < 0 || ammo < 0) return;

    ULONGLONG now = GetTickCount64();

    switch (g_DrogozState) {
    case 0: // idle — watch for the barrage running dry
        if (mode == drogozBarrageMode && ammo <= 0) {
            ApplyFireModeRaw(w, drogozReloadMode); // swap to the mode that CAN reload
            g_DrogozState = 2;
            g_DrogozStateAtMs = now;
        }
        break;

    case 2: // reloading in the reload-capable mode
        // Leave early the moment ammo actually comes back, rather than always
        // burning the full timeout — the wait is only a fallback for when the
        // reload gets interrupted.
        if ((maxAmmo > 0 && ammo >= maxAmmo) ||
            (now - g_DrogozStateAtMs) > (ULONGLONG)drogozReloadWaitMs) {
            ApplyFireModeRaw(w, drogozBarrageMode); // back to the barrage
            g_DrogozState = 0;
            g_DrogozCycles++;
        }
        break;

    default:
        g_DrogozState = 0;
        break;
    }
}

struct EqScanResult { int point; std::string name; int numModes; };
static std::vector<EqScanResult> g_ScanResults;

void ScanEquipPoints(int lowInclusive, int highInclusive) {
    g_ScanResults.clear();
    g_ManualDevice = nullptr; // clear old selection so a stale champion's device never lingers on screen
    if (!Globals::LocalPawn) return;
    SDK::ATgPawn* pawn = (SDK::ATgPawn*)Globals::LocalPawn;
    for (int i = lowInclusive; i <= highInclusive; i++) {
        SDK::ATgDevice* d = pawn->GetDeviceByEqPoint(i);
        if (d) {
            g_ScanResults.push_back({ i, d->GetName(), (int)d->m_FireMode.Num() });
        }
    }
}

const char* FireTypeToString(int t) {
    switch (t) {
        case 0: return "InstantHit";
        case 1: return "Projectile";
        case 2: return "Custom";
        case 3: return "None";
        default: return "Unknown";
    }
}

// mode0Label/mode1Label: what real-world input triggers fire mode 0 / mode 1
// on this device - e.g. "LEFT CLICK"/"RIGHT CLICK" for the weapon, or
// "ABILITY 1"/"ALTERNATIVE ABILITY 1" for an ability device. Purely a label
// appended next to each mode below so new users can map a mode number to the
// button they actually press - no behavior change. Pass nullptr for either
// to leave that mode unlabeled (e.g. an ability with no alternate use).
void DrawDeviceFireModes(SDK::ATgDevice* weapon, const char* mode0Label = nullptr, const char* mode1Label = nullptr) {
    if (!weapon) {
        ImGui::TextDisabled(Tm("Nothing selected yet.", "Nada seleccionado aun."));
        return;   // nothing drawn, so nothing pushed - do not touch the ID stack
    }

    // ========================================================================
    // THE "2 visible items with conflicting ID" BUG
    // ========================================================================
    // This function runs once for the WEAPON and again for each ABILITY, and
    // every call built the same labels: "Use Mode 0", "Use Mode 1". In ImGui a
    // widget's identity IS its label, so two buttons reading "Use Mode 0" in
    // one window are literally the same widget.
    //
    // That is the error dialog users kept seeing, and it is also why Pip could
    // not switch his potion back: the ability's button and the weapon's button
    // were sharing one ID, so a click landed on whichever won that frame. It
    // looked random because it depended on draw order.
    //
    // PushID(the device pointer) scopes every widget below to THIS device.
    // Same visible labels, different IDs.
    //
    // Every return path from here on MUST PopID.
    ImGui::PushID((const void*)weapon);

    int numModes = weapon->m_FireMode.Num();
    ImGui::Text(Tm("Selected: %s", "Seleccionado: %s"), weapon->GetName().c_str());
    ImGui::Text(Tm("Modes found: %d", "Modos encontrados: %d"), numModes);

    if (numModes <= 1) {
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)), Tm("Only one mode — nothing extra to switch to here.", "Solo un modo — nada mas a que cambiar aqui."));
        ImGui::PopID();   // balance the PushID above - every return path must
        return;
    }

    ImGui::Separator();
    ImGui::TextDisabled(Tm("Can't tell modes apart by feel? Compare the numbers below.",
                            "No distingues los modos? Compara los numeros de abajo."));
    for (int i = 0; i < numModes; ++i) {
        char label[64];
        snprintf(label, sizeof(label), Tm("Use Mode %d%s", "Usar Modo %d%s"), i,
            (int)weapon->CurrentFireMode == i ? Tm("  (current)", "  (actual)") : "");

        if (ImGui::Button(label, ImVec2(200, 24))) {
            // Routed through the shared helper on purpose. This used to be an
            // inline COPY of the same three writes, which meant it never set
            // g_ForcedDeviceWasWeapon — so a forced ABILITY mode was reverted by
            // the per-frame weapon-change check on the very next frame. That is
            // the "I click mode 2 and nothing happens" bug. One code path only.
            ApplyFireModeRaw(weapon, i);
        }

        SDK::UTgDeviceFire* fm = weapon->m_FireMode[i];
        if (fm) {
            ImGui::SameLine();
            ImGui::TextDisabled("id=%d type=%s shots=%d ammo=%d/%d fireTime=%.2f",
                fm->m_nId, FireTypeToString((int)fm->m_nFireType.GetValue()),
                fm->m_nShotsPerFire, fm->m_nAmmoCostPerShot, fm->m_nAmmoClipSize, fm->m_fFireTime);
        }

        const char* inputLabel = (i == 0) ? mode0Label : (i == 1) ? mode1Label : nullptr;
        if (inputLabel) {
            ImGui::SameLine();
            ImGui::TextColored(Ink(ImVec4(0.5f, 0.85f, 1.0f, 1.0f)), "[%s]", inputLabel);
        }
    }

    if (g_ForcedDevice) {
        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.7f, 0.3f, 1.0f)), Tm(
            "Forcing a mode on a champion NOT in the confirmed-working list below "
            "carries real crash risk (seen on Evie) — the game may have extra "
            "bookkeeping tied to a real mode switch that this bypasses, and it can "
            "surface as a crash later, not just immediately. Auto-reverts on match-"
            "end/respawn, but if things feel off sooner, revert manually:",
            "Forzar un modo en un campeon que NO esta en la lista confirmada de abajo "
            "conlleva riesgo real de crash (visto en Evie) — el juego puede tener "
            "contabilidad extra ligada a un cambio de modo real que esto se salta, y puede "
            "aparecer como un crash mas tarde, no solo de inmediato. Se revierte automaticamente al "
            "terminar la partida/respawn, pero si algo se siente mal antes, revierte manualmente:"));
        if (ImGui::Button(Tm("Revert to Original Mode Now", "Revertir al Modo Original Ahora"))) {
            ForceRevertFireModeNow(); // safe here — you're actively viewing this device's own menu right now
        }
    }

    ImGui::PopID();   // closes the PushID(weapon) at the top
}

// Champions/abilities confirmed (via the game's own dev notes) to work through
// a fire-mode switch, same as Vatu's Ambush. No talent swap needed for any of
// these — keep your normal talent equipped, just use the ability once then scan.
struct KnownFireModeTalent { const char* champion; const char* ability; };
static const KnownFireModeTalent g_KnownList[] = {
    { "Mal'Damba", "Slither (2 modes) — mode 2 = Poison Slither (27797), CONFIRMED WORKING" },
    { "Vatu", "Ambush = TgDevice_ShadowTeleport_1 (NOT ShadowUlt) — this is Omnipresence, CONFIRMED WORKING" },
    { "Ruckus", "TgDevice_RocketLauncher_1 — matches Missile Launcher" },
    { "Mal'Damba", "Gourd (already normally usable, bonus confirmation)" },
    { "Makoa", "Cannon" },
    { "Pip", "Healing Potion" },
    { "Grohk", "Lightning Staff" },
};

void RenderFireModeMenu() {
    // Auto-scan once per champion change, so the list is populated without
    // needing to click Scan first — click Scan again any time to refresh.
    static SDK::APawn* lastAutoScannedPawn = nullptr;
    if (Globals::LocalPawn && Globals::LocalPawn != lastAutoScannedPawn) {
        ScanEquipPoints(0, 20);
        lastAutoScannedPawn = Globals::LocalPawn;
    }

    // REVERTED to exactly the original behaviour. The "ALL SWITCHABLE MODES"
    // panel that briefly lived here called GetDeviceByEqPoint() for all 21 equip
    // points EVERY FRAME from the render thread — and that's a scripted call
    // routed through ProcessEvent, i.e. the precise cross-thread pattern that
    // breaks everything in this project. It made every fire-mode switch crash on
    // every champion, including ones that were rock solid (Lex). The original
    // only touched GetDeviceByEqPoint on an explicit Scan button press, which is
    // why it was stable. Do not reintroduce a per-frame device walk here.
    ImGui::Text(Tm("Your current weapon:", "Tu arma actual:"));
    if (Globals::LocalWeapon) {
        ImGui::SameLine();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.6f, 1.0f)), "%s", Globals::LocalWeapon->GetName().c_str());
    } else {
        ImGui::SameLine();
        ImGui::TextDisabled(Tm("(none found)", "(ninguno encontrado)"));
    }
    DrawDeviceFireModes(Globals::LocalWeapon, Tm("LEFT CLICK", "CLIC IZQUIERDO"), Tm("RIGHT CLICK", "CLIC DERECHO"));

    // Drogoz-only automation, hidden entirely on other champions.
    if (g_DrogozIsDrogoz || IsPlayingDrogoz()) {
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.6f, 0.3f, 1.0f)), Tm("SUPER DROGOZ", "SUPER DROGOZ"));
        ImGui::TextWrapped(Tm("Mode 2 fires the rocket barrage but can't reload. This watches for "
            "the barrage running dry, auto-swaps to mode 1 so it reloads, then swaps straight "
            "back to mode 2 when ammo returns.",
            "El Modo 2 dispara la andanada de cohetes pero no puede recargar. Esto vigila "
            "que la andanada se quede sin municion, cambia automaticamente al modo 1 para recargar, y luego "
            "vuelve directo al modo 2 cuando la municion regresa."));
        ImGui::Checkbox(Tm("Enable Super Drogoz", "Activar Super Drogoz"), &superDrogozEnabled);
        ImGui::Text(Tm("State: %s   |   cycles completed: %d", "Estado: %s   |   ciclos completados: %d"),
            g_DrogozState == 0 ? Tm("watching", "vigilando") : Tm("reloading", "recargando"), g_DrogozCycles);
        ImGui::PushItemWidth(120);
        ImGui::InputInt(Tm("Barrage mode", "Modo de andanada"), &drogozBarrageMode);
        ImGui::InputInt(Tm("Reload mode", "Modo de recarga"), &drogozReloadMode);
        ImGui::PopItemWidth();
        ImGui::SliderFloat(Tm("Reload wait (ms)", "Espera de recarga (ms)"), &drogozReloadWaitMs, 400.0f, 4000.0f, "%.0f");
        ImGui::TextDisabled(Tm("It swaps back as soon as ammo refills; the wait is only a fallback",
            "Cambia de vuelta en cuanto la municion se rellena; la espera es solo un respaldo"));
        ImGui::TextDisabled(Tm("for an interrupted reload. Adjust the mode numbers if his modes are",
            "para una recarga interrumpida. Ajusta los numeros de modo si sus modos estan"));
        ImGui::TextDisabled(Tm("ordered differently than 1/2 on your build.", "ordenados distinto a 1/2 en tu build."));
    }

    // The "worth checking" list and the multi-mode filter are research aids, not
    // features - they tell you where to LOOK rather than doing anything. Behind
    // developer mode so the tab shows only what actually acts.
    if (RecoverySuite_DeveloperMode()) {
    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Text(Tm("Known champions/abilities worth checking:", "Campeones/habilidades conocidos que vale revisar:"));
    ImGui::TextDisabled(Tm("Keep your normal talent equipped — use the ability once, then Scan below.",
        "Manten tu talento normal equipado — usa la habilidad una vez, luego Escanea abajo."));
    ImGui::BeginChild("KnownList", ImVec2(0, 90), true);
    for (auto& k : g_KnownList) {
        ImGui::BulletText("%s — %s", k.champion, k.ability);
    }
    ImGui::EndChild();

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Text(Tm("Scan for an ability:", "Escanear una habilidad:"));
    ImGui::TextDisabled(Tm("Auto-scans when you switch champion. Click Scan any time to refresh.",
        "Auto-escanea al cambiar de campeon. Haz clic en Escanear en cualquier momento para actualizar."));
    if (ImGui::Button(Tm("Scan (checks slots 0-20)", "Escanear (revisa ranuras 0-20)"))) {
        ScanEquipPoints(0, 20);
    }
    ImGui::SameLine();
    ImGui::PushItemWidth(70.0f);
    ImGui::InputInt(Tm("Specific #", "Numero especifico"), &g_EqPointToCheck);
    ImGui::PopItemWidth();
    ImGui::SameLine();
    if (ImGui::Button(Tm("Check", "Revisar"))) {
        ScanEquipPoints(g_EqPointToCheck, g_EqPointToCheck);
    }
    ImGui::SameLine();
    if (ImGui::Button(Tm("Clear", "Limpiar"))) {
        g_ScanResults.clear();
        g_ManualDevice = nullptr;
    }

    ImGui::Checkbox(Tm("Only show devices with more than 1 mode", "Mostrar solo dispositivos con mas de 1 modo"), &g_OnlyShowMultiMode);
    }   // end developer-only research block

    if (!g_ScanResults.empty()) {
        ImGui::Separator();
        ImGui::Text(Tm("Found these:", "Se encontro esto:"));
        ImGui::SameLine();
        if (ImGui::SmallButton(Tm("Copy List", "Copiar Lista"))) {
            std::string clip;
            for (auto& r : g_ScanResults) {
                clip += "[" + std::to_string(r.point) + "] " + r.name + " (" + std::to_string(r.numModes) + " modes)\n";
            }
            ImGui::SetClipboardText(clip.c_str());
        }
        ImGui::BeginChild("ScanResults", ImVec2(0, 120), true);
        // Counts non-weapon entries in scan order to label them ABILITY 1, 2,
        // 3... below. Compared by NAME, not by re-calling GetDeviceByEqPoint
        // here - that call is scripted/ProcessEvent-only, and this loop runs
        // every frame the list is visible (see the big warning above about
        // why a per-frame eq-point walk from the render thread broke
        // everything). A name string compare is free and thread-safe.
        int abilityCounter = 0;
        for (auto& r : g_ScanResults) {
            if (g_OnlyShowMultiMode && r.numModes <= 1) continue;
            bool isWeapon = Globals::LocalWeapon && r.name == Globals::LocalWeapon->GetName();
            if (!isWeapon) abilityCounter++;
            char label[160];
            // ##r.point makes the ID unique even when two devices share a name
            // and mode count - the visible text is unchanged.
            snprintf(label, sizeof(label), "[%d] %s  (%d mode%s)##scan%d", r.point, r.name.c_str(),
                r.numModes, r.numModes == 1 ? "" : "s", r.point);
            if (ImGui::Selectable(label)) {
                g_ManualDevice = ((SDK::ATgPawn*)Globals::LocalPawn)->GetDeviceByEqPoint(r.point);
                g_ManualDeviceAbilityNumber = isWeapon ? 0 : abilityCounter;
            }
        }
        ImGui::EndChild();
    }

    if (g_ManualDevice) {
        ImGui::Separator();
        ImGui::Text(Tm("Selected from the list above:", "Seleccionado de la lista de arriba:"));
        if (g_ManualDeviceAbilityNumber > 0) {
            char mode0[24], mode1[36];
            snprintf(mode0, sizeof(mode0), Tm("ABILITY %d", "HABILIDAD %d"), g_ManualDeviceAbilityNumber);
            snprintf(mode1, sizeof(mode1), Tm("ALTERNATIVE ABILITY %d", "HABILIDAD ALTERNATIVA %d"), g_ManualDeviceAbilityNumber);
            ImGui::TextDisabled(Tm("(ability number is inferred from scan order, not a confirmed keybind)",
                "(el numero de habilidad se infiere del orden de escaneo, no es una tecla confirmada)"));
            DrawDeviceFireModes(g_ManualDevice, mode0, mode1);
        } else {
            DrawDeviceFireModes(g_ManualDevice, Tm("LEFT CLICK", "CLIC IZQUIERDO"), Tm("RIGHT CLICK", "CLIC DERECHO"));
        }
    }
}
