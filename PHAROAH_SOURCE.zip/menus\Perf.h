#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"

// ============================================================================
// PERF  —  one place that owns "how hard is this tool allowed to work"
// ============================================================================
// WHY THIS EXISTS
//
// Users reported the game stuttering while the FPS counter stayed at 40-50.
// That combination is the signature of a periodic HITCH, not a framerate
// problem: something expensive runs on a timer, blocks a frame, and the average
// barely moves.
//
// The cause was several subsystems each walking the ENTIRE GObjects array - a
// couple of hundred thousand objects, with class-name string compares on every
// one - on their own independent timers:
//
//     Unlocker::RunPass        every 1.0s   (on by DEFAULT, hidden in dev mode)
//     HealthBarColor pass      every 1.5s   (only when recolouring is on)
//     MeshSkin scans           on spawn / tab open
//
// The Unlocker was the big one. It defaults to ON, it is not visible outside
// developer mode, so a user could turn off every feature they could SEE and
// still have a 200k-object walk running every second.
//
// On a fast machine that is invisible. On a slow one it is the whole complaint.
//
// So: every periodic full-object-array walk in the tool now asks here first.
// ============================================================================

namespace Perf {

    // ---- POTATO MODE -------------------------------------------------------
    // One switch that stops every optional background scan. Nothing that draws
    // is affected - boxes, reticle, skeletons all still work, because those read
    // an already-gathered cache rather than walking objects themselves.
    //
    // What it actually stops:
    //   - the Unlocker's periodic re-apply
    //   - health-bar recolour re-apply
    //   - continuous skin/material rescans
    //   - the card sweep's fast retry loop
    // ON by default now. This directly targets the stutter complaints that
    // kept coming in even on lowest graphics settings - the hitch is from
    // background GObjects walks (Unlocker/healthbar/skin scans), which are
    // completely independent of graphics quality, so lowering settings never
    // touched it. It only slows OPTIONAL re-apply timers; nothing that draws
    // (boxes/skeletons/reticle) is affected - see the header comment above.
    //
    // WAS the actual cause of "I have to click Apply Now" for health bar
    // recolour: static ON by default meant AllowBackgroundScan() was FALSE
    // from the moment the tool loaded, so the periodic reapply timer in
    // HealthBarColor.h never ran on its own - the game kept re-tinting bars
    // on every damage/heal/range change, and only an explicit forced press
    // (Apply Now, or a checkbox that sets g_PendingApply) ever fixed it back.
    // Nothing was broken in the recolour code itself; potato mode being
    // static-on was silently starving it. See g_AutoPotato below.
    inline bool g_PotatoMode = true;

    // ---- AUTO POTATO MODE ---------------------------------------------
    // Per request: potato mode should engage itself when it's actually
    // needed (a real hitch, the same >50ms worst-frame threshold the UI
    // already uses to suggest it) and switch itself back off once things
    // have been smooth for a while - not sit statically ON forever, quietly
    // blocking every background reapply (health bar recolour included) on
    // machines that never needed it in the first place. ON (auto-managed)
    // by default; manually touching the POTATO MODE checkbox turns this off
    // so a deliberate choice always wins and the auto logic doesn't fight it
    // a second later.
    inline bool g_AutoPotato = true;
    inline int  g_CleanSecondsInARow = 0;
    inline const float kHitchThresholdMs = 50.0f;   // matches the UI's own "that is a visible hitch" line
    inline const int   kCleanSecondsToRelax = 5;    // this many clean 1s windows in a row before auto-OFF

    // Multiplier applied to every periodic interval. Potato mode stretches
    // things that must still run occasionally rather than killing them.
    inline float IntervalScale() { return g_PotatoMode ? 4.0f : 1.0f; }

    // "May an expensive full-GObjects walk run right now?"
    // Optional background work asks this; anything the user just clicked does
    // not, because an explicit press should always do the thing.
    inline bool AllowBackgroundScan() { return !g_PotatoMode; }

    // ---- frame-time readout, so the effect is visible ---------------------
    // Worst frame in the last second. A hitch shows here even when the average
    // FPS looks fine, which is exactly the case users were describing.
    inline float g_WorstFrameMs = 0.0f;
    inline float g_WorstShown   = 0.0f;
    inline float g_Accum        = 0.0f;

    inline void Tick(float dtSeconds) {
        const float ms = dtSeconds * 1000.0f;
        if (ms > g_WorstFrameMs) g_WorstFrameMs = ms;
        g_Accum += dtSeconds;
        if (g_Accum >= 1.0f) {
            g_WorstShown   = g_WorstFrameMs;
            g_WorstFrameMs = 0.0f;
            g_Accum        = 0.0f;

            // AUTO POTATO MODE - engage the instant a real hitch shows up,
            // relax again after several clean seconds in a row. A single
            // spike shouldn't immediately relax it (that's how you'd get
            // on/off flapping every other second), but a single spike DOES
            // immediately engage it - better to over-react once than let a
            // real stutter run.
            if (g_AutoPotato) {
                if (g_WorstShown > kHitchThresholdMs) {
                    g_PotatoMode = true;
                    g_CleanSecondsInARow = 0;
                } else {
                    g_CleanSecondsInARow++;
                    if (g_PotatoMode && g_CleanSecondsInARow >= kCleanSecondsToRelax) {
                        g_PotatoMode = false;
                    }
                }
            }
        }
    }

    // The POTATO MODE checkbox itself lives in the header row now (next to
    // DEV MODE / SIDE TABS / NOTES) so it is visible without opening this tab.
    // This function draws the explanation and the frame-time readout only, so
    // it is not a second copy of the same checkbox.
    inline void DrawControls() {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("PERFORMANCE");
        ImGui::PopStyleColor();

        ImGui::TextWrapped("POTATO MODE (top of the window, next to DEV MODE) stops the tool's "
            "background scanning. Several parts of it walk the game's entire object list on a "
            "timer to keep things applied; on a slower PC that is a hitch every second or so.");
        ImGui::TextDisabled("Boxes, skeletons and the reticle are NOT affected - they read a cache");
        ImGui::TextDisabled("rather than scanning, so they cost nothing extra.");

        if (ImGui::Checkbox("AUTO (engage on a real hitch, relax after it clears)", &g_AutoPotato)) {
            g_CleanSecondsInARow = 0;
        }
        ImGui::TextDisabled("This is what fixes 'I have to click Apply Now' on health bar recolour -");
        ImGui::TextDisabled("potato mode used to sit statically ON by default, which silently blocked");
        ImGui::TextDisabled("its periodic reapply even on machines that never hitched at all.");

        ImGui::TextColored(Ink(g_PotatoMode ? ImVec4(0.45f, 1.0f, 0.55f, 1.0f)
                                            : ImVec4(0.65f, 0.65f, 0.65f, 1.0f)),
            "Potato mode is currently %s%s.", g_PotatoMode ? "ON" : "OFF",
            g_AutoPotato ? " (auto)" : " (manual)");

        ImGui::Spacing();
        const float avg = ImGui::GetIO().Framerate;
        ImGui::Text("FPS %.0f      worst frame in the last second: %.1f ms", avg, g_WorstShown);
        if (g_WorstShown > 50.0f) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.45f, 0.30f, 1.0f)),
                "That is a visible hitch. Try POTATO MODE.");
        } else if (g_WorstShown > 0.0f) {
            ImGui::TextColored(Ink(ImVec4(0.45f, 1.0f, 0.55f, 1.0f)), "Smooth - no hitching.");
        }
        ImGui::TextDisabled("A hitch does NOT show up in average FPS, which is why the counter can");
        ImGui::TextDisabled("read 50 while the game still feels bad. This number is the one to watch.");
    }
}
