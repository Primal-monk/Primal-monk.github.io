#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
//
// Hand-rolled, minimal interactive menu drawn through UE3's native Canvas,
// for machines where the D3D11 Present hook never fires (see initlogs.md -
// kiero::bind() itself reports Success and the dummy device even resolves
// the real game window, but hkPresent still never gets called; a real,
// load-bearing fact about at least one confirmed machine, not a theory).
//
// DRAW2DLINE AND PROJECT ONLY - NOTHING ELSE. This is the second version of
// this file. The first used DrawTile (filled rects) and DrawText (labels)
// too, reasoning that since they're generated via the exact same forced-
// native ProcessEvent dispatch as Draw2DLine (verified by reading the SDK's
// generated .cpp for all of them), they should be equally safe. That
// reasoning was WRONG, or at least incomplete: it crashed a real match
// twice. The first crash's visible stack frame was inside DrawTile, but a
// SECOND crash happened after DrawTile was guarded AND wrapped in
// __try/__except - and that second crash was the game's own native "Fatal
// error!" format, not something our SEH handler ever saw. That means the
// actual damage happens somewhere OTHER than the frame that faults - almost
// certainly VM/engine state corruption from calling a scripted ProcessEvent
// function RE-ENTRANTLY (from inside our own ProcessEvent hook, before the
// real dispatch for the CURRENT call has even happened), which then trips
// an unrelated internal consistency check later, in a call frame with no
// SEH protection of ours anywhere near it. Draw2DLine/Project have been
// exercised at high volume across many full matches (RenderBoxesViaCanvas,
// VisibilityBoxes.h) with zero incidents - that's real evidence, not an
// assumption. DrawTile/DrawText/SetPos/SetDrawColorStruct have none, and
// two crashes is enough. Every pixel in this file goes through Draw2DLine.
// Text is a small hand-drawn stroke font (see the Font:: namespace below) -
// slower to author, uglier than a real font, but it never calls anything
// but the one primitive that's actually proven itself.
//
// INPUT: independent of any hook. Mouse position/clicks are polled directly
// against the real game window (kiero::findRealGameWindow()) via
// GetCursorPos/ScreenToClient/GetAsyncKeyState. Works identically whether or
// not the Present hook ever fires.

#include "globals.h"
#include "ext/kiero/kiero.h"
#include <Windows.h>
#include <cstdio>
#include <cctype>

namespace CanvasMenu {

    // ---------------------------------------------------------------------
    // INPUT
    // ---------------------------------------------------------------------
    struct InputState {
        float mouseX = 0.0f, mouseY = 0.0f;
        bool mouseDown = false;
        bool clickedEdge = false;
    };
    inline InputState g_Input;

    inline void PollInput() {
        static bool wasDown = false;
        HWND wnd = (HWND)kiero::findRealGameWindow();
        if (!wnd) {
            g_Input = InputState();
            wasDown = false;
            return;
        }
        POINT p{};
        GetCursorPos(&p);
        ScreenToClient(wnd, &p);
        g_Input.mouseX = (float)p.x;
        g_Input.mouseY = (float)p.y;
        bool down = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        g_Input.mouseDown = down;
        g_Input.clickedEdge = down && !wasDown;
        wasDown = down;
    }

    inline bool g_MenuOpen = false;
    inline void PollToggleKey() {
        static bool wasDown = false;
        bool down = (GetAsyncKeyState(VK_INSERT) & 0x8000) != 0;
        if (down && !wasDown) g_MenuOpen = !g_MenuOpen;
        wasDown = down;
    }

    // ---------------------------------------------------------------------
    // DRAWING PRIMITIVES - Draw2DLine only, proven safe at high volume.
    // ---------------------------------------------------------------------
    inline void Line(SDK::UCanvas* canvas, float x0, float y0, float x1, float y1,
                      unsigned char r, unsigned char g, unsigned char b, unsigned char a = 255) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = a;
        canvas->Draw2DLine(x0, y0, x1, y1, c);
    }

    inline void Outline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                         unsigned char r, unsigned char g, unsigned char b) {
        Line(canvas, x,     y,     x + w, y,     r, g, b);
        Line(canvas, x + w, y,     x + w, y + h, r, g, b);
        Line(canvas, x + w, y + h, x,     y + h, r, g, b);
        Line(canvas, x,     y + h, x,     y,     r, g, b);
    }

    // Approximates a filled rect with stacked horizontal lines - no DrawTile
    // involved at all. Step of 2px keeps the call count sane (a 280x300
    // panel is ~150 lines, trivial next to RenderBoxesViaCanvas's proven
    // per-second call volume) while still reading as solid.
    inline void FillRectLines(SDK::UCanvas* canvas, float x, float y, float w, float h,
                               unsigned char r, unsigned char g, unsigned char b) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = 255;
        for (float row = y; row < y + h; row += 2.0f) {
            canvas->Draw2DLine(x, row, x + w, row, c);
        }
    }

    // ---------------------------------------------------------------------
    // FONT - tiny hand-drawn stroke font, 3 units wide x 5 units tall,
    // Draw2DLine only. Only the letters/digits this file's own labels
    // actually use are defined (see the big comment at the top for why the
    // label wording was chosen to fit exactly this set) - add more cases if
    // a future label needs a letter that isn't here yet, following the same
    // pattern.
    // ---------------------------------------------------------------------
    namespace Font {
        struct Seg { float x0, y0, x1, y1; };

        // Returns the number of segments written into out (max 8) for one
        // glyph, in a 3(w) x 5(h) unit grid, origin top-left.
        inline int Glyph(char ch, Seg* out) {
            switch (ch) {
            case 'A': out[0]={0,4,0,1}; out[1]={0,1,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,4}; out[4]={0,2,2,2}; return 5;
            case 'C': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; return 3;
            case 'D': out[0]={0,0,0,4}; out[1]={0,0,1,0}; out[2]={1,0,2,1}; out[3]={2,1,2,3}; out[4]={2,3,1,4}; out[5]={1,4,0,4}; return 6;
            case 'E': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={0,2,2,2}; return 4;
            case 'F': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,2,2,2}; return 3;
            case 'G': out[0]={2,0,0,0}; out[1]={0,0,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,1,2}; return 5;
            case 'H': out[0]={0,0,0,4}; out[1]={2,0,2,4}; out[2]={0,2,2,2}; return 3;
            case 'I': out[0]={0,0,2,0}; out[1]={1,0,1,4}; out[2]={0,4,2,4}; return 3;
            case 'L': out[0]={0,0,0,4}; out[1]={0,4,2,4}; return 2;
            case 'M': out[0]={0,4,0,0}; out[1]={0,0,1,2}; out[2]={1,2,2,0}; out[3]={2,0,2,4}; return 4;
            case 'N': out[0]={0,4,0,0}; out[1]={0,0,2,4}; out[2]={2,4,2,0}; return 3;
            case 'O': out[0]={0,0,2,0}; out[1]={2,0,2,4}; out[2]={2,4,0,4}; out[3]={0,4,0,0}; return 4;
            case 'P': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; return 4;
            case 'R': out[0]={0,4,0,0}; out[1]={0,0,2,0}; out[2]={2,0,2,2}; out[3]={2,2,0,2}; out[4]={0,2,2,4}; return 5;
            case 'S': out[0]={2,0,0,0}; out[1]={0,0,0,2}; out[2]={0,2,2,2}; out[3]={2,2,2,4}; out[4]={2,4,0,4}; return 5;
            case 'T': out[0]={0,0,2,0}; out[1]={1,0,1,4}; return 2;
            case 'U': out[0]={0,0,0,4}; out[1]={0,4,2,4}; out[2]={2,4,2,0}; return 3;
            case 'W': out[0]={0,0,0,4}; out[1]={0,4,1,2}; out[2]={1,2,2,4}; out[3]={2,4,2,0}; return 4;
            case 'X': out[0]={0,0,2,4}; out[1]={2,0,0,4}; return 2;
            case 'Y': out[0]={0,0,1,2}; out[1]={2,0,1,2}; out[2]={1,2,1,4}; return 3;
            case '6': out[0]={1,0,0,1}; out[1]={0,1,0,4}; out[2]={0,4,2,4}; out[3]={2,4,2,2}; out[4]={2,2,0,2}; return 5;
            case '-': out[0]={0,2,2,2}; return 1;
            default: return 0; // space and anything undefined - blank, cursor still advances
            }
        }
    }

    // Draws one glyph at (x,y) top-left, scaled - grid is 3x5 units.
    inline void DrawChar(SDK::UCanvas* canvas, char ch, float x, float y, float scale,
                          unsigned char r, unsigned char g, unsigned char b) {
        Font::Seg segs[8];
        int n = Font::Glyph((char)toupper((unsigned char)ch), segs);
        for (int i = 0; i < n; i++) {
            Line(canvas, x + segs[i].x0 * scale, y + segs[i].y0 * scale,
                         x + segs[i].x1 * scale, y + segs[i].y1 * scale, r, g, b);
        }
    }

    // Advances left-to-right; each glyph is 3 units wide + 1 unit gap = 4
    // units per character at the given scale. Returns the total width drawn.
    inline float DrawString(SDK::UCanvas* canvas, float x, float y, const char* text, float scale,
                             unsigned char r, unsigned char g, unsigned char b) {
        float cursor = x;
        for (const char* p = text; *p; p++) {
            DrawChar(canvas, *p, cursor, y, scale, r, g, b);
            cursor += 4.0f * scale;
        }
        return cursor - x;
    }

    // ---------------------------------------------------------------------
    // LAYOUT + WIDGETS
    // ---------------------------------------------------------------------
    struct Layout {
        float x, width;
        float cursorY;
    };

    inline Layout Begin(float x, float y, float width) {
        Layout L; L.x = x; L.width = width; L.cursorY = y;
        return L;
    }

    inline bool HitTest(const Layout& L, float h) {
        return g_Input.mouseX >= L.x && g_Input.mouseX <= L.x + L.width &&
               g_Input.mouseY >= L.cursorY && g_Input.mouseY <= L.cursorY + h;
    }

    const float kFontScale = 3.0f; // ~12px tall characters

    inline void Header(SDK::UCanvas* canvas, Layout& L, const char* title) {
        DrawString(canvas, L.x, L.cursorY, title, kFontScale, 255, 210, 110);
        L.cursorY += 22.0f;
    }

    inline void Separator(SDK::UCanvas* canvas, Layout& L) {
        Line(canvas, L.x, L.cursorY, L.x + L.width, L.cursorY, 90, 90, 95);
        L.cursorY += 8.0f;
    }

    inline bool Checkbox(SDK::UCanvas* canvas, Layout& L, const char* label, bool* value) {
        const float h = 20.0f;
        bool hovered = HitTest(L, h);
        bool clicked = hovered && g_Input.clickedEdge;
        if (clicked) *value = !*value;

        unsigned char boxR = hovered ? 220 : 190, boxG = hovered ? 220 : 190, boxB = hovered ? 225 : 190;
        Outline(canvas, L.x, L.cursorY, 16, 16, boxR, boxG, boxB);
        if (hovered) Outline(canvas, L.x - 1, L.cursorY - 1, 18, 18, boxR, boxG, boxB); // thicker ring on hover
        if (*value) {
            Line(canvas, L.x + 3,  L.cursorY + 8,  L.x + 6,  L.cursorY + 12, 90, 230, 120);
            Line(canvas, L.x + 6,  L.cursorY + 12, L.x + 13, L.cursorY + 3,  90, 230, 120);
        }
        DrawString(canvas, L.x + 24, L.cursorY + 2, label, kFontScale, 225, 225, 225);

        L.cursorY += h + 6.0f;
        return clicked;
    }

    inline bool Button(SDK::UCanvas* canvas, Layout& L, const char* label) {
        const float h = 22.0f;
        bool hovered = HitTest(L, h);
        bool clicked = hovered && g_Input.clickedEdge;

        unsigned char r = hovered ? 140 : 150, g = hovered ? 220 : 180, b = hovered ? 160 : 160;
        Outline(canvas, L.x, L.cursorY, L.width, h, r, g, b);
        if (hovered) Outline(canvas, L.x - 1, L.cursorY - 1, L.width + 2, h + 2, r, g, b);
        DrawString(canvas, L.x + 8, L.cursorY + 5, label, kFontScale, 235, 235, 235);

        L.cursorY += h + 6.0f;
        return clicked;
    }

    // ---------------------------------------------------------------------
    // THE ACTUAL PANEL - real backend globals, not stubs. Same effect as
    // flipping the same checkbox in the real ImGui menu.
    // ---------------------------------------------------------------------
    inline void DrawPanel(SDK::UCanvas* canvas) {
        if (!canvas) return;
        const float panelX = 60.0f, panelY = 60.0f, panelW = 220.0f, panelH = 210.0f;

        FillRectLines(canvas, panelX - 10, panelY - 10, panelW + 20, panelH, 18, 18, 20);
        Outline(canvas, panelX - 10, panelY - 10, panelW + 20, panelH, 120, 120, 130);

        Layout L = Begin(panelX, panelY, panelW);
        Header(canvas, L, "PHAROAH-SAFE MODE");
        Separator(canvas, L);

        Checkbox(canvas, L, "SPREAD", &Speeden::noSpreadEnabled);
        Checkbox(canvas, L, "RECOIL", &Speeden::noRecoilEnabled);
        Checkbox(canvas, L, "WALLS", &VisibilityBoxes::enabled);
        // NOT a raw bool flip like the others - grayscale needs ApplyGrayscale()
        // to set g_GrayscalePendingImmediate, or turning it OFF leaves the
        // desaturation effect stuck on. The real ImGui checkbox already goes
        // through this same wrapper, not the raw bool.
        {
            bool g = RecoverySuite::grayscaleOn;
            if (Checkbox(canvas, L, "GRAY", &g)) {
                RecoverySuite::ApplyGrayscale(g);
            }
        }
        Checkbox(canvas, L, "RESPAWN", &RecoverySuite::autoInstantRespawn);

        Separator(canvas, L);
        if (Button(canvas, L, "RESPAWN NOW")) {
            RecoverySuite::g_PendingInstantRespawn = true;
        }
    }

    // DISCOVERABILITY. Draws regardless of g_MenuOpen, any time the
    // fallback path is active at all, so "how do I open this" is answered
    // on screen instead of remembered from a chat log.
    inline void DrawHint(SDK::UCanvas* canvas) {
        if (!canvas) return;
        bool simulated = g_SimulateFallbackMode;
        float h = simulated ? 40.0f : 22.0f;
        FillRectLines(canvas, 16, 16, 300, h, 18, 18, 20);
        Outline(canvas, 16, 16, 300, h, 120, 120, 130);
        DrawString(canvas, 24, 20, "INSERT-MENU", kFontScale, 255, 210, 110);
        if (simulated) {
            DrawString(canvas, 24, 34, "F6 EXIT TEST", kFontScale * 0.85f, 180, 220, 255);
        }
    }

    // VISIBLE CURSOR - the game hides the real OS cursor during play.
    // Crosshair + small box, magenta (nothing else in this UI uses it).
    inline bool g_LoggedCursorFirstDraw = false;
    inline void DrawCursor(SDK::UCanvas* canvas) {
        if (!canvas) return;
        float x = g_Input.mouseX, y = g_Input.mouseY;
        if (!g_LoggedCursorFirstDraw) {
            g_LoggedCursorFirstDraw = true;
            InitLog("[CanvasMenu] cursor first drawn at client-space (%.0f, %.0f), resolved window=%p, "
                    "canvas size=%dx%d.",
                    x, y, kiero::findRealGameWindow(), canvas->SizeX, canvas->SizeY);
        }
        Line(canvas, x - 20, y, x + 20, y, 255, 0, 255);
        Line(canvas, x, y - 20, x, y + 20, 255, 0, 255);
        Outline(canvas, x - 4, y - 4, 8, 8, 255, 0, 255);
    }

    // Call once per PostRender tick, right alongside RenderBoxesViaCanvas.
    // GATED behind g_D3D11RenderHookConfirmedWorking (unless F6/simulate
    // mode forces it) - see VisibilityBoxes::RenderBoxesViaCanvas's comment
    // for why: a working machine must never see this on top of the real menu.
    inline bool g_LoggedCanvasMenuException = false;

    inline void Tick(SDK::UCanvas* canvas) {
        if (g_D3D11RenderHookConfirmedWorking && !g_SimulateFallbackMode) return;
        PollToggleKey();

        // __try/__except kept as a defensive backstop even though the
        // ROOT CAUSE fix here is removing DrawTile/DrawText entirely, not
        // this wrapper - see the big comment at the top of this file. A
        // crash whose actual corruption happens inside this scope but whose
        // detected fault surfaces elsewhere won't be caught by this either;
        // nothing below should be able to produce that now, since every
        // call in this file is Draw2DLine, the one primitive with real
        // proof behind it.
        __try {
            DrawHint(canvas);
            if (!g_MenuOpen) return;
            PollInput();
            DrawPanel(canvas);
            DrawCursor(canvas);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            if (!g_LoggedCanvasMenuException) {
                g_LoggedCanvasMenuException = true;
                InitLog("[CanvasMenu] EXCEPTION caught inside Tick() (code 0x%08lX).",
                        GetExceptionCode());
            }
        }
    }
}
