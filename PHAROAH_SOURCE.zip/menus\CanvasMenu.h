#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
//
// Hand-rolled, minimal interactive menu drawn entirely through UE3's native
// Canvas (UCanvas::DrawTile/Draw2DLine/DrawText/Project), the SAME mechanism
// RenderBoxesViaCanvas (VisibilityBoxes.h) already proved reliable on machines
// where the D3D11 Present hook never fires (see initlogs.md - kiero::bind()
// itself reports Success and the dummy device even resolves the real game
// window, but hkPresent still never gets called; this is a real, load-bearing
// fact about at least one confirmed NVIDIA-driver-heavy machine, not a theory).
//
// WHY NOT PORT IMGUI ITSELF: ImGui's renderer needs its font atlas uploaded as
// a real texture every frame. The SDK exposes no safe/reflected pixel-upload
// path for UTexture2D - only raw native Mips/FByteBulkData structs that would
// need risky, unverified reverse engineering to write into correctly. Rather
// than gamble the one mechanism that's actually proven to work, this is a
// second, smaller, real widget set built only from Canvas primitives already
// confirmed firing on the machine that needed this in the first place.
//
// INPUT: this cannot rely on the D3D11 hook for anything, including input -
// that's the whole point. Mouse position/clicks are polled directly against
// the real game window (kiero::findRealGameWindow(), the same window-finding
// logic already proven to locate the right HWND on Spider's machine) via
// GetCursorPos/ScreenToClient/GetAsyncKeyState. No hook of any kind is needed
// for this - it works identically whether or not the Present hook ever fires.
//
// SCOPE (first pass): this is not a pixel-for-pixel port of the ImGui menu.
// It's a new, smaller, genuinely functional panel exposing the highest-value
// toggles (no-spread, no-recoil, walls, grayscale, auto-respawn) through the
// SAME backend globals the ImGui menu already reads/writes, so turning
// something on here has exactly the same effect as the real menu - nothing
// is a stub. More controls can be added to this file the same way as the
// need comes up; the widget kit itself (Button/Checkbox/Slider/Text/Layout)
// is general-purpose, not tied to these five specific toggles.

#include "globals.h"
#include "ext/kiero/kiero.h"
#include <Windows.h>
#include <cstdio>

namespace CanvasMenu {

    // ---------------------------------------------------------------------
    // INPUT — polled directly against the real game window. Independent of
    // any hook; safe to call every PostRender tick regardless of whether the
    // D3D11 hook is alive.
    // ---------------------------------------------------------------------
    struct InputState {
        float mouseX = 0.0f, mouseY = 0.0f;
        bool mouseDown = false;
        bool clickedEdge = false;   // true only on the poll where the button first went down
    };
    inline InputState g_Input;

    inline void PollInput() {
        static bool wasDown = false;
        HWND wnd = (HWND)kiero::findRealGameWindow();
        if (!wnd) {
            g_Input = InputState();
            wasDown = false;
            return;
        }
        POINT p{};
        GetCursorPos(&p);
        ScreenToClient(wnd, &p);
        g_Input.mouseX = (float)p.x;
        g_Input.mouseY = (float)p.y;
        bool down = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        g_Input.mouseDown = down;
        g_Input.clickedEdge = down && !wasDown;
        wasDown = down;
    }

    // Toggled with INSERT, same key family the rest of PHAROAH's menu already
    // uses for show/hide - polled the same hook-independent way as the mouse,
    // so this works even when the real menu can't open.
    inline bool g_MenuOpen = false;
    inline void PollToggleKey() {
        static bool wasDown = false;
        bool down = (GetAsyncKeyState(VK_INSERT) & 0x8000) != 0;
        if (down && !wasDown) g_MenuOpen = !g_MenuOpen;
        wasDown = down;
    }

    // ---------------------------------------------------------------------
    // DRAWING PRIMITIVES
    // ---------------------------------------------------------------------
    inline SDK::UTexture2D* WhiteTex() {
        if (!Globals::LocalPawn) return nullptr;
        SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
        if (!p->WorldInfo) return nullptr;
        return p->WorldInfo->WhiteSquareTexture;
    }

    inline void FillRect(SDK::UCanvas* canvas, float x, float y, float w, float h,
                          unsigned char r, unsigned char g, unsigned char b, unsigned char a = 220) {
        SDK::UTexture2D* tex = WhiteTex();
        if (!tex || !canvas) return;
        SDK::FLinearColor lc;
        lc.R = r / 255.0f; lc.G = g / 255.0f; lc.B = b / 255.0f; lc.A = a / 255.0f;
        canvas->SetPos(x, y, 0.0f);
        canvas->DrawTile(tex, w, h, 0.0f, 0.0f, 1.0f, 1.0f, lc, false,
                          SDK::EBlendMode::BLEND_Translucent, SDK::EDisplayPlane::DISPLAYPLANE_HUD);
    }

    inline void Outline(SDK::UCanvas* canvas, float x, float y, float w, float h,
                         unsigned char r, unsigned char g, unsigned char b) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = 255;
        canvas->Draw2DLine(x,     y,     x + w, y,     c);
        canvas->Draw2DLine(x + w, y,     x + w, y + h, c);
        canvas->Draw2DLine(x + w, y + h, x,     y + h, c);
        canvas->Draw2DLine(x,     y + h, x,     y,     c);
    }

    inline void Text(SDK::UCanvas* canvas, float x, float y, const wchar_t* text,
                      unsigned char r, unsigned char g, unsigned char b) {
        if (!canvas) return;
        SDK::FColor c; c.R = r; c.G = g; c.B = b; c.A = 255;
        canvas->SetPos(x, y, 0.0f);
        canvas->SetDrawColorStruct(c);
        SDK::FString s(text);
        canvas->DrawText(s, false, 1.0f, 1.0f, SDK::EDisplayPlane::DISPLAYPLANE_HUD, nullptr);
    }

    // ---------------------------------------------------------------------
    // LAYOUT + WIDGETS — one auto-advancing vertical column, hit-tested
    // against g_Input (populated once per frame by PollInput() before any
    // widget calls below).
    // ---------------------------------------------------------------------
    struct Layout {
        float x, width;
        float cursorY;
    };

    inline Layout Begin(float x, float y, float width) {
        Layout L; L.x = x; L.width = width; L.cursorY = y;
        return L;
    }

    inline bool HitTest(const Layout& L, float h) {
        return g_Input.mouseX >= L.x && g_Input.mouseX <= L.x + L.width &&
               g_Input.mouseY >= L.cursorY && g_Input.mouseY <= L.cursorY + h;
    }

    inline void Header(SDK::UCanvas* canvas, Layout& L, const wchar_t* title) {
        Text(canvas, L.x, L.cursorY, title, 255, 210, 110);
        L.cursorY += 20.0f;
    }

    inline void Separator(SDK::UCanvas* canvas, Layout& L) {
        SDK::FColor c; c.R = 90; c.G = 90; c.B = 95; c.A = 255;
        canvas->Draw2DLine(L.x, L.cursorY, L.x + L.width, L.cursorY, c);
        L.cursorY += 8.0f;
    }

    inline bool Checkbox(SDK::UCanvas* canvas, Layout& L, const wchar_t* label, bool* value) {
        const float h = 20.0f;
        bool hovered = HitTest(L, h);
        bool clicked = hovered && g_Input.clickedEdge;
        if (clicked) *value = !*value;

        if (hovered) FillRect(canvas, L.x, L.cursorY, 16, 16, 90, 90, 95);
        else         FillRect(canvas, L.x, L.cursorY, 16, 16, 55, 55, 60);
        Outline(canvas, L.x, L.cursorY, 16, 16, 190, 190, 190);
        if (*value) {
            SDK::FColor check; check.R = 90; check.G = 230; check.B = 120; check.A = 255;
            canvas->Draw2DLine(L.x + 3,  L.cursorY + 8,  L.x + 6,  L.cursorY + 12, check);
            canvas->Draw2DLine(L.x + 6,  L.cursorY + 12, L.x + 13, L.cursorY + 3,  check);
        }
        Text(canvas, L.x + 24, L.cursorY, label, 225, 225, 225);

        L.cursorY += h + 4.0f;
        return clicked;
    }

    inline bool Button(SDK::UCanvas* canvas, Layout& L, const wchar_t* label) {
        const float h = 24.0f;
        bool hovered = HitTest(L, h);
        bool clicked = hovered && g_Input.clickedEdge;

        if (hovered) FillRect(canvas, L.x, L.cursorY, L.width, h, 80, 130, 95);
        else         FillRect(canvas, L.x, L.cursorY, L.width, h, 55, 70, 60);
        Outline(canvas, L.x, L.cursorY, L.width, h, 150, 180, 160);
        Text(canvas, L.x + 8, L.cursorY + 4, label, 235, 235, 235);

        L.cursorY += h + 4.0f;
        return clicked;
    }

    inline void Label(SDK::UCanvas* canvas, Layout& L, const wchar_t* text) {
        Text(canvas, L.x, L.cursorY, text, 200, 200, 205);
        L.cursorY += 18.0f;
    }

    // ---------------------------------------------------------------------
    // THE ACTUAL PANEL — real backend globals, not stubs. Same effect as
    // flipping the same checkbox in the real ImGui menu.
    // ---------------------------------------------------------------------
    inline void DrawPanel(SDK::UCanvas* canvas) {
        if (!canvas) return;
        const float panelX = 60.0f, panelY = 60.0f, panelW = 260.0f;

        float bgH = 300.0f;
        FillRect(canvas, panelX - 10, panelY - 10, panelW + 20, bgH, 20, 20, 22, 235);
        Outline(canvas, panelX - 10, panelY - 10, panelW + 20, bgH, 120, 120, 130);

        Layout L = Begin(panelX, panelY, panelW);
        Header(canvas, L, L"PHAROAH  (fallback menu — INSERT to hide)");
        Separator(canvas, L);

        Checkbox(canvas, L, L"No spread", &Speeden::noSpreadEnabled);
        Checkbox(canvas, L, L"No recoil", &Speeden::noRecoilEnabled);
        Checkbox(canvas, L, L"Walls / boxes", &VisibilityBoxes::enabled);
        // NOT a raw bool flip like the others - grayscale needs ApplyGrayscale()
        // to set g_GrayscalePendingImmediate, or turning it OFF leaves the
        // desaturation effect stuck on (ForceGrayscaleIfEnabled bails out early
        // whenever grayscaleOn is false and no pending flag is set - see the
        // "stuck muted brownish state" note in RecoverySuite.h). The real ImGui
        // checkbox already goes through this same wrapper, not the raw bool.
        {
            bool g = RecoverySuite::grayscaleOn;
            if (Checkbox(canvas, L, L"Grayscale", &g)) {
                RecoverySuite::ApplyGrayscale(g);
            }
        }
        Checkbox(canvas, L, L"Auto-respawn", &RecoverySuite::autoInstantRespawn);

        Separator(canvas, L);
        if (Button(canvas, L, L"Respawn now")) {
            RecoverySuite::g_PendingInstantRespawn = true;
        }

        Separator(canvas, L);
        Label(canvas, L, L"This is the fallback renderer - your D3D11");
        Label(canvas, L, L"hook did not fire on this machine, so the");
        Label(canvas, L, L"full menu can't draw. Everything above hits");
        Label(canvas, L, L"the same settings as the real menu.");
    }

    // Call once per PostRender tick, right alongside RenderBoxesViaCanvas.
    //
    // GATED behind the SAME g_D3D11RenderHookConfirmedWorking flag used there,
    // and for the same reason: this reuses INSERT, the real menu's own
    // show/hide key (main.cpp), so that on a broken machine the ordinary
    // "open the menu" habit just works without anyone needing to learn a
    // special fallback key. But g_bShowMenu's OWN toggle logic lives inside
    // hkPresent (main.cpp) - which is exactly the code path that never runs
    // on a broken machine - so it can't be reused directly; this keeps a
    // fully independent poll of the same physical key instead. On a WORKING
    // machine that means both toggles would fire off the same keypress if
    // this weren't gated, popping this panel open on top of the real ImGui
    // menu - the exact "alien boxes" duplicate-UI complaint that shaped the
    // boxes gate. Skip entirely once the real hook is confirmed alive.
    inline void Tick(SDK::UCanvas* canvas) {
        // g_SimulateFallbackMode (F6) forces this active even on a working
        // machine - see the big comment on it in main.cpp and the matching
        // gate in VisibilityBoxes::RenderBoxesViaCanvas.
        if (g_D3D11RenderHookConfirmedWorking && !g_SimulateFallbackMode) return;
        PollToggleKey();
        if (!g_MenuOpen) return;
        PollInput();
        DrawPanel(canvas);
    }
}
