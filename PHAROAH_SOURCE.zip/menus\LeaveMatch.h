#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include "menus/Gating.h"
#include "menus/Language.h"
using Language::Tm;
#include <Windows.h>

// ============================================================================
// LEAVE  —  leave the current match and get back to the menu to re-queue
// ============================================================================
// Route: APlayerController::ConsoleCommand("disconnect").
//
// "disconnect" is the stock Unreal Engine 3 command for dropping the client's
// connection to a server and returning to the entry level. It is not a Paladins
// invention and it is not a Tempest one — it is engine-level, which is why it is
// the most likely of the options here to just work.
//
// WHAT THIS DOES NOT DO
//   It does not cancel a desertion penalty, hide the leave from the server, or
//   make you un-leave. The server sees a client that disconnected, exactly as
//   if the game had crashed or the network dropped. If Tempest applies a leaver
//   penalty, you will get it. This is a convenience button, not an exploit.
//
// Bot matches vs real matches: both are the same client-side action. A bot
// match may simply end; a real one continues without you.
//
// The command box below exists because "disconnect" is the best guess, not a
// certainty. If it does something unhelpful on Tempest, the alternates are one
// click away and whatever works can be promoted to the main button.
// ============================================================================

namespace LeaveMatch {

    inline bool  g_Armed = false;         // two-step confirm
    inline char  g_Status[192] = "Ready.";
    inline char  g_Custom[128] = "disconnect";

    // Alternates, in rough order of how likely they are to be the right thing.
    struct Preset { const wchar_t* cmd; const char* label; const char* note; };
    static const Preset kPresets[] = {
        { L"disconnect",     "disconnect",     "Engine-standard. Drops the server connection, returns to the entry level." },
        { L"open Front_End", "open Front_End", "Force-travel to the front-end map. Map name is a guess." },
        { L"cancel",         "cancel",         "Cancels a pending connection/travel. Useful while still loading in." },
    };

    inline void Fire(const wchar_t* cmd, const char* label) {
        if (SafeCalls::RunConsoleCommand(cmd))
            wsprintfA(g_Status, "Sent '%s'. If nothing happened, that command is not handled.", label);
        else
            wsprintfA(g_Status, "'%s' faulted or there was no controller.", label);
        g_Armed = false;
    }

    inline void DrawControls(bool inMatch) {
        // Leaving a match is deliberately NOT gated - see g_GateGroup in
        // Gating.h. The banner stays so the state is still visible.
        Gating::DrawBlockedBannerFor(Gating::Gated::Leave);

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted(Tm("LEAVE MATCH", "SALIR PARTIDA"));
        ImGui::PopStyleColor();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::TextUnformatted(Tm("State:", "Estado:"));
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Text, Gating::StateColor());
        ImGui::TextUnformatted(Gating::StateName());
        ImGui::PopStyleColor();

        if (!inMatch) {
            ImGui::TextDisabled(Tm("Not in a match — nothing to leave.", "No estás en partida — nada que salir."));
        }

        ImGui::Spacing();
        ImGui::TextWrapped(Tm("Disconnects you from the current match and returns you to the menu so "
            "you can queue again.", "Te desconecta de la partida actual y te devuelve al menú para poder "
            "volver a entrar en cola."));
        ImGui::Spacing();

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.72f, 0.3f, 1.0f)));
        ImGui::TextWrapped(Tm("The server sees a normal disconnect. If Tempest gives leaver penalties, "
            "you will get one. This does not hide anything.", "El servidor ve una desconexión normal. Si Tempest aplica "
            "penalizaciones por abandono, recibirás una. Esto no esconde nada."));
        ImGui::PopStyleColor();

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        // Two-step, because a misclick mid-match is expensive.
        if (!g_Armed) {
            if (ImGui::Button(Tm(">>> LEAVE MATCH <<<", ">>> SALIR DE PARTIDA <<<"), ImVec2(260, 40))) g_Armed = true;
            ImGui::SameLine();
            ImGui::TextDisabled(Tm("(asks once more before it fires)", "(pregunta una vez más antes de ejecutar)"));
        } else {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.62f, 0.16f, 0.14f, 1.0f));
            if (ImGui::Button(Tm("CONFIRM - LEAVE NOW", "CONFIRMAR - SALIR AHORA"), ImVec2(260, 40)))
                Fire(L"disconnect", "disconnect");
            ImGui::PopStyleColor();
            ImGui::SameLine();
            if (ImGui::Button(Tm("Cancel", "Cancelar"), ImVec2(110, 40))) {
                g_Armed = false;
                lstrcpynA(g_Status, Tm("Cancelled.", "Cancelado."), 190);
            }
        }

        ImGui::Spacing();
        ImGui::TextWrapped("%s", g_Status);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        if (ImGui::CollapsingHeader(Tm("If the main button does nothing - alternates", "Si el botón principal no hace nada - alternativas"))) {
            ImGui::TextWrapped(Tm("'disconnect' is the best guess, not a guarantee. Try these and tell "
                "me which one works; whichever it is becomes the main button.", "'disconnect' es la mejor estimación, no una garantía. Prueba estas y dime cuál "
                "funciona; la que funcione se convierte en el botón principal."));
            ImGui::Spacing();
            for (int i = 0; i < (int)(sizeof(kPresets) / sizeof(kPresets[0])); ++i) {
                char id[64];
                wsprintfA(id, "%s##lv%d", kPresets[i].label, i);
                if (ImGui::Button(id, ImVec2(190, 26))) Fire(kPresets[i].cmd, kPresets[i].label);
                ImGui::SameLine();
                ImGui::TextDisabled("%s", kPresets[i].note);
            }

            ImGui::Spacing();
            ImGui::TextUnformatted(Tm("Custom console command:", "Comando de consola personalizado:"));
            ImGui::SetNextItemWidth(300);
            bool go = ImGui::InputText("##lvcustom", g_Custom, sizeof(g_Custom),
                                       ImGuiInputTextFlags_EnterReturnsTrue);
            ImGui::SameLine();
            if (ImGui::Button(Tm("Run##lvrun", "Ejecutar##lvrun"), ImVec2(90, 0)) || go) {
                wchar_t w[128] = { 0 };
                MultiByteToWideChar(CP_ACP, 0, g_Custom, -1, w, 127);
                Fire(w, g_Custom);
            }
            ImGui::TextDisabled(Tm("Goes straight to APlayerController::ConsoleCommand. Most commands "
                "are stripped from shipping builds and will silently do nothing.", "Va directo a APlayerController::ConsoleCommand. "
                "La mayoría de comandos están eliminados en versiones de lanzamiento y harán nada silenciosamente."));
        }
    }
}
