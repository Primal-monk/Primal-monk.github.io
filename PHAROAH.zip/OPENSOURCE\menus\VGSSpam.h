#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include <Windows.h>

// ============================================================================
// VGS / LAUGH SPAM — parity with Anubis's "Laugh/VGS Spam"
//
// Anubis lists: "Laugh/VGS Spam - Automated chat spam with anti-flood protection."
// The "anti-flood protection" half is not a nicety, it is the whole feature. The
// game has a server-side flood counter specifically for this:
//
//   ATgPlayerController::s_VGSFlood   (struct FFLOOD { int m_nCount; float m_fLastUpdate; })
//   ATgPlayerController::m_fLastVGS   (float)
//   ATgPlayerController::m_bBlockVGS  (bitfield)
//
// So naive spam does not just get ignored, it trips a counter. And ServerPlayVGS
// is a RELIABLE RPC — we already learned the hard way in this project that
// bursting reliable RPCs overflows the channel and closes the connection (that is
// the "booted back to menu" failure). Both facts point the same way: this has to
// be a throttled queue, never a per-frame call.
//
// WHY THIS WORKS AT ALL (fits the predictive model):
// Playing a VGS is the client declaring an EVENT about itself. It is not claiming
// a stat or a capability. Same category as the Octavia buff spam that works.
//
// THE ID PROBLEM, AND HOW IT IS SOLVED HERE:
// There is no VGS id table in the reference data (Paladins_Ids has emote ids, not
// VGS ids). Rather than guess, this learns them: ATgPawn::c_nCurrentVGSPlaying
// (0x2DE4) holds the id of the VGS playing right now. Press VGS keys in game with
// "Learn IDs" on and each distinct id is captured into a list you can then spam.
// That is more reliable than a hardcoded table anyway, since it reads the ids
// this build actually uses.
// ============================================================================

namespace VGSSpam {

    inline bool enabled = false;
    inline int  vgsId = 0;
    inline int  intervalMs = 1400;      // floored below; see kMinIntervalMs
    inline int  vpSetting = 0;
    inline bool learnIds = true;
    inline bool cycleLearned = false;   // rotate through everything learned

    // The flood counter is the reason for this floor. Going faster does not make
    // the spam land faster, it makes it get blocked and risks the channel.
    inline const int kMinIntervalMs = 700;

    inline ULONGLONG g_LastSendMs = 0;
    inline int  g_SentCount = 0;
    inline bool g_PendingSend = false;
    inline int  g_PendingId = 0;

    inline const int kMaxLearned = 32;
    inline int  g_Learned[kMaxLearned] = {};
    inline int  g_LearnedCount = 0;
    inline int  g_CycleIndex = 0;
    inline int  g_LastSeenPlaying = -1;

    inline bool TryReadCurrentVGS(SDK::ATgPawn* p, int* out) {
        __try { *out = p->c_nCurrentVGSPlaying; return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TrySendVGS(SDK::ATgPlayerController* pc, int id, int vp) {
        __try { pc->ServerPlayVGS(id, vp); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline void Remember(int id) {
        if (id <= 0) return;
        for (int i = 0; i < g_LearnedCount; ++i) if (g_Learned[i] == id) return;
        if (g_LearnedCount >= kMaxLearned) return;
        g_Learned[g_LearnedCount++] = id;
    }

    // Field reads only — safe from the render thread.
    inline void Update() {
        SDK::APawn* pawn = Globals::LocalPawn;
        if (pawn && learnIds) {
            int playing = -1;
            if (TryReadCurrentVGS((SDK::ATgPawn*)pawn, &playing)) {
                if (playing > 0 && playing != g_LastSeenPlaying) Remember(playing);
                g_LastSeenPlaying = playing;
            }
        }

        if (!enabled) return;

        int interval = intervalMs < kMinIntervalMs ? kMinIntervalMs : intervalMs;
        ULONGLONG now = GetTickCount64();
        if (now - g_LastSendMs < (ULONGLONG)interval) return;

        int id = vgsId;
        if (cycleLearned && g_LearnedCount > 0) {
            id = g_Learned[g_CycleIndex % g_LearnedCount];
            g_CycleIndex++;
        }
        if (id <= 0) return;

        // Flag only. The actual RPC goes out on the ProcessEvent thread — firing
        // scripted calls from hkPresent is what corrupted pawn state before.
        g_PendingId = id;
        g_PendingSend = true;
        g_LastSendMs = now;
    }

    // ProcessEvent thread.
    inline void ProcessPending() {
        if (!g_PendingSend) return;
        g_PendingSend = false;
        SDK::ATgPlayerController* pc = (SDK::ATgPlayerController*)Globals::LocalController;
        if (!pc || g_PendingId <= 0) return;
        if (TrySendVGS(pc, g_PendingId, vpSetting)) g_SentCount++;
    }

    inline void DrawControls(bool inMatch) {
        ImGui::TextColored(Ink(ImVec4(0.9f, 0.8f, 0.5f, 1.0f)), "VGS / LAUGH SPAM");
        ImGui::TextWrapped("Playing a VGS is the client declaring an EVENT about itself, which is "
            "the category that works - same as the Octavia buff spam.");

        if (!inMatch) { ImGui::TextDisabled("Join a match first."); return; }

        ImGui::Checkbox("Enable spam", &enabled);
        ImGui::PushItemWidth(140);
        ImGui::InputInt("VGS ID", &vgsId);
        ImGui::PopItemWidth();
        ImGui::SliderInt("Interval (ms)", &intervalMs, kMinIntervalMs, 5000);
        if (intervalMs <= kMinIntervalMs) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)),
                "At the floor. Faster is not better here - see below.");
        }

        ImGui::Separator();
        ImGui::Checkbox("Learn IDs (press VGS keys in game)", &learnIds);
        ImGui::Text("Learned %d ID%s:", g_LearnedCount, g_LearnedCount == 1 ? "" : "s");
        for (int i = 0; i < g_LearnedCount; ++i) {
            ImGui::SameLine();
            char btn[32];
            wsprintfA(btn, "%d", g_Learned[i]);
            if (ImGui::SmallButton(btn)) vgsId = g_Learned[i];
        }
        if (g_LearnedCount == 0) {
            ImGui::TextDisabled("None yet - use your VGS keys in a match and they appear here.");
        } else {
            ImGui::TextDisabled("Click a learned ID to load it above.");
        }
        ImGui::Checkbox("Cycle through all learned IDs", &cycleLearned);

        ImGui::Separator();
        ImGui::Text("Sent: %d", g_SentCount);
        if (ImGui::TreeNode("Why the interval has a floor")) {
            ImGui::TextWrapped(
                "The game keeps a server-side flood counter just for this "
                "(s_VGSFlood, m_fLastVGS, m_bBlockVGS), so spamming past the limit "
                "gets blocked rather than played. On top of that, ServerPlayVGS is a "
                "RELIABLE RPC, and bursting reliable RPCs overflows the channel and "
                "closes the connection - that is the 'booted back to the menu' "
                "failure seen elsewhere in this project. The floor is what Anubis "
                "means by 'anti-flood protection'.");
            ImGui::TreePop();
        }
    }
}
