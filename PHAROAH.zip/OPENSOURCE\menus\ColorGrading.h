#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include <Windows.h>
#include <string>
#include <vector>

// Real full color grading — not just desaturation. Uses UTgCombinedPostProcessEffect's
// own fields (SceneShadows/MidTones/HighLights/Colorize/Desaturation) directly.
//
// BUG FOUND (why "Test This Name" said FOUND for literally anything you typed):
// this SDK's FName(const char*) constructor silently falls back to Index=0
// (which is "None" in the game's own name table) when the typed string isn't
// actually in that table — it never signals failure. So GetPostProcessEffect
// was being called with FName("None") every time a name didn't match, and
// apparently that returns SOME default object instead of null. Fixed by
// checking the FName's OWN resolved name string against what was typed —
// if they don't match, it silently fell back to None, so treat it as not found
// and never even call GetPostProcessEffect with garbage.

namespace ColorGrading {

    inline char g_EffectNameBuf[64] = "SceneEffect";

    // True only if `name` is actually a real entry in the game's name table —
    // catches the FName-silently-becomes-None fallback described above.
    inline bool IsRealName(const char* name) {
        SDK::FName f(name);
        // "None" typed on purpose is the one legitimate case where Index==0.
        if (_stricmp(name, "None") == 0) return true;
        if (f.Index == 0) return false;
        return _stricmp(f.GetName().c_str(), name) == 0;
    }

    // Isolated, SEH-safe: no C++ objects with destructors in here.
    inline SDK::UTgCombinedPostProcessEffect* TryGetEffect(const char* name) {
        if (!IsRealName(name)) return nullptr; // don't even call the game with a name that doesn't exist
        __try {
            if (!Globals::LocalPlayer) return nullptr;
            SDK::UTgLocalPlayer* lp = (SDK::UTgLocalPlayer*)Globals::LocalPlayer;
            SDK::UPostProcessEffect* fx = lp->GetPostProcessEffect(SDK::FName(name));
            if (!fx) return nullptr;
            return (SDK::UTgCombinedPostProcessEffect*)fx;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return nullptr;
        }
    }

    inline bool TryApplyToEffect(SDK::UTgCombinedPostProcessEffect* fx, SDK::FVector shadows,
        SDK::FVector midtones, SDK::FVector highlights, SDK::FVector colorize, float desaturation) {
        __try {
            fx->SceneShadows = shadows;
            fx->SceneMidTones = midtones;
            fx->SceneHighLights = highlights;
            fx->SceneColorize = colorize;
            fx->SceneDesaturation = desaturation;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    struct Preset {
        const char* name;
        SDK::FVector shadows, midtones, highlights, colorize;
        float desaturation;
    };

    static const Preset g_Presets[] = {
        { "Reset (Neutral)",     {1,1,1}, {1,1,1}, {1,1,1}, {0,0,0},        0.0f },
        { "Cold Blue",           {1.0f,1.0f,1.15f}, {0.95f,1.0f,1.1f}, {0.9f,1.0f,1.2f}, {-0.05f,0.0f,0.1f}, 0.1f },
        { "Warm Sepia",          {1.15f,1.05f,0.85f}, {1.1f,1.0f,0.8f}, {1.15f,1.05f,0.75f}, {0.12f,0.06f,-0.1f}, 0.35f },
        { "High Contrast B&W",   {0.9f,0.9f,0.9f}, {1.0f,1.0f,1.0f}, {1.1f,1.1f,1.1f}, {0,0,0}, 1.0f },
        { "Vintage Film",        {1.05f,0.95f,0.85f}, {1.05f,1.0f,0.9f}, {1.0f,0.95f,0.8f}, {0.08f,0.02f,-0.08f}, 0.25f },
        { "Horror Green",        {0.9f,1.05f,0.9f}, {0.85f,1.0f,0.85f}, {0.8f,1.05f,0.8f}, {-0.05f,0.08f,-0.05f}, 0.5f },
        { "Neon Purple",         {1.1f,0.9f,1.2f}, {1.05f,0.85f,1.15f}, {1.15f,0.8f,1.25f}, {0.1f,-0.05f,0.12f}, 0.15f },
        { "Sunset Orange",       {1.2f,1.0f,0.8f}, {1.25f,0.9f,0.7f}, {1.3f,0.85f,0.6f}, {0.15f,0.05f,-0.12f}, 0.1f },
        { "Arctic White",        {1.05f,1.05f,1.1f}, {1.1f,1.1f,1.15f}, {1.2f,1.2f,1.25f}, {0.02f,0.02f,0.05f}, 0.4f },
    };

    // Every candidate name worth trying, all in one place — add more here any
    // time and "Test ALL Candidates" below picks them up automatically.
    static const char* g_Candidates[] = {
        "SceneEffect", "Combined", "PostProcessChain", "SceneColor",
        "TgCombinedPostProcessEffect", "Default", "None", "PostProcess",
        "ColorGrading", "TgPostProcessEffect", "MainScene", "Scene",
    };

    inline char g_BatchResults[4096] = "Click \"Test ALL Candidates\" to run every name above at once, "
        "then Copy Results to paste back.";

    inline void RunAllCandidates() {
        std::string out;
        for (const char* name : g_Candidates) {
            bool real = IsRealName(name);
            SDK::UTgCombinedPostProcessEffect* fx = real ? TryGetEffect(name) : nullptr;
            out += std::string("[") + (fx ? "FOUND   " : (real ? "no fx   " : "no name ")) + "] " + name + "\n";
        }
        strncpy_s(g_BatchResults, sizeof(g_BatchResults), out.c_str(), _TRUNCATE);
    }

    // ---- BLUR / UNBLUR ----------------------------------------------------
    // The card-exploit DLL leaves the screen blurred. Two routes are offered
    // because they fail differently:
    //
    //   SetBlur()          - the game's own scripted call. Sets a TARGET and
    //                        interpolates toward it. Clean, but anything that
    //                        re-drives the blur every frame just wins the race.
    //   ForceBlurAmount()  - writes UTgLocalPlayer::m_fBlurAmount AND
    //                        m_fTargetBlurAmount directly, so there is nothing
    //                        left to interpolate from. Neither field is (Net).
    //
    // HOLD re-clears every frame, which is what actually beats another DLL that
    // keeps re-applying it.
    inline bool  g_HoldUnblur   = false;
    inline float g_BlurAmount   = 0.0f;
    inline char  g_BlurStatus[160] = "Not touched.";

    // Called every frame from the same place the other per-frame handlers run.
    inline void Update() {
        if (!g_HoldUnblur) return;
        SafeCalls::ForceBlurAmount(0.0f);
    }

    inline void DrawBlurControls() {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("BLUR / UNBLUR");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Clears the screen blur - including the one the card-exploit DLL "
            "leaves behind.");

        float cur = -1.0f, tgt = -1.0f;
        if (SafeCalls::ReadBlurAmount(&cur, &tgt))
            ImGui::Text("live blur: %.3f   target: %.3f", cur, tgt);
        else
            ImGui::TextDisabled("live blur: unreadable (no local player yet)");

        if (ImGui::Button(">>> UNBLUR <<<", ImVec2(170, 30))) {
            bool a1 = SafeCalls::ForceBlurAmount(0.0f);
            bool a2 = SafeCalls::SetBlur(0.0f, 100.0f, 0.0f);
            wsprintfA(g_BlurStatus, "Unblur: raw %s, scripted %s.",
                      a1 ? "ok" : "failed", a2 ? "ok" : "failed");
        }
        ImGui::SameLine();
        if (ImGui::Button("Re-blur (test)", ImVec2(150, 30))) {
            SafeCalls::ForceBlurAmount(1.0f);
            lstrcpynA(g_BlurStatus, "Forced blur to 1.0 - press UNBLUR to clear.", 150);
        }
        ImGui::SameLine();
        ImGui::Checkbox("HOLD unblurred (every frame)", &g_HoldUnblur);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Leave this on if the blur keeps coming back. Another DLL re-applying\n"
            "it every frame will beat a one-shot clear; this re-clears every frame\n"
            "so it cannot.");

        ImGui::SetNextItemWidth(200);
        if (ImGui::SliderFloat("manual amount", &g_BlurAmount, 0.0f, 1.0f, "%.2f"))
            SafeCalls::ForceBlurAmount(g_BlurAmount);

        ImGui::TextDisabled("%s", g_BlurStatus);
        ImGui::Separator();
        ImGui::Spacing();
    }

    inline void DrawControls(bool inMatch) {
        DrawBlurControls();
        ImGui::TextWrapped("Color grading. The name tester used to say FOUND for anything you "
            "typed — that was a real bug (this SDK's FName silently falls back to \"None\" for "
            "unrecognized names instead of failing), now fixed: it checks the name actually "
            "exists in the game's own name table before ever calling into the game with it.");
        if (!inMatch) { ImGui::TextDisabled("Join a match first."); return; }

        ImGui::Text("Effect name to try:");
        ImGui::PushItemWidth(200.0f);
        ImGui::InputText("##EffectName", g_EffectNameBuf, sizeof(g_EffectNameBuf));
        ImGui::PopItemWidth();
        ImGui::SameLine();
        static int testResult = 0; // 0 = not tested, 1 = found, -1 = not found
        if (ImGui::Button("Test This Name")) {
            testResult = TryGetEffect(g_EffectNameBuf) ? 1 : -1;
        }
        if (testResult == 1) {
            ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.6f, 1.0f)), "FOUND something with this name.");
        } else if (testResult == -1) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.6f, 0.4f, 1.0f)), "Nothing found with this name.");
        } else {
            ImGui::TextDisabled("Not tested yet — click Test This Name.");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Or test every known candidate at once:");
        if (ImGui::Button("Test ALL Candidates")) {
            RunAllCandidates();
        }
        ImGui::SameLine();
        if (ImGui::Button("Copy Results")) {
            ImGui::SetClipboardText(g_BatchResults);
        }
        ImGui::InputTextMultiline("##BatchResults", g_BatchResults, sizeof(g_BatchResults),
            ImVec2(0, 100), ImGuiInputTextFlags_ReadOnly);

        ImGui::Spacing();
        ImGui::Separator();
        for (auto& p : g_Presets) {
            if (ImGui::Button(p.name, ImVec2(220, 26))) {
                SDK::UTgCombinedPostProcessEffect* fx = TryGetEffect(g_EffectNameBuf);
                if (fx) {
                    if (!TryApplyToEffect(fx, p.shadows, p.midtones, p.highlights, p.colorize, p.desaturation)) {
                        ImGui::TextColored(Ink(ImVec4(1.0f, 0.3f, 0.3f, 1.0f)), "Applying crashed internally — caught safely.");
                    }
                }
            }
        }
    }
}
