#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include <Windows.h>
#include <string>
#include <cctype>

// ============================================================================
// RECORDER — always-on instrumentation.
//
// Design goal: you should never have to remember to arm anything. Click buttons,
// play normally, then copy one report that answers "did anything actually
// happen." Three independent recorders run continuously:
//
//  1. RPC TIMELINE (always on, cheap). Captures every Server*-prefixed call
//     (client -> server) and Client*-prefixed call (server -> client) with a
//     timestamp. This is the thing we could never see before: if we fire an RPC
//     and a Client* callback lands 40ms later, the server ANSWERED. If nothing
//     lands, it silently dropped us. Button presses inject their own markers so
//     the timeline reads as cause-and-effect.
//
//  2. STATE WATCHER (always on, throttled). Polls a handful of values that
//     matter (card points per equipped card, health, ammo, energy) a few times
//     a second and records only CHANGES. So if a card level ever moves, for any
//     reason, it shows up automatically — no need to click "verify" at the right
//     moment and hope.
//
//  3. FILTERED NAME LOG (opt-in). The original broad capture, for exploring
//     what a given action calls. Still useful, just no longer the main tool.
//
// PERFORMANCE: ProcessEvent fires thousands of times per frame, so recorder #1
// must not do string work per call. It resolves each UFunction*'s name ONCE,
// caches the verdict keyed by pointer, and after warmup every subsequent call is
// a pointer compare — same optimization already used for postRenderFunc.
// ============================================================================

namespace CallLogger {

    // ---------- shared ----------
    inline ULONGLONG g_T0 = 0; // timeline origin
    inline ULONGLONG NowMs() {
        ULONGLONG t = GetTickCount64();
        if (g_T0 == 0) g_T0 = t;
        return t - g_T0;
    }

    inline void TryCopyFuncName(SDK::UFunction* fn, char* buf, size_t bufSize) {
        buf[0] = 0;
        __try {
            if (!fn) return;
            int idx = fn->Name.Index;
            if (idx == 0) return;
            auto& names = SDK::FName::GetGlobalNames();
            if (!names.IsValidIndex((size_t)idx)) return;
            SDK::FNameEntry* entry = names[idx];
            if (!entry) return;
            const char* ansi = entry->GetAnsiName();
            if (ansi) strncpy_s(buf, bufSize, ansi, _TRUNCATE);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            buf[0] = 0;
        }
    }

    // ================= 1. RPC TIMELINE =================
    enum EvKind { EV_Sent = 1, EV_Recv = 2, EV_Marker = 3 };

    struct TimelineEvent {
        ULONGLONG ms;
        int kind;
        char name[80];
    };
    static const int kTimelineMax = 200;
    inline TimelineEvent g_Timeline[kTimelineMax] = {};
    inline int g_TimelineCount = 0;   // total ever recorded
    inline int g_TimelineWrite = 0;   // ring index

    inline void PushEvent(int kind, const char* name) {
        TimelineEvent& e = g_Timeline[g_TimelineWrite];
        e.ms = NowMs();
        e.kind = kind;
        strncpy_s(e.name, sizeof(e.name), name, _TRUNCATE);
        g_TimelineWrite = (g_TimelineWrite + 1) % kTimelineMax;
        g_TimelineCount++;
    }

    // Called by button handlers so the timeline shows what YOU did, inline with
    // what the game did in response.
    inline void Mark(const char* what) { PushEvent(EV_Marker, what); }

    // Pointer-keyed verdict cache: 0 = unresolved, 1 = ignore, 2 = Server*, 3 = Client*
    static const int kCacheSize = 1024;
    inline SDK::UFunction* g_CacheKey[kCacheSize] = {};
    inline unsigned char   g_CacheVal[kCacheSize] = {};
    inline char            g_CacheName[kCacheSize][80] = {};

    inline void OnProcessEvent(SDK::UFunction* fn); // fwd (defined below, uses filter log too)

    // ================= 2. STATE WATCHER =================
    struct WatchedCard { int eqPoint; int deviceId; int points; };
    inline WatchedCard g_Cards[16] = {};
    inline int g_CardCount = 0;

    struct ChangeRec { ULONGLONG ms; char text[110]; };
    static const int kChangeMax = 120;
    inline ChangeRec g_Changes[kChangeMax] = {};
    inline int g_ChangeCount = 0;
    inline int g_ChangeWrite = 0;
    inline ULONGLONG g_LastPollMs = 0;

    inline void PushChange(const char* text) {
        ChangeRec& c = g_Changes[g_ChangeWrite];
        c.ms = NowMs();
        strncpy_s(c.text, sizeof(c.text), text, _TRUNCATE);
        g_ChangeWrite = (g_ChangeWrite + 1) % kChangeMax;
        g_ChangeCount++;
    }

    // Isolated read of one equip point — no C++ objects, SEH-legal.
    inline bool TryReadCard(SDK::ATgPawn* pawn, int eqPoint, int* outId, int* outPoints) {
        __try {
            SDK::ATgDevice* d = pawn->GetDeviceByEqPoint(eqPoint);
            if (!d) return false;
            *outId = d->r_nDeviceId;
            *outPoints = d->r_nPointsAllocated;
            return (*outId > 0);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Polls a few times a second; records only differences.
    inline void PollState() {
        ULONGLONG now = GetTickCount64();
        if (now - g_LastPollMs < 300) return;
        g_LastPollMs = now;

        if (!Globals::LocalPawn) return;
        SDK::ATgPawn* pawn = (SDK::ATgPawn*)Globals::LocalPawn;

        for (int p = 0; p <= 20; p++) {
            int id = 0, pts = 0;
            if (!TryReadCard(pawn, p, &id, &pts)) continue;

            // find existing record for this eq point
            int found = -1;
            for (int i = 0; i < g_CardCount; i++) {
                if (g_Cards[i].eqPoint == p) { found = i; break; }
            }
            if (found < 0) {
                if (g_CardCount < 16) {
                    g_Cards[g_CardCount].eqPoint = p;
                    g_Cards[g_CardCount].deviceId = id;
                    g_Cards[g_CardCount].points = pts;
                    g_CardCount++;
                }
                continue;
            }
            if (g_Cards[found].deviceId != id) {
                char buf[110];
                sprintf_s(buf, sizeof(buf), "eq%d: device %d -> %d (loadout changed)",
                          p, g_Cards[found].deviceId, id);
                PushChange(buf);
                g_Cards[found].deviceId = id;
                g_Cards[found].points = pts;
            } else if (g_Cards[found].points != pts) {
                char buf[110];
                sprintf_s(buf, sizeof(buf), "*** CARD POINTS CHANGED *** eq%d device %d: %d -> %d",
                          p, id, g_Cards[found].points, pts);
                PushChange(buf);
                g_Cards[found].points = pts;
            }
        }
    }

    inline void ResetState() {
        g_CardCount = 0;
        g_ChangeCount = 0;
        g_ChangeWrite = 0;
        for (int i = 0; i < kChangeMax; i++) g_Changes[i].text[0] = 0;
    }

    // ================= 3. FILTERED NAME LOG (opt-in) =================
    inline bool g_FilterLogEnabled = false;
    inline bool g_LogAll = false;
    inline char g_Filter[64] = "Card";
    static const int kMaxEntries = 96;
    inline char g_Names[kMaxEntries][110] = {};
    inline int  g_Counts[kMaxEntries] = {};
    inline int  g_EntryCount = 0;
    inline bool g_Overflowed = false;

    inline void ClearFilterLog() {
        g_EntryCount = 0;
        g_Overflowed = false;
        for (int i = 0; i < kMaxEntries; i++) { g_Names[i][0] = 0; g_Counts[i] = 0; }
    }

    inline void SetFilter(const char* f) {
        strncpy_s(g_Filter, sizeof(g_Filter), f, _TRUNCATE);
        g_LogAll = false;
        ClearFilterLog();
    }

    inline bool ContainsNoCase(const char* hay, const char* needle) {
        for (const char* p = hay; *p; p++) {
            const char* a = p; const char* b = needle;
            while (*a && *b && (tolower((unsigned char)*a) == tolower((unsigned char)*b))) { a++; b++; }
            if (!*b) return true;
        }
        return false;
    }

    // ---------- the hot path ----------
    inline void OnProcessEvent(SDK::UFunction* fn) {
        if (!fn) return;

        // Pointer-keyed cache so we only resolve each function's name once.
        size_t slot = (((size_t)fn) >> 4) % kCacheSize;
        size_t start = slot;
        unsigned char verdict = 0;
        while (true) {
            if (g_CacheKey[slot] == fn) { verdict = g_CacheVal[slot]; break; }
            if (g_CacheKey[slot] == nullptr) {
                // first sighting — resolve now
                char nameBuf[80];
                TryCopyFuncName(fn, nameBuf, sizeof(nameBuf));
                unsigned char v = 1; // ignore by default
                if (nameBuf[0]) {
                    if (_strnicmp(nameBuf, "Server", 6) == 0) v = 2;
                    else if (_strnicmp(nameBuf, "Client", 6) == 0) v = 3;
                }
                g_CacheKey[slot] = fn;
                g_CacheVal[slot] = v;
                strncpy_s(g_CacheName[slot], sizeof(g_CacheName[slot]), nameBuf, _TRUNCATE);
                verdict = v;
                break;
            }
            slot = (slot + 1) % kCacheSize;
            if (slot == start) { verdict = 1; break; } // cache full, give up
        }

        // 1. Always-on timeline for the two directions that matter.
        if (verdict == 2)      PushEvent(EV_Sent, g_CacheName[slot]);
        else if (verdict == 3) PushEvent(EV_Recv, g_CacheName[slot]);

        // 3. Opt-in broad filter log.
        if (g_FilterLogEnabled) {
            const char* nm = g_CacheName[slot];
            if (!nm[0]) return;
            if (!g_LogAll && g_Filter[0] && !ContainsNoCase(nm, g_Filter)) return;
            for (int i = 0; i < g_EntryCount; i++) {
                if (strcmp(g_Names[i], nm) == 0) { g_Counts[i]++; return; }
            }
            if (g_EntryCount >= kMaxEntries) { g_Overflowed = true; return; }
            strncpy_s(g_Names[g_EntryCount], sizeof(g_Names[g_EntryCount]), nm, _TRUNCATE);
            g_Counts[g_EntryCount] = 1;
            g_EntryCount++;
        }
    }

    // ---------- reporting ----------
    inline std::string BuildFullReport() {
        std::string out = "=== RECORDER REPORT ===\n\n";

        out += "--- RPC TIMELINE (newest last) ---\n";
        out += "SENT = we called the server | RECV = SERVER CALLED US BACK | MARK = your button\n";
        out += "A RECV shortly after a SENT means the server actually responded.\n\n";
        int shown = g_TimelineCount < kTimelineMax ? g_TimelineCount : kTimelineMax;
        int startIdx = g_TimelineCount < kTimelineMax ? 0 : g_TimelineWrite;
        if (shown == 0) {
            out += "(nothing recorded yet)\n";
        }
        for (int i = 0; i < shown; i++) {
            const TimelineEvent& e = g_Timeline[(startIdx + i) % kTimelineMax];
            const char* tag = (e.kind == EV_Sent) ? "SENT" : (e.kind == EV_Recv) ? "RECV" : "MARK";
            out += "[" + std::to_string((unsigned long long)e.ms) + "ms] " + tag + "  " + e.name + "\n";
        }

        out += "\n--- STATE CHANGES DETECTED ---\n";
        out += "Polled ~3x/sec. Card point changes are flagged loudly.\n\n";
        int cShown = g_ChangeCount < kChangeMax ? g_ChangeCount : kChangeMax;
        int cStart = g_ChangeCount < kChangeMax ? 0 : g_ChangeWrite;
        if (cShown == 0) {
            out += "(no changes detected — nothing we watch has moved)\n";
        }
        for (int i = 0; i < cShown; i++) {
            const ChangeRec& c = g_Changes[(cStart + i) % kChangeMax];
            if (!c.text[0]) continue;
            out += "[" + std::to_string((unsigned long long)c.ms) + "ms] " + c.text + "\n";
        }

        out += "\n--- CURRENT CARD SNAPSHOT ---\n";
        if (g_CardCount == 0) {
            out += "(no equipped devices seen — not in a match?)\n";
        }
        for (int i = 0; i < g_CardCount; i++) {
            out += "eq" + std::to_string(g_Cards[i].eqPoint) + "  device " + std::to_string(g_Cards[i].deviceId)
                 + "  points=" + std::to_string(g_Cards[i].points) + "\n";
        }

        if (g_EntryCount > 0) {
            out += "\n--- FILTERED NAME LOG (filter: ";
            out += g_LogAll ? "everything" : g_Filter;
            out += ") ---\n";
            for (int i = 0; i < g_EntryCount; i++) {
                out += std::string(g_Names[i]) + "   x" + std::to_string(g_Counts[i]) + "\n";
            }
        }
        return out;
    }

    inline void DrawControls(std::string* outReport) {
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.6f, 1.0f)), "RECORDER — always on, nothing to arm");
        ImGui::TextWrapped("Just play and click things, then hit the big button and paste the result. "
            "Two recorders run continuously without you doing anything:\n\n"
            "RPC TIMELINE — every call we make to the server (SENT) and every call the server makes "
            "back to us (RECV). A RECV following a SENT is proof the server responded. This is the "
            "answer to \"did that button do anything\".\n\n"
            "STATE WATCHER — polls your card points 3x/sec and logs any change automatically, so a "
            "card level moving can never be missed.");
        ImGui::Separator();

        ImGui::Text("Timeline events: %d   |   State changes: %d   |   Cards tracked: %d",
                    g_TimelineCount, g_ChangeCount, g_CardCount);

        if (ImGui::Button("BUILD FULL REPORT -> paste this to Claude", ImVec2(330, 34))) {
            *outReport = BuildFullReport();
        }
        ImGui::SameLine();
        if (ImGui::Button("Reset")) {
            g_TimelineCount = 0; g_TimelineWrite = 0;
            for (int i = 0; i < kTimelineMax; i++) g_Timeline[i].name[0] = 0;
            ResetState();
            g_T0 = 0;
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextDisabled("Optional: broad name capture, for exploring what an action calls.");
        ImGui::Checkbox("Enable filtered log", &g_FilterLogEnabled);
        ImGui::SameLine();
        ImGui::Checkbox("Everything (heavy)", &g_LogAll);
        ImGui::SameLine();
        if (ImGui::Button("Clear##fl")) ClearFilterLog();
        ImGui::PushItemWidth(180);
        ImGui::InputText("Filter", g_Filter, sizeof(g_Filter));
        ImGui::PopItemWidth();
        if (ImGui::Button("Card")) SetFilter("Card");
        ImGui::SameLine();
        if (ImGui::Button("Deck")) SetFilter("Deck");
        ImGui::SameLine();
        if (ImGui::Button("Point")) SetFilter("Point");
        ImGui::SameLine();
        if (ImGui::Button("Talent")) SetFilter("Talent");
        ImGui::SameLine();
        if (ImGui::Button("Passive")) SetFilter("Passive");
    }
}
