#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include <Windows.h>

// Every function here does ONE risky SDK call and nothing else — no local
// C++ objects with destructors, so each is safe to wrap in __try/__except
// (MSVC forbids mixing SEH with C++ object unwinding in the same function).
// Returns true if the call completed, false if it crashed and was caught.
// This is the blanket fix for "any button might crash the game" — every
// button that touches a real SDK function should call through here instead
// of calling the SDK function directly.

namespace SafeCalls {

    inline bool SetOutlines(bool friendly, bool enemy) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->SetOutlines(friendly, enemy);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // ---- BLUR ------------------------------------------------------------
    // ATgPlayerController::SetBlur - same class as SetDesaturation, which is
    // already known to work. Amount 0 = no blur.
    inline bool SetBlur(float amount, float interpSpeed, float kernelSize) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->SetBlur(amount, interpSpeed, kernelSize);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Raw force-clear on UTgLocalPlayer. The scripted call above sets a TARGET
    // and interpolates toward it, so anything re-driving the blur every frame
    // (another injected DLL, for instance) simply wins the race. Zeroing both
    // the target AND the current amount leaves nothing to interpolate from.
    inline bool ForceBlurAmount(float amount) {
        __try {
            SDK::UTgLocalPlayer* lp = (SDK::UTgLocalPlayer*)Globals::LocalPlayer;
            if (!lp) return false;
            lp->m_fTargetBlurAmount = amount;
            lp->m_fBlurAmount       = amount;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool ReadBlurAmount(float* outCur, float* outTarget) {
        __try {
            SDK::UTgLocalPlayer* lp = (SDK::UTgLocalPlayer*)Globals::LocalPlayer;
            if (!lp) return false;
            *outCur    = lp->m_fBlurAmount;
            *outTarget = lp->m_fTargetBlurAmount;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool SetDesaturation(float amount, float seconds) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->SetDesaturation(amount, seconds);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // The REAL function behind the low-health/near-death vision effect —
    // desaturation is only one piece of what this drives (likely also tint/
    // vignette together). SetDesaturation alone leaving a "stuck, muted
    // brownish" state after toggling off is consistent with this composite
    // effect only being partially reset. Call with fHealthPCT=1, bDeathVision
    // =false to force a full reset of whatever it manages.
    inline bool UpdateLowHealthEffect(float deltaSeconds, float healthPct, float healthLostPct, bool deathVision) {
        __try {
            ((SDK::UTgLocalPlayer*)Globals::LocalPlayer)->UpdateLowHealthEffect(deltaSeconds, healthPct, healthLostPct, deathVision);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    inline bool EnableColorBlindEffect(bool enable, int type, float intensity) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->EnableColorBlindEffect(enable, type, intensity);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    inline bool EnableOutlineEffect(bool enable) {
        __try {
            ((SDK::UTgLocalPlayer*)Globals::LocalPlayer)->EnableOutlineEffect(enable);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    inline bool MaxLevel() {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->MaxLevel();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // UTgBattleCheatManager is a real, designed-for-this dev cheat interface
    // (same class MaxLevel already uses successfully) — these are all
    // official entry points, not us forcing raw fields, so meaningfully
    // lower risk than most of what else is in this file.
    inline bool GainCredits(int amount) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->GainCredits(amount);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool AddGold(int amount) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->AddGold(amount);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool GainXP(int amount) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->GainXP(amount);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool SetCardCooldownIncrease(float increase) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->SetCardCooldownIncrease(increase);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool FillEnergyAll(float pct) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->FillEnergyAll(pct);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool GiveCard(int deviceId) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->GiveCard(deviceId);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Third person via the CheatManager's own Set3p/Set1p, not PushCameraPosture
    // — PushCameraPosture didn't work in bot matches even though the real
    // escape-menu option proves the underlying feature works there. These are
    // direct dev commands, much more likely to bypass whatever UI-only
    // restriction is hiding the menu button for bot matches specifically.
    inline bool Set3p(bool force3P) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->Set3p(force3P);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // THE most promising card-leveling lead: unlike direct field writes
    // (which the server can silently ignore/overwrite), this sends an actual
    // REQUEST to the server for a card at a given level — the same real
    // pathway the game's own UI uses, not us guessing at client memory.
    inline bool TestServerRequestCard(int deviceId, int level) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->TestServerRequestCard(deviceId, level);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Real, unused-by-any-menu camera posture stack — TG_CAMERAPOSTURE_Force3P
    // forces third person. Returns -1 on failure/crash (a real stack ID is
    // always >= 0), so callers can tell success from failure.
    // Direct, real dev commands — don't need a world-spawned pickup actor to
    // exist at all, so unlike the pickup scanner these work in ANY match type
    // including bot matches, not just shooting range/wave defense.
    inline bool RefillAmmo() {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->RefillAmmo();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool SetGroundSpeedMultiplier(float mult) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->SetGroundSpeedMultiplier(mult);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool SetDamageMultiplier(float mult) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->SetDamageMultiplier(mult);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Spawns a deployable actor by ID directly — if the wave-defense pickup
    // classes (infinite ammo, speed, damage) have known deployable IDs, this
    // creates one directly instead of needing one to already exist in the
    // world to scan for. IDs unconfirmed — this is for testing/discovery.
    inline bool SpawnDeployable(int depId) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->SpawnDeployable(depId);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ============================================================
    // REAL SERVER RPCs (ATgPlayerController)
    // ============================================================
    // This is a fundamentally different mechanism from everything above.
    // UnrealScript functions marked `server` are DESIGNED to be invoked by the
    // client — the engine packages the call and executes it on the server. So
    // these aren't client-side field pokes the server ignores (which is why
    // raw writes never stuck), and they aren't admin/NM_Standalone-gated dev
    // commands (which is why most CheatManager calls did nothing on a real
    // server). These are the actual network pathway the game itself uses when
    // you level a card, pick a deck, or buy an item.
    //
    // Whether any given one lands depends on whether that specific server-side
    // handler validates the caller. Unknown per-function until tested — that's
    // exactly what these buttons are for.

    // THE card-leveling RPC — the real one the game uses, not CheatManager's
    // TestServerRequestCard. nRank is the card level.
    inline bool ServerRequestCard(int deviceId, int rank) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerRequestCard(deviceId, rank);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // The real "spend a loadout point on this card" RPC. Call repeatedly to
    // stack points on one card.
    inline bool ServerAllocateDevicePoint(int deviceId) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerAllocateDevicePoint(deviceId);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool ServerGiveCard(int deviceId) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerGiveCard(deviceId);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // The REAL surrender-vote RPC — same one the game's own "vote to
    // surrender" UI calls. Legitimate, sanctioned feature; this just gives
    // programmatic access to it. Whether the server actually requires a real
    // team majority before honouring it, or trusts the vote count too far,
    // is an open question worth testing live — not something knowable from
    // the SDK alone. EndGameBySurrender/SurrenderComplete on the server side
    // are what actually end the match once votes clear whatever threshold
    // it enforces.
    inline bool ServerSurrender(bool bSurrender) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerSurrender(bSurrender);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // NEW match-ending lead, found after PRIMAL_MONKE confirmed ServerSurrender
    // does nothing even in a bot match. CheatManager (Engine.PlayerController's
    // own field, offset 0x590, Transient) is genuinely client-side — every
    // PlayerController gets one, unlike AGameInfo/ATgGame_Mission which are
    // server-only actors a client can never instantiate. The runtime object
    // behind it is UTgBattleCheatManager, which carries EndGame() and
    // QuickEndGame(bool) — both dumped straight from the shipped binary as
    // "(Defined, Exec, Public)", meaning the console-command flag survived
    // into the shipped client. That does NOT prove the call still does
    // anything once it reaches the function body (shipped/non-dev builds
    // commonly gate cheat commands behind an AllowCheats()-style check
    // server doesn't grant) — genuinely untested until tried live. Returns
    // false (not just "no effect") specifically when CheatManager itself is
    // null, so a live test can tell "not reachable at all" apart from
    // "reached it, nothing happened."
    inline bool HasCheatManager() {
        __try { return Globals::LocalController && Globals::LocalController->CheatManager != nullptr; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool CheatManagerEndGame() {
        __try {
            auto* cm = (SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager;
            if (!cm) return false;
            cm->EndGame();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool CheatManagerQuickEndGame(bool bWin) {
        __try {
            auto* cm = (SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager;
            if (!cm) return false;
            cm->QuickEndGame(bWin);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // NOTE: ServerGetValue/ServerSetValue/SetClientValue already exist further
    // up in this file (found in an earlier session) — genuinely (Net,
    // NetReliable, Public, NetServer)/scripted calls, unlike EndGame() and
    // ServerProfileScript above which are Exec-only, non-networked, and
    // consistent with EndGame() being confirmed dead. SetClientValue against
    // a CDO (see ClientValues.h) is the mechanism now used for the checkmark
    // fix — see Unlocker.h's CDO section for the writeup.

    // The real loadout+talent confirm RPC — what fires when you lock in your
    // deck pregame. Much more likely to be accepted than poking talent IDs in
    // memory, since this IS the sanctioned path.
    inline bool ServerRequestDeckAndTalent(int talentId, int deckId, bool bTemplateDeck) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerRequestDeckAndTalent(talentId, deckId, bTemplateDeck);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Very likely the REAL Octavia pregame-passive pathway ("temp passive" ==
    // the pick-before-talents slot). If so this is the proper way to select
    // one of her 4 Commander buffs — and possibly to select one on any champ.
    inline bool ServerRequestSelectTempPassive(int id) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerRequestSelectTempPassive(id);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool ServerRequestEquipPassive() {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerRequestEquipPassive();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // In-match item shop RPCs — the "second item shop"/modulation items asked
    // about earlier. AddTempItem takes an item id + rank.
    inline bool ServerRequestAddTempItem(int id, int rank) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerRequestAddTempItem(id, rank);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool ServerRequestPurchaseAllTempItems() {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerRequestPurchaseAllTempItems();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool ServerRequestAutoAddTempItems() {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerRequestAutoAddTempItems();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Includes a DamageMultiplier the SERVER applies — unlike the CheatManager
    // SetDamageMultiplier (local, ignored). Other flags are real match rules.
    inline bool ServerSetServerFlags(bool bSprint, bool bMinimapTeamVis, float damageMultiplier,
                                     bool bForce3P, bool bForce1P, bool bOutOfCombatSprint) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerSetServerFlags(
                bSprint, bMinimapTeamVis, damageMultiplier, bForce3P, bForce1P, bOutOfCombatSprint);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // GENERIC server-side variable setter. If this handler isn't locked down
    // it's the single most powerful thing in the SDK — it names an object and
    // a variable on the SERVER and assigns it. Caller builds the wchar_t
    // buffers; FString here just wraps them (no destructor, SEH-safe).
    inline bool ServerSetValue(const wchar_t* objName, const wchar_t* varName, const wchar_t* value) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerSetValue(
                SDK::FString(objName), SDK::FString(varName), SDK::FString(value));
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // CLIENT-side counterpart of ServerSetValue. Names an object - including a
    // CLASS DEFAULT OBJECT like Default__TgPawn_Androxus - and assigns a
    // variable on it. Setting a CDO changes the class default, which is how the
    // community Input.ini bindings turn on wallhack, third person and aim
    // magnetism for every champion at once.
    //
    // FString borrows the caller's buffer and has no destructor, so this is
    // SEH-safe, same as ServerSetValue below.
    inline bool SetClientValue(const wchar_t* objName, const wchar_t* varName, const wchar_t* value) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->SetClientValue(
                SDK::FString(objName), SDK::FString(varName), SDK::FString(value));
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool ServerGetValue(const wchar_t* objName, const wchar_t* varName) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerGetValue(
                SDK::FString(objName), SDK::FString(varName));
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ========================================================================
    // THE DEV SKIN COMMANDS — chasing "there is a hidden developer item shop
    // that lets you equip any skin".
    //
    // These all live on UTgBattleCheatManager, and crucially we KNOW that class
    // is reachable in real matches: the Octavia Commander buffs go through
    // TestServerRequestCard on this same object and they demonstrably work. So
    // "it's the CheatManager" is not a reason to dismiss these.
    //
    // SwitchClass takes the skin BY NAME, which is exactly the shape of thing a
    // dev shop would call. `sc` is its short console alias.
    //
    // PrecacheClass matters for a second reason: UE3 loads assets lazily, so a
    // skin's mesh may not be in memory. Precaching is the game's own way of
    // forcing that load — which is the missing piece the mesh-pointer approach
    // was going to need anyway.
    // ========================================================================

    // ########################################################################
    // *** THE STRONGEST CANDIDATE FOUND SO FAR ***
    //
    //   ATgPlayerController::LiveMatchSwitchChampion(int BotId, int BodySkinId,
    //                                                int WeaponSkinId)
    //   ATgPlayerController::SwitchChampion(int BotId, int BodySkinId,
    //                                       int WeaponSkinId, int VoicePackId)
    //
    // WHY THESE BEAT EVERYTHING ELSE WE HAVE TRIED:
    //
    // 1. The dumped flags are "(Native, Public)". NOT `server`. NOT `client`.
    //    NOT `exec`. A plain native function on the player controller, which
    //    means it executes LOCALLY and is not a replicated RPC the server has to
    //    approve. Contrast r_nSkinId, which is (Net) and therefore server-owned —
    //    that is exactly why the skin-id approach never worked.
    //
    // 2. It takes BodySkinId and WeaponSkinId DIRECTLY as ints. No ownership
    //    argument, no entitlement parameter, nothing to satisfy.
    //
    // 3. The name says "LiveMatch" — this is the mid-match champion-swap path
    //    (the mechanism behind swap-champion game modes). Mid-match is precisely
    //    what we want.
    //
    // 4. It is genuinely "really well hidden": nobody hunting for skins would
    //    look inside a function named LiveMatchSwitchChampion.
    //
    // 5. SwitchChampion additionally takes VoicePackId — which answers the
    //    separate question about whether VGS lines can match the skin.
    //
    // NEITHER has HasOptionalParms, so the params struct is a plain run of ints
    // and there is no risk of the stack corruption that broke SetSkeletalMesh
    // (that one has OptionalParm bools, where the SDK struct and the native's
    // real expectation disagree — hence "stack around 'params' was corrupted").
    //
    // Pass your CURRENT champion's BotId to change only the skin. Passing a
    // different BotId would attempt an actual champion swap.
    // ########################################################################
    inline bool LiveMatchSwitchChampion(int botId, int bodySkinId, int weaponSkinId) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)
                ->LiveMatchSwitchChampion(botId, bodySkinId, weaponSkinId);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool SwitchChampion(int botId, int bodySkinId, int weaponSkinId, int voicePackId) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)
                ->SwitchChampion(botId, bodySkinId, weaponSkinId, voicePackId);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // UTgSkeletalMeshComponent::SetDefaultSkin(int nIndex) — also a strong lead,
    // and a different shape: it takes an INDEX, which pairs with the pawn's
    // m_pAmAllSkins array (TArray<FPointer>, all skins, not replicated). Lives on
    // the pawn's m_BodyMesh. (Native, Public), single int, so also safe.
    inline bool SetDefaultSkinOnBody(int nIndex) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p || !p->m_BodyMesh) return false;
            p->m_BodyMesh->SetDefaultSkin(nIndex);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool SetDefaultSkinOnHead(int nIndex) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p || !p->m_HeadMesh) return false;
            p->m_HeadMesh->SetDefaultSkin(nIndex);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Reports how many skins the pawn is tracking natively — the valid range for
    // SetDefaultSkin's index.
    inline int GetAllSkinsCount() {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return -1;
            int n = (int)p->m_pAmAllSkins.Num();
            if (n < 0 || n > 4096) return -1;
            return n;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }

    // ########################################################################
    // FORCE-LOAD (defeating lazy loading) — the obstacle the mesh scan revealed.
    //
    // THE PROBLEM, measured: scanning GObjects while playing Pip found 49
    // SkeletalMesh objects total and only 4 Pip ones, ALL named "skin00a" — the
    // skin actually equipped. UE3 loads skin assets on demand, so a skin we don't
    // wear simply is not in memory. No pointer write can reach an object that
    // does not exist yet.
    //
    // THE ANSWER: the game has its own precache API. These are the designed way
    // to force that load.
    //
    // SpawnBotAllSkins(int nBatch) is the most interesting: "(Native, Public)",
    // ONE int, no optional params — a clean signature. It spawns bots wearing all
    // skins, which necessarily loads those skins' assets. If it runs, the meshes
    // become resident and everything downstream becomes possible.
    //
    // PrecacheClassById / PrecacheClassByName live on ATgRepInfo_Game. That
    // matters because the RepInfo is REPLICATED TO CLIENTS (reachable via
    // WorldInfo->GRI), unlike ATgGame::EnsureBotPrecache — WorldInfo->Game reads
    // NULL on a client, which is how we detect NetMode in the first place. So the
    // RepInfo is the client-side route and ATgGame is not.
    //
    // CAUTION: both Precache* are "(Native, HasOptionalParms, Public)". That is
    // the same flag combination that made SetSkeletalMesh corrupt the stack, so
    // they are offered but flagged, and SpawnBotAllSkins is preferred.
    // ########################################################################

    // ########################################################################
    // THE HIDDEN DEVELOPER MENU — the most literal match for the hint yet.
    //
    // ATgClientHUD::ToggleDevMenu()  is (Exec, Native, Public).
    // The HUD carries: UTgDevMenuMoviePlayer* m_DevMenu, a Scaleform UI that
    // builds ITSELF from a command list (AddCommand / AddSubMenu / FillMenu
    // Commands). That is precisely "a hidden developer [menu]" — an in-game dev
    // panel, off by default, that lists developer commands including (per the
    // hint) a way to equip any skin.
    //
    // If this opens the real dev menu on screen, you can navigate to the skin
    // section yourself and read the exact command it fires — which tells us the
    // final answer directly instead of guessing.
    //
    // Reached via PlayerController->myHUD, cast to ATgClientHUD.
    // ########################################################################
    inline bool ToggleDevMenu() {
        __try {
            SDK::AHUD* hud = ((SDK::APlayerController*)Globals::LocalController)->myHUD;
            if (!hud) return false;
            ((SDK::ATgClientHUD*)hud)->ToggleDevMenu();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // HIDE MESHES — the clean answer to "make me invisible / hide my weapon".
    //
    // ATgPlayerController::HideMeshes(bool bHide1PMesh, bool bHide3PMesh)
    // Far better than selecting a "nogeo" mesh: this is the game's DEDICATED
    // function for it, so it can't cause a bone mismatch.
    //   bHide1PMesh -> your first-person view (arms + the weapon you hold)
    //   bHide3PMesh -> your third-person body
    // Flags include Exec and NetClient; calling it locally runs the simulated
    // hide. Reversible by calling again with false.
    // ########################################################################
    inline bool HideMeshes(bool hide1P, bool hide3P) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->HideMeshes(hide1P, hide3P);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Mesh-by-id on the local pawn's target (self). TargetSetMeshes takes a body
    // id and optional head id — a cleaner id-based route than SetBodyMesh alone.
    inline bool TargetSetMeshes(int nBodyMeshID, int nHeadMeshID) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->TargetSetMeshes(nBodyMeshID, nHeadMeshID);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Opens the dev skin gallery UI — a "(Exec)" viewer of skins, one of the
    // literal "item shop / gallery" candidates.
    inline bool TestSkinGalleryOpen(int nGallery) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->TestSkinGallery(nGallery);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // LOAD A SKIN MESH BY NAME — the answer to "only a few skins ever list".
    //
    // The problem the user hit: force-loaded skins get garbage-collected, so the
    // scan count keeps dropping (5 -> 2). The scan can only ever show what happens
    // to be resident this instant.
    //
    // The fix: don't wait for a skin to be resident — NAME it and fetch it.
    // Mesh names follow a strict pattern, e.g. skl_pc_pip_skin00a_3p. Swap the
    // number and you have skl_pc_pip_skin05a_3p. Then:
    //   1. STATIC_FindObject  — clean (Final,Native,Static), returns it if loaded
    //   2. STATIC_DynamicLoadObject — force-loads it from the package if not
    // Once we apply the returned mesh to the pawn, the pawn REFERENCES it, so it
    // can no longer be collected. Load-and-wear in one motion defeats the GC.
    //
    // FindObject is the safe primary. DynamicLoadObject is (HasOptionalParms) —
    // the flag family that corrupted SetSkeletalMesh — so it is separated out and
    // only used when FindObject misses. MayFail is passed explicitly so the
    // optional slot is filled rather than left for the native to guess.
    // ########################################################################
    // NOTE: STATIC_FindObject / STATIC_DynamicLoadObject are UnrealScript-static
    // but C++ member functions in this SDK — they go through ProcessEvent, so
    // (a) they need SOME UObject instance to be invoked on, and (b) they MUST run
    // on the ProcessEvent (safe) thread, never the render thread. The pawn is a
    // convenient live instance; the function ignores instance state anyway.
    inline SDK::USkeletalMesh* FindLoadedMesh(const wchar_t* fullName) {
        __try {
            SDK::UObject* self = (SDK::UObject*)Globals::LocalPawn;
            if (!self) return nullptr;
            SDK::UObject* o = self->STATIC_FindObject(
                SDK::FString(fullName), SDK::USkeletalMesh::StaticClass());
            return (SDK::USkeletalMesh*)o;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline SDK::USkeletalMesh* ForceLoadMesh(const wchar_t* fullName) {
        __try {
            SDK::UObject* self = (SDK::UObject*)Globals::LocalPawn;
            if (!self) return nullptr;
            SDK::UObject* o = self->STATIC_DynamicLoadObject(
                SDK::FString(fullName), SDK::USkeletalMesh::StaticClass(), true);
            return (SDK::USkeletalMesh*)o;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // Load a whole PACKAGE by name (e.g. "PC_Pip_Skin06A"). This is the standard
    // UE3 way to bring a cooked package into memory — once loaded, the meshes
    // inside it are findable. Returns non-null if the package resolved.
    inline SDK::UObject* ForceLoadPackage(const wchar_t* packageName) {
        __try {
            SDK::UObject* self = (SDK::UObject*)Globals::LocalPawn;
            if (!self) return nullptr;
            return self->STATIC_DynamicLoadObject(
                SDK::FString(packageName), SDK::UPackage::StaticClass(), true);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // ########################################################################
    // THE GAME'S OWN SKIN REBUILD — the method that renders CORRECTLY.
    //
    // Everything we tried by hand (raw mesh pointer writes) breaks skinning
    // (strings/spikes) and materials (wrong textures), because it skips the work
    // the engine does when a skin legitimately changes. So instead we drive the
    // engine's OWN rebuild:
    //
    //   1. Write r_nSkinId / r_nWeaponSkinId to the target ids.
    //   2. FlashChangeMesh()   - rebuilds the body mesh from the skin id
    //   3. AddBodyMesh()       - (re)creates the body mesh component
    //   4. UpdateWeaponMesh()  - rebuilds the weapon
    //   5. ForceUpdate1PMeshes() - rebuilds the FIRST-PERSON meshes (the weapon
    //                              and arms you actually see)
    //
    // All are (Native/Simulated, Public) with no params, so they're safe. This is
    // the path that uses the SKIN CODES directly (Invader Pip = 25865, etc.).
    //
    // r_nSkinId is (Net), so the server re-asserts its own value on the next
    // replication - that's why this must be re-applied on an interval, and why
    // others still see your real skin. But the rebuild itself renders the chosen
    // skin properly on your client.
    // ########################################################################
    // SetPlayerProfile — the game's LOADOUT skin setter. This is the path the
    // loadout screen uses to pick your skin. If it doesn't hard-check ownership,
    // it sets the skin properly (the game's own apply), which is what we want.
    inline bool SetPlayerProfile(int profileId, int skinId, int weaponSkinId, int voicePackId) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)
                ->SetPlayerProfile(profileId, skinId, weaponSkinId, voicePackId);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // "THE ROUTE ACTUAL SKINS TAKE" — per the OG discoverer's hint.
    //
    // A real skin arrives from the server as a replicated r_nSkinId. When it
    // lands, the client runs ReplicatedEvent(VarName="r_nSkinId"), and THAT
    // handler is the game's own full skin application: resolve id -> mesh +
    // materials + weapon, correctly. It is the route.
    //
    // So: write r_nSkinId (and weapon/mount) locally, then fire ReplicatedEvent
    // with those exact property names. The game applies the skin as if the server
    // had sent it - which is why it renders perfectly, unlike our manual hacks.
    //
    // The FName for the property name is looked up ONCE and cached. FName(const
    // char*) scans GNames (the source of the old bone crash), so it is wrapped
    // and done a single time behind a static.
    // ########################################################################
    // FName construction lives HERE, in a function with NO __try. FName(const
    // char*) uses std::string/std::set internally (needs stack unwinding), and
    // MSVC forbids that in any function containing __try (error C2712). The FName
    // RESULT is just two ints, so copying it into the __try function below is
    // fine. Built once behind statics — the scan only runs on the first call.
    inline void GetSkinRouteFNames(SDK::FName& s, SDK::FName& w, SDK::FName& m) {
        static SDK::FName fs = SDK::FName("r_nSkinId");
        static SDK::FName fw = SDK::FName("r_nWeaponSkinId");
        static SDK::FName fm = SDK::FName("r_nMountSkinId");
        s = fs; w = fw; m = fm;   // POD copies
    }

    // ########################################################################
    // CHAMPION-SELECT / LOBBY SKIN — targets the PREVIEW mesh.
    //
    // In champion select the game renders ANY skin correctly (even unowned) on
    // the preview model via ATgSkeletalMeshActor_Lobby::SetSkin(skinId, deviceId).
    // That is the game's own correct-rendering path for any skin. We scan for the
    // lobby preview actor(s) and drive SetSkin on them.
    //
    // This is the ENTRANCE to the route: pick the skin where the game already
    // knows how to draw it, instead of forcing it onto a spawned pawn.
    //
    // Returns how many lobby actors we applied to (0 = none found = not in a
    // preview screen right now).
    // ########################################################################
    inline int SetLobbySkinAll(int skinId, int deviceSkinId) {
        int applied = 0;
        __try {
            auto& objects = SDK::UObject::GetGlobalObjects();
            size_t count = objects.Num();
            if (count == 0 || count > 4000000) return 0;
            for (size_t i = 0; i < count; ++i) {
                SDK::UObject* o = nullptr;
                __try { if (objects.IsValidIndex(i)) o = objects[i]; }
                __except (EXCEPTION_EXECUTE_HANDLER) { o = nullptr; }
                if (!o) continue;

                // Match the lobby mesh class by name (name-matching beats IsA in
                // this SDK). GetFullName includes the class; check the class name.
                SDK::UClass* cls = nullptr;
                __try { cls = o->Class; } __except (EXCEPTION_EXECUTE_HANDLER) { cls = nullptr; }
                if (!cls || cls->Name.Index == 0) continue;
                auto& names = SDK::FName::GetGlobalNames();
                if (!names.IsValidIndex((size_t)cls->Name.Index)) continue;
                SDK::FNameEntry* e = names[cls->Name.Index];
                if (!e) continue;
                const char* n = e->GetAnsiName();
                if (!n) continue;
                // "TgSkeletalMeshActor_Lobby" and subclasses.
                bool isLobby = false;
                for (int k = 0; n[k]; ++k) {
                    if (_strnicmp(n + k, "SkeletalMeshActor_Lobby", 23) == 0) { isLobby = true; break; }
                }
                if (!isLobby) continue;
                // Skip the class-default object.
                if (names.IsValidIndex((size_t)o->Name.Index)) {
                    SDK::FNameEntry* on = names[o->Name.Index];
                    if (on) { const char* onm = on->GetAnsiName();
                              if (onm && _strnicmp(onm, "Default__", 9) == 0) continue; }
                }

                __try {
                    ((SDK::ATgSkeletalMeshActor_Lobby*)o)->SetSkin(skinId, deviceSkinId);
                    applied++;
                } __except (EXCEPTION_EXECUTE_HANDLER) {}
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
        return applied;
    }

    // ########################################################################
    // MESH ASSEMBLY ID — the non-replicated client-side skin driver.
    //
    // m_nBodyMeshAsmId (0x07C0) is (Const) but NOT (Net). Unlike r_nSkinId it is
    // NOT server-owned, so writing it isn't reverted in real matches. It's what
    // the game's OWN mesh builder reads, so rebuilding from it should give correct
    // textures/skinning AND carry to illusions (they build from the same asm id).
    //
    // This is the one avenue that could combine Method A's correctness with Method
    // B's real-match survival. The asm id for a target skin is learned via
    // GetMeshAssemblyToUse (call it while wearing a skin to read its asm id).
    // ########################################################################
    inline int ReadBodyAsmId() {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return -1;
            return p->m_nBodyMeshAsmId;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -2; }
    }

    // Ask the game which body+core assembly ids it would use RIGHT NOW. In the
    // shooting range, set r_nSkinId to a skin first, then read this to LEARN that
    // skin's asm id — then reuse the id in a real match.
    inline bool ReadMeshAssemblyToUse(int* bodyAsm, int* coreAsm) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            int b = 0, c = 0;
            p->GetMeshAssemblyToUse(&b, &c);
            *bodyAsm = b; *coreAsm = c;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Set the client-side body asm id and rebuild through the game's own pipeline.
    inline bool SetBodyAsmIdAndRebuild(int bodyAsmId, int coreAsmId, bool setCore) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            if (bodyAsmId > 0) p->m_nBodyMeshAsmId = bodyAsmId;
            if (setCore && coreAsmId > 0) p->m_nCoreMeshAsmId = coreAsmId;
            p->AddBodyMesh();
            p->ForceRecalculateMaterial();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Read the pawn's LIVE r_nSkinId, so we can see what value the game actually
    // uses for the current skin — the key to whether our DB ids are the right
    // number space at all.
    inline int ReadLiveSkinId() {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return -1;
            return p->r_nSkinId;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -2; }
    }

    inline bool ApplySkinViaRoute(int skinId, int weaponSkinId, int mountSkinId,
                                  bool doWeapon, bool doMount) {
        // Build the FNames outside the __try (see the note above).
        SDK::FName fnSkin, fnWeapon, fnMount;
        GetSkinRouteFNames(fnSkin, fnWeapon, fnMount);

        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;

            if (skinId > 0)  p->r_nSkinId = skinId;
            if (doWeapon && weaponSkinId > 0) p->r_nWeaponSkinId = weaponSkinId;
            if (doMount && mountSkinId > 0)   p->r_nMountSkinId = mountSkinId;

            // Fire the replication handler for each changed property — this is the
            // game's own skin-apply route.
            p->ReplicatedEvent(fnSkin);
            if (doWeapon) p->ReplicatedEvent(fnWeapon);
            if (doMount)  p->ReplicatedEvent(fnMount);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // COMBINED FULL APPLY — everything the game does, in order, in one call.
    //
    // The user's insight: the raw mesh swap changed the in-match MODEL; the
    // champion-select preview has the correct MATERIALS loaded. We never ran the
    // game's COMPLETE sequence. This does:
    //   1. r_nSkinId / r_nWeaponSkinId = target   (the id)
    //   2. ReplicatedEvent(...)                    (the route trigger)
    //   3. FlashChangeMesh + AddBodyMesh           (rebuild body from the id)
    //   4. UpdateWeaponMesh + ForceUpdate1PMeshes  (rebuild weapon, incl. 1P)
    //   5. ForceRecalculateMaterial                (apply THIS skin's materials)
    //
    // Step 5 was the missing finisher — the pawn re-derives materials for
    // r_nSkinId, which is now the target, so the textures should be correct.
    //
    // PREREQUISITE: the skin's assets must be loaded, or the rebuild goes
    // invisible. Preview the skin in champion select first, THEN spawn and call
    // this. That's the combination we never tried.
    // ########################################################################
    inline bool ApplySkinFull(int skinId, int weaponSkinId, bool doWeapon) {
        SDK::FName fnSkin, fnWeapon, fnMount;
        GetSkinRouteFNames(fnSkin, fnWeapon, fnMount);
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            if (skinId > 0) p->r_nSkinId = skinId;
            if (doWeapon && weaponSkinId > 0) p->r_nWeaponSkinId = weaponSkinId;
            p->ReplicatedEvent(fnSkin);
            if (doWeapon) p->ReplicatedEvent(fnWeapon);
            p->FlashChangeMesh();
            p->AddBodyMesh();
            if (doWeapon) p->UpdateWeaponMesh();
            p->ForceUpdate1PMeshes();
            p->ForceRecalculateMaterial();   // the finisher — correct textures
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // CLIENT SKIN OVERRIDE  — the real-match lever we missed for months.
    //
    // USkeletalMeshComponent::c_nOverrideSkinId (0x0508) and c_nOverrideSkinLevel
    // (0x050C) are (Transient) — CLIENT ONLY. The server never replicates them,
    // so unlike r_nSkinId it physically CANNOT revert them. The "c_" prefix means
    // client. This is the field we wrongly concluded didn't exist — because we
    // searched the PAWN, and it actually lives on the mesh COMPONENT that renders
    // the body. Offset 0x508 confirmed across TWO independent SDK dumps
    // (EmoteTalent + BlueFire), so it's not a fluke.
    //
    // Write it by raw offset (the SDK struct doesn't name it), then rebuild so the
    // game re-reads the override and renders our skin locally. Because it's client
    // Transient, it should HOLD in a real match — the server has nothing to fight
    // it with. This is the profile of "works flawlessly in real matches."
    // ########################################################################
    inline bool ApplyOverrideSkin(int skinId, int skinLevel, bool alsoSetRepId) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p || !p->m_BodyMesh) return false;
            char* comp = (char*)p->m_BodyMesh;
            *(int*)(comp + 0x508) = skinId;      // c_nOverrideSkinId   (Transient)
            *(int*)(comp + 0x50C) = skinLevel;   // c_nOverrideSkinLevel(Transient)
            // Optionally set the replicated id too, so materials/asm resolve to the
            // same skin. Server will revert THIS, but the override above should win.
            if (alsoSetRepId && skinId > 0) p->r_nSkinId = skinId;
            p->FlashChangeMesh();
            p->AddBodyMesh();
            p->ForceUpdate1PMeshes();
            p->ForceRecalculateMaterial();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Read back the live override value, to confirm our write stuck and to see
    // what the game currently holds (server can't touch this, so it should equal
    // whatever we last wrote).
    inline int ReadOverrideSkinId() {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p || !p->m_BodyMesh) return -999;
            return *(int*)((char*)p->m_BodyMesh + 0x508);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -999; }
    }

    // Re-assert the override every tick (for the persistence loop). Cheap: just
    // the two writes, no rebuild — the rebuild only needs to happen once, but
    // re-writing the field guards against anything clearing it.
    inline bool ReassertOverrideSkin(int skinId, int skinLevel) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p || !p->m_BodyMesh) return false;
            char* comp = (char*)p->m_BodyMesh;
            *(int*)(comp + 0x508) = skinId;
            *(int*)(comp + 0x50C) = skinLevel;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // ***** THE MENU PREVIEW, CALLED THE WAY THE GAME CALLS IT *****
    //
    // This is the function the champion-select / skins screen runs when YOU click
    // a skin. Not a mesh poke — the game's own model swap:
    //
    //   ATgLobbyHUD::ChangeClassModel(nClassId, nSkinId, nDeviceId, nDeviceSkinId,
    //                                 nPedestalSkinId, pose, camDirection,
    //                                 bAsync, HighlightType, MVPDeviceId)
    //
    // It takes the SKIN **and** the DEVICE(weapon) SKIN, so it loads the complete
    // package — body, arms, weapon — positions it on the correct pedestal, and
    // uses the proper camera. That is exactly why our old approach was wrong:
    // SetLobbySkinAll walked the preview meshes and overwrote pointers, which
    // lands the model in the wrong place, smears it onto ally stage circles, and
    // never touches the weapon. This calls the real entry point instead.
    //
    // Because it is the legitimate path, it renders ANY skin (the store has to
    // preview skins you don't own), which makes it an ownership-free loader for
    // BOTH halves — the thing we have needed all along.
    //
    // Enums (confirmed): ELobbyAnimPose LAP_Match=0; ECameraTransType CTT_None=0;
    //                    EModelHighlightType HIGHLIGHT_None=0.
    // Runs on the safe (ProcessEvent) thread only.
    // ########################################################################
    // Is the CURRENT hud actually the lobby/menu hud? In a match myHUD is an
    // ATgGameHUD, and blind-casting that to ATgLobbyHUD and calling ChangeClassModel
    // walks a different vtable/layout — that is the "params corrupted" hard crash.
    // Never call the lobby functions unless we are genuinely in the lobby HUD.
    inline bool IsLobbyHud() {
        __try {
            SDK::AHUD* hud = ((SDK::APlayerController*)Globals::LocalController)->myHUD;
            if (!hud || !hud->Class) return false;
            auto& names = SDK::FName::GetGlobalNames();
            int idx = hud->Class->Name.Index;
            if (idx <= 0 || !names.IsValidIndex((size_t)idx)) return false;
            SDK::FNameEntry* e = names[idx];
            if (!e) return false;
            const char* a = e->GetAnsiName();
            return a && strstr(a, "LobbyHUD") != nullptr;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // *** DO NOT use the SDK's generated ChangeClassModel wrapper. ***
    // It declares a 28-byte params struct on the stack, but ProcessEvent writes
    // fn->ParmsSize bytes into it. When the real function's parameter block is
    // larger than the dump's struct, that overflows the stack variable — which is
    // EXACTLY the "Run-Time Check Failure #2 - Stack around the variable 'params'
    // was corrupted" popup. Same hazard for every generated wrapper whose struct
    // the dump got wrong.
    //
    // Fix: allocate a buffer sized from the ENGINE's own ParmsSize, fill the
    // fields by offset, and call ProcessEvent ourselves. Can't overflow.
    // Function lookups live in their OWN functions. FindObject uses std::string,
    // and when it inlines into a function that also contains __try you get
    // C2712 ("__try in functions that require object unwinding"). Keeping the
    // lookup in a separate non-__try function is the fix.
    inline SDK::UFunction* g_fnChangeClassModel = nullptr;
    inline SDK::UFunction* g_fnChangeTeamModel  = nullptr;

    inline SDK::UFunction* GetFnChangeClassModel() {
        if (!g_fnChangeClassModel)
            g_fnChangeClassModel = SDK::UObject::FindObject<SDK::UFunction>(
                "Function TgClient.TgLobbyHUD.ChangeClassModel");
        return g_fnChangeClassModel;
    }
    inline SDK::UFunction* GetFnChangeTeamModel() {
        if (!g_fnChangeTeamModel)
            g_fnChangeTeamModel = SDK::UObject::FindObject<SDK::UFunction>(
                "Function TgClient.TgLobbyHUD.ChangeTeamModel");
        return g_fnChangeTeamModel;
    }

    // Raw invoke, POD-only body so __try is legal here.
    inline bool InvokeRaw(SDK::UObject* obj, SDK::UFunction* fn, void* buf, int bufSize) {
        __try {
            if (!obj || !fn) return false;
            int need = (int)fn->ParmsSize;
            if (need <= 0 || need > bufSize) return false;
            unsigned long saved = fn->FunctionFlags;
            fn->FunctionFlags |= 0x400;          // treat as native
            obj->ProcessEvent(fn, buf);
            fn->FunctionFlags = saved;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline SDK::UObject* GetHudObject() {
        __try {
            return (SDK::UObject*)((SDK::APlayerController*)Globals::LocalController)->myHUD;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline bool MenuPreviewSkin(int classId, int skinId, int deviceId,
                                int deviceSkinId, int pedestalSkinId, bool bAsync) {
        if (!IsLobbyHud()) return false;   // menu only — wrong HUD type = hard crash
        SDK::UFunction* fn = GetFnChangeClassModel();
        SDK::UObject*  hud = GetHudObject();
        if (!fn || !hud) return false;

        unsigned char buf[512];
        ZeroMemory(buf, sizeof(buf));
        // Declaration order: five ints, four bytes, one int.
        *(int*)(buf + 0)  = classId;
        *(int*)(buf + 4)  = skinId;
        *(int*)(buf + 8)  = deviceId;
        *(int*)(buf + 12) = deviceSkinId;    // the WEAPON skin
        *(int*)(buf + 16) = pedestalSkinId;
        buf[20] = 0;                          // pose          = LAP_Match
        buf[21] = 0;                          // camDirection  = CTT_None
        buf[22] = bAsync ? 1 : 0;             // bAsync
        buf[23] = 0;                          // HighlightType = HIGHLIGHT_None
        *(int*)(buf + 24) = 0;                // MVPDeviceId
        return InvokeRaw(hud, fn, buf, (int)sizeof(buf));
    }


    // Same call, but for the champion-select TEAM slots (your own slot is index 0
    // on the friendly side). Useful when ChangeClassModel targets the wrong actor.
    inline bool MenuPreviewTeamModel(int index, int classId, int skinId, int deviceId,
                                     int deviceSkinId, bool friendly) {
        if (!IsLobbyHud()) return false;   // menu only — same crash guard
        SDK::UFunction* fn = GetFnChangeTeamModel();   // lookup in its own function
        SDK::UObject*  hud = GetHudObject();
        if (!fn || !hud) return false;

        unsigned char buf[512];
        ZeroMemory(buf, sizeof(buf));
        buf[0] = friendly ? 1 : 0;            // bFriendly (bool, 4-byte slot)
        *(int*)(buf + 4)  = index;
        *(int*)(buf + 8)  = classId;
        *(int*)(buf + 12) = skinId;
        *(int*)(buf + 16) = deviceId;
        *(int*)(buf + 20) = deviceSkinId;     // the WEAPON skin
        *(int*)(buf + 24) = 0;                // nPedestalSkinId
        buf[28] = 0;                          // pose = LAP_Match
        buf[29] = 0;                          // bAsync
        buf[30] = 0;                          // HighlightType
        // remaining (MVPDeviceId, XP, delegate) stay zeroed.
        return InvokeRaw(hud, fn, buf, (int)sizeof(buf));
    }

    // ########################################################################
    // ############  THE FULL SKIN ROUTE — "THE ANUBIS METHOD"  ###############
    //
    // Every previous attempt touched ONE link of a FOUR-link chain, which is why
    // we kept getting partial results (ult/VGS/sounds change, body doesn't).
    // The complete route a real skin takes, mapped from the SDK:
    //
    //   1. UTgClientSettings::ChosenSkinId       0x01C0   <-- YOUR CHOICE
    //      UTgClientSettings::ChosenClassId      0x01C4       (client-side,
    //      UTgClientSettings::ChosenWeaponId     0x01C8        NOT replicated,
    //      UTgClientSettings::ChosenWeaponSkinId 0x01CC        NO ownership check)
    //          reached via ATgPlayerController::STATIC_GetClientSettings()
    //                       |
    //   2. ATgRepInfo_Player (the PRI):  r_nSkinId 0x101C, r_nWeaponSkinId 0x1030
    //          <-- what the game reads to DRESS a player. Everyone's skin lives
    //              here. We have NEVER written this. This is the missing link.
    //                       |
    //   3. ATgPawn: r_nSkinId 0x2828, r_nWeaponSkinId 0x282C, c_nHeadSkinId 0x2844
    //          <-- the only thing we ever touched before
    //                       |
    //   4. ATgPawn::m_pAmSkin 0x2850 / m_pAmWeaponSkin 0x2858
    //          <-- the RESOLVED skin pointer the renderer dereferences
    //
    // "There is a hidden developer item shop that lets you equip any skin" =
    // step 1 (write the CHOICE). "No such thing as ownership flags that matter" =
    // ChosenSkinId is a plain int in client settings; nothing validates it.
    // "Just find the route actual skins take" = this chain, in order.
    // "Only I can see it" = the PRI write is local; the server keeps its own copy,
    // so it renders for us and never leaves the machine.
    //
    // This applies it EXACTLY like the fire-mode fix: write every field the
    // client reads, top to bottom, then let the game's own rebuild run.
    // ########################################################################

    // NOTE: despite the STATIC_ prefix the SDK declares this as a NON-static
    // member, so it needs an object — same pattern the existing vendor-store
    // helpers use. Members are directly accessible by name, so we use those
    // rather than raw offsets (safer and self-documenting).
    inline bool SetChosenSkin(int skinId, int weaponSkinId, int classId, int weaponId) {
        __try {
            SDK::UTgClientSettings* cs =
                ((SDK::ATgPlayerController*)Globals::LocalController)->STATIC_GetClientSettings();
            if (!cs) return false;
            if (skinId > 0)       cs->ChosenSkinId       = skinId;
            if (classId > 0)      cs->ChosenClassId      = classId;
            if (weaponId > 0)     cs->ChosenWeaponId     = weaponId;
            if (weaponSkinId > 0) cs->ChosenWeaponSkinId = weaponSkinId;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline int ReadChosenSkinId() {
        __try {
            SDK::UTgClientSettings* cs =
                ((SDK::ATgPlayerController*)Globals::LocalController)->STATIC_GetClientSettings();
            if (!cs) return -999;
            return cs->ChosenSkinId;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -999; }
    }

    // Step 2 — write the PRI (what the game reads to dress a player).
    inline bool SetPriSkin(int skinId, int weaponSkinId) {
        __try {
            SDK::APawn* p = Globals::LocalPawn;
            if (!p || !p->PlayerReplicationInfo) return false;
            char* b = (char*)p->PlayerReplicationInfo;
            if (skinId > 0)       *(int*)(b + 0x101C) = skinId;        // r_nSkinId
            if (weaponSkinId > 0) *(int*)(b + 0x1030) = weaponSkinId;  // r_nWeaponSkinId
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline int ReadPriSkinId() {
        __try {
            SDK::APawn* p = Globals::LocalPawn;
            if (!p || !p->PlayerReplicationInfo) return -999;
            return *(int*)((char*)p->PlayerReplicationInfo + 0x101C);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -999; }
    }

    // ===== THE ONE-SHOT FULL APPLY =====
    // Writes all four links, then runs the game's own rebuild. `amIndex` optionally
    // repoints m_pAmSkin at an entry from m_pAmAllSkins (-1 = leave alone).
    inline bool ApplyFullSkinRoute(int skinId, int weaponSkinId, int classId,
                                   int weaponId, int amIndex, bool doRebuild) {
        // Step 1 first: the choice must be set before anything re-reads it.
        SetChosenSkin(skinId, weaponSkinId, classId, weaponId);
        // Step 2: the PRI.
        SetPriSkin(skinId, weaponSkinId);

        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            char* b = (char*)p;

            // Step 3: the pawn's own ids.
            if (skinId > 0)       *(int*)(b + 0x2828) = skinId;        // r_nSkinId
            if (weaponSkinId > 0) *(int*)(b + 0x282C) = weaponSkinId;  // r_nWeaponSkinId
            if (skinId > 0)       *(int*)(b + 0x2844) = skinId;        // c_nHeadSkinId

            // Step 4: the resolved skin pointer, if an index was given.
            if (amIndex >= 0) {
                void** data  = *(void***)(b + 0x2868);
                int    count = *(int*)(b + 0x2868 + 8);
                if (data && amIndex < count && data[amIndex]) {
                    *(void**)(b + 0x2850) = data[amIndex];   // m_pAmSkin
                    *(void**)(b + 0x2858) = data[amIndex];   // m_pAmWeaponSkin
                }
            }

            // Let the GAME rebuild — same route a legitimate skin change takes.
            if (doRebuild) {
                p->FlashChangeMesh();
                p->AddBodyMesh();
                p->UpdateWeaponMesh();
                p->ForceUpdate1PMeshes();
                p->ForceRecalculateMaterial();
            }
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Persistence: re-write the ids WITHOUT rebuilding (cheap), so a server
    // re-assert of r_nSkinId gets immediately overwritten again on our side.
    inline bool ReassertFullRoute(int skinId, int weaponSkinId) {
        SetPriSkin(skinId, weaponSkinId);
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            char* b = (char*)p;
            if (skinId > 0)       *(int*)(b + 0x2828) = skinId;
            if (weaponSkinId > 0) *(int*)(b + 0x282C) = weaponSkinId;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // *** THE FIRE-MODE METHOD, FOR SKINS ***
    //
    // Hidden FIRE MODES work in real matches in this same mod. How? Not via the
    // engine setter (which "silently refuses these hidden modes"), but by writing
    // ALL the fields the client reads, raw, in one go:
    //     device->CurrentFireMode = m; m_PendingFireMode = m; m_nDesiredFireMode = m;
    //
    // The skin equivalent needs the same treatment. The pawn's skin state is NOT
    // just r_nSkinId — it is a set of fields, and the one that actually matters is
    // m_pAmSkin (0x2850): "Am" = ASSET MANIFEST, the resolved POINTER to the skin
    // the renderer uses. r_nSkinId is only the ID the server syncs; m_pAmSkin is
    // the thing the render path dereferences.
    //
    // Field map (ATgPawn), all confirmed in the SDK dump:
    //   0x07B4 m_nCoreMeshAsmId   (Const, not Net)
    //   0x07C0 m_nBodyMeshAsmId   (Const, not Net)
    //   0x2828 r_nSkinId          (Net)  <- the only one the server owns
    //   0x282C r_nWeaponSkinId    (Net)
    //   0x2844 c_nHeadSkinId      (client)
    //   0x2850 m_pAmSkin          (FPointer) <- THE RESOLVED SKIN. Not replicated.
    //   0x2858 m_pAmWeaponSkin    (FPointer) <- resolved WEAPON skin.
    //   0x2868 m_pAmAllSkins      (TArray<FPointer>) <- EVERY skin, already resolved
    //
    // m_pAmAllSkins is the payoff: the pawn already holds pointers to all of its
    // skins. We do not need to load, precache or name anything — we just point
    // m_pAmSkin at a different entry. That IS "the route actual skins take", and
    // being a raw non-replicated pointer, the server has nothing to revert.
    // ########################################################################

    // (GetAllSkinsCount already exists above — it uses m_pAmAllSkins.Num().)

    inline void* GetAllSkinsEntry(int index) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return nullptr;
            void** data = *(void***)((char*)p + 0x2868);
            int    count = *(int*)((char*)p + 0x2868 + 8);
            if (!data || index < 0 || index >= count) return nullptr;
            return data[index];
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline void* ReadAmSkin() {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return nullptr;
            return *(void**)((char*)p + 0x2850);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // THE APPLY. Point m_pAmSkin (and optionally m_pAmWeaponSkin) at the chosen
    // entry from m_pAmAllSkins, then run the game's own rebuild so it re-reads
    // them. This is the fire-mode pattern: write the resolved state directly and
    // let the client render it, instead of asking a setter that refuses us.
    inline bool ApplyAmSkinByIndex(int index, bool alsoWeapon, bool rebuild) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            void** data = *(void***)((char*)p + 0x2868);
            int    count = *(int*)((char*)p + 0x2868 + 8);
            if (!data || index < 0 || index >= count) return false;
            void* target = data[index];
            if (!target) return false;

            *(void**)((char*)p + 0x2850) = target;              // m_pAmSkin
            if (alsoWeapon) *(void**)((char*)p + 0x2858) = target;  // m_pAmWeaponSkin

            if (rebuild) {
                p->FlashChangeMesh();
                p->AddBodyMesh();
                p->UpdateWeaponMesh();
                p->ForceUpdate1PMeshes();
                p->ForceRecalculateMaterial();
            }
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Re-assert without rebuilding (persistence tick) — cheap pointer write.
    inline bool ReassertAmSkin(int index, bool alsoWeapon) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            void** data = *(void***)((char*)p + 0x2868);
            int    count = *(int*)((char*)p + 0x2868 + 8);
            if (!data || index < 0 || index >= count || !data[index]) return false;
            *(void**)((char*)p + 0x2850) = data[index];
            if (alsoWeapon) *(void**)((char*)p + 0x2858) = data[index];
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // The full raw multi-field write — every skin field at once, fire-mode style.
    // Use when you have a skin ID: sets ids + asm ids together so nothing is left
    // pointing at the old skin (a half-written state is what renders invisible).
    inline bool ApplySkinAllFieldsRaw(int skinId, int weaponSkinId, int bodyAsmId,
                                      int coreAsmId, bool rebuild) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            char* b = (char*)p;
            if (skinId > 0)       *(int*)(b + 0x2828) = skinId;        // r_nSkinId
            if (weaponSkinId > 0) *(int*)(b + 0x282C) = weaponSkinId;  // r_nWeaponSkinId
            if (skinId > 0)       *(int*)(b + 0x2844) = skinId;        // c_nHeadSkinId
            if (bodyAsmId > 0)    *(int*)(b + 0x07C0) = bodyAsmId;     // m_nBodyMeshAsmId
            if (coreAsmId > 0)    *(int*)(b + 0x07B4) = coreAsmId;     // m_nCoreMeshAsmId
            if (rebuild) {
                p->FlashChangeMesh();
                p->AddBodyMesh();
                p->UpdateWeaponMesh();
                p->ForceUpdate1PMeshes();
                p->ForceRecalculateMaterial();
            }
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // ASSEMBLY REMAP  — YOUR idea, made real: "make the server confirm default,
    // but default renders the target."
    //
    // The pawn holds m_BodyMeshAssembly (0x07C4) and m_CoreMeshAssembly (0x07B8):
    // ATgMeshAssembly objects that RESOLVE your skin id into an actual mesh
    // (m_nMeshAsmId 0x0280, then LoadMesh() builds m_Mesh). The server owns the
    // skin ID — it does NOT own what the assembly resolves that id to. So we
    // repoint the assembly at the TARGET skin's asm id and call the game's own
    // LoadMesh(): the game rebuilds your body from the target while the server
    // still believes you're default. Because we changed the RESOLUTION, not the
    // id, a server re-assert of the id STILL resolves to our target — which is
    // why this can survive a real match where every other method reverts.
    //
    // This is also "the route actual skins take": LoadMesh is the game's own
    // skin-build routine, so the result is a clean, correct skin, not a poke.
    //
    // Get the target asm id first: in the RANGE, wear the skin (Method A / Combined
    // Full Apply) and press LEARN to read its asm id. Then REMAP to that id.
    // ########################################################################
    inline bool RemapBodyAssembly(int targetAsmId, bool alsoCore, int coreAsmId) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            SDK::ATgMeshAssembly* body = *(SDK::ATgMeshAssembly**)((char*)p + 0x07C4);
            if (!body) return false;
            body->m_nMeshAsmId = targetAsmId;   // repoint what "your skin" resolves to
            body->LoadMesh();                    // game's OWN build routine (the route)
            if (alsoCore && coreAsmId > 0) {
                SDK::ATgMeshAssembly* core = *(SDK::ATgMeshAssembly**)((char*)p + 0x07B8);
                if (core) { core->m_nMeshAsmId = coreAsmId; core->LoadMesh(); }
            }
            *(int*)((char*)p + 0x07C0) = targetAsmId;   // keep pawn's asm field in sync
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Read the assembly's live asm id, to confirm the remap held (server can't
    // touch this — it only touches the skin id, not the resolution).
    inline int ReadBodyAssemblyAsmId() {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return -999;
            SDK::ATgMeshAssembly* body = *(SDK::ATgMeshAssembly**)((char*)p + 0x07C4);
            if (!body) return -998;
            return body->m_nMeshAsmId;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -997; }
    }

    // Re-assert the remap every tick (persistence), in case a rebuild resets the
    // assembly. Cheap: id write + LoadMesh.
    inline bool ReassertBodyAssembly(int targetAsmId) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            SDK::ATgMeshAssembly* body = *(SDK::ATgMeshAssembly**)((char*)p + 0x07C4);
            if (!body) return false;
            body->m_nMeshAsmId = targetAsmId;
            body->LoadMesh();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // ####################  SELF-HEAL / STAT MULTIPLIERS  ###################
    //
    // All on UTgBattleCheatManager. Worth trying because CardsTab's own notes
    // record that SOME cheat-manager calls (TestServerRequestCard) demonstrably
    // DO work in real matches — the manager is not blanket-gated.
    //
    //   Heal(int)                       direct heal on self
    //   SetHealth(int)                  set absolute health
    //   HealTarget(int)                 heal whoever you're looking at
    //   SetAutoHealingMultiplier(float) scales OUT-OF-COMBAT regen  <-- likely the
    //                                   "self heal" others have shown off: it uses
    //                                   the game's own regen instead of injecting
    //                                   health, so it looks legitimate and works
    //                                   on ANY champion (no card needed)
    //   SetDamageMultiplier(float)      bonus
    //   SetGroundSpeedMultiplier(float) the OFFICIAL speed multiplier — may work
    //                                   where Speeden's raw GroundSpeed write does
    //                                   not, since the game applies it itself
    //   SetMana(int)
    // ########################################################################
    inline bool CheatHeal(int amount) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->Heal(amount);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool CheatSetHealth(int hp) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->SetHealth(hp);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool CheatHealTarget(int amount) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->HealTarget(amount);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool CheatAutoHealMult(float mult) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->SetAutoHealingMultiplier(mult);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool CheatDamageMult(float mult) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->SetDamageMultiplier(mult);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool CheatGroundSpeedMult(float mult) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->SetGroundSpeedMultiplier(mult);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool CheatSetMana(int mana) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->SetMana(mana);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Read current health so the UI can show whether a heal actually landed.
    // APawn::Health / HealthMax are ints (same fields RecoverySuite already uses).
    inline int ReadHealth(int* outMax) {
        __try {
            SDK::APawn* p = Globals::LocalPawn;
            if (!p) return -1;
            if (outMax) *outMax = p->HealthMax;
            return p->Health;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }

    // ########################################################################
    // ############  INVENTORY / CARD SYSTEM  (card-maxxing surface)  ########
    //
    // NOT the skin route (that was my error — this is the IN-MATCH item/card
    // system). But it is a genuine, previously untouched exploit surface:
    //
    //   APawn::InvManager                            0x04DC  -> ATgInventoryManager
    //   ATgInventoryManager::GetInventoryByEquipPoint(ETG_EQUIP_POINT, int nItemType)
    //   UTgInventoryObject::m_nRefData               0x0084  (the device/card id)
    //   UTgInventoryObject::m_bTemporary : 1         0x0090
    //   UTgInventoryObject::c_nNbrAcquired           0x00A0
    //   UTgInventoryObject_Device::m_nDeviceInstanceId 0x00B0
    //   UTgInventoryObject_Device::m_nStackCount     0x00B8  <-- CARD LEVEL (1..5)
    //   UTgInventoryObject_Device::IsCard()
    //   UTgInventoryObject::SetInstanceCount(int)
    //
    // Equip points of interest: EQP_CARD = 5, EQP_BURN_CARD 8..11 (in-match items).
    //
    // READ FIRST. Card effects are very likely server-calculated (same wall as
    // movement speed), so the local number may change while the effect does not.
    // Enumerating tells us whether the values are even reachable before we write.
    // ########################################################################
    inline void* GetInvManager() {
        __try {
            SDK::APawn* p = Globals::LocalPawn;
            if (!p) return nullptr;
            return *(void**)((char*)p + 0x04DC);   // APawn::InvManager
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // Ask the manager for the inventory object at an equip point.
    inline SDK::UTgInventoryObject* GetInvByEquipPoint(int equipPoint, int itemType) {
        __try {
            void* mgr = GetInvManager();
            if (!mgr) return nullptr;
            return ((SDK::ATgInventoryManager*)mgr)->GetInventoryByEquipPoint(
                (SDK::ETG_EQUIP_POINT)equipPoint, itemType);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // ========================================================================
    // DIRECT DEVICE FIRE  —  the CardsExploit mechanism, reimplemented
    // ========================================================================
    // Static analysis of CardsExploit.dll (see
    // 05_DOCS/06_REVERSE_ENGINEERING/CARDSEXPLOIT_REVERSE_ENGINEERING_REPORT.md)
    // found that of 38 functions it resolves and calls through ProcessEvent, 36
    // are cosmetic (Engine.Canvas.* drawing, TgClient UI). Exactly two are
    // gameplay:
    //
    //     Function TgGame.TgDevice.StartFire
    //     Function TgGame.TgDevice.StopFire
    //
    // Both are invoked bare - the object is an ATgDevice, the params buffer is
    // empty - straight through the same generic wrapper as its Canvas calls.
    //
    // That is the whole trick, and it is notable for what it does NOT do: it
    // never zeroes a cooldown field. It calls the game's own fire function
    // directly, bypassing the normal input path and whatever rate limiting sits
    // on it. No memory patching, no hooks.
    //
    // We do not need their code for this. Both functions are plain
    // parameterless entries in our own SDK dump, so we call them by name the
    // same way every other scripted call in this file works.
    // The SDK's generated ATgDevice::StartFire wrapper declares
    // ATgDevice_StartFire_Params - a struct holding ONE bool - and passes its
    // address to ProcessEvent. But the engine writes fn->ParmsSize bytes there,
    // and ParmsSize is bigger than that struct. The result is the exact error
    // this project already hit once on the skin work:
    //
    //     "stack around the variable 'params' was corrupted"
    //
    // So we do not use the generated wrappers. We resolve the UFunction by name
    // once, hand ProcessEvent a buffer sized from ParmsSize itself, and let the
    // engine write as much as it likes.
    inline SDK::UFunction* g_fnStartFire = nullptr;
    inline SDK::UFunction* g_fnStopFire  = nullptr;

    inline SDK::UFunction* GetFnStartFire() {
        if (!g_fnStartFire)
            g_fnStartFire = SDK::UObject::FindObject<SDK::UFunction>(
                "Function TgGame.TgDevice.StartFire");
        return g_fnStartFire;
    }
    inline SDK::UFunction* GetFnStopFire() {
        if (!g_fnStopFire)
            g_fnStopFire = SDK::UObject::FindObject<SDK::UFunction>(
                "Function TgGame.TgDevice.StopFire");
        return g_fnStopFire;
    }

    inline bool CallDeviceFn(SDK::ATgDevice* dev, SDK::UFunction* fn) {
        __try {
            if (!dev || !fn) return false;
            int need = (int)fn->ParmsSize;
            if (need < 0 || need > 512) return false;   // 512 is far beyond sane
            unsigned char buf[512] = {};
            unsigned long saved = fn->FunctionFlags;
            fn->FunctionFlags |= 0x400;                 // treat as native
            ((SDK::UObject*)dev)->ProcessEvent(fn, buf);
            fn->FunctionFlags = saved;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool DeviceStartFire(SDK::ATgDevice* dev) { return CallDeviceFn(dev, GetFnStartFire()); }
    inline bool DeviceStopFire (SDK::ATgDevice* dev) { return CallDeviceFn(dev, GetFnStopFire()); }

    // UTgInventoryObject_Device::s_Device at +0x00A8 is the live ATgDevice for
    // an inventory entry. This is the same object CardsExploit reads at +0xA8
    // alongside m_nDeviceInstanceId (+0xB0) and m_nStackCount (+0xB8, the card
    // level) when drawing its overlay.
    inline SDK::ATgDevice* GetDeviceFromInvObject(SDK::UTgInventoryObject* obj) {
        __try {
            if (!obj) return nullptr;
            return *(SDK::ATgDevice**)((char*)obj + 0x00A8);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // ATgPawn::GetDeviceByEqPoint - THE route that works on a client.
    //
    // GetInventoryByEquipPoint (via InvManager) returns null in a real match,
    // and UTgInventoryObject_Device::s_Device is server-local, so both of those
    // dead-end on a client. This one is a method on the PAWN and it works: the
    // Call Log tab has been quietly reading every card through it this whole
    // time, in real matches, which is how it was found.
    //
    // Scripted (ProcessEvent), so safe-thread only.
    inline SDK::ATgDevice* GetDeviceByEqPointPawn(int eqPoint) {
        __try {
            if (!Globals::LocalPawn) return nullptr;
            return ((SDK::ATgPawn*)Globals::LocalPawn)->GetDeviceByEqPoint(eqPoint);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // Device id and card level off a device, both replicated.
    inline bool ReadDeviceIdAndPoints(SDK::ATgDevice* d, int* outId, int* outPts) {
        __try {
            if (!d) return false;
            *outId  = d->r_nDeviceId;
            *outPts = d->r_nPointsAllocated;
            return (*outId > 0);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Convenience: slot -> device -> StartFire, in one guarded call.
    inline SDK::ATgDevice* GetDeviceByEquipPoint(int equipPoint, int itemType) {
        SDK::UTgInventoryObject* io = GetInvByEquipPoint(equipPoint, itemType);
        return GetDeviceFromInvObject(io);
    }

    // ========================================================================
    // TELEPORT  —  ATgPawn::Teleport
    // ========================================================================
    // CardsExploit's third hotkey mechanism (report Addendum 6): teleport to
    // the camera's aim point, or to the currently locked target. This is
    // TgGame.TgPawn.Teleport, entry #35 in its resolved-function table.
    //
    // Signature from our own SDK:
    //   bool Teleport(FVector vDest, FRotator rDest, bool bPlayFx,
    //                 int enterState, int exitState, bool bFailOnNoSafeSpot,
    //                 bool bFakeTeleport, FVector* vTeleportLocation)
    //
    // bFailOnNoSafeSpot is left FALSE by default: true makes the engine refuse
    // any destination it cannot validate, which is most interesting places.
    inline bool PawnTeleport(float x, float y, float z, bool playFx, bool failOnNoSafeSpot) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            SDK::FVector dest; dest.X = x; dest.Y = y; dest.Z = z;
            SDK::FRotator rot = p->Rotation;
            SDK::FVector out;
            return p->Teleport(dest, rot, playFx, 0, 0, failOnNoSafeSpot, false, &out);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Current pawn location + view rotation, so a caller can work out where
    // "forward" is without touching the SDK itself.
    inline bool GetPawnPosRot(float* x, float* y, float* z,
                              int* pitch, int* yaw, int* roll) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            *x = p->Location.X; *y = p->Location.Y; *z = p->Location.Z;
            *pitch = p->Rotation.Pitch; *yaw = p->Rotation.Yaw; *roll = p->Rotation.Roll;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ========================================================================
    // AUTO-RESPAWN  —  the chain CardsExploit calls at low health
    // ========================================================================
    // Report Addendum 6: at <=5% HP it calls, in order,
    //   UpdateReviveTimeRemaining -> ServerSetReadyToPlay ->
    //   ClientSetReadyState -> EnterStartState
    // All four are real functions on ATgPlayerController in our SDK. Exposed
    // individually so the sequence can be tested a step at a time - if the
    // server refuses one, we want to know WHICH.
    inline bool UpdateReviveTimeRemaining(float secs) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->UpdateReviveTimeRemaining(secs);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool ClientSetReadyState(bool ready) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ClientSetReadyState(ready);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool EnterStartState() {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->EnterStartState();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Health, for the low-HP trigger.
    inline bool GetPawnHealth(int* cur, int* max) {
        __try {
            SDK::APawn* p = Globals::LocalPawn;
            if (!p) return false;
            *cur = p->Health;
            *max = p->HealthMax;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    struct InvRow {
        void* obj;
        int   equipPoint;
        int   itemType;
        int   refData;        // device/card id
        int   stackCount;     // CARD LEVEL
        int   instanceId;
        int   nbrAcquired;
        bool  temporary;
        bool  isCard;
        char  name[64];
    };

    inline bool ReadInvObject(void* o, InvRow* out) {
        __try {
            if (!o || !out) return false;
            char* b = (char*)o;
            out->obj         = o;
            out->refData     = *(int*)(b + 0x0084);
            out->temporary   = ((*(unsigned long*)(b + 0x0090)) & 1) != 0;
            out->nbrAcquired = *(int*)(b + 0x00A0);
            out->instanceId  = *(int*)(b + 0x00B0);
            out->stackCount  = *(int*)(b + 0x00B8);
            out->name[0]     = '\0';
            // class name, so we can tell Device from the listener subclasses
            SDK::UObject* uo = (SDK::UObject*)o;
            if (uo->Class) {
                auto& names = SDK::FName::GetGlobalNames();
                int idx = uo->Class->Name.Index;
                if (idx > 0 && names.IsValidIndex((size_t)idx)) {
                    SDK::FNameEntry* e = names[idx];
                    if (e && e->GetAnsiName()) lstrcpynA(out->name, e->GetAnsiName(), 64);
                }
            }
            out->isCard = (strstr(out->name, "Device") != nullptr);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Raw write of the card level. Field write only — no scripted call, so it is
    // safe on any thread and cannot throw a params-size problem.
    inline bool SetCardStack(void* o, int stack) {
        __try {
            if (!o) return false;
            *(int*)((char*)o + 0x00B8) = stack;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // The engine's own setter, for comparison — if the raw write is ignored but
    // this one sticks (or vice versa) that tells us where the real state lives.
    inline bool CallSetInstanceCount(void* o, int count) {
        __try {
            if (!o) return false;
            ((SDK::UTgInventoryObject*)o)->SetInstanceCount(count);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // ################  METHOD C — BUILD BY ID, GAME'S OWN BUILDER  #########
    //
    // ATgPawn::CreateMeshComponent(nMeshId, DestComponent, bPartialFixup)
    //   -> "Function TgGame.TgPawn.CreateMeshComponent"   (verified implemented)
    // ATgSkeletalMeshActor::CreateSkeletalMeshComponent(MeshAsmId, Dest, bPartial)
    //
    // Why this is structurally different from A and B:
    //   Method A: change the replicated ID and hope the game rebuilds  -> server reverts
    //   Method B: overwrite the loaded mesh POINTER                    -> broken skeletons
    //   Method C: hand an ID to the game's OWN component builder and let it build
    //             the mesh INTO a component we choose.
    //
    // It satisfies every constraint we derived:
    //   - not a replicated property        -> server has nothing to revert
    //   - the game does the construction   -> correct skeleton, anim tree, materials
    //                                         (no extruded/exploded meshes)
    //   - takes a DESTINATION component    -> body, ARMS or WEAPON, individually
    //   - purely local                     -> only we see it
    //
    // We previously WROTE m_nBodyMeshAsmId and called AddBodyMesh, which re-reads
    // from the skin id and threw our value away. That is why the asm-id path
    // "did nothing". We never once called the builder directly with an id.
    // ########################################################################
    inline SDK::UFunction* g_fnCreateMeshComponent = nullptr;
    inline SDK::UFunction* GetFnCreateMeshComponent() {
        if (!g_fnCreateMeshComponent)
            g_fnCreateMeshComponent = SDK::UObject::FindObject<SDK::UFunction>(
                "Function TgGame.TgPawn.CreateMeshComponent");
        return g_fnCreateMeshComponent;
    }

    // Build meshId into destComponent. destComponent==nullptr lets the game make
    // a fresh one (returned). Manual invoke so a wrong SDK params struct can't
    // overflow the stack (see the ChangeClassModel note above).
    inline void* BuildMeshById(int meshId, void* destComponent, bool partialFixup) {
        SDK::UFunction* fn = GetFnCreateMeshComponent();
        if (!fn || !Globals::LocalPawn) return nullptr;
        unsigned char buf[256];
        ZeroMemory(buf, sizeof(buf));
        *(int*)(buf + 0)      = meshId;
        *(void**)(buf + 8)    = destComponent;   // pointer slot is 8-aligned
        buf[16]               = partialFixup ? 1 : 0;
        __try {
            int need = (int)fn->ParmsSize;
            if (need <= 0 || need > (int)sizeof(buf)) return nullptr;
            unsigned long saved = fn->FunctionFlags;
            fn->FunctionFlags |= 0x400;
            ((SDK::UObject*)Globals::LocalPawn)->ProcessEvent(fn, buf);
            fn->FunctionFlags = saved;
            // Return value sits after the parameters; read it defensively.
            return *(void**)(buf + ((need >= 32) ? 24 : 20));
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // Build a mesh id straight onto the BODY component.
    inline bool BuildBodyFromId(int meshId, bool partialFixup) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p || !p->m_BodyMesh) return false;
            return BuildMeshById(meshId, p->m_BodyMesh, partialFixup) != nullptr
                   || true;   // some builds return void; treat no-crash as success
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Build onto the 1P ARMS (m_HandsMesh) — part 2 of the pipeline.
    inline bool BuildArmsFromId(int meshId, bool partialFixup) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p || !p->m_WeaponMesh || !p->m_WeaponMesh->m_HandsMesh) return false;
            BuildMeshById(meshId, p->m_WeaponMesh->m_HandsMesh, partialFixup);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Build onto the WEAPON (1P or 3P) — part 3, the one that has never worked.
    inline bool BuildWeaponFromId(int meshId, bool firstPerson, bool partialFixup) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p || !p->m_WeaponMesh) return false;
            void* dest = firstPerson ? (void*)p->m_WeaponMesh->m_WeaponMesh1P
                                     : (void*)p->m_WeaponMesh->m_WeaponMesh3P;
            if (!dest) return false;
            BuildMeshById(meshId, dest, partialFixup);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // *** THE WEAPON ROUTE — FOUND ***
    //
    // The weapon is built exactly like the body: from MESH ASSEMBLY IDs.
    //   ATgWeaponMeshActor::m_nDeviceId    0x0348   which weapon (device)
    //   ATgWeaponMeshActor::m_MeshAsmId1P  0x034C   1P mesh assembly id
    //   ATgWeaponMeshActor::m_MeshAsmId3P  0x0350   3P mesh assembly id
    //
    // Compare the body: m_nBodyMeshAsmId 0x07C0 -> assembly -> LoadMesh.
    // Same shape, different owner. That is why every body attempt half-worked and
    // no weapon attempt ever did: we were writing skin IDs at the weapon, when the
    // weapon is driven by ASSEMBLY IDs on its own actor.
    //
    // Read them while wearing a skin (in the range) to LEARN that skin's weapon
    // asm ids, then write them to wear that weapon. Pure field writes — no
    // scripted call, so this is safe on any thread and the server never sees it.
    // ########################################################################
    inline bool ReadWeaponAsmIds(int* device, int* asm1P, int* asm3P) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p || !p->m_WeaponMesh) return false;
            char* w = (char*)p->m_WeaponMesh;
            if (device) *device = *(int*)(w + 0x0348);
            if (asm1P)  *asm1P  = *(int*)(w + 0x034C);
            if (asm3P)  *asm3P  = *(int*)(w + 0x0350);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Write the weapon's assembly ids, then ask the game to rebuild the weapon.
    // UpdateWeaponMesh is the pawn's own weapon rebuild — the game's route.
    inline bool SetWeaponAsmIds(int asm1P, int asm3P, int deviceId, bool rebuild) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p || !p->m_WeaponMesh) return false;
            char* w = (char*)p->m_WeaponMesh;
            if (deviceId > 0) *(int*)(w + 0x0348) = deviceId;
            if (asm1P > 0)    *(int*)(w + 0x034C) = asm1P;
            if (asm3P > 0)    *(int*)(w + 0x0350) = asm3P;
            if (rebuild) {
                p->UpdateWeaponMesh();
                p->ForceUpdate1PMeshes();
                p->ForceRecalculateMaterial();
            }
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ########################################################################
    // WEAPON FORCE-LOADER  — the "Ying's illusion, but for the gun" we never had.
    //
    // ATgGame::EnsureBotPrecache(nBotId, nSkinId, nDeviceSkinId) is the game's own
    // routine to pull a champion's body + WEAPON(device) skin assets into memory.
    // WorldInfo->Game (AGameInfo*) is only valid when you are the host/authority —
    // which is exactly the SHOOTING RANGE (NetMode 0). So this is the tool for the
    // one goal that matters: get the WEAPON to actually load+swap in the range.
    // deviceSkinId = the weapon skin id.
    // ########################################################################
    inline bool EnsureWeaponPrecache(int botId, int skinId, int deviceSkinId) {
        __try {
            if (!Globals::LocalPawn || !Globals::LocalPawn->WorldInfo) return false;
            SDK::AGameInfo* g = Globals::LocalPawn->WorldInfo->Game;   // host/range only
            if (!g) return false;
            ((SDK::ATgGame*)g)->EnsureBotPrecache(botId, skinId, deviceSkinId);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool EnsureDevicePrecache(int deviceId, int deviceSkinId) {
        __try {
            if (!Globals::LocalPawn || !Globals::LocalPawn->WorldInfo) return false;
            SDK::AGameInfo* g = Globals::LocalPawn->WorldInfo->Game;
            if (!g) return false;
            ((SDK::ATgGame*)g)->EnsureDevicePrecache(deviceId, deviceSkinId);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Clean weapon-skin apply: force-load the weapon assets (above), set the
    // pawn's weapon skin id, then let the game rebuild the weapon mesh. This is
    // the missing weapon half of the skin swap, using the game's own pipeline.
    inline bool ApplyWeaponSkin(int botId, int bodySkinId, int weaponSkinId) {
        // Precache OUTSIDE the __try group is fine — it has its own guard.
        EnsureWeaponPrecache(botId, bodySkinId, weaponSkinId);
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            // The 0->target TOGGLE (your body trick, for the weapon). Forcing the id
            // to change value makes the game rebuild the weapon mesh, which resolves
            // the "loaded late = invisible" case once precache has finished.
            if (weaponSkinId > 0) {
                p->r_nWeaponSkinId = 0;
                p->UpdateWeaponMesh();
                p->r_nWeaponSkinId = weaponSkinId;
            }
            p->UpdateWeaponMesh();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Read the live weapon skin id, to see whether an apply took.
    inline int ReadLiveWeaponSkinId() {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return -999;
            return p->r_nWeaponSkinId;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -999; }
    }

    inline bool ApplySkinRebuild(int skinId, int weaponSkinId, bool doWeapon) {
        __try {
            SDK::ATgPawn* p = (SDK::ATgPawn*)Globals::LocalPawn;
            if (!p) return false;
            if (skinId > 0)       p->r_nSkinId = skinId;
            if (doWeapon && weaponSkinId > 0) p->r_nWeaponSkinId = weaponSkinId;
            p->FlashChangeMesh();
            p->AddBodyMesh();
            if (doWeapon) p->UpdateWeaponMesh();
            p->ForceUpdate1PMeshes();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool SpawnBotAllSkins(int nBatch) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->SpawnBotAllSkins(nBatch);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Client-reachable precache, via the replicated GameReplicationInfo.
    inline bool PrecacheSkinById(int nBotId, const wchar_t* skinName,
                                 const wchar_t* weaponSkinName) {
        __try {
            if (!Globals::LocalPawn || !Globals::LocalPawn->WorldInfo) return false;
            SDK::AGameReplicationInfo* gri = Globals::LocalPawn->WorldInfo->GRI;
            if (!gri) return false;
            ((SDK::ATgRepInfo_Game*)gri)->PrecacheClassById(
                nBotId, SDK::FString(skinName), SDK::FString(weaponSkinName));
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Precache a skin BY ID (no asset name needed) via the client-reachable GRI.
    // This is the loader for the A+B combine: feed it the champion's bot id + a
    // skin id from the database and the skin's mesh comes into memory, so Method
    // B's scanner can then LIST it. Call it across many skins to populate the list.
    inline bool TestPrecacheById(int botId, int skinId, int weaponSkinId) {
        __try {
            if (!Globals::LocalPawn || !Globals::LocalPawn->WorldInfo) return false;
            SDK::AGameReplicationInfo* gri = Globals::LocalPawn->WorldInfo->GRI;
            if (!gri) return false;
            ((SDK::ATgRepInfo_Game*)gri)->TestPrecache(botId, skinId, weaponSkinId, false);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool PrecacheSkinByName(const wchar_t* godName, const wchar_t* skinName,
                                   const wchar_t* weaponSkinName) {
        __try {
            if (!Globals::LocalPawn || !Globals::LocalPawn->WorldInfo) return false;
            SDK::AGameReplicationInfo* gri = Globals::LocalPawn->WorldInfo->GRI;
            if (!gri) return false;
            ((SDK::ATgRepInfo_Game*)gri)->PrecacheClassByName(
                SDK::FString(godName), SDK::FString(skinName), SDK::FString(weaponSkinName));
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool SwitchClass(const wchar_t* godName, const wchar_t* skinName,
                            const wchar_t* weaponSkinName) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->SwitchClass(SDK::FString(godName), SDK::FString(skinName),
                              SDK::FString(weaponSkinName));
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Short console alias for SwitchClass. Worth having separately: aliases are
    // sometimes wired to a different (less gated) handler than the long name.
    inline bool sc(const wchar_t* godName, const wchar_t* skinName,
                   const wchar_t* weaponSkinName) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->sc(SDK::FString(godName), SDK::FString(skinName),
                     SDK::FString(weaponSkinName));
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Forces the skin's assets to load. Run this BEFORE SwitchClass.
    inline bool PrecacheClass(const wchar_t* godName, const wchar_t* skinName,
                              const wchar_t* weaponSkinName) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->PrecacheClass(SDK::FString(godName), SDK::FString(skinName),
                                SDK::FString(weaponSkinName));
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ID-based precache — an alternative if the name strings don't resolve.
    inline bool TestPrecache(int nBotId, int nSkinId, int nWeaponSkinId, bool bAll) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->TestPrecache(nBotId, nSkinId, nWeaponSkinId, bAll);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Direct mesh setters. SetBodyMesh is the body/skin mesh by asset id; the
    // pawn carries the matching m_nBodyMeshAsmId (0x07C0) and m_n1PHeadMeshId.
    inline bool SetBodyMesh(int nBodyMeshID) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->SetBodyMesh(nBodyMeshID);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool SetHeadMesh(int nHeadMeshID) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->SetHeadMesh(nHeadMeshID);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // "Hidden developer item shop" candidates. TestShowInventory is the closest
    // literal match for what was described; the store-landing toggles sit right
    // beside it in the class and are about showing items you can't obtain.
    inline bool TestShowInventory() {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->TestShowInventory();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TestSkinGallery(int nGallery) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->TestSkinGallery(nGallery);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool ToggleShowAllStoreLandingItems() {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->ToggleShowAllStoreLandingItems();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool ToggleShowUnobtainableStoreLandingItems() {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->ToggleShowUnobtainableStoreLandingItems();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ------------------------------------------------------------------------
    // VENDOR STORE CONFIG — the strongest "hidden dev FILE" candidate.
    //
    // UTgClientSettings::VendorStoreTabId / VendorStoreTypeId /
    // VendorStoreTypeRecId are all marked (Edit, Config, GlobalConfig), which
    // means they are read from an .ini on disk. And here is the telling part,
    // checked against the real install:
    //
    //   ChaosGame/Config/DefaultGame.ini  [TgGame.TgClientSettings]
    //     VendorStoreTabId=0
    //     VendorStoreTopTier=true
    //   ... and VendorStoreTypeId / VendorStoreTypeRecId are ABSENT.
    //
    // Two of the three vendor-store settings exist in the class but were never
    // written to the config. Unused store type ids are exactly where a hidden
    // developer store would live. Writing them at runtime is cheaper than
    // editing game files, and reversible.
    //
    // Honest status: a lead, not a confirmed method.
    // ------------------------------------------------------------------------
    inline bool SetVendorStore(int tabId, int typeId, int typeRecId,
                               bool writeTab, bool writeType, bool writeRec) {
        __try {
            SDK::UTgClientSettings* cs =
                ((SDK::ATgPlayerController*)Globals::LocalController)->STATIC_GetClientSettings();
            if (!cs) return false;
            if (writeTab)  cs->VendorStoreTabId = tabId;
            if (writeType) cs->VendorStoreTypeId = typeId;
            if (writeRec)  cs->VendorStoreTypeRecId = typeRecId;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Reads them back, so the UI can show what is actually in there rather than
    // what we hoped we wrote.
    inline bool GetVendorStore(int* tabId, int* typeId, int* typeRecId) {
        __try {
            SDK::UTgClientSettings* cs =
                ((SDK::ATgPlayerController*)Globals::LocalController)->STATIC_GetClientSettings();
            if (!cs) return false;
            *tabId = cs->VendorStoreTabId;
            *typeId = cs->VendorStoreTypeId;
            *typeRecId = cs->VendorStoreTypeRecId;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool RefreshStoreLandingItems() {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)
                ->RefreshStoreLandingItems();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Generic command execution on the server. NOTE: this one lives on the
    // CheatManager, not the PlayerController — but unlike the CheatManager's
    // purely-local commands, it's `server`-marked, so it forwards to the
    // server. Probably admin-gated; decisive if it isn't.
    inline bool ServerExec(const wchar_t* command) {
        __try {
            ((SDK::UTgBattleCheatManager*)Globals::LocalController->CheatManager)->ServerExec(SDK::FString(command));
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // The game's OWN fire-mode switch. We had been writing CurrentFireMode /
    // m_PendingFireMode / m_nDesiredFireMode raw, which skips everything this
    // function does internally (ammo pool rebinding, effect groups, animation
    // state). That missing setup is the most likely cause of "switched a mode,
    // crashed shortly after" on abilities outside the known-good list — the
    // engine later reads state we never initialised. Going through the real
    // function lets it do its own bookkeeping.
    //
    // NOTE: this is a scripted call, so it MUST be invoked from the
    // ProcessEvent thread (deferred pending-request pattern), never from a
    // button/render-thread context.
    inline bool SetFireMode(SDK::ATgDevice* device, int mode, bool forceSet) {
        __try {
            if (!device) return false;
            device->SetFireMode(mode, forceSet);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // INSTANT RESPAWN. A real `server`-marked RPC on the PlayerController — the
    // same function the game itself calls when you click "ready" on the death
    // screen. Because it's a server RPC (not a CheatManager command), it is NOT
    // admin/standalone-gated, so unlike almost everything else it has a genuine
    // chance of working at NetMode 3. Only meaningful while you're dead.
    // ---- CLIENT-SIDE RESPAWN TIMER ----
    // ATgPlayerController::c_fRespawnTime (0x0A10). The "c_" prefix is this
    // codebase's convention for a CLIENT-CACHED value (cf. c_fOldRemoteStamina,
    // c_bUseSecondDeathAnim), i.e. not replicated authority — a local countdown
    // the client keeps for its own UI/gating.
    //
    // Worth attacking because if the CLIENT is what refuses to send the respawn
    // request until this reaches zero, then zeroing it lets the request go out
    // immediately — and ServerSetReadyToPlay is a legitimate RPC the server
    // already expects, so it isn't being asked to accept anything unusual.
    // If instead the server keeps its own clock, this changes nothing. Reading
    // it live tells us which.
    inline float GetClientRespawnTime() {
        __try {
            if (!Globals::LocalController) return -1.0f;
            return ((SDK::ATgPlayerController*)Globals::LocalController)->c_fRespawnTime;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1.0f; }
    }

    inline bool SetClientRespawnTime(float v) {
        __try {
            if (!Globals::LocalController) return false;
            ((SDK::ATgPlayerController*)Globals::LocalController)->c_fRespawnTime = v;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Jump height. A `server` RPC about YOUR OWN pawn — the category that works.
    // TELEPORT. AActor::SetLocation is the engine's own move primitive and
    // returns false if the destination is blocked, so it won't shove you into
    // geometry. Position is the one thing the client genuinely declares
    // (ServerMove reports where you ended up), which is why this has a real
    // chance — unlike GroundSpeed, which is a stat the server owns.
    inline bool SetPawnLocation(float x, float y, float z) {
        __try {
            if (!Globals::LocalPawn) return false;
            SDK::FVector v; v.X = x; v.Y = y; v.Z = z;
            return Globals::LocalPawn->SetLocation(v);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool GetPawnLocation(float* x, float* y, float* z) {
        __try {
            if (!Globals::LocalPawn) return false;
            SDK::FVector v = Globals::LocalPawn->Location;
            *x = v.X; *y = v.Y; *z = v.Z;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool ServerSetJumpZ(float newJumpZ) {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerSetJumpZ(newJumpZ);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool ServerSetReadyToPlay() {
        __try {
            ((SDK::ATgPlayerController*)Globals::LocalController)->ServerSetReadyToPlay();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ---- THE CORRECT CONTROLLER MECHANISM ----
    // UPlayerInput::aTurn / aLookUp are the engine's ANALOG AXIS inputs (flagged
    // `(Input)` in the SDK) — literally the values a controller's right stick
    // writes into. Feeding these is how a stick turns the view, so the game's own
    // UpdateRotation() consumes them naturally instead of fighting us.
    //
    // This is why setting Rotation directly failed: we were writing the RESULT
    // while the engine recomputed it from these INPUTS every tick. Write the
    // input instead and the engine does the work.
    //
    // IMPORTANT: the engine consumes and clears these each tick, so they must be
    // rewritten every frame for continuous movement — which is exactly what
    // hold-to-turn needs anyway.
    inline bool SetLookAxes(float turn, float lookUp) {
        __try {
            if (!Globals::LocalController) return false;
            SDK::UPlayerInput* pi = Globals::LocalController->PlayerInput;
            if (!pi) return false;
            pi->aTurn = turn;
            pi->aLookUp = lookUp;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool HasPlayerInput() {
        __try {
            return Globals::LocalController && Globals::LocalController->PlayerInput != nullptr;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ---- View rotation (fallback approach, kept for diagnosis) ----
    // Why SendInput/mouse_event didn't work: the game reads raw input and drives
    // its view through UpdateRotation() every tick, so a synthetic mouse move (or
    // a raw write to the Rotation field) gets overwritten on the very next frame.
    // ClientSetRotationAndDesired sets the current AND the desired rotation, which
    // is what makes it actually stick.
    //
    // Rotator units: 65536 == 360 degrees, so 1 degree == ~182.04 units.
    inline bool GetViewRotation(int* outPitch, int* outYaw, int* outRoll) {
        __try {
            if (!Globals::LocalController) return false;
            SDK::FRotator r = Globals::LocalController->Rotation;
            *outPitch = r.Pitch; *outYaw = r.Yaw; *outRoll = r.Roll;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool SetViewRotation(int pitch, int yaw, int roll) {
        __try {
            if (!Globals::LocalController) return false;
            SDK::FRotator r; r.Pitch = pitch; r.Yaw = yaw; r.Roll = roll;
            ((SDK::ATgPlayerController*)Globals::LocalController)->ClientSetRotationAndDesired(r, false);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Fallback: raw field write. Kept because if ClientSetRotationAndDesired is
    // refused or does nothing, this tells us whether the field itself is even
    // writable — two different failure modes worth telling apart.
    inline bool SetViewRotationRaw(int pitch, int yaw, int roll) {
        __try {
            if (!Globals::LocalController) return false;
            Globals::LocalController->Rotation.Pitch = pitch;
            Globals::LocalController->Rotation.Yaw = yaw;
            Globals::LocalController->Rotation.Roll = roll;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline int PushCameraPosture(SDK::ETG_CAMERAPOSTURE posture) {
        __try {
            return ((SDK::ATgPlayerController*)Globals::LocalController)->PushCameraPosture(posture);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return -1;
        }
    }

    inline bool PopCameraPosture(int stackId) {
        __try {
            return ((SDK::ATgPlayerController*)Globals::LocalController)->PopCameraPosture(stackId);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // ---- MATCH-STATE DETECTION -------------------------------------------
    // UE3 keeps the authority model on AWorldInfo::NetMode, and every AActor
    // carries a WorldInfo pointer, so the local controller is the cheapest way
    // in. The distinction we care about:
    //   NM_Standalone(0) = WE are the server  -> shooting range / local
    //   NM_Client(3)     = a real server owns replication -> real match
    // That is the exact same split that decides whether writing a (Net)
    // property sticks, which is why the skin work keeps running into it.
    inline bool TryReadNetMode(int* outMode) {
        __try {
            if (!Globals::LocalController) return false;
            SDK::AWorldInfo* wi = ((SDK::AActor*)Globals::LocalController)->WorldInfo;
            if (!wi) return false;
            *outMode = (int)wi->NetMode.GetValue();   // TEnumAsByte -> ENetMode -> int (two hops)
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // ---- CONSOLE COMMAND -------------------------------------------------
    // APlayerController::ConsoleCommand(FString, bool). FString here borrows the
    // caller's buffer and has no destructor, so it is SEH-safe (same pattern as
    // ServerSetValue above). The return value is ignored deliberately - binding
    // it would introduce an object with a lifetime into the __try scope.
    inline bool RunConsoleCommand(const wchar_t* cmd) {
        __try {
            if (!Globals::LocalController) return false;
            Globals::LocalController->ConsoleCommand(SDK::FString(cmd), false);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }
}
