#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include <Windows.h>
#include <shellapi.h>

// ============================================================================
// FEATURE IDEAS  —  the open to-do list
// ============================================================================
// PHAROAH is open source. This tab is the handover: everything tried, half
// tried, or thought about and never started. Anyone who wants to take one of
// these further has the code to do it with.
//
// Written as leads, not promises. Where something is known not to work, it says
// so and says why - a dead end you can read is worth more than a blank page.
// ============================================================================

namespace FeatureIdeas {

    inline void Link(const char* label, const char* url, const char* note) {
        if (ImGui::Button(label, ImVec2(210, 26)))
            ShellExecuteA(nullptr, "open", url, nullptr, nullptr, SW_SHOWNORMAL);
        ImGui::SameLine();
        ImGui::TextDisabled("%s", note);
    }

    inline void Bullet(const char* title, const char* body) {
        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.45f, 0.80f, 1.00f, 1.0f)));
        ImGui::TextUnformatted(title);
        ImGui::PopStyleColor();
        ImGui::TextWrapped("%s", body);
    }

    inline void DrawControls(bool /*inMatch*/) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("FEATURE IDEAS  -  an open to-do list");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("PHAROAH is released as-is. These are the leads worth picking up next - "
            "for me, or for anyone who forks it. The code is open, so none of this is gatekept.");
        ImGui::Separator();

        // ---- links ----
        ImGui::Spacing();
        Link("PHAROAH Discord", "https://discord.com/invite/WNtne3YauG",
             "Questions or need help? Hit me up.");
        Link("YouTube", "https://www.youtube.com/@Primal_Monke/videos",
             "Videos and demos.");
        Link("Vibe reversing guide", "https://pastebin.com/0HKTGv9M",
             "Hook an MCP to VS Code and reverse away.");

        ImGui::Spacing();
        ImGui::Separator();

        // ---- the near-misses ----
        if (ImGui::CollapsingHeader("Close, but not solved", ImGuiTreeNodeFlags_DefaultOpen)) {
            Bullet("Recolouring enemy outlines",
                "ODIN can make every enemy outline show through walls in yellow. That means the "
                "outline colour IS reachable somewhere. Find the mechanism it uses and the same "
                "handle very likely allows recolouring them freely. This is the one I most wanted "
                "and never got.");

            Bullet("Method A skins in real matches",
                "Writing r_nSkinId plus forcing a mesh rebuild works in the shooting range and "
                "not in a real match. Shooting range is NetMode 0, where you are the server. The "
                "card-maxxer fails on the same boundary - so whatever explains one very likely "
                "explains the other, and solving either probably solves both.");

            Bullet("Chests via an overflow",
                "Chest opening is gated on a client-side comparison of the shape (owned >= needed). "
                "Feeding it a negative value should invert that test. I also managed to make every "
                "chest display 5 instead of 1, which suggests the count is writable and worth "
                "pushing further.");
        }

        // ---- untried ----
        if (ImGui::CollapsingHeader("Untried leads", ImGuiTreeNodeFlags_DefaultOpen)) {
            Bullet("Spam-applying talents",
                "Cards can be re-triggered by firing their device. Talents are devices too. The "
                "same approach should apply to any talent effect - it has simply not been tested.");

            Bullet("Unlocking all champions on injection",
                "No champion-ownership flag was found anywhere in the SDK - m_bUnlocked and "
                "m_bOwned belong to a battle-pass level and a health-bar overlay, not champions. "
                "The method must exist somewhere; it is not where the obvious names suggest.");

            Bullet("The Cassie ultimate / leave interaction",
                "Casting Cassie's ultimate and then leaving ends the match. If the mechanism behind "
                "that can be isolated, it becomes a single button - and a genuinely useful one "
                "against people ruining lobbies.");

            Bullet("Vatu predictive aiming",
                "Vatu's daggers fire in sequence, left to right. Given the distance to a target, "
                "the target's direction and speed, dagger travel speed, and how far each dagger "
                "spreads from the leftmost per unit of distance, an algorithm could land all three "
                "at any range. Reference: youtu.be/4OELh_2MZqc");

            Bullet("Switching champions mid-match",
                "The way Overwatch allows. Whether the server permits it at all is unknown.");
        }

        // ---- how to help ----
        if (ImGui::CollapsingHeader("Taking one of these on")) {
            ImGui::TextWrapped("This list is meant to be edited. Pick one, work on it, add what you "
                "learn - including the failures, which are worth as much as the wins.");
            ImGui::Spacing();
            ImGui::TextWrapped("The code can be confusing in places. Feel free to drop it into an AI "
                "to help you read it; that is how a good deal of it was written.");
            ImGui::Spacing();
            ImGui::TextWrapped("I may keep updating this myself, but purely for fun. The tool is "
                "finished enough to use and free for anyone to take further.");
        }
    }
}
