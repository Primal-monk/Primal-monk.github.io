# PHAROAH — modification mapping

What kind of problem is each feature, actually? A running catalogue, sorted
by the underlying mechanism instead of by feature name. The idea: given a
plain-English description of what something does, know immediately which
category it falls in — because the category tells you what's actually
possible, what's client-only, what needs the server to cooperate, and what
kind of bug (if any) would need to exist for it to work at all.

Six categories, from PRIMAL_MONKE's own framing:

1. Local memory/state manipulation
2. Engine/object/function manipulation
3. Client/server authorization problem
4. Matchmaking/session/bot/account architecture
5. Replication/malformed-input/state-transition/resource-exhaustion (server crash class)
6. Moderation backend / identity / report-ingestion

---

## 1. Local memory/state manipulation

**"I changed a value in my own process's memory, and only my own client's
rendering changed."**

Nothing leaves the machine. The server never finds out, because there was
never a message to send it. This is the safest category by construction —
it cannot be "caught" in the sense of a server log flagging it, because the
server has no visibility into it at all. It's also the *weakest* category:
it can only ever change what YOU see, never what anyone else sees.

Examples already in this codebase:
- **Grayscale / desaturation** (`RecoverySuite::ApplyGrayscale`) — a local
  visual filter.
- **Boxes / skeletons / prediction box** (`VisibilityBoxes.h`) — reads
  positions already sent to your client for normal gameplay reasons (you
  need to know where nearby players are to render them), and draws extra
  UI on top. Nothing is asked of the server that it wasn't already sending.
- **Skins (Method A/B)** — writes directly into a pawn's mesh/material
  pointers on YOUR client. `PRIMAL_MONKE` already knows this doesn't apply
  in real matches for other viewers — see category 3 for why.
- **The 4th Talent picker's camera nudge**, `ProcessAimAssist` — a plain
  float write to your own view rotation.

---

## 2. Engine/object/function manipulation

**"I made the game execute an Unreal function I chose, with arguments I
chose."**

One level up from category 1: instead of just poking a value, you're
calling a real UFunction the game itself would call, through the same
`ProcessEvent` dispatch the engine uses internally. Whether this stays
client-only or reaches the server depends entirely on whether the function
you called is a client-local convenience (draws something, changes a
setting) or an RPC that the client is *allowed* to fire toward the server.

Examples:
- **Fire Modes** — calling the weapon's own mode-switch function.
- **`SafeCalls::RunConsoleCommand`** (Leave Match) — `ConsoleCommand` is a
  real engine entry point, not a hack; "disconnect" is the same command a
  developer console would use.
- **`Unlocker.h`'s item-unlock write** — technically closer to category 1
  (a raw field write, `UUIDataItem::m_qwInventorySessionId`), but it's
  listed here too because the WHY only makes sense with engine knowledge:
  it works because `UUIDataItem` is the shared base class for every
  cosmetic type (skins, titles, avatars, MVP poses), so one field, one
  write pattern, unlocks all of them at once — that's an object-model fact,
  not a memory-address coincidence.
- **The talent/emote pickers** — `decks->m_nTalent = id`,
  `skinComp->m_pSelectedEmote->m_nId = id`. Raw field writes on live engine
  objects, same category as the unlocker.

**The dividing line to category 3**: does the function/field you touched
also need the SERVER to agree with what you just did? If yes, you're really
doing a category-3 thing that happens to be *implemented* as a category-2
call.

---

## 3. Client/server authorization problem

**"I got the client to accept/show something the server never actually
granted — but only locally, or only until the server checks."**

This is the category that answers "why does X work but Y doesn't," and it's
the one worth understanding best, because it explains almost every
disappointment in this project's own history.

The pattern: some piece of state is **client-authoritative** (the client
decides, the server just trusts whatever the client says) versus
**server-authoritative** (the server is the source of truth, and the client
is just displaying a copy). Client-authoritative state is exploitable and
VISIBLE TO OTHERS. Server-authoritative state, faked locally, is exploitable
but INVISIBLE TO OTHERS — you see it, nobody else does, because everyone
else's client is asking the server directly, not trusting anything your
client said.

Confirmed examples, this project:
- **Skins in a real match**: server-authoritative for what OTHER players
  see you wearing. Your own local fake shows on your own screen; nothing
  propagates. (Confirmed by testing, matches the architecture.)
- **The `r_nEquippedTitleId` title field**: marked `(Net)` in the SDK dump
  — i.e. server-replicated. The same shape of problem as skins. A local
  write is very likely self-view-only, same reasoning, same caveat: not
  confirmed by a live two-client test, just architecturally consistent
  with skins.
- **Chests (`Unlocker.h`'s `MODE_CHESTS_ONLY`)**: confirmed a dead end for
  exactly this reason — "unlocking" a chest client-side doesn't make the
  server actually GRANT its contents. The grant is server-authoritative;
  the unlock flag is not.
- **The "verified player" checkmark** — `bIsVerifiedPlayer` on
  `UUIDataPlayer` / `UUIData_PlayerMatchRecord`. Same shape as titles: these
  are UI-data objects, populated per-viewer (almost certainly from a
  backend profile lookup, not live network replication in the traditional
  sense) — meaning every OTHER player who looks at your profile very likely
  builds their OWN copy of that data independently, from the same backend
  truth, unaffected by anything your client did locally. **Built into
  `Unlocker.h` (`RunCheckmarkPass()`)**, riding the exact same GObjects
  walk the item unlocker already does every 5 seconds — no separate toggle,
  runs automatically. Ships with the self-view-only caveat stated plainly
  in the tab itself; not confirmed to show to others, and per PRIMAL_MONKE's
  call, not chasing the `UTgChatData::m_bSenderIsVerifiedPlayer` chat
  variant further (would have needed the packet logger, which is out of
  scope now).

**How to tell which kind you're looking at, without a live test:** in this
SDK dump, a field tagged `(Net)` is UE's own replication system — the
server pushes it to every relevant client automatically, so faking it
locally is almost always self-view-only (the server's value will
eventually — or immediately — overwrite yours, and other clients are
getting THEIR copy from the server, not from you). A `UUIData*`-prefixed
class populated for a UI screen (profile, scoreboard, chest opening) is
usually built fresh each time that screen loads, likely from a backend
service call — same practical conclusion (self-view-only) but for a
different reason (nobody else ever reads YOUR local copy of it at all).
The one thing that reliably crosses to other clients is something your
own client SENDS as an outbound message the server relays close to
verbatim (chat text, certain cosmetic selections at champion-select time
that then get broadcast) — those are worth a second look each time,
individually, because "sent" and "received-and-trusted-as-is" is not
automatic even then.

---

## 4. Matchmaking/session/bot/account architecture

**"I made five players appear in one match" / "can a bot take over while
I'm still connected and watching?"**

This category is about the shape of a MATCH itself — who's in it, how they
got there, what happens when someone leaves — rather than about any single
value. It's the hardest category to affect from a client DLL, because
session/matchmaking/bot-assignment logic overwhelmingly lives on
infrastructure the client never touches directly (the server, and likely a
separate matchmaking service the game server talks to, not the client).

**Researched this session — bot replacement on disconnect.** Confirmed the
actual class hierarchy exists in the SDK:
```
ATgAIController_BehaviorGod
  -> ATgAIController_BehaviorGodDisconnected
       -> ATgAIController_BehaviorGodDisconnectedStillBot
```
Reading the naming straight: a disconnected player's pawn gets a
`BehaviorGodDisconnected` AI controller first (a state that still
implies "might reconnect"), and if that doesn't happen in time, it steps up
to `BehaviorGodDisconnectedStillBot` ("permanently a bot for the rest of
this match"). There's also `AController::SwapToNewAIController(...)`,
which reads like the actual swap function.

**The honest conclusion: this is almost certainly server-authoritative,
triggered by a genuine dropped connection, not something a client can
request while staying connected.** `SwapToNewAIController` takes a
controller and a pawn and swaps who's possessing what — that's exactly the
kind of decision that has to live on the server in an authoritative
multiplayer game (the server owns who controls what; a client asking to
be replaced by a bot while still receiving the game state is not something
this architecture appears to support — there's no "soft disconnect, stay
observing" channel visible anywhere in the SDK, and `LeaveMatch.h`'s own
prior research only ever found the real, full `disconnect` console command,
which severs everything, including your own view). **Bottom line: no
credible path found to "bot takes over, I keep watching," and the
architecture actively argues against one existing.**

Separately, worth being direct about: even if a legitimate "let a bot take
over temporarily" trigger existed, using it to farm XP/currency from
AFK/bot-piloted matches is the kind of thing publishers commonly treat as
reward-abuse independent of any "hacking" concern — it's a policy risk on
top of the technical one, worth knowing going in.

**Follow-up, same session — reconnect-to-match IS real.** PRIMAL_MONKE's
next question: not "stay watching," but "leave, then rejoin the SAME
match later." Different question, and the SDK answers it more directly:
`ClientReconnected()`, `OnPlayerReconnected()`, `DespawnOnReconnect()`, and
`m_nRejoinQueueTimerCBHandle` ("rejoin QUEUE, with a TIMER") all exist. This
is a genuine, sanctioned feature — Tempest already supports leaving and
coming back to an in-progress match, the same way most competitive shooters
handle a real network drop. **No hack needed for the reconnect leg itself**
— it's presumably just the game's own normal client flow noticing you have
an active match and offering to rejoin it.

What this DOES confirm is achievable: disconnect (bot takes over, per the
finding above), do something else, reconnect later through the game's own
normal flow, resume control. What it does NOT resolve: whether time spent
under bot control actually earns XP/currency at all (no evidence either
way — plenty of games explicitly detect and zero out bot-piloted time for
exactly this reason), and the reward-abuse policy risk noted above still
applies regardless of the technical answer.

Other things in this category, for the map (not investigated yet):
- "5 players in one match" — would require the client to convince
  matchmaking/session logic of something false about the lobby; almost
  certainly server-side, no lead yet.
- Account-level stuff (unlocks that persist account-wide rather than
  per-session) — different question from anything above; not investigated.

---

## 5. Replication / malformed-input / state-transition / resource-exhaustion (the "I made everybody disconnect" class)

**"Something I did (or something that just HAPPENED) took the whole server
down, not just my own client."**

This is the most serious category by consequence and the one most worth
handing to Tempest's own moderation/dev team rather than exploiting: a bug
here means the SERVER PROCESS ITSELF has a crash or hang condition, which
is a genuine reliability bug in Tempest's fork, not a client-side trick.

**Researched this session — the Cassie-ult-then-disconnect crash.**
PRIMAL_MONKE's report: casting Cassie's ultimate changes something visible
to every player (their words: "everyone's outlines visible/change color"),
and if Cassie disconnects specifically while that effect is still active,
the whole match ends immediately for everyone — but leaving normally, or
disconnecting outside that window, doesn't do this.

Found the mechanism family that fits: `ATgPlayerController::SetOutlines(bool
bFriendly, bool bEnemy)` — a per-controller function, meaning something
(very plausibly Cassie's ultimate) has to reach out and call this on OTHER
players' controllers to make everyone see enhanced outlines while it's
active, then presumably call it again (or something adjacent) to turn it
back off when the ultimate ends.

**The working hypothesis**, stated precisely enough to hand to a developer:
Cassie's ultimate likely holds a reference to its own owner (the Cassie
pawn/controller) for the duration of its effect, so that when the effect
ENDS NORMALLY it knows whose ability this was, for cleanup (turning
outlines back off, ending the effect cue, etc). If the owning player
disconnects WHILE that effect is still active, the ability's end/cleanup
logic runs later against a now-destroyed owner reference — a null/dangling
pointer dereference **on the server**, which is why it doesn't just glitch
locally, it crashes the shared server process and drops every connected
client at once. This is exactly PRIMAL_MONKE's own read of it ("some
dependency that relies on them being there breaks"), and it is a textbook
example of category 5: a state-transition the code didn't anticipate
(ability owner disappearing mid-effect), not a client exploit.

**This is not confirmed** — it's a structurally sound hypothesis built from
what the SDK's function/class shapes imply, not from having reproduced and
observed the actual crash. Confirming it needs a live repro with logging:
timestamp Cassie ultimate start, timestamp the disconnect, timestamp the
server drop, and see if the drop only happens inside that window (matching
the report) or if it's actually a different trigger.

**The ANTI-CHEAT tab exists now** (`RecoverySuite::DrawAntiCheatTab`), built
as a proof-of-concept per PRIMAL_MONKE's direct ask, alongside a broader
"can a match — or one player in it — be ended on purpose" investigation
that came out of the same conversation:

- **Match roster**: lists every ally/enemy currently loaded as a pawn (name
  + champion), reusing `VisibilityBoxes::g_CachedGather` — the same cache
  Highlights/aim-lock already build every frame, so this is free, not a new
  scan. Only covers players once a match has actually started; pre-match/
  queue visibility (seeing opponents before the match begins) needs the
  matchmaking/lobby scene, not yet found.
- **Kick a specific player — investigated, closed off.** `AGameInfo::Kick`
  / `ForceKickPlayer` exist in the SDK, but `AGameInfo` is server-only in
  UE3's model; a client never holds a valid instance to call through. No
  path found.
- **End the match for everyone via surrender — real RPC, CONFIRMED NOT
  WORKING.** `ATgPlayerController::ServerSurrender(bool)` is the actual
  client RPC the game's own surrender-vote UI fires (`SafeCalls::ServerSurrender`,
  "Send surrender vote" button in the tab). PRIMAL_MONKE tested this live in
  a bot match and it had no visible effect at all — not gated by time/mode
  in any way that mattered, genuinely a dead end as the primary method.
  Left wired up (it's still a real, legitimate RPC and costs nothing to
  leave available) but no longer the plan.
- **End the match for everyone via CheatManager — new lead, wired up,
  untested live.** `UTgBattleCheatManager::EndGame()` and
  `QuickEndGame(bool bWin)`, reached through
  `APlayerController::CheatManager` (`SafeCalls::CheatManagerEndGame`,
  `SafeCalls::CheatManagerQuickEndGame` — three buttons now in the tab:
  EndGame(), QuickEndGame(win), QuickEndGame(lose)). CheatManager is
  architecturally different from every dead end found so far
  (`AGameInfo`/`ATgGame_Mission`) because it is genuinely CLIENT-SIDE —
  every `APlayerController` carries one as a real, non-`(Net)` field
  (offset `0x590`, `Transient`). Both functions are dumped straight from
  the shipped binary as `(Defined, Exec, Public)`, meaning the
  console-command flag survived into the shipped client — the strongest
  signal found yet that these are reachable at all, though not proof the
  function body still does anything once cheats-gating (if any) is
  checked inside it. The tab now also reads whether `CheatManager` is
  non-null live, so a test tells apart "not reachable at all" from
  "reached it, did nothing" — worth knowing which, if either happens.

This directly answers PRIMAL_MONKE's framing that "A and B likely share a
mechanism, and we'll get A first": A (end for everyone) now has TWO wired-up
attempts — one confirmed dead, one new and untested — rather than one
theoretical RPC. B (end for one specific player) still has a confirmed dead
end (`AGameInfo` is unreachable) and no other lead — every function found
that plausibly does per-player removal lives on a server-only actor.

Other things that belong in this category, not yet investigated:
- Malformed input crashes in general (anything that crashes the server via
  a bad RPC payload) — a much bigger, more dangerous research area, not
  touched.
- Resource exhaustion (spamming something until the server falls over) —
  not investigated, and notably NOT something to go looking for casually;
  this is the one sub-class of bug that most resembles a real DoS attack
  regardless of intent.

---

## 6. Moderation backend / identity / report-ingestion

**"I got someone suspended through reports" / anything touching how
Tempest's trust-and-safety systems decide who gets flagged.**

Not investigated this session, and flagged here mainly to name it as its
own category rather than lump it into #5. This is backend/account-service
territory, furthest from anything a client DLL can observe or influence
directly — any finding here would almost certainly come from a completely
different kind of research than everything above.

---

## How to use this file

When something new comes up, ask: **what has to be true on the SERVER for
this to work?**
- Nothing → category 1.
- "The engine has to run this exact function" → category 2.
- "The server has to accept/display something it didn't actually grant" →
  category 3, and the very next question is whether the field is `(Net)`-
  replicated or UI-data-populated, per the section 3 rule of thumb.
- "The server has to be convinced about who's IN the match or WHO controls
  a pawn" → category 4.
- "The server has to actually fall over or drop everyone" → category 5,
  handle with more care, and lean toward reporting rather than exploiting.
- "Tempest's trust/safety pipeline has to be fooled" → category 6.

Update this file as new features get built or new research lands — it's
meant to keep growing, and it's meant to ship in `OPENSOURCE/` eventually
once it's more filled in.
