#pragma once

template<typename T>
static T GetCallAddress(void* address) {
	signed __int32 relative = *(signed __int32*)((unsigned __int64)address + 1);
	void* absolute = (void*)((unsigned __int64)address + relative + 5);
	return reinterpret_cast<T>(absolute);
}

template<typename T>
static T GetMovAddress(void* address) {
	signed __int32 relative = *(signed __int32*)((unsigned __int64)address + 3);
	void* absolute = (void*)((unsigned __int64)address + relative + 7);
	return reinterpret_cast<T>(absolute);
}

// NOTE: these read a 32-bit immediate out of an instruction and hand it back as
// T. reinterpret_cast<T>(relative) is illegal on x64 when T is a pointer —
// "conversion from 'int' to 'void *' of greater size" — because reinterpret_cast
// won't widen. Widen explicitly first (zero-extend, matching what the 32-bit
// behaviour would have been), then convert. Value is unchanged.
template<typename T>
static T GetMovValue(void* address) {
	signed __int32 relative = *(signed __int32*)((unsigned __int64)address + 1);
	return (T)(unsigned __int64)(unsigned __int32)relative;
}

template<typename T>
static T GetAndValue(void* address) {
	signed __int32 relative = *(signed __int32*)((unsigned __int64)address + 2);
	return (T)(unsigned __int64)(unsigned __int32)relative;
}