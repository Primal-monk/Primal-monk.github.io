#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "menus/SkinSwap.h"
#include "menus/CardsTab.h"
#include "menus/InstantReload.h"
#include "menus/CameraTools.h"
#include "menus/LogoTexture.h"
#include <Windows.h>

// ============================================================================
// TEST REPORT — one button that copies everything needed to diagnose a failure
//
// The point: instead of going back and forth ("did it say SENT?", "what was the
// skin id?"), press one button and paste the result. Every number here is one
// that has actually mattered while debugging this project.
//
// It writes to the clipboard rather than a file, because a file means finding it.
// ============================================================================

namespace TestReport {

    inline char g_Buf[4096];
    inline bool g_Copied = false;

    inline void Append(const char* s) {
        lstrcatA(g_Buf, s);
    }

    inline void Line(const char* fmt, int a = 0, int b = 0, int c = 0) {
        char tmp[256];
        wsprintfA(tmp, fmt, a, b, c);
        lstrcatA(g_Buf, tmp);
        lstrcatA(g_Buf, "\r\n");
    }

    inline void Build(bool inMatch) {
        g_Buf[0] = '\0';
        Append("===== PHAROAH TEST REPORT =====\r\n");

        Line("In match             : %d", inMatch ? 1 : 0);
        Line("LocalPawn present    : %d", Globals::LocalPawn ? 1 : 0);
        Line("LocalController      : %d", Globals::LocalController ? 1 : 0);
        Line("LocalWeapon present  : %d", Globals::LocalWeapon ? 1 : 0);

        Append("\r\n--- SKINS ---\r\n");
        Line("Enabled              : %d", SkinSwap::enabled ? 1 : 0);
        Line("Desired skin id      : %d", SkinSwap::desiredSkinId);
        Line("Your real skin id    : %d", SkinSwap::g_BaseSkinId);
        Line("Currently rendering  : %d", SkinSwap::g_LiveSkinId);
        Line("Apply count          : %d", SkinSwap::g_ApplyCount);
        Line("Last mesh rebuild ok : %d", SkinSwap::g_LastRebuildOk ? 1 : 0);
        // The single most diagnostic line: if desired == live, the write is
        // sticking and any remaining problem is visual. If they differ, the
        // server is overwriting us.
        Line("HOLDING (live==want) : %d",
             (SkinSwap::desiredSkinId > 0 &&
              SkinSwap::g_LiveSkinId == SkinSwap::desiredSkinId) ? 1 : 0);

        Append("\r\n--- CARDS / TALENTS ---\r\n");
        Line("Talents sent         : %d", CardsTab::g_TalentsSent);
        Line("Cards sent           : %d", CardsTab::g_CardsSent);
        Line("Allocates sent       : %d", CardsTab::g_AllocatesSent);
        Line("Deck id / template   : %d / %d", CardsTab::deckId, CardsTab::templateDeck ? 1 : 0);
        Append("Last action          : ");
        Append(CardsTab::g_LastAction);
        Append("\r\n");

        Append("\r\n--- INSTANT RELOAD ---\r\n");
        Line("On supported champ   : %d", InstantReload::g_OnSupportedChamp ? 1 : 0);
        Append("Weapon class         : ");
        Append(InstantReload::g_DetectedWeapon[0] ? InstantReload::g_DetectedWeapon : "(none)");
        Append("\r\n");
        Line("Enabled / forceFinish: %d / %d",
             InstantReload::enabled ? 1 : 0, InstantReload::forceFinish ? 1 : 0);
        Line("Scale writes         : %d", InstantReload::g_ScaleWrites);
        Line("Force-finish calls   : %d", InstantReload::g_ForceFinishCalls);
        {
            char tmp[128];
            wsprintfA(tmp, "Reload time orig/live: %d / %d (ms)",
                      (int)(InstantReload::g_OriginalReloadTime * 1000.0f),
                      (int)(InstantReload::g_LastSeenReloadTime * 1000.0f));
            Append(tmp); Append("\r\n");
        }

        Append("\r\n--- CAMERA ---\r\n");
        Line("Modules in list      : %d", CameraTools::g_ModulesFound);
        Line("3P module found      : %d", CameraTools::g_ThirdPersonModuleFound ? 1 : 0);
        Line("3P swap applied      : %d", CameraTools::g_SwapApplied ? 1 : 0);
        Append("Active cam module    : ");
        Append(CameraTools::g_CurrentModuleName);
        Append("\r\n");
        Line("FOV writes           : %d", CameraTools::g_FovWrites);

        Append("\r\n--- LOGO ---\r\n");
        Line("Texture loaded       : %d", LogoTexture::g_Loaded ? 1 : 0);
        Line("Size                 : %d x %d", LogoTexture::g_Width, LogoTexture::g_Height);
        Append("Loaded from          : ");
        Append(LogoTexture::g_LoadedFrom);
        Append("\r\n");
        if (!LogoTexture::g_Loaded) {
            Append("Error                : ");
            Append(LogoTexture::g_LastError);
            Append("\r\n");
        }

        Append("===== END REPORT =====\r\n");
    }

    inline bool CopyToClipboard(const char* text) {
        if (!OpenClipboard(nullptr)) return false;
        EmptyClipboard();
        int len = lstrlenA(text) + 1;
        HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, len);
        if (!h) { CloseClipboard(); return false; }
        void* p = GlobalLock(h);
        if (p) {
            memcpy(p, text, len);
            GlobalUnlock(h);
            SetClipboardData(CF_TEXT, h);
        }
        CloseClipboard();
        return true;
    }

    inline void DrawButton(bool inMatch) {
        if (ImGui::Button("COPY TEST REPORT", ImVec2(190, 26))) {
            Build(inMatch);
            g_Copied = CopyToClipboard(g_Buf);
        }
        ImGui::SameLine();
        if (g_Copied) {
            ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), "Copied - paste it to me.");
        } else {
            ImGui::TextDisabled("One click, then paste it in chat.");
        }
    }
}
