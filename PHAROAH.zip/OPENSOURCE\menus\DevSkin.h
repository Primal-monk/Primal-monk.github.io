#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include "menus/SkinDatabase.h"
#include "menus/MeshSkin.h"   // CopyClip / HasCI / g_WantRescanAfterWear
#include "ChampionMapping.h"
#include <Windows.h>

// ============================================================================
// DEV SKIN SHOP — chasing the hint: "There is a hidden developer item shop that
// lets you equip any skin. It's really well hidden though."
//
// WHAT I FOUND IN THE 8.1 SDK
// UTgBattleCheatManager carries a set of developer commands that are exactly the
// shape of that description:
//
//   void SwitchClass(FString godName, FString SkinName, FString weaponSkinName)
//   void sc(FString godName, FString SkinName, FString weaponSkinName)   <- alias
//   void PrecacheClass(FString godName, FString SkinName, FString weaponSkinName)
//   void SetBodyMesh(int nBodyMeshID)      // alias SBM
//   void SetHeadMesh(int nHeadMeshID)      // alias SHM
//   void TestShowInventory()
//   void TestSkinGallery(int nGallery)
//   void ToggleShowAllStoreLandingItems()
//   void ToggleShowUnobtainableStoreLandingItems()
//   void RefreshStoreLandingItems()
//
// SwitchClass takes the skin BY NAME. That is what a dev shop would call.
//
// WHY "IT'S ON THE CHEATMANAGER" IS NOT A REASON TO DOUBT IT
// Worth being explicit, because I got this wrong earlier and corrected it: the
// Octavia Commander buffs go through TestServerRequestCard on this SAME object
// and they demonstrably work in real matches. So this class IS reachable. Some
// of its functions are gated (Set3p does nothing, SetMountSkin does nothing) and
// some are not. Which means each one has to be TESTED, not assumed — hence every
// button below reports its own result separately.
//
// WHY PrecacheClass MATTERS
// UE3 loads assets lazily, so a skin's mesh may simply not be in memory. That was
// the open risk with the raw mesh-pointer approach. PrecacheClass is the game's
// OWN way of forcing that load. So the order to try is: Precache first, then
// switch. There is a button that does both in sequence.
//
// THREADING: every one of these is a scripted (ProcessEvent) call, so they are
// all queued here and dispatched from the ProcessEvent thread. Firing scripted
// calls from the render thread is what corrupted pawn state before (the
// "Buck with Octavia's gun" bug).
// ============================================================================

namespace DevSkin {

    // Names are typed as ANSI in the UI and widened before the call, because
    // FString wants wchar_t.
    inline char godName[64] = "Maeve";
    inline char skinName[64] = "Raeve";
    inline char weaponSkinName[64] = "";

    inline int  bodyMeshId = 0;
    inline int  headMeshId = 0;
    inline int  galleryIndex = 0;
    inline int  precacheBotId = 0;
    inline int  precacheSkinId = 0;
    inline int  precacheWeaponId = 0;

    // One pending action at a time, drained on the safe thread. An enum rather
    // than a pile of bools so two buttons can't fight over the same tick.
    enum Action {
        None = 0, Precache, Switch, SwitchAlias, PrecacheThenSwitch,
        BodyMesh, HeadMesh, ShowInventory, SkinGallery,
        ToggleAllStore, ToggleUnobtainable, RefreshStore, TestPrecacheIds,
        // The new prime candidates.
        LiveSwitch, FullSwitch, DefaultSkinBody, DefaultSkinHead,
        // Force-load, to defeat lazy loading.
        LoadAllSkins, PrecacheById, PrecacheByName,
        // Newest Fable-found leads.
        OpenDevMenu, HideMesh1P, HideMesh3P, ShowMeshes, SkinGalleryOpen, TgtSetMeshes,
        // The game's own rebuild pipeline, by skin code.
        RebuildSkin, ProfileSkin,
        // "The route actual skins take" - fire the replication handler.
        RouteSkin,
        // Champion-select: drive the LOBBY PREVIEW mesh (renders any skin).
        LobbySkin,
        // The kitchen-sink combined apply (id + route + rebuild + materials).
        FullApply,
        // Non-Net asm-id path (the potential real-match method).
        LearnAsm, ApplyAsm,
        // THE CLIENT OVERRIDE — c_nOverrideSkinId (Transient, server can't revert).
        OverrideSkin, ReadOverride,
        // WEAPON: force-load device assets + apply weapon skin (range = host).
        WeaponApply, WeaponPrecacheOnly,
        // ASSEMBLY REMAP: server confirms default, assembly resolves to target.
        RemapAssembly, ReadAssembly,
        // FIRE-MODE METHOD for skins: write the resolved m_pAmSkin pointer.
        AmSkinApply, AmSkinScan, AmSkinNext, AllFieldsRaw,
        // THE FULL ROUTE: ClientSettings -> PRI -> pawn -> m_pAmSkin -> rebuild.
        FullRoute, ReadRoute,
        // MENU PREVIEW the way the game does it (body + WEAPON, correct pedestal).
        MenuPreview, MenuPreviewTeam
    };
    inline char g_MenuChampFilter[48] = "Maeve";   // menu skin-picker filter
    inline bool g_DedupeSkins = true;              // hide repeated skin names
    inline int  g_WepDevice = 0, g_WepAsm1P = 0, g_WepAsm3P = 0;  // weapon asm route
    inline bool g_DHoldSelection = false;          // METHOD D: keep re-writing it
    inline ULONGLONG g_LastDHoldMs = 0;
    inline int  g_BuildMeshId = 0;                 // METHOD C: id to build
    inline bool g_BuildPartialFixup = false;
    inline int  g_PrevDeviceId    = 0;   // weapon device id (0 = default weapon)
    inline int  g_PrevPedestalId  = 0;
    inline bool g_PrevAsync       = false;
    inline int  g_PrevTeamIndex   = 0;
    inline bool g_RoutePersist   = false;
    inline bool g_RouteUseAmIdx  = false;
    inline int  g_LiveChosenSkin = -999;
    inline int  g_LivePriSkin    = -999;
    inline ULONGLONG g_LastRouteMs = 0;
    inline int  g_AmSkinIndex   = 0;
    inline int  g_AmSkinCount   = -1;
    inline bool g_AmSkinWeapon  = true;
    inline bool g_AmSkinPersist = false;
    inline ULONGLONG g_LastAmSkinMs = 0;
    inline int  g_LiveWeaponSkinId = -999;
    inline int  g_LiveAssemblyAsm  = -999;
    inline bool g_RemapPersist     = false;
    inline ULONGLONG g_LastRemapMs = 0;
    inline int  g_OverrideSkinLevel = 1;   // c_nOverrideSkinLevel to write
    inline bool g_OverrideAlsoRepId = true;
    inline bool g_OverridePersist  = false;
    inline int  g_LiveOverrideId   = -999;
    inline ULONGLONG g_LastOverrideMs = 0;
    inline int  g_ProfileId      = 0;   // SetPlayerProfile profile slot (experiment)
    inline int  g_ProfileVoiceId = 0;   // voice pack id (0 = leave)
    inline int  g_LearnedBodyAsm = -1;
    inline int  g_LearnedCoreAsm = -1;
    inline int  g_ApplyAsmId = 0;
    inline bool g_AsmSetCore = false;
    inline int g_LastLobbyApplied = -1;
    inline int  rebuildSkinId = 0;
    inline int  rebuildWeaponId = 0;
    inline bool rebuildDoWeapon = true;
    inline bool rebuildReassert = false;
    inline ULONGLONG g_LastRebuildMs = 0;
    inline bool g_FocusMode = true;   // hide dead-end sections by default
    inline int  rawSkinId = 0;        // for the raw-id sweep diagnostic
    inline bool hide1P = false;
    inline bool hide3P = false;
    inline int  loadBatch = 0;
    // Set after a force-load; the UI consumes it and re-scans, since the assets
    // only just arrived and the old scan results are stale.
    inline bool g_WantRescan = false;

    // LOOP LOADER — one SpawnBotAllSkins per tick across many batches, because a
    // single batch only loaded a couple of skins. Draining it one-per-tick keeps
    // it off the render thread and avoids hammering the engine in a single frame.
    inline int  g_LoadLoopRemaining = 0;
    inline int  g_LoadLoopBatch = 0;

    // ---- prime candidate state ----
    inline int  liveBotId = 0;          // your champion's id
    inline int  liveBodySkinId = 0;
    inline int  liveWeaponSkinId = 0;
    inline int  liveVoicePackId = 0;
    inline int  defaultSkinIndex = 0;   // index into m_pAmAllSkins
    inline int  g_AllSkinsCount = -1;
    inline Action g_Pending = None;
    inline Action g_Follow = None;      // for the two-step precache-then-switch

    inline char g_Log[8][160] = {};
    inline int  g_LogCount = 0;

    // ---- vendor store config poke (candidate #3) ----
    // Declared HERE, above ProcessPending, because ProcessPending reads them.
    // Declaring them next to the UI code that also uses them put them after
    // first use, which is a compile error — a mistake this project has hit
    // several times now, so: state first, then the functions that touch it.
    inline int  vsTab = 0, vsType = 0, vsRec = 0;
    inline bool vsWriteTab = false, vsWriteType = true, vsWriteRec = true;
    inline int  vsLiveTab = -1, vsLiveType = -1, vsLiveRec = -1;
    inline bool g_PendingVendorWrite = false;
    inline bool g_PendingVendorRead = false;

    inline void Log(const char* what, bool ok) {
        // Newest first — the thing you just pressed should be the top line.
        for (int i = 7; i > 0; --i) lstrcpynA(g_Log[i], g_Log[i - 1], 160);
        char tmp[160];
        wsprintfA(tmp, "%s -> %s", what, ok ? "called OK" : "FAULTED");
        lstrcpynA(g_Log[0], tmp, 160);
        if (g_LogCount < 8) g_LogCount++;
    }

    inline void Widen(const char* src, wchar_t* dst, int cap) {
        MultiByteToWideChar(CP_ACP, 0, src, -1, dst, cap);
    }

    // A+B COMBINE loader state: precache EVERY database skin for one champion,
    // a few per tick, so Method B's scanner can then list them all. This is the
    // "Method A loads, Method B wears" you kept asking for.
    inline bool g_DbLoadActive = false;
    inline int  g_DbLoadIndex  = 0;
    inline int  g_DbLoadBotId  = 0;
    inline char g_DbLoadChamp[48] = {};
    inline int  g_DbLoadDone   = 0;

    // Guarded start: loading with no valid champion/bot id is what crashed when
    // you pressed LOAD ALL before ever scanning (it fed garbage ids to precache).
    inline bool CanStartLoadAll(const char* champ, int botId, char* whyNot, int cap) {
        if (!champ || !champ[0]) {
            lstrcpynA(whyNot, "No champion detected yet - press SCAN / re-scan first.", cap);
            return false;
        }
        if (botId <= 0) {
            lstrcpynA(whyNot, "No champion (bot) id yet - pick your champion in the list first.", cap);
            return false;
        }
        if (!Globals::LocalPawn) {
            lstrcpynA(whyNot, "No pawn - spawn in first.", cap);
            return false;
        }
        whyNot[0] = '\0';
        return true;
    }

    inline void StartLoadAllChampionSkins(const char* champ, int botId) {
        lstrcpynA(g_DbLoadChamp, champ, 48);
        g_DbLoadBotId = botId;
        g_DbLoadIndex = 0;
        g_DbLoadDone  = 0;
        g_DbLoadActive = true;
    }

    // ========================================================================
    // DEV-SHOP COMMAND DUMPER  — read the "hidden developer item shop" contents.
    //
    // UTgDevMenuMoviePlayer::AddCommand(FString Section, FString Command,
    // FString DisplayName) is what BUILDS the dev menu: the game calls it once
    // per entry to register every command. If we watch that call, the game hands
    // us the shop's real contents — exact command strings, correct format,
    // including the skin ones. No guessing at names or formats.
    //
    // This is the most literal reading of "just find the route actual skins take":
    // don't reconstruct the route, LOG it. Open the dev menu with the capture on
    // and every command it registers lands in this buffer.
    //
    // Params layout is 3 x FString (each: void* Data; int Count; int Max = 12
    // bytes on this build's 32-bit-ish FString). We read them defensively.
    // ========================================================================
    inline bool g_CaptureDevCommands = false;
    inline char g_DevCmdLog[64][192] = {};
    inline int  g_DevCmdCount = 0;

    inline void WideToAnsi(const wchar_t* src, char* dst, int cap) {
        if (!src) { dst[0] = '\0'; return; }
        WideCharToMultiByte(CP_ACP, 0, src, -1, dst, cap, nullptr, nullptr);
    }

    // ========================================================================
    // *** SKIN CAPTURE — let the GAME tell us what it does ***
    //
    // Your idea, and it's the right one. Instead of guessing the parameters, we
    // watch the game's OWN call when you click a skin normally in the menu:
    //   ATgLobbyHUD::ChangeClassModel(nClassId, nSkinId, nDeviceId, nDeviceSkinId, ...)
    //   ATgLobbyHUD::ChangeTeamModel(...)
    //   ATgSkeletalMeshActor_Lobby::SetSkin(nSkinId, nDeviceSkinId)
    //
    // This hands us the real DEVICE ID and DEVICE-SKIN ID for the weapon — the
    // exact values we have been passing as 0, which is why no weapon ever showed.
    // Turn capture on, click skins/weapons in the menu normally, then COPY.
    // ========================================================================
    // OFF by default. This is NOT free: the first time it runs it calls
    // FindObject three times, and FindObject walks the entire GObjects table doing
    // string compares. Inside the ProcessEvent hook that can fire during match
    // load — an expensive stall on the game thread, and StaticFindObject during a
    // GC pass is an outright crash (we have hit that before in this project).
    // Turn it on only while you are in the MENU and want to capture.
    inline bool g_CaptureSkinCalls = false;
    inline char g_SkinCapLog[48][160] = {};
    inline int  g_SkinCapCount = 0;

    // Function pointers for the capture, resolved from the UI thread (NOT from
    // inside the ProcessEvent hook). Previous version resolved them in the hook
    // behind a "!Globals::LocalPawn" guard — but LocalPawn is never cleared when
    // you return to the menu, so that condition was never true, the lookup never
    // ran, the pointers stayed null, and NOTHING could ever be captured. That is
    // why the log came back empty even with capture on.
    inline SDK::UFunction* g_fnCapCCM = nullptr;
    inline SDK::UFunction* g_fnCapCTM = nullptr;
    inline SDK::UFunction* g_fnCapSS  = nullptr;
    inline SDK::UFunction* g_fnCapSetSkinLobbyBase = nullptr;
    inline bool g_CapResolved = false;

    inline void ResolveSkinCaptureFns() {
        g_fnCapCCM = SDK::UObject::FindObject<SDK::UFunction>(
            "Function TgClient.TgLobbyHUD.ChangeClassModel");
        g_fnCapCTM = SDK::UObject::FindObject<SDK::UFunction>(
            "Function TgClient.TgLobbyHUD.ChangeTeamModel");
        g_fnCapSS = SDK::UObject::FindObject<SDK::UFunction>(
            "Function TgGame.TgSkeletalMeshActor_Lobby.SetSkin");
        g_fnCapSetSkinLobbyBase = SDK::UObject::FindObject<SDK::UFunction>(
            "Function TgGame.TgSkeletalMeshActor_Lobby.SetSkinFromMessage");
        g_CapResolved = true;
    }

    // WIDE NET. My three named guesses may simply be wrong, or the menu may call
    // the native implementation directly (native calls never pass through
    // ProcessEvent). Rather than capture nothing and learn nothing, log EVERY
    // scripted function whose name mentions Skin/Model/Mesh — with its first few
    // ints. If the real route is scripted, it will show up here by name.
    inline bool g_CapWideNet = true;
    inline char g_WideLog[64][160] = {};
    inline int  g_WideCount = 0;

    inline void LogWideSkinCall(SDK::UFunction* fn, void* parms) {
        if (g_WideCount >= 64 || !fn) return;
        __try {
            auto& names = SDK::FName::GetGlobalNames();
            int idx = fn->Name.Index;
            if (idx <= 0 || !names.IsValidIndex((size_t)idx)) return;
            SDK::FNameEntry* e = names[idx];
            if (!e) return;
            const char* a = e->GetAnsiName();
            if (!a) return;
            // Only functions that plausibly carry a skin/model change.
            bool interesting =
                (strstr(a, "Skin")  != nullptr) ||
                (strstr(a, "Model") != nullptr) ||
                (strstr(a, "Mesh")  != nullptr && strstr(a, "Update") == nullptr);
            if (!interesting) return;
            char line[160];
            int off = wsprintfA(line, "%s(", a);
            if (parms && fn->ParmsSize >= 4) {
                int n = (int)fn->ParmsSize / 4; if (n > 6) n = 6;
                for (int i = 0; i < n && off < 140; ++i)
                    off += wsprintfA(line + off, "%d%s", *(int*)((char*)parms + i * 4),
                                     (i + 1 < n) ? "," : "");
            }
            wsprintfA(line + off, ")");
            for (int i = 0; i < g_WideCount; ++i)
                if (lstrcmpA(g_WideLog[i], line) == 0) return;   // dedupe
            lstrcpynA(g_WideLog[g_WideCount], line, 160);
            g_WideCount++;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }

    inline void LogSkinCall(const char* what, const int* ints, int n) {
        if (!g_CaptureSkinCalls || g_SkinCapCount >= 48) return;
        char line[160];
        int off = wsprintfA(line, "%s(", what);
        for (int i = 0; i < n && off < 140; ++i)
            off += wsprintfA(line + off, "%d%s", ints[i], (i + 1 < n) ? "," : "");
        wsprintfA(line + off, ")");
        // Skip consecutive duplicates so holding/hovering doesn't flood it.
        if (g_SkinCapCount > 0 && lstrcmpA(g_SkinCapLog[g_SkinCapCount - 1], line) == 0) return;
        lstrcpynA(g_SkinCapLog[g_SkinCapCount], line, 160);
        g_SkinCapCount++;
    }

    // Called from the ProcessEvent hook when AddCommand fires.
    inline void OnDevAddCommand(void* pParms) {
        if (!g_CaptureDevCommands || g_DevCmdCount >= 64 || !pParms) return;
        __try {
            struct FStr { wchar_t* Data; int Count; int Max; };
            FStr* a = (FStr*)pParms;          // Section
            FStr* b = (FStr*)((char*)pParms + sizeof(FStr));   // Command
            FStr* c = (FStr*)((char*)pParms + 2 * sizeof(FStr)); // DisplayName
            char s1[64] = {}, s2[96] = {}, s3[64] = {};
            if (a && a->Data && a->Count > 0 && a->Count < 512) WideToAnsi(a->Data, s1, 64);
            if (b && b->Data && b->Count > 0 && b->Count < 512) WideToAnsi(b->Data, s2, 96);
            if (c && c->Data && c->Count > 0 && c->Count < 512) WideToAnsi(c->Data, s3, 64);
            wsprintfA(g_DevCmdLog[g_DevCmdCount], "[%s] CMD='%s' | \"%s\"", s1, s2, s3);
            g_DevCmdCount++;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }

    // ProcessEvent thread only.
    inline void ProcessPending() {
        // A+B COMBINE: walk the skin database for this champion and precache each
        // skin BY ID (a handful per tick to avoid stutter). Once loaded, they show
        // up in Method B's scanner and can be worn by pointer-swap in real matches.
        if (g_DbLoadActive) {
            const int total = (int)(sizeof(SkinDB::kSkins) / sizeof(SkinDB::kSkins[0]));
            int perTick = 0;
            while (g_DbLoadIndex < total && perTick < 6) {
                const SkinDB::Entry& e = SkinDB::kSkins[g_DbLoadIndex++];
                if (MeshSkin::HasCI(e.champion, g_DbLoadChamp)) {
                    SafeCalls::TestPrecacheById(g_DbLoadBotId, e.id, e.id);
                    g_DbLoadDone++;
                    perTick++;
                }
            }
            if (g_DbLoadIndex >= total) {
                g_DbLoadActive = false;
                char msg[160];
                wsprintfA(msg, "Precached %d %s skins - now SCAN in Skins tab.",
                          g_DbLoadDone, g_DbLoadChamp);
                Log(msg, true);
                MeshSkin::g_WantRescanAfterWear = true;   // repopulate Method B list
                g_WantRescan = true;
            }
            return;   // one loader step per tick
        }

        // Drain the batch loader one step per tick. This is what actually loads
        // lots of skins — one SpawnBotAllSkins per batch index.
        if (g_LoadLoopRemaining > 0) {
            SafeCalls::SpawnBotAllSkins(g_LoadLoopBatch);
            g_LoadLoopBatch++;
            g_LoadLoopRemaining--;
            if (g_LoadLoopRemaining == 0) {
                Log("Loaded 16 skin batches", true);
                g_WantRescan = true;
            }
            return;   // one heavy call per tick
        }

        // KEEP RE-APPLYING = re-run the COMBINED FULL APPLY on an interval. Per
        // live testing this is what fixes both cases: it re-asserts r_nSkinId (the
        // server keeps resetting it), and it re-applies after the skin's assets
        // finish loading (the "invisible then correct" behaviour). ApplySkinFull
        // is the working method, not the plain route.
        if (rebuildReassert && rebuildSkinId > 0) {
            ULONGLONG now = GetTickCount64();
            if (now - g_LastRebuildMs > 1200) {
                SafeCalls::ApplySkinFull(rebuildSkinId, rebuildWeaponId, rebuildDoWeapon);
                g_LastRebuildMs = now;
            }
        }

        // OVERRIDE PERSISTENCE — re-write c_nOverrideSkinId every 500ms. It's
        // Transient so the server can't revert it, but re-asserting is cheap
        // insurance against a respawn/mesh-recreate clearing the component. No
        // rebuild here (that only needs to happen once), just the field write.
        if (g_OverridePersist && rebuildSkinId > 0) {
            ULONGLONG now = GetTickCount64();
            if (now - g_LastOverrideMs > 500) {
                SafeCalls::ReassertOverrideSkin(rebuildSkinId, g_OverrideSkinLevel);
                g_LiveOverrideId = SafeCalls::ReadOverrideSkinId();
                g_LastOverrideMs = now;
            }
        }

        // METHOD D hold: keep ChosenSkinId set while you sit in the menu, in case
        // the UI rewrites it when you move around the champion/loadout screens.
        if (g_DHoldSelection && rebuildSkinId > 0) {
            ULONGLONG now = GetTickCount64();
            if (now - g_LastDHoldMs > 500) {
                SafeCalls::SetChosenSkin(rebuildSkinId, rebuildWeaponId, liveBotId, g_PrevDeviceId);
                g_LastDHoldMs = now;
            }
        }

        // FULL ROUTE persistence — re-write ids (PRI + pawn) twice a second with
        // no rebuild, so any server re-assert is immediately overwritten again.
        if (g_RoutePersist && rebuildSkinId > 0) {
            ULONGLONG now = GetTickCount64();
            if (now - g_LastRouteMs > 500) {
                SafeCalls::ReassertFullRoute(rebuildSkinId, rebuildWeaponId);
                g_LastRouteMs = now;
            }
        }

        // AM-SKIN persistence — re-point m_pAmSkin twice a second. Pure pointer
        // write, no rebuild, so it's cheap enough to hold against anything that
        // tries to reset it mid-match.
        if (g_AmSkinPersist && g_AmSkinIndex >= 0) {
            ULONGLONG now = GetTickCount64();
            if (now - g_LastAmSkinMs > 500) {
                SafeCalls::ReassertAmSkin(g_AmSkinIndex, g_AmSkinWeapon);
                g_LastAmSkinMs = now;
            }
        }

        // ASSEMBLY REMAP persistence — re-assert the remapped asm id + LoadMesh on
        // an interval so a server-driven rebuild can't quietly revert it.
        if (g_RemapPersist) {
            int asmId = (g_LearnedBodyAsm > 0) ? g_LearnedBodyAsm : g_ApplyAsmId;
            if (asmId > 0) {
                ULONGLONG now = GetTickCount64();
                if (now - g_LastRemapMs > 1000) {
                    SafeCalls::ReassertBodyAssembly(asmId);
                    g_LiveAssemblyAsm = SafeCalls::ReadBodyAssemblyAsmId();
                    g_LastRemapMs = now;
                }
            }
        }

        // Promote a queued follow-up before the early-out. Without this the
        // precache-then-switch pair would stall forever: the first tick leaves
        // g_Pending == None with g_Follow set, and the early return below would
        // then never look at g_Follow again.
        if (g_Pending == None && g_Follow != None) {
            g_Pending = g_Follow;
            g_Follow = None;
        }
        // Vendor-store read/write is handled BEFORE the early-out below. It is
        // independent of the action enum, and putting it after the return would
        // mean those two buttons silently did nothing whenever no other action
        // was queued — which is always, since actions clear themselves.
        if (g_PendingVendorRead) {
            g_PendingVendorRead = false;
            Log("GetVendorStore", SafeCalls::GetVendorStore(&vsLiveTab, &vsLiveType, &vsLiveRec));
        }
        if (g_PendingVendorWrite) {
            g_PendingVendorWrite = false;
            bool okw = SafeCalls::SetVendorStore(vsTab, vsType, vsRec,
                                                 vsWriteTab, vsWriteType, vsWriteRec);
            Log("SetVendorStore", okw);
            // Refresh so the store rebuilds from the new ids instead of showing a
            // stale list and looking like nothing happened.
            Log("RefreshStoreLandingItems", SafeCalls::RefreshStoreLandingItems());
            SafeCalls::GetVendorStore(&vsLiveTab, &vsLiveType, &vsLiveRec);
        }

        if (g_Pending == None) return;
        Action a = g_Pending;
        g_Pending = None;

        wchar_t wGod[64], wSkin[64], wWeap[64];
        Widen(godName, wGod, 64);
        Widen(skinName, wSkin, 64);
        Widen(weaponSkinName, wWeap, 64);

        switch (a) {
        case ProfileSkin:
            // The LEGIT path: hand skin+weapon+voice to the profile system, which
            // is what the server reads to dress your pawn at spawn. profileId and
            // voicePack are configurable now (0 was a guess). Use in champ-select,
            // or fire then respawn so the server re-dresses you.
            Log("SetPlayerProfile",
                SafeCalls::SetPlayerProfile(g_ProfileId, rebuildSkinId, rebuildWeaponId,
                                            g_ProfileVoiceId));
            g_LastRebuildMs = GetTickCount64();
            break;

        case LobbySkin: {
            // Champion-select preview: drive the lobby mesh, which renders any
            // skin correctly. deviceSkinId reuses the skin id as a best guess.
            g_LastLobbyApplied = SafeCalls::SetLobbySkinAll(rebuildSkinId, rebuildSkinId);
            char msg[64]; wsprintfA(msg, "SetLobbySkin -> %d preview meshes", g_LastLobbyApplied);
            Log(msg, g_LastLobbyApplied > 0);
            break;
        }

        case LearnAsm: {
            // Read the LIVE m_nBodyMeshAsmId (changes per skin) - the useful value.
            // GetMeshAssemblyToUse returns a constant base id, so it's ignored.
            int live = SafeCalls::ReadBodyAsmId();
            g_LearnedBodyAsm = live;
            g_ApplyAsmId = live;
            char m[80]; wsprintfA(m, "Learned LIVE body asm = %d", live);
            Log(m, live > 0);
            break;
        }
        case ApplyAsm: {
            bool ok = SafeCalls::SetBodyAsmIdAndRebuild(g_ApplyAsmId, g_LearnedCoreAsm, g_AsmSetCore);
            Log("SetBodyAsmId + AddBodyMesh", ok);
            break;
        }

        case FullApply: {
            // Combined: preview should be loaded first. Precache as a backstop,
            // then run the game's complete sequence in order.
            wchar_t pS[64]; Widen(skinName, pS, 64);
            SafeCalls::PrecacheSkinById(liveBotId, pS, pS);
            bool ok = SafeCalls::ApplySkinFull(rebuildSkinId, rebuildWeaponId, rebuildDoWeapon);
            Log("ApplySkinFull (id+route+rebuild+materials)", ok);
            g_LastRebuildMs = GetTickCount64();
            break;
        }

        case OverrideSkin: {
            // THE CLIENT OVERRIDE. Precache (so the mesh is resident), then write
            // c_nOverrideSkinId on the body mesh component + rebuild. Transient =
            // server can't revert it. This is the real-match candidate.
            wchar_t pS[64]; Widen(skinName, pS, 64);
            SafeCalls::PrecacheSkinById(liveBotId, pS, pS);
            bool ok = SafeCalls::ApplyOverrideSkin(rebuildSkinId, g_OverrideSkinLevel,
                                                   g_OverrideAlsoRepId);
            g_LiveOverrideId = SafeCalls::ReadOverrideSkinId();
            Log("ApplyOverrideSkin (c_nOverrideSkinId, client-only)", ok);
            g_LastRebuildMs = GetTickCount64();
            break;
        }
        case ReadOverride: {
            g_LiveOverrideId = SafeCalls::ReadOverrideSkinId();
            Log("Read c_nOverrideSkinId", g_LiveOverrideId != -999);
            break;
        }
        case WeaponApply: {
            // Force-load the weapon (device) assets via the game host, then set
            // the weapon skin id + rebuild the weapon mesh. Range = you're host.
            bool ok = SafeCalls::ApplyWeaponSkin(liveBotId, rebuildSkinId, rebuildWeaponId);
            g_LiveWeaponSkinId = SafeCalls::ReadLiveWeaponSkinId();
            Log("ApplyWeaponSkin (EnsureBotPrecache + r_nWeaponSkinId + Update)", ok);
            g_LastRebuildMs = GetTickCount64();
            break;
        }
        case WeaponPrecacheOnly: {
            bool ok = SafeCalls::EnsureWeaponPrecache(liveBotId, rebuildSkinId, rebuildWeaponId);
            Log("EnsureBotPrecache (weapon force-load only)", ok);
            break;
        }
        case RemapAssembly: {
            // Uses the LEARNED body asm id (learn it in the range while wearing the
            // target skin). Falls back to the manual "Asm id to apply" field.
            int asmId = (g_LearnedBodyAsm > 0) ? g_LearnedBodyAsm : g_ApplyAsmId;
            bool ok = SafeCalls::RemapBodyAssembly(asmId, g_AsmSetCore, g_LearnedCoreAsm);
            g_LiveAssemblyAsm = SafeCalls::ReadBodyAssemblyAsmId();
            Log("RemapBodyAssembly (server thinks default, renders target)", ok);
            g_LastRemapMs = GetTickCount64();
            break;
        }
        case ReadAssembly: {
            g_LiveAssemblyAsm = SafeCalls::ReadBodyAssemblyAsmId();
            Log("Read assembly asm id", g_LiveAssemblyAsm > 0);
            break;
        }
        case AmSkinScan: {
            g_AmSkinCount = SafeCalls::GetAllSkinsCount();
            char m[96];
            wsprintfA(m, "m_pAmAllSkins holds %d resolved skins", g_AmSkinCount);
            Log(m, g_AmSkinCount > 0);
            break;
        }
        case AmSkinApply: {
            bool ok = SafeCalls::ApplyAmSkinByIndex(g_AmSkinIndex, g_AmSkinWeapon, true);
            g_AmSkinCount = SafeCalls::GetAllSkinsCount();
            char m[96];
            wsprintfA(m, "ApplyAmSkin index %d (of %d)", g_AmSkinIndex, g_AmSkinCount);
            Log(m, ok);
            g_LastAmSkinMs = GetTickCount64();
            break;
        }
        case AmSkinNext: {
            g_AmSkinCount = SafeCalls::GetAllSkinsCount();
            if (g_AmSkinCount > 0) g_AmSkinIndex = (g_AmSkinIndex + 1) % g_AmSkinCount;
            bool ok = SafeCalls::ApplyAmSkinByIndex(g_AmSkinIndex, g_AmSkinWeapon, true);
            char m[96];
            wsprintfA(m, "AmSkin NEXT -> index %d of %d", g_AmSkinIndex, g_AmSkinCount);
            Log(m, ok);
            g_LastAmSkinMs = GetTickCount64();
            break;
        }
        case FullRoute: {
            bool ok = SafeCalls::ApplyFullSkinRoute(
                rebuildSkinId, rebuildWeaponId, liveBotId, 0,
                g_RouteUseAmIdx ? g_AmSkinIndex : -1, true);
            g_LiveChosenSkin = SafeCalls::ReadChosenSkinId();
            g_LivePriSkin    = SafeCalls::ReadPriSkinId();
            char m[128];
            wsprintfA(m, "FULL ROUTE skin=%d chosen=%d pri=%d",
                      rebuildSkinId, g_LiveChosenSkin, g_LivePriSkin);
            Log(m, ok);
            g_LastRouteMs = GetTickCount64();
            break;
        }
        case MenuPreview: {
            // The game's OWN menu model swap: body + WEAPON in one call, correct
            // pedestal and camera. rebuildWeaponId is the DEVICE(weapon) skin.
            bool ok = SafeCalls::MenuPreviewSkin(liveBotId, rebuildSkinId, g_PrevDeviceId,
                                                 rebuildWeaponId, g_PrevPedestalId, g_PrevAsync);
            char m[128];
            wsprintfA(m, "MenuPreview class=%d skin=%d devSkin=%d",
                      liveBotId, rebuildSkinId, rebuildWeaponId);
            Log(m, ok);
            break;
        }
        case MenuPreviewTeam: {
            bool ok = SafeCalls::MenuPreviewTeamModel(g_PrevTeamIndex, liveBotId, rebuildSkinId,
                                                      g_PrevDeviceId, rebuildWeaponId, true);
            char m[128];
            wsprintfA(m, "MenuPreviewTeam idx=%d class=%d skin=%d", g_PrevTeamIndex,
                      liveBotId, rebuildSkinId);
            Log(m, ok);
            break;
        }
        case ReadRoute: {
            g_LiveChosenSkin = SafeCalls::ReadChosenSkinId();
            g_LivePriSkin    = SafeCalls::ReadPriSkinId();
            char m[128];
            wsprintfA(m, "route read: chosen=%d pri=%d pawn=%d",
                      g_LiveChosenSkin, g_LivePriSkin, SafeCalls::ReadLiveSkinId());
            Log(m, true);
            break;
        }
        case AllFieldsRaw: {
            bool ok = SafeCalls::ApplySkinAllFieldsRaw(rebuildSkinId, rebuildWeaponId,
                                                       g_LearnedBodyAsm, g_LearnedCoreAsm, true);
            Log("ApplySkinAllFieldsRaw (fire-mode style multi-field write)", ok);
            g_LastRebuildMs = GetTickCount64();
            break;
        }

        case RouteSkin: {
            // "The route actual skins take": precache, then fire the replication
            // handler so the game applies the skin its own way.
            wchar_t pS[64]; Widen(skinName, pS, 64);
            SafeCalls::PrecacheSkinById(liveBotId, pS, pS);
            bool ok = SafeCalls::ApplySkinViaRoute(rebuildSkinId, rebuildWeaponId, 0,
                                                   rebuildDoWeapon, false);
            Log("ApplySkinViaRoute (ReplicatedEvent)", ok);
            g_LastRebuildMs = GetTickCount64();
            break;
        }

        // ---- the game's own rebuild, by skin code ----
        case RebuildSkin: {
            // Precache the skin's assets FIRST (by champion bot id + skin name),
            // so FlashChangeMesh has something to build. Then rebuild. Both on the
            // safe thread already.
            wchar_t pSkin[64]; Widen(skinName, pSkin, 64);
            SafeCalls::PrecacheSkinById(liveBotId, pSkin, pSkin);
            bool ok = SafeCalls::ApplySkinRebuild(rebuildSkinId, rebuildWeaponId, rebuildDoWeapon);
            Log("Precache+ApplySkinRebuild", ok);
            g_LastRebuildMs = GetTickCount64();
            break;
        }

        // ---- Fable-found leads ----
        case OpenDevMenu:
            Log("ToggleDevMenu", SafeCalls::ToggleDevMenu());
            break;
        case HideMesh1P:
            hide1P = !hide1P;
            Log(hide1P ? "HideMeshes 1P=on" : "HideMeshes 1P=off",
                SafeCalls::HideMeshes(hide1P, hide3P));
            break;
        case HideMesh3P:
            hide3P = !hide3P;
            Log(hide3P ? "HideMeshes 3P=on" : "HideMeshes 3P=off",
                SafeCalls::HideMeshes(hide1P, hide3P));
            break;
        case ShowMeshes:
            hide1P = false; hide3P = false;
            Log("HideMeshes both=off", SafeCalls::HideMeshes(false, false));
            break;
        case SkinGalleryOpen:
            Log("TestSkinGallery", SafeCalls::TestSkinGalleryOpen(galleryIndex));
            break;
        case TgtSetMeshes:
            Log("TargetSetMeshes", SafeCalls::TargetSetMeshes(bodyMeshId, headMeshId));
            break;

        // ---- force-load first: nothing downstream can work without the assets ----
        // CONFIRMED WORKING: on Pip this brought skl_pc_pip_skin03a into memory,
        // which was not resident before (total meshes 49 -> 51). Each of these
        // re-scans afterwards so the newly loaded meshes show up without having to
        // remember to press scan.
        case LoadAllSkins:
            Log("SpawnBotAllSkins", SafeCalls::SpawnBotAllSkins(loadBatch));
            g_WantRescan = true;
            break;
        case PrecacheById:
            Log("PrecacheClassById", SafeCalls::PrecacheSkinById(liveBotId, wSkin, wWeap));
            g_WantRescan = true;
            break;
        case PrecacheByName:
            Log("PrecacheClassByName", SafeCalls::PrecacheSkinByName(wGod, wSkin, wWeap));
            g_WantRescan = true;
            break;

        // ---- prime candidates first ----
        case LiveSwitch:
            Log("LiveMatchSwitchChampion",
                SafeCalls::LiveMatchSwitchChampion(liveBotId, liveBodySkinId, liveWeaponSkinId));
            break;
        case FullSwitch:
            Log("SwitchChampion(+voice)",
                SafeCalls::SwitchChampion(liveBotId, liveBodySkinId, liveWeaponSkinId, liveVoicePackId));
            break;
        case DefaultSkinBody:
            Log("SetDefaultSkin(body)", SafeCalls::SetDefaultSkinOnBody(defaultSkinIndex));
            break;
        case DefaultSkinHead:
            Log("SetDefaultSkin(head)", SafeCalls::SetDefaultSkinOnHead(defaultSkinIndex));
            break;

        case Precache:
            Log("PrecacheClass", SafeCalls::PrecacheClass(wGod, wSkin, wWeap));
            break;
        case Switch:
            Log("SwitchClass", SafeCalls::SwitchClass(wGod, wSkin, wWeap));
            break;
        case SwitchAlias:
            Log("sc (alias)", SafeCalls::sc(wGod, wSkin, wWeap));
            break;
        case PrecacheThenSwitch:
            // Precache now; the switch fires on the NEXT tick so the load has a
            // frame to happen. Doing both in one tick is what would make a
            // working method look broken.
            Log("PrecacheClass", SafeCalls::PrecacheClass(wGod, wSkin, wWeap));
            g_Follow = Switch;
            break;
        case BodyMesh:
            Log("SetBodyMesh", SafeCalls::SetBodyMesh(bodyMeshId));
            break;
        case HeadMesh:
            Log("SetHeadMesh", SafeCalls::SetHeadMesh(headMeshId));
            break;
        case ShowInventory:
            Log("TestShowInventory", SafeCalls::TestShowInventory());
            break;
        case SkinGallery:
            Log("TestSkinGallery", SafeCalls::TestSkinGallery(galleryIndex));
            break;
        case ToggleAllStore:
            Log("ToggleShowAllStoreLandingItems", SafeCalls::ToggleShowAllStoreLandingItems());
            break;
        case ToggleUnobtainable:
            Log("ToggleShowUnobtainable", SafeCalls::ToggleShowUnobtainableStoreLandingItems());
            break;
        case RefreshStore:
            Log("RefreshStoreLandingItems", SafeCalls::RefreshStoreLandingItems());
            break;
        case TestPrecacheIds:
            Log("TestPrecache(ids)",
                SafeCalls::TestPrecache(precacheBotId, precacheSkinId, precacheWeaponId, false));
            break;
        default: break;
        }


        // g_Follow (if set) is picked up at the top of the NEXT call, giving the
        // precache a full tick to complete before the switch fires.
    }

    // ---- champion dropdown for champion-select mode (no pawn needed) ----
    // g_DetectedChamp is declared here (before BuildChampionDropdown uses it);
    // AutoDetectChampion further down fills it. Declaring it only next to
    // AutoDetectChampion put it after first use — the undeclared-identifier error.
    inline char g_DetectedChamp[48] = {};
    inline char g_SelChampName[48] = {};
    inline const char* g_ChampList[80] = {};
    inline int  g_ChampListCount = 0;
    inline int  g_ChampSel = -1;
    inline bool g_ChampListBuilt = false;

    inline void BuildChampionDropdown() {
        if (!g_ChampListBuilt) {
            g_ChampListBuilt = true;
            for (int i = 0; i < SkinDB::kSkinCount && g_ChampListCount < 80; ++i) {
                const char* c = SkinDB::kSkins[i].champion;
                bool seen = false;
                for (int j = 0; j < g_ChampListCount; ++j)
                    if (lstrcmpA(g_ChampList[j], c) == 0) { seen = true; break; }
                if (!seen) g_ChampList[g_ChampListCount++] = c;
            }
        }
        // If auto-detect found the champion, default the dropdown to it once.
        if (g_ChampSel < 0 && g_DetectedChamp[0]) {
            for (int j = 0; j < g_ChampListCount; ++j)
                if (lstrcmpA(g_ChampList[j], g_DetectedChamp) == 0) { g_ChampSel = j; break; }
        }
        ImGui::PushItemWidth(200);
        if (ImGui::Combo("Champion##lobbycombo", &g_ChampSel, g_ChampList, g_ChampListCount)) {
            if (g_ChampSel >= 0 && g_ChampSel < g_ChampListCount)
                lstrcpynA(g_SelChampName, g_ChampList[g_ChampSel], sizeof(g_SelChampName));
        }
        ImGui::PopItemWidth();
        if (g_ChampSel >= 0 && g_ChampSel < g_ChampListCount && !g_SelChampName[0])
            lstrcpynA(g_SelChampName, g_ChampList[g_ChampSel], sizeof(g_SelChampName));
    }

    // ---- champion auto-detect, so nothing has to be typed ----
    // (g_DetectedChamp is declared up with the dropdown state above.)

    // Internal pawn codenames differ from display names ("Blades" IS Maeve). The
    // mesh FILES also use the codename (skl_pc_blades...), so filtering by codename
    // is correct — but the display and the skin database need the real name. This
    // maps the ones that differ; anything not listed passes through unchanged.
    struct CodePair { const char* code; const char* real; };
    inline const char* CodenameToReal(const char* code) {
        static const CodePair kMap[] = {
            {"Blades","Maeve"}, {"Bunny","Rei"}, {"Churchill","Vivian"},
            {"Darklord","Zhin"}, {"Princess","Lian"}, {"Shadow","Vatu"},
            {"Owl","Strix"}, {"Oracle","Seris"}, {"Seven","VII"},
            {"Vampire","Lillith"}, {"Vanguard","Khan"}, {"Fairy","Willo"},
            {"Commander","Octavia"}, {"Astro","Io"}, {"Juggernaut","Terminus"},
            {"Demon","Vora"}, {"Corrupter","Nyx"}, {"Druid","Io"},
            {"BombQueen","Betty la Bomba"}, {"ImaniAvatar","Imani"},
        };
        for (int i = 0; i < (int)(sizeof(kMap)/sizeof(kMap[0])); ++i)
            if (lstrcmpiA(kMap[i].code, code) == 0) return kMap[i].real;
        return code;
    }

    inline void AutoDetectChampion() {
        g_DetectedChamp[0] = '\0';
        SDK::APawn* p = Globals::LocalPawn;
        if (!p) return;

        char cls[80] = {};
        // GNames index, not FName(const char*) — the latter scans ~200k entries.
        __try {
            SDK::UClass* c = p->Class;
            if (c && c->Name.Index != 0) {
                auto& names = SDK::FName::GetGlobalNames();
                if (names.IsValidIndex((size_t)c->Name.Index)) {
                    SDK::FNameEntry* e = names[c->Name.Index];
                    if (e) {
                        const char* n = e->GetAnsiName();
                        if (n) lstrcpynA(cls, n, 80);
                    }
                }
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return; }
        if (!cls[0]) return;

        const char* codesrc = cls;
        if (_strnicmp(cls, "TgPawn_", 7) == 0) codesrc = cls + 7;
        // Translate the internal codename to the real name ("Blades" -> "Maeve").
        const char* src = CodenameToReal(codesrc);

        // Match the class name against the database's champion names. They don't
        // always agree exactly (class "MalDamba" vs display "Mal'Damba"), so this
        // compares ignoring apostrophes and spaces.
        for (int i = 0; i < SkinDB::kSkinCount; ++i) {
            const char* dbName = SkinDB::kSkins[i].champion;
            int a = 0, b = 0;
            bool match = true;
            while (dbName[a] || src[b]) {
                while (dbName[a] == '\'' || dbName[a] == ' ') a++;
                while (src[b] == '\'' || src[b] == ' ') b++;
                char ca = dbName[a], cb = src[b];
                if (ca >= 'A' && ca <= 'Z') ca = (char)(ca - 'A' + 'a');
                if (cb >= 'A' && cb <= 'Z') cb = (char)(cb - 'A' + 'a');
                if (ca != cb) { match = false; break; }
                if (!ca) break;
                a++; b++;
            }
            if (match) {
                lstrcpynA(g_DetectedChamp, dbName, 48);
                lstrcpynA(godName, dbName, sizeof(godName));
                return;
            }
        }
        // No database match: still report the raw class name so it's visible.
        lstrcpynA(g_DetectedChamp, src, 48);
    }

    // Fills the LiveMatchSwitchChampion ids from the detected champion and the
    // skin currently selected in the list, so nothing has to be typed. Champion
    // ids come from ChampionMapping.h, which the project already maintains.
    inline void FillLiveIdsFromSelection() {
        g_AllSkinsCount = SafeCalls::GetAllSkinsCount();

        if (precacheSkinId > 0) liveBodySkinId = precacheSkinId;

        // championIdToName maps id -> display name; we need the reverse.
        // Try the DETECTED champion first (in-match, from the pawn)...
        if (g_DetectedChamp[0]) {
            for (auto& kv : championIdToName) {
                if (lstrcmpA(kv.second.c_str(), g_DetectedChamp) == 0) {
                    liveBotId = kv.first;
                    return;
                }
            }
        }
        // ...then fall back to the champion of the SKIN YOU PICKED (godName).
        //
        // THIS IS THE METHOD D FIX. g_DetectedChamp is only populated from a live
        // pawn, so in the MENU it is always empty -> liveBotId stayed 0 -> the
        // classId was never written (SetChosenSkin skips values <= 0), so the game
        // was told a skin id with no champion. That is exactly what the Method D
        // report showed: "classId (liveBotId) : 0".
        // The skin list already knows the champion, so use it.
        if (godName[0]) {
            for (auto& kv : championIdToName) {
                if (_stricmp(kv.second.c_str(), godName) == 0) {
                    liveBotId = kv.first;
                    return;
                }
            }
        }
    }

    // ---- skins-only test report, separate from the global one ----
    inline char g_Report[2048];
    inline bool g_ReportCopied = false;

    inline bool CopyClip(const char* text) {
        if (!OpenClipboard(nullptr)) return false;
        EmptyClipboard();
        int len = lstrlenA(text) + 1;
        HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, len);
        if (!h) { CloseClipboard(); return false; }
        void* p = GlobalLock(h);
        if (p) { memcpy(p, text, len); GlobalUnlock(h); SetClipboardData(CF_TEXT, h); }
        CloseClipboard();
        return true;
    }

    inline void BuildReport() {
        g_Report[0] = '\0';
        lstrcatA(g_Report, "===== PHAROAH SKIN REPORT =====\r\n");
        char t[320];
        wsprintfA(t, "God / Skin / Weapon : %s / %s / %s\r\n",
                  godName, skinName, weaponSkinName[0] ? weaponSkinName : "(blank)");
        lstrcatA(g_Report, t);
        wsprintfA(t, "Body / Head mesh id : %d / %d\r\n", bodyMeshId, headMeshId);
        lstrcatA(g_Report, t);
        wsprintfA(t, "LIVE r_nSkinId (game): %d   |  we set rebuildSkinId=%d rawSkinId=%d\r\n",
                  SafeCalls::ReadLiveSkinId(), rebuildSkinId, rawSkinId);
        lstrcatA(g_Report, t);
        wsprintfA(t, "VendorStore live    : tab=%d type=%d rec=%d\r\n",
                  vsLiveTab, vsLiveType, vsLiveRec);
        lstrcatA(g_Report, t);
        lstrcatA(g_Report, "\r\n--- what each button reported ---\r\n");
        for (int i = 0; i < g_LogCount; ++i) {
            lstrcatA(g_Report, g_Log[i]);
            lstrcatA(g_Report, "\r\n");
        }
        if (g_LogCount == 0) lstrcatA(g_Report, "(nothing pressed yet)\r\n");
        lstrcatA(g_Report, "\r\nDID MY CHARACTER VISIBLY CHANGE? -> (type yes/no here)\r\n");
        lstrcatA(g_Report, "===== END =====\r\n");
    }

    // ========================================================================
    // ################  METHOD D — PRE-MATCH SELECTION INJECTION  ###########
    //
    // The reframing that makes this different from A/B/C:
    //
    //   Ownership is a SELECTION-TIME gate ONLY. Skin boosters prove it — they
    //   unlock selection, and once you are past the menu the game simply accepts
    //   what you picked. There is NO in-match ownership validation to defeat.
    //
    // A, B and C all try to change the skin AFTER the game has already decided
    // what you are wearing. That is why they fight the server, break skeletons,
    // and never carry the weapon. Method D changes WHAT YOU SELECTED, before the
    // match starts, and then lets the game's own pipeline do everything —
    // body + arms + weapon, correctly, with no overrides at all.
    //
    // Why we don't need to beat the ownership lock:
    //   The lock lives in the menu UI (Flash/native — confirmed NOT in the SDK).
    //   We don't unlock it. We SKIP it, by writing the selection directly:
    //       UTgClientSettings::ChosenSkinId       0x01C0
    //       UTgClientSettings::ChosenClassId      0x01C4
    //       UTgClientSettings::ChosenWeaponId     0x01C8
    //       UTgClientSettings::ChosenWeaponSkinId 0x01CC
    //   These are plain ints on a CLIENT object. Nothing validates them, because
    //   validation happened in the UI we never went through.
    //
    // This is the "wrapping" idea stated correctly: we are not disguising one
    // skin as another. We are declaring our selection directly, bypassing the
    // screen that would have refused it.
    // ========================================================================
    inline char g_DState[4096] = "";

    inline void BuildMethodDReport() {
        int chosen = SafeCalls::ReadChosenSkinId();
        int pri    = SafeCalls::ReadPriSkinId();
        int pawn   = SafeCalls::ReadLiveSkinId();
        int wep    = SafeCalls::ReadLiveWeaponSkinId();
        wsprintfA(g_DState,
            "===== METHOD D STATE =====\r\n"
            "ChosenSkinId (client settings) : %d\r\n"
            "PRI r_nSkinId                  : %d\r\n"
            "Pawn r_nSkinId                 : %d\r\n"
            "Pawn r_nWeaponSkinId           : %d\r\n"
            "--- what we intend to select ---\r\n"
            "classId (liveBotId)            : %d\r\n"
            "skinId                         : %d\r\n"
            "weaponSkinId                   : %d\r\n"
            "skin name                      : %s\r\n"
            "champion                       : %s\r\n"
            "===== END =====\r\n",
            chosen, pri, pawn, wep, liveBotId, rebuildSkinId, rebuildWeaponId,
            skinName, godName);
    }

    // Writes the report next to the DLL so it can be pasted/shared.
    inline bool WriteMethodDFile() {
        BuildMethodDReport();
        HANDLE h = CreateFileA("PHAROAH_MethodD.txt", GENERIC_WRITE, 0, nullptr,
                               CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (h == INVALID_HANDLE_VALUE) return false;
        DWORD written = 0;
        WriteFile(h, g_DState, (DWORD)lstrlenA(g_DState), &written, nullptr);
        CloseHandle(h);
        return written > 0;
    }

    inline void DrawMethodDTab(bool inMatch);

    inline void DrawMenuPreviewSection();   // fwd: menu-only, drawn before the !inMatch return
    inline void DrawFullRouteSection();     // fwd

    // Set by the Skins tab each frame from RecoverySuite::g_DeveloperMode (this
    // header is included before that symbol exists, so it's mirrored here). Gates
    // the advanced/experimental loaders so a normal user sees a clean flow.
    inline bool g_DevMode = false;

    // ========================================================================
    // LOAD ALL SKINS  +  COMBINED FULL APPLY
    // ========================================================================
    // THE section that makes skins work. Method B can only list meshes that are
    // already IN MEMORY, which is why some champions scan empty - this walks the
    // skin database and precaches every skin for your champion, and then the
    // mesh list finally has something to show.
    //
    // It used to live at the bottom of the dev methods. It belongs at the TOP of
    // the Skins tab, because nothing else works until it has run.
    inline void DrawLoadAllSection() {
        // ---- A+B COMBINE: load every skin so METHOD B can finally list them ----
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.4f, 0.9f, 1.0f, 1.0f)));
        ImGui::TextWrapped("LOAD ALL SKINS FOR THIS CHAMPION  (fixes 'Method B scans nothing')");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Method B can only list meshes that are IN MEMORY - that's why Maeve scans "
            "empty while Ying works (her illusions load meshes for free). This walks the skin database "
            "and precaches EVERY skin for your champion by id, a few per tick. When it finishes, hit "
            "SCAN in the Skins mesh list and Method B should finally have a full list to pick from - "
            "and Method B is the one that works in real matches.");
        {
            const char* champ = g_DetectedChamp[0] ? g_DetectedChamp : godName;
            char btn[96];
            wsprintfA(btn, "*** LOAD ALL %s SKINS (then SCAN) ***", champ);
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.45f, 0.6f, 1.0f));
            if (ImGui::Button(btn, ImVec2(360, 30))) {
                // AUTO RE-DETECT FIRST, per PRIMAL_MONKE - no more "click
                // Re-detect, THEN click Load All." This button now re-detects
                // your champion and refills the live ids itself before loading.
                AutoDetectChampion();
                FillLiveIdsFromSelection();
                const char* champNow = g_DetectedChamp[0] ? g_DetectedChamp : godName;
                // GUARD: pressing this before a scan fed garbage ids to precache
                // and crashed. Auto-scan first, then verify we have what we need.
                static char why[160];
                MeshSkin::RunScan();                 // ensures champion + list exist
                if (CanStartLoadAll(champNow, liveBotId, why, 160))
                    StartLoadAllChampionSkins(champNow, liveBotId);
                else
                    Log(why, false);
            }
            ImGui::PopStyleColor();
            if (g_DbLoadActive)
                ImGui::Text("loading... %d precached so far", g_DbLoadDone);
            else if (g_DbLoadDone > 0)
                ImGui::Text("done: %d skins precached - now SCAN in the mesh list", g_DbLoadDone);

            // The x16 batch loader is a fallback force-loader (SpawnBotAllSkins
            // across 16 batches) that pulls in skins the database pass can miss.
            // Hidden behind dev mode - the single blue button above is what a
            // normal user needs; this is clutter for them.
            if (g_DevMode) {
                if (ImGui::Button("LOAD ALL SKINS x16 (loop)", ImVec2(240, 28))) {
                    g_LoadLoopBatch = 0;
                    g_LoadLoopRemaining = 16;   // batches 0..15, one per tick
                }
                ImGui::SameLine();
                if (ImGui::Button("single batch", ImVec2(110, 28))) g_Pending = LoadAllSkins;
                if (g_LoadLoopRemaining > 0)
                    ImGui::Text("x16 loading... %d batches left", g_LoadLoopRemaining);
            }
        }

        // The combined apply — the winner.
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.2f, 0.6f, 0.2f, 1.0f));
        if (ImGui::Button("*** COMBINED FULL APPLY ***", ImVec2(240, 30))) g_Pending = FullApply;
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::Checkbox("Keep re-applied", &rebuildReassert);
        ImGui::TextWrapped("If it goes INVISIBLE, the skin's assets aren't loaded yet - tick 'Keep "
            "re-applied' and it re-fires until it loads (on Ying, placing an illusion also loads it). "
            "Preview the skin in champion select first to pre-load it.");
        ImGui::Checkbox("Also rebuild weapon", &rebuildDoWeapon);
    }

    // STEP 1 - PICK A SKIN, extracted so the Skins tab can draw it standalone at
    // the top of the clean flow (it used to be buried under collapsibles). This
    // is the database-driven picker: it lists every skin for your champion by
    // name, and clicking one runs COMBINED FULL APPLY, the method that works in
    // the range. DrawControls calls this too, so there's one copy of the logic.
    inline void DrawStep1PickSkin() {
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.4f, 1.0f)), "### STEP 1 - PICK A SKIN ###");

        if (!g_DetectedChamp[0]) AutoDetectChampion();   // automatic, no button needed
        ImGui::Text("You are playing: %s   (champion id %d)",
                    g_DetectedChamp[0] ? g_DetectedChamp : "detecting...", liveBotId);
        if (liveBotId == 0 && g_DetectedChamp[0]) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.5f, 0.5f, 1.0f)),
                "Champion id not found - press Re-detect below.");
        }
        ImGui::SameLine();
        if (ImGui::SmallButton("Re-detect")) { AutoDetectChampion(); FillLiveIdsFromSelection(); }

        if (g_DetectedChamp[0]) {
            ImGui::BeginChild("oneclicklist", ImVec2(0, 170), true);
            for (int i = 0; i < SkinDB::kSkinCount; ++i) {
                const SkinDB::Entry& e = SkinDB::kSkins[i];
                if (lstrcmpA(e.champion, g_DetectedChamp) != 0) continue;
                bool dup = false;
                for (int k = i - 1; k >= 0; --k) {
                    if (lstrcmpA(SkinDB::kSkins[k].champion, e.champion) != 0) break;
                    if (lstrcmpA(SkinDB::kSkins[k].name, e.name) == 0) { dup = true; break; }
                }
                if (dup) continue;

                char lbl[160];
                wsprintfA(lbl, "%-9s %s##oc%d", e.rarity, e.name, i);
                ImVec4 col(0.85f, 0.85f, 0.85f, 1.0f);
                if (lstrcmpA(e.rarity, "Legendary") == 0)    col = ImVec4(1.00f, 0.78f, 0.35f, 1.0f);
                else if (lstrcmpA(e.rarity, "Epic") == 0)    col = ImVec4(0.78f, 0.55f, 1.00f, 1.0f);
                else if (lstrcmpA(e.rarity, "Rare") == 0)    col = ImVec4(0.45f, 0.75f, 1.00f, 1.0f);
                ImGui::PushStyleColor(ImGuiCol_Text, col);
                if (ImGui::Selectable(lbl, liveBodySkinId == e.id)) {
                    liveBodySkinId = e.id;
                    precacheSkinId = e.id;
                    rebuildSkinId = e.id;       // feeds COMBINED FULL APPLY
                    rebuildWeaponId = e.id;
                    lstrcpynA(skinName, e.name, sizeof(skinName));
                    lstrcpynA(godName, e.champion, sizeof(godName));
                    FillLiveIdsFromSelection();
                    g_Pending = FullApply;      // the WORKING method (per testing)
                }
                ImGui::PopStyleColor();
            }
            ImGui::EndChild();
        }
        ImGui::Text("Selected: %s  (id %d)   live r_nSkinId: %d",
                    skinName, liveBodySkinId, SafeCalls::ReadLiveSkinId());
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.4f, 1.0f)),
            "Clicking a skin runs COMBINED FULL APPLY (the method that works in the range).");
    }

    inline void DrawControls(bool inMatch) {
        // COLLAPSED. Method A works now, so the "try each method in order"
        // instructions are no longer the first thing anyone needs - they were
        // pushing the working controls below the fold.
        if (ImGui::CollapsingHeader("How to use this tab / report")) {
        ImGui::TextWrapped(
            "1. Be IN A MATCH (bot match is fine). These act on your live pawn, so the menu "
            "screen is not enough.\n"
            "2. Type the god and skin name (e.g. Maeve / Raeve). Names are in "
            "SKINS_BY_CHAMPION.txt.\n"
            "3. Press PRECACHE + SWITCH. Watch your character.\n"
            "4. If nothing happens, work DOWN the tab: sc alias, then the hidden-shop buttons, "
            "then mesh id, then vendor store.\n"
            "5. Press COPY SKIN REPORT and send it to me - it records which buttons you pressed "
            "and what each one said.");
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)),
            "This changes what YOU see only. It does not unlock skins in the");
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)),
            "game's own menu, and other players still see your real skin.");

        if (ImGui::Button("COPY SKIN REPORT", ImVec2(190, 26))) {
            BuildReport();
            g_ReportCopied = CopyClip(g_Report);
        }
        ImGui::SameLine();
        if (g_ReportCopied) {
            ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), "Copied - paste it to me.");
        } else {
            ImGui::TextDisabled("Records every result for me.");
        }
        }   // end "How to use this tab" collapse

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        // THE ROUTE METHOD - collapsed too. It is background on how skins work,
        // not a control you press.
        if (ImGui::CollapsingHeader("The ROUTE method - how skins actually apply")) {
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), "SKINS - THE ROUTE METHOD");
        ImGui::TextWrapped("Per the OG discoverer: skins aren't ownership flags or mesh swaps - you "
            "fire THE ROUTE a real skin takes. Pick your champion's skin below and click it; it sets "
            "r_nSkinId and fires ReplicatedEvent, so the game applies it its own way (correct model, "
            "textures, weapon). Tick 'Keep re-applying' so it survives death.");

        // ====================================================================
        // CHAMPION-SELECT MODE — works BEFORE you spawn, which is exactly where
        // the game already renders any skin correctly (the preview model). This
        // section shows whether or not you're in a match, because that's the whole
        // point: drive the skin where the game knows how to draw it.
        // ====================================================================
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), "CHAMPION-SELECT PREVIEW SKIN");
        ImGui::TextWrapped("Use this on the champion-select / loadout screen (before you spawn). It "
            "drives the PREVIEW mesh, which renders any skin correctly. Pick a champion below, click "
            "a skin, and watch the preview model. If it changes AND carries into the match, that's it.");
        if (!g_DetectedChamp[0]) AutoDetectChampion();
        // Champion selector (manual, since auto-detect needs a pawn we may not have).
        BuildChampionDropdown();
        ImGui::Text("Showing skins for: %s", g_SelChampName[0] ? g_SelChampName : "(pick a champion)");
        if (g_SelChampName[0]) {
            ImGui::BeginChild("lobbyskins", ImVec2(0, 140), true);
            for (int i = 0; i < SkinDB::kSkinCount; ++i) {
                const SkinDB::Entry& e = SkinDB::kSkins[i];
                if (lstrcmpA(e.champion, g_SelChampName) != 0) continue;
                bool dup = false;
                for (int k = i - 1; k >= 0; --k) {
                    if (lstrcmpA(SkinDB::kSkins[k].champion, e.champion) != 0) break;
                    if (lstrcmpA(SkinDB::kSkins[k].name, e.name) == 0) { dup = true; break; }
                }
                if (dup) continue;
                char lbl[160]; wsprintfA(lbl, "%-9s %s##lob%d", e.rarity, e.name, i);
                if (ImGui::Selectable(lbl, rebuildSkinId == e.id)) {
                    rebuildSkinId = e.id; rebuildWeaponId = e.id;
                    lstrcpynA(skinName, e.name, sizeof(skinName));
                    g_Pending = LobbySkin;   // drive the preview mesh
                }
            }
            ImGui::EndChild();
        }
        if (g_LastLobbyApplied >= 0)
            ImGui::Text("Last preview apply hit %d lobby meshes (0 = not on a preview screen)",
                        g_LastLobbyApplied);

        // The preview (SetSkin) only changes the model you're LOOKING at, not the
        // skin you SPAWN with. This tries the loadout setter, which is the thing
        // that should carry into the match. Do it in champion select, then spawn.
        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.9f, 1.0f)), "MAKE IT CARRY INTO THE MATCH:");
        if (ImGui::Button("Set as LOADOUT skin (SetPlayerProfile)", ImVec2(320, 26)))
            g_Pending = ProfileSkin;
        ImGui::SetNextItemWidth(90); ImGui::InputInt("profileId", &g_ProfileId);
        ImGui::SameLine();
        ImGui::SetNextItemWidth(90); ImGui::InputInt("voicePack", &g_ProfileVoiceId);
        ImGui::TextWrapped("This is the LEGIT path the dev item shop uses. Server dresses you at SPAWN. "
            "TEST: fire this in CHAMPION SELECT then lock in - OR fire it in-match then SUICIDE/respawn. "
            "If you respawn wearing the skin (and a teammate sees it), that's the real method - it went "
            "through the server, not a local repaint. Try profileId 0, then 1, then your champion id.");
        ImGui::TextDisabled("Click this in champion select AFTER picking the preview skin, then spawn.");
        ImGui::TextDisabled("If you spawn WITH the skin, this is the route. If not, tell me.");
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.9f, 0.4f, 1.0f)),
            "If preview meshes = 0, you're not on a preview screen. If it changes the");
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.9f, 0.4f, 1.0f)),
            "preview but NOT the match, tell me - the carry-over is the next step.");
        ImGui::Separator();
        }   // end "The ROUTE method" collapse

        // ---- MENU-ONLY TOOLS: drawn BEFORE the !inMatch return ----
        // These are the tools you use in the MENU, so gating them behind "needs a
        // spawned pawn" made them unreachable exactly where they're meant to be
        // used. That is why the blue MENU PREVIEW button never appeared in the menu.
        // ---- EXPERIMENTS: collapsed by default, none of these ever worked ----
        // Menu preview (ChangeClassModel), the game-call capture, the dev-shop
        // command dumper, the MeshInfo tree scan and the weapon asm-id route all
        // produced nothing usable in testing. Kept for reference, out of the way.
        // Collapsed for TIDINESS, not because it's all dead. Contents vary:
        // METHOD C and the weapon asm ids are UNTESTED and live; the capture /
        // menu-preview / meshinfo pieces returned nothing so far.
        // Champion-select preview and the menu tools - collapsed. None of them
        // apply a skin in a match; they are for previewing and for research.
        if (ImGui::CollapsingHeader("CHAMPION-SELECT PREVIEW + menu tools (collapsed)")) {
            DrawMenuPreviewSection();
        }

        if (!inMatch) {
            ImGui::TextDisabled("The IN-MATCH methods below need a spawned pawn.");
            ImGui::TextDisabled("Use the MENU PREVIEW above (and the MeshInfo scan) here.");
            return;
        }

        // FOCUS MODE — collapses the dead-end sections (dev menu, route-by-name,
        // vendor, id sweep) so only the working COMBINED FULL APPLY flow shows.
        ImGui::Checkbox("Focus mode (show only Combined Full Apply)", &g_FocusMode);
        ImGui::Separator();

        // The dev-menu + full hide-mesh block only shows outside focus mode.
        if (!g_FocusMode) {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.85f, 0.45f, 0.1f, 1.0f));
            if (ImGui::Button(">>> OPEN HIDDEN DEV MENU <<<", ImVec2(320, 34))) g_Pending = OpenDevMenu;
            ImGui::PopStyleColor();
            ImGui::TextWrapped("Most literal match for 'hidden developer item shop'. If a dev panel "
                "appears, find a Skin section, equip there, and tell me the commands it lists.");

            ImGui::Spacing();
            ImGui::TextColored(Ink(ImVec4(0.6f, 0.85f, 1.0f, 1.0f)), "INVISIBLE / HIDE WEAPON  (HideMeshes)");
            if (ImGui::Button(hide1P ? "1P (arms+weapon): HIDDEN" : "Hide 1P (arms+weapon)", ImVec2(230, 26)))
                g_Pending = HideMesh1P;
            ImGui::SameLine();
            if (ImGui::Button(hide3P ? "3P (body): HIDDEN" : "Hide 3P (body)", ImVec2(190, 26)))
                g_Pending = HideMesh3P;
            if (ImGui::Button("Show everything again", ImVec2(200, 24))) g_Pending = ShowMeshes;
            ImGui::Separator();
        }

        // STEP 1 - PICK A SKIN (extracted to DrawStep1PickSkin so the Skins tab
        // can also draw it standalone at the top of its clean flow).
        DrawStep1PickSkin();

        // METHOD A's other half: precache every skin for this champion so the
        // mesh list has something to show. Directly under the picker, because
        // the two are used together.
        ImGui::Spacing();
        DrawLoadAllSection();

        // (MENU PREVIEW now lives in DrawMenuPreviewSection(), drawn above the
        // !inMatch return so it is reachable in the menu where it belongs.)

    }


    // ===================== METHOD C SECTION ==============================
    // Lifted out of DrawControls so the Skins tab can show Method C and
    // Method D together inside ONE collapsible. Neither actually changes a
    // skin in a real match - they are kept for anyone who wants to take the
    // research further, not as features. Code is unchanged from where it
    // used to live inline.
    inline void DrawMethodCSection(bool /*inMatch*/) {
        // ==== THE FULL SKIN ROUTE (the complete method) =====================
        // ==== METHOD C: BUILD BY ID (the game's own component builder) =======
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.6f, 1.0f, 1.0f, 1.0f)));
        ImGui::TextWrapped("########  METHOD C - BUILD BY ID  ########");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("ATgPawn::CreateMeshComponent(meshId, destComponent, partialFixup) - the "
            "game's OWN mesh builder. Method A changes a replicated id (server reverts it). Method B "
            "overwrites a mesh pointer (broken skeletons). Method C hands an ID to the builder and "
            "lets the GAME construct the mesh into a component we pick - correct skeleton, correct "
            "anim tree, no extrusions, not replicated, and it targets BODY / ARMS / WEAPON separately.");
        ImGui::TextWrapped("We never tried this: we wrote m_nBodyMeshAsmId then called AddBodyMesh, "
            "which re-reads the skin id and discarded our value. That is why asm ids 'did nothing'.");
        ImGui::SetNextItemWidth(120); ImGui::InputInt("mesh id", &g_BuildMeshId);
        ImGui::SameLine();
        ImGui::Checkbox("partial fixup", &g_BuildPartialFixup);
        if (ImGui::Button("LEARN current ids (body/arms/wep)", ImVec2(280, 26))) {
            g_BuildMeshId = SafeCalls::ReadBodyAsmId();
            int d = 0, a1 = 0, a3 = 0;
            SafeCalls::ReadWeaponAsmIds(&d, &a1, &a3);
            g_WepAsm1P = a1; g_WepAsm3P = a3; g_WepDevice = d;
            char m[128];
            wsprintfA(m, "body asm=%d  wep1P=%d  wep3P=%d  device=%d", g_BuildMeshId, a1, a3, d);
            Log(m, true);
        }
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.5f, 0.6f, 1.0f));
        if (ImGui::Button("BUILD -> BODY", ImVec2(150, 28)))
            Log("BuildBodyFromId", SafeCalls::BuildBodyFromId(g_BuildMeshId, g_BuildPartialFixup));
        ImGui::SameLine();
        if (ImGui::Button("BUILD -> ARMS", ImVec2(150, 28)))
            Log("BuildArmsFromId", SafeCalls::BuildArmsFromId(g_BuildMeshId, g_BuildPartialFixup));
        ImGui::SameLine();
        if (ImGui::Button("BUILD -> WEAPON 1P", ImVec2(170, 28)))
            Log("BuildWeaponFromId 1P", SafeCalls::BuildWeaponFromId(g_BuildMeshId, true, g_BuildPartialFixup));
        ImGui::SameLine();
        if (ImGui::Button("BUILD -> WEAPON 3P", ImVec2(170, 28)))
            Log("BuildWeaponFromId 3P", SafeCalls::BuildWeaponFromId(g_BuildMeshId, false, g_BuildPartialFixup));
        ImGui::PopStyleColor();
        ImGui::TextWrapped("TEST: shooting range -> wear skin A -> LEARN (records its ids) -> wear "
            "skin B -> put skin A's id in 'mesh id' -> BUILD -> BODY. If skin A's model appears on "
            "skin B cleanly, Method C works. Then try BUILD -> WEAPON with the learned wep1P/3P ids.");

        // FULL ROUTE is a CollapsingHeader now (not a TreeNode) so it sits flush
        // with the other sections and can be opened/closed like the rest.
        if (ImGui::CollapsingHeader("METHOD: FULL ROUTE / m_pAmSkin")) {
            DrawFullRouteSection();
        }
    }

    // Menu-only: the game's own model swap. Safe to draw with no pawn.
    // ===================== METHOD D TAB (Skins2) ==========================
    inline void DrawMethodDTab(bool inMatch) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.5f, 1.0f, 0.8f, 1.0f)));
        ImGui::TextWrapped("METHOD D - PRE-MATCH SELECTION INJECTION");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("A/B/C all change the skin AFTER the game decided what you're wearing - so "
            "they fight the server, break skeletons, and never carry the weapon. D changes WHAT YOU "
            "SELECTED, before the match, then lets the game's own pipeline load body + arms + weapon "
            "normally.");
        ImGui::TextWrapped("Ownership is a SELECTION-TIME gate only (skin boosters prove it: unlock "
            "selection and the game just accepts it afterwards). There is no in-match ownership check "
            "to beat. We don't unlock the menu - we SKIP it, writing the selection directly into "
            "UTgClientSettings (ChosenSkinId 0x1C0 / ChosenClassId / ChosenWeaponId / "
            "ChosenWeaponSkinId). Plain ints on a client object, nothing validates them.");
        ImGui::Separator();

        // --- 1. pick the skin ---
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.4f, 1.0f)), "1. PICK THE SKIN");
        ImGui::SetNextItemWidth(180);
        ImGui::InputText("champion##d", g_MenuChampFilter, sizeof(g_MenuChampFilter));
        ImGui::SameLine();
        ImGui::Checkbox("hide dupes##d", &g_DedupeSkins);
        ImGui::Text("SELECTED: %s   class=%d skin=%d weaponSkin=%d",
                    skinName[0] ? skinName : "(none)", liveBotId, rebuildSkinId, rebuildWeaponId);
        ImGui::BeginChild("dskins", ImVec2(0, 190), true);
        {
            const int total = (int)(sizeof(SkinDB::kSkins) / sizeof(SkinDB::kSkins[0]));
            int shownN = 0;
            for (int i = 0; i < total && shownN < 400; ++i) {
                const SkinDB::Entry& e = SkinDB::kSkins[i];
                if (g_MenuChampFilter[0] && !MeshSkin::HasCI(e.champion, g_MenuChampFilter)) continue;
                if (g_DedupeSkins) {
                    bool dup = false;
                    for (int j = 0; j < i; ++j)
                        if (lstrcmpiA(SkinDB::kSkins[j].champion, e.champion) == 0 &&
                            lstrcmpiA(SkinDB::kSkins[j].name, e.name) == 0) { dup = true; break; }
                    if (dup) continue;
                }
                shownN++;
                char lbl[160];
                wsprintfA(lbl, "%s | %s (%d)##d%d", e.champion, e.name, e.id, i);
                if (ImGui::Selectable(lbl, rebuildSkinId == e.id)) {
                    rebuildSkinId = e.id; rebuildWeaponId = e.id; liveBodySkinId = e.id;
                    lstrcpynA(skinName, e.name, sizeof(skinName));
                    lstrcpynA(godName, e.champion, sizeof(godName));
                    FillLiveIdsFromSelection();
                }
            }
            if (shownN == 0) ImGui::TextDisabled("Type a champion name above (e.g. Maeve).");
        }
        ImGui::EndChild();

        // --- 2. inject the selection ---
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.4f, 1.0f)), "2. INJECT THE SELECTION  (do this in the MENU)");
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.55f, 0.45f, 1.0f));
        if (ImGui::Button(">>> SET AS MY SELECTED SKIN <<<", ImVec2(340, 32))) {
            bool ok = SafeCalls::SetChosenSkin(rebuildSkinId, rebuildWeaponId, liveBotId, g_PrevDeviceId);
            BuildMethodDReport();
            Log("SetChosenSkin (ChosenSkinId/ClassId/WeaponId/WeaponSkinId)", ok);
        }
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::Checkbox("hold it (re-write 2/s)", &g_DHoldSelection);
        ImGui::TextWrapped("Then queue and load into the match NORMALLY. Do not touch Skins tab, do "
            "not apply anything in-match. The game should load the skin itself.");

        // --- 3. verify ---
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.4f, 1.0f)), "3. VERIFY");
        if (ImGui::Button("READ STATE", ImVec2(140, 24))) BuildMethodDReport();
        ImGui::SameLine();
        if (ImGui::Button("COPY STATE", ImVec2(140, 24))) { BuildMethodDReport(); MeshSkin::CopyClip(g_DState); }
        ImGui::SameLine();
        if (ImGui::Button("WRITE TO FILE", ImVec2(150, 24))) {
            bool ok = WriteMethodDFile();
            Log(ok ? "wrote PHAROAH_MethodD.txt (next to the game exe)" : "file write FAILED", ok);
        }
        ImGui::BeginChild("dstate", ImVec2(0, 150), true);
        ImGui::TextUnformatted(g_DState[0] ? g_DState : "(press READ STATE)");
        ImGui::EndChild();
        ImGui::TextWrapped("ChosenSkinId is the number that matters. If it holds your chosen id in the "
            "MENU and the match loads you wearing it, Method D works and every other method becomes "
            "unnecessary. If ChosenSkinId reads -999 the client-settings object isn't reachable.");
    }

    inline void DrawMenuPreviewSection() {
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.4f, 0.9f, 1.0f, 1.0f)));
        ImGui::TextWrapped(">>> MENU PREVIEW - THE GAME'S OWN CALL <<<");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("USE THIS IN THE MENU / CHAMPION SELECT. This calls the exact function the "
            "game runs when you click a skin: ATgLobbyHUD::ChangeClassModel(classId, skinId, deviceId, "
            "DEVICE-SKIN, pedestal, pose, camera, async, highlight, mvp).");
        ImGui::TextWrapped("It takes the WEAPON skin as its own parameter, so it loads the COMPLETE "
            "package - body, arms and weapon - on the right pedestal with the right camera. Our old "
            "preview walked the lobby meshes and overwrote pointers, which is exactly why the model "
            "landed in the wrong place, smeared onto ally stage circles, and never had a weapon.");
        ImGui::TextWrapped("Because it's the legitimate path it renders ANY skin (the store previews "
            "skins you don't own) - an ownership-free loader for BOTH halves.");
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.45f, 0.65f, 1.0f));
        // NOTE: never start an ImGui label with '#'. "##" means "everything after
        // is ID, not text", so "##### PREVIEW..." rendered as an EMPTY button with
        // a colliding ID — unclickable, and the source of the "conflicting ID"
        // popup. This is why the menu preview appeared to do nothing.
        // ==== CAPTURE WHAT THE GAME DOES (do this FIRST) ====================
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.9f, 0.4f, 1.0f)));
        ImGui::TextWrapped(">>> CAPTURE: change a skin/weapon NORMALLY and we record the game's own call <<<");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Leave this on, then in the menu click skins and WEAPONS the normal way (not "
            "our buttons). Every ChangeClassModel / ChangeTeamModel / Lobby.SetSkin the game makes is "
            "logged with its REAL parameters - including the deviceId and deviceSkinId we've been "
            "passing as 0. That is the weapon answer, straight from the game. Then press COPY.");
        if (ImGui::Checkbox("capture game skin calls", &g_CaptureSkinCalls)) {
            if (g_CaptureSkinCalls) ResolveSkinCaptureFns();   // resolve HERE, safe thread
        }
        ImGui::SameLine();
        if (ImGui::Button("RESOLVE fns", ImVec2(110, 22))) ResolveSkinCaptureFns();
        ImGui::SameLine();
        if (ImGui::Button("CLEAR##cap", ImVec2(80, 22))) { g_SkinCapCount = 0; g_WideCount = 0; }
        // Show whether the functions were even FOUND. If these are all NO, the
        // names are wrong and no amount of clicking will ever capture anything —
        // which is the information the empty log failed to give us last time.
        ImGui::Text("fn found:  ChangeClassModel=%s  ChangeTeamModel=%s  Lobby.SetSkin=%s",
                    g_fnCapCCM ? "YES" : "NO", g_fnCapCTM ? "YES" : "NO", g_fnCapSS ? "YES" : "NO");
        ImGui::Text("captured: %d    wide-net hits: %d", g_SkinCapCount, g_WideCount);
        ImGui::Checkbox("WIDE NET (log any scripted fn named *Skin*/*Model*/*Mesh*)", &g_CapWideNet);
        if (g_WideCount > 0) {
            if (ImGui::Button("COPY WIDE-NET LOG", ImVec2(200, 24))) {
                static char wbig[64 * 160 + 256];
                wbig[0] = '\0';
                lstrcatA(wbig, "===== WIDE NET (scripted skin/model/mesh calls) =====\r\n");
                for (int i = 0; i < g_WideCount; ++i) {
                    lstrcatA(wbig, g_WideLog[i]); lstrcatA(wbig, "\r\n");
                }
                MeshSkin::CopyClip(wbig);
            }
            ImGui::BeginChild("widenet", ImVec2(0, 110), true);
            for (int i = 0; i < g_WideCount; ++i) ImGui::TextUnformatted(g_WideLog[i]);
            ImGui::EndChild();
        }
        if (ImGui::Button("COPY CAPTURED SKIN CALLS", ImVec2(280, 26))) {
            static char big[48 * 160 + 256];
            big[0] = '\0';
            lstrcatA(big, "===== GAME'S OWN SKIN CALLS =====\r\n");
            for (int i = 0; i < g_SkinCapCount; ++i) {
                lstrcatA(big, g_SkinCapLog[i]);
                lstrcatA(big, "\r\n");
            }
            if (g_SkinCapCount == 0)
                lstrcatA(big, "(nothing captured - change a skin in the menu with capture ON)\r\n");
            MeshSkin::CopyClip(big);
        }
        if (g_SkinCapCount > 0) {
            ImGui::BeginChild("skincap", ImVec2(0, 110), true);
            for (int i = 0; i < g_SkinCapCount; ++i) ImGui::TextUnformatted(g_SkinCapLog[i]);
            ImGui::EndChild();
        }

        // ---- SKIN PICKER (menu) ----
        // This was the missing half: the button below reads rebuildSkinId, but the
        // only skin list lived BELOW the !inMatch return, so in the menu there was
        // nothing to set it and the button applied skin id 0 = did nothing.
        {
            ImGui::SetNextItemWidth(180);
            ImGui::InputText("champion filter", g_MenuChampFilter, sizeof(g_MenuChampFilter));
            ImGui::SameLine();
            ImGui::Checkbox("hide duplicate names", &g_DedupeSkins);
            ImGui::Text("SELECTED: %s  (skinId %d)", skinName[0] ? skinName : "(none)", rebuildSkinId);
            ImGui::BeginChild("menuskinpick", ImVec2(0, 150), true);
            const int total = (int)(sizeof(SkinDB::kSkins) / sizeof(SkinDB::kSkins[0]));
            int shownN = 0;
            for (int i = 0; i < total && shownN < 400; ++i) {
                const SkinDB::Entry& e = SkinDB::kSkins[i];
                if (g_MenuChampFilter[0] && !MeshSkin::HasCI(e.champion, g_MenuChampFilter)) continue;
                // DEDUPE by champion+name. The database holds the same skin under
                // several ids (Raeve appearing 6 times), which made the list a mess
                // and gave no way to tell the entries apart. Show the first id and
                // skip later repeats of the same name.
                if (g_DedupeSkins) {
                    bool dup = false;
                    for (int j = 0; j < i; ++j) {
                        const SkinDB::Entry& p = SkinDB::kSkins[j];
                        if (lstrcmpiA(p.champion, e.champion) == 0 &&
                            lstrcmpiA(p.name, e.name) == 0) { dup = true; break; }
                    }
                    if (dup) continue;
                }
                shownN++;
                char lbl[160];
                wsprintfA(lbl, "%s | %s (%d)##mp%d", e.champion, e.name, e.id, i);
                if (ImGui::Selectable(lbl, rebuildSkinId == e.id)) {
                    rebuildSkinId   = e.id;      // what the preview button uses
                    rebuildWeaponId = e.id;      // weapon skin id
                    liveBodySkinId  = e.id;
                    lstrcpynA(skinName, e.name, sizeof(skinName));
                    lstrcpynA(godName, e.champion, sizeof(godName));
                    FillLiveIdsFromSelection();  // resolves liveBotId (classId)
                }
            }
            if (shownN == 0) ImGui::TextDisabled("No matches - type a champion name above (e.g. Maeve).");
            ImGui::EndChild();
            ImGui::Text("classId(liveBotId)=%d  skinId=%d  weaponSkinId=%d",
                        liveBotId, rebuildSkinId, rebuildWeaponId);
        }

        bool lobby = SafeCalls::IsLobbyHud();
        if (!lobby) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.5f, 0.4f, 1.0f)),
                "MENU ONLY - you are in a match (HUD is not the lobby HUD). Button disabled.");
        }
        if (!lobby) ImGui::BeginDisabled();
        if (ImGui::Button(">>> PREVIEW SKIN IN MENU (body + weapon) <<<", ImVec2(400, 34)))
            g_Pending = MenuPreview;
        if (!lobby) ImGui::EndDisabled();
        ImGui::PopStyleColor();
        ImGui::SetNextItemWidth(110); ImGui::InputInt("deviceId", &g_PrevDeviceId);
        ImGui::SameLine();
        ImGui::SetNextItemWidth(110); ImGui::InputInt("pedestal", &g_PrevPedestalId);
        ImGui::SameLine();
        ImGui::Checkbox("async", &g_PrevAsync);
        ImGui::Text("uses: class=%d  skin=%d  weaponSkin=%d  (pick a skin in the list above)",
                    liveBotId, rebuildSkinId, rebuildWeaponId);
        if (ImGui::Button("Preview on TEAM slot instead", ImVec2(260, 24))) g_Pending = MenuPreviewTeam;
        ImGui::SameLine();
        ImGui::SetNextItemWidth(90); ImGui::InputInt("slot", &g_PrevTeamIndex);
        ImGui::TextWrapped("If the main button targets the wrong actor, try the TEAM slot version "
            "(slot 0 = you). deviceId 0 = the champion's default weapon; leave pedestal 0.");
        // MeshInfo scan is a menu tool too — draw it right here.
        MeshSkin::DrawMeshInfoSection();

        // ---- WEAPON ASSEMBLY IDS: the actual weapon route ----
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.75f, 0.35f, 1.0f)));
        ImGui::TextWrapped(">>> WEAPON ASM IDS - the real weapon route <<<");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("The weapon is built from MESH ASSEMBLY IDS on the weapon actor "
            "(m_MeshAsmId1P 0x34C / m_MeshAsmId3P 0x350 / m_nDeviceId 0x348), exactly like the body "
            "uses m_nBodyMeshAsmId. That is why writing skin IDs at the weapon never did anything - "
            "wrong field entirely. LEARN while wearing a skin, then APPLY those ids on another skin.");
        if (ImGui::Button("LEARN weapon asm ids", ImVec2(210, 24))) {
            int d = 0, a1 = 0, a3 = 0;
            bool ok = SafeCalls::ReadWeaponAsmIds(&d, &a1, &a3);
            if (ok) { g_WepDevice = d; g_WepAsm1P = a1; g_WepAsm3P = a3; }
            char m[128]; wsprintfA(m, "weapon device=%d asm1P=%d asm3P=%d", d, a1, a3);
            Log(m, ok);
        }
        ImGui::SameLine();
        if (ImGui::Button("APPLY weapon asm ids", ImVec2(210, 24))) {
            bool ok = SafeCalls::SetWeaponAsmIds(g_WepAsm1P, g_WepAsm3P, g_WepDevice, true);
            Log("SetWeaponAsmIds + UpdateWeaponMesh", ok);
        }
        ImGui::SetNextItemWidth(100); ImGui::InputInt("asm1P", &g_WepAsm1P); ImGui::SameLine();
        ImGui::SetNextItemWidth(100); ImGui::InputInt("asm3P", &g_WepAsm3P); ImGui::SameLine();
        ImGui::SetNextItemWidth(100); ImGui::InputInt("deviceId##wep", &g_WepDevice);
        ImGui::TextWrapped("Workflow: shooting range -> wear skin A -> LEARN -> wear skin B -> APPLY. "
            "If skin A's gun appears on skin B, the weapon route is cracked.");
    }

    inline void DrawFullRouteSection() {
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)));
        ImGui::TextWrapped(">>> THE FULL ROUTE - TRY THIS FIRST <<<");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Every earlier attempt wrote ONE link of a FOUR-link chain, which is exactly "
            "why you got ult/VGS/sounds but never the body. The real route is:");
        ImGui::TextWrapped("  1. ClientSettings.ChosenSkinId  <- your CHOICE (this IS the 'dev item "
            "shop'; it's a plain int, nothing checks ownership)");
        ImGui::TextWrapped("  2. PlayerReplicationInfo.r_nSkinId  <- what the game reads to DRESS a "
            "player. WE HAVE NEVER WRITTEN THIS. This is the missing link.");
        ImGui::TextWrapped("  3. Pawn.r_nSkinId  <- the only thing we ever touched before");
        ImGui::TextWrapped("  4. Pawn.m_pAmSkin  <- the resolved skin pointer the renderer uses");
        ImGui::TextWrapped("This button writes all four in order, then runs the game's own rebuild - "
            "the same way a legitimate skin change happens. Pick a skin in the list above first.");
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.1f, 0.6f, 0.25f, 1.0f));
        if (ImGui::Button(">>> APPLY FULL ROUTE <<<", ImVec2(380, 36))) g_Pending = FullRoute;
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::Checkbox("Persist##route", &g_RoutePersist);
        ImGui::Checkbox("also repoint m_pAmSkin (uses skin index below)", &g_RouteUseAmIdx);
        if (ImGui::Button("Read route state", ImVec2(170, 22))) g_Pending = ReadRoute;
        ImGui::SameLine();
        ImGui::Text("chosen=%d  pri=%d  pawn=%d",
                    g_LiveChosenSkin, g_LivePriSkin, SafeCalls::ReadLiveSkinId());
        ImGui::TextWrapped("Read route state tells us WHICH link fails: if chosen/pri hold your id but "
            "the body is default, the block is at the rebuild; if they revert, the server is "
            "re-asserting and you should tick Persist.");

        // ==== DEV-SHOP COMMAND DUMPER =======================================
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.5f, 0.5f, 1.0f)));
        ImGui::TextWrapped("*** READ THE HIDDEN DEV ITEM SHOP ***");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("The dev shop is NOT a store - it's a menu built from console commands via "
            "AddCommand(Section, Command, DisplayName). Turn this on, then open the dev menu: every "
            "command it registers gets logged here, with the exact strings the game itself uses. "
            "That's the 'route actual skins take', read rather than guessed.");
        ImGui::Checkbox("CAPTURE dev menu commands", &g_CaptureDevCommands);
        ImGui::SameLine();
        if (ImGui::Button("Open dev menu", ImVec2(140, 22))) g_Pending = OpenDevMenu;
        ImGui::SameLine();
        if (ImGui::Button("Clear", ImVec2(70, 22))) g_DevCmdCount = 0;
        ImGui::Text("captured: %d", g_DevCmdCount);
        if (g_DevCmdCount > 0) {
            if (ImGui::Button("COPY ALL DEV COMMANDS", ImVec2(260, 24))) {
                static char big[64 * 192 + 128];
                big[0] = '\0';
                lstrcatA(big, "===== DEV MENU COMMANDS =====\r\n");
                for (int i = 0; i < g_DevCmdCount; ++i) {
                    lstrcatA(big, g_DevCmdLog[i]);
                    lstrcatA(big, "\r\n");
                }
                MeshSkin::CopyClip(big);
            }
            ImGui::BeginChild("devcmds", ImVec2(0, 140), true);
            for (int i = 0; i < g_DevCmdCount; ++i) ImGui::TextUnformatted(g_DevCmdLog[i]);
            ImGui::EndChild();
        }

        // ==== THE FIRE-MODE METHOD FOR SKINS (m_pAmSkin) ====================
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.95f, 0.3f, 1.0f)));
        ImGui::TextWrapped("*** FIRE-MODE METHOD: m_pAmSkin pointer swap ***");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Hidden FIRE MODES work in real matches because we write the fields the "
            "client READS, raw, instead of calling a setter that refuses hidden content. Same idea "
            "here: m_pAmSkin (0x2850) is the RESOLVED skin pointer the renderer dereferences - "
            "r_nSkinId is only the id the server syncs. m_pAmAllSkins (0x2868) already holds pointers "
            "to this pawn's skins, so we just point m_pAmSkin at a different entry. Nothing to load, "
            "nothing to name, and no replicated field for the server to revert.");
        if (ImGui::Button("1. SCAN pawn's skin array", ImVec2(240, 26))) g_Pending = AmSkinScan;
        ImGui::SameLine();
        ImGui::Text("count = %d", g_AmSkinCount);
        ImGui::SetNextItemWidth(120);
        ImGui::InputInt("skin index", &g_AmSkinIndex);
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.65f, 0.55f, 0.1f, 1.0f));
        if (ImGui::Button("2. *** WEAR (m_pAmSkin) ***", ImVec2(260, 30))) g_Pending = AmSkinApply;
        ImGui::PopStyleColor();
        ImGui::SameLine();
        if (ImGui::Button("NEXT skin >>", ImVec2(130, 30))) g_Pending = AmSkinNext;
        ImGui::Checkbox("also weapon (m_pAmWeaponSkin)", &g_AmSkinWeapon);
        ImGui::SameLine();
        ImGui::Checkbox("Persist##amskin", &g_AmSkinPersist);
        if (ImGui::Button("RAW multi-field write (all skin fields at once)", ImVec2(340, 24)))
            g_Pending = AllFieldsRaw;
        ImGui::TextWrapped("Use NEXT to cycle every entry - no ids needed. This is the most direct "
            "'route actual skins take' we've found: it swaps the resolved skin object itself, and it "
            "also carries the WEAPON (m_pAmWeaponSkin), which no other method has managed.");

        // This whole section moved into DrawLoadAllSection() so the MAIN Skins
        // tab can show it at the top - it is the part that makes everything else
        // work, and it was buried down here in the dev methods.
        DrawLoadAllSection();

        // ---- WEAPON (the one piece we never cracked) ----
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.7f, 0.3f, 1.0f)));
        ImGui::TextWrapped("WEAPON SKIN  (force-load via game host + apply)");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("NEW: the game has EnsureBotPrecache(botId, skin, WEAPONskin) - a real "
            "weapon force-loader (the 'Ying illusion for the gun'). It works when you're the HOST = "
            "the SHOOTING RANGE. Uses skin id (body) + weapon id from your selection above. If the "
            "weapon still doesn't change, hit PRECACHE, wait 2s, then APPLY (loading is async).");
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.55f, 0.4f, 0.15f, 1.0f));
        if (ImGui::Button("*** APPLY WEAPON SKIN (range) ***", ImVec2(280, 28)))
            g_Pending = WeaponApply;
        ImGui::PopStyleColor();
        ImGui::SameLine();
        if (ImGui::Button("Precache weapon only", ImVec2(180, 28))) g_Pending = WeaponPrecacheOnly;
        ImGui::Text("live r_nWeaponSkinId = %d   (selected weapon id %d)",
                    g_LiveWeaponSkinId, rebuildWeaponId);

        // ---- ASSEMBLY REMAP: "server confirms default, renders target" ----
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.4f, 0.9f, 1.0f)));
        ImGui::TextWrapped("ASSEMBLY REMAP  (your idea: lie to the server)");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("The server owns your skin ID - but NOT what the mesh-assembly resolves that "
            "id into. We repoint the assembly at the target's asm id and call the game's OWN LoadMesh() "
            "(the route skins actually take). Server keeps confirming 'default', but default now builds "
            "the target. Because we changed the RESOLUTION not the id, a server re-assert still lands on "
            "the target - which is why this can survive a REAL match.");
        ImGui::TextWrapped("STEP 1 (range): wear the target skin (Combined Full Apply), press 'LEARN "
            "current asm id' below. STEP 2 (real match, on default): press REMAP.");
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.6f, 0.2f, 0.5f, 1.0f));
        if (ImGui::Button("*** REMAP ASSEMBLY (real-match body) ***", ImVec2(340, 30)))
            g_Pending = RemapAssembly;
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::Checkbox("Persist (re-assert 1/s)", &g_RemapPersist);
        if (ImGui::Button("Read live assembly id", ImVec2(190, 22))) g_Pending = ReadAssembly;
        ImGui::SameLine();
        ImGui::Text("assembly asm id = %d   (learned target = %d)", g_LiveAssemblyAsm, g_LearnedBodyAsm);
        ImGui::TextWrapped("If assembly id shows your target but body is still default -> the assembly "
            "isn't the render source; tell me and I'll walk it via GObjects. If body CHANGES and holds "
            "in a real match -> that's the win, and it's exactly what your source described.");

        // ---- CLIENT OVERRIDE: c_nOverrideSkinId (THE real-match candidate) ----
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.3f, 1.0f, 0.6f, 1.0f)));
        ImGui::TextWrapped("CLIENT SKIN OVERRIDE  (c_nOverrideSkinId - Transient/client-only)");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("NEW find: the mesh COMPONENT has a client-only skin id the server CANNOT "
            "replicate over (unlike r_nSkinId). This is the field we thought didn't exist - it's on "
            "the body mesh, not the pawn. Confirmed 0x508 in two SDK dumps. This is the profile of "
            "'works flawlessly in real matches'. Uses the id from the skin you selected above.");
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.55f, 0.35f, 1.0f));
        if (ImGui::Button("*** WEAR (CLIENT OVERRIDE - try in REAL match) ***", ImVec2(360, 30)))
            g_Pending = OverrideSkin;
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::Checkbox("Persist (re-write 2/s)", &g_OverridePersist);
        ImGui::Checkbox("Also set r_nSkinId (helps materials resolve)", &g_OverrideAlsoRepId);
        ImGui::SameLine();
        ImGui::SetNextItemWidth(90);
        ImGui::InputInt("Skin level", &g_OverrideSkinLevel);
        if (ImGui::Button("Read live override id", ImVec2(180, 22))) g_Pending = ReadOverride;
        ImGui::SameLine();
        ImGui::Text("live c_nOverrideSkinId = %d", g_LiveOverrideId);
        ImGui::TextWrapped("TEST: in a REAL match, click WEAR (CLIENT OVERRIDE). If your body renders "
            "the skin and it HOLDS (doesn't flash back), that's the crack. Tick Persist if a respawn "
            "clears it. Preview the skin in champ-select first so the mesh is loaded.");

        // ---- NON-NET ASM-ID PATH (the real-match experiment) ----
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.3f, 1.0f)), "ASM-ID METHOD (non-Net -> might survive real matches)");
        ImGui::TextWrapped("m_nBodyMeshAsmId is NOT server-replicated, unlike r_nSkinId. Plan: in the "
            "RANGE, wear a skin (combined apply), press LEARN to read that skin's asm id, then in a "
            "REAL MATCH press APPLY with that id. If the skin holds in the match AND illusions follow, "
            "this is the method.");
        ImGui::Text("Live body asm id: %d    learned: body=%d core=%d",
                    SafeCalls::ReadBodyAsmId(), g_LearnedBodyAsm, g_LearnedCoreAsm);
        if (ImGui::Button("LEARN current asm id", ImVec2(190, 24))) g_Pending = LearnAsm;
        ImGui::SameLine();
        ImGui::PushItemWidth(110);
        ImGui::InputInt("Asm id to apply", &g_ApplyAsmId);
        ImGui::PopItemWidth();
        if (ImGui::Button("APPLY asm id + rebuild", ImVec2(200, 24))) g_Pending = ApplyAsm;
        ImGui::SameLine();
        ImGui::Checkbox("also set core", &g_AsmSetCore);
        ImGui::TextDisabled("If APPLY changes your skin in a REAL match, tell me immediately - that's the unlock.");

        if (ImGui::Button(hide1P ? "1P weapon: HIDDEN" : "Hide 1P weapon", ImVec2(160, 22)))
            g_Pending = HideMesh1P;
        ImGui::SameLine();
        if (ImGui::Button("Show weapon", ImVec2(110, 22))) g_Pending = ShowMeshes;

        ImGui::TextColored(Ink(ImVec4(1.0f, 1.0f, 0.5f, 1.0f)), "Results (newest first):");
        for (int i = 0; i < g_LogCount && i < 3; ++i)
            ImGui::TextColored(i == 0 ? ImVec4(1,1,0.6f,1) : ImVec4(0.7f,0.7f,0.7f,1), "%s", g_Log[i]);

        // FOCUS MODE cut: everything below is older/experimental methods kept for
        // research. In focus mode we stop here so the ROUTE method is all you see.
        if (g_FocusMode) return;

        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.4f, 1.0f)), "### STEP 2 - APPLY ###");
        if (ImGui::Button("*** TRY SKIN NOW ***", ImVec2(240, 34))) {
            FillLiveIdsFromSelection();
            g_Pending = LiveSwitch;
        }
        ImGui::SameLine();
        if (ImGui::Button("Try with voice pack", ImVec2(170, 34))) {
            FillLiveIdsFromSelection();
            liveVoicePackId = liveBodySkinId;   // best guess: voice pack tracks the skin
            g_Pending = FullSwitch;
        }
        ImGui::TextDisabled("Watch your character (3rd person helps). Then press");
        ImGui::TextDisabled("COPY SKIN REPORT at the top and send it to me.");

        // ====================================================================
        // STEP 2b — FORCE LOAD. Added after the mesh scan proved the real
        // obstacle: other skins' assets are not in memory at all.
        // ====================================================================
        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.3f, 1.0f)),
            "### STEP 2b - FORCE LOAD (the actual obstacle) ###");
        ImGui::TextWrapped("Your mesh scan proved the problem: only the skin you're WEARING is in "
            "memory (everything was named skin00a). UE3 loads skin assets on demand, so no pointer "
            "write can reach a mesh that doesn't exist yet. These force that load using the game's "
            "own precache API.");
        ImGui::TextWrapped("Press one, then go to the mesh scanner below and re-scan. If new names "
            "appear (skin01a, skin02a...) then we've beaten lazy loading and the rest follows.");

        if (ImGui::Button("LOAD ALL SKINS x16 (loop)", ImVec2(240, 28))) {
            g_LoadLoopBatch = 0;
            g_LoadLoopRemaining = 16;   // batches 0..15, one per tick
        }
        if (g_LoadLoopRemaining > 0) {
            ImGui::SameLine();
            ImGui::TextColored(Ink(ImVec4(1,1,0.4f,1)), "loading... %d left", g_LoadLoopRemaining);
        }
        ImGui::SameLine();
        if (ImGui::Button("single batch", ImVec2(110, 28))) g_Pending = LoadAllSkins;
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip(
                "SpawnBotAllSkins - (Native, Public), one int, clean signature.\n"
                "Spawns bots wearing every skin, which necessarily loads their\n"
                "assets. If it runs, the meshes become resident.\n"
                "It may briefly spawn visible bots. That's expected.");
        }
        ImGui::SameLine();
        ImGui::PushItemWidth(70);
        ImGui::InputInt("batch", &loadBatch);
        ImGui::PopItemWidth();

        if (ImGui::Button("Precache my skin (by id)", ImVec2(200, 24))) g_Pending = PrecacheById;
        ImGui::SameLine();
        if (ImGui::Button("Precache (by name)", ImVec2(170, 24))) g_Pending = PrecacheByName;
        ImGui::TextDisabled("These two are (HasOptionalParms) - the same flag that made");
        ImGui::TextDisabled("SetSkeletalMesh corrupt the stack. Try LOAD ALL SKINS first.");

        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.4f, 1.0f)), "### STEP 3 - IF THAT DID NOTHING ###");
        ImGui::TextWrapped("Press these in order. Each one is a different mechanism, so if one "
            "works we know exactly which.");
        if (ImGui::Button("B: skin index 0", ImVec2(130, 24))) { defaultSkinIndex = 0; g_Pending = DefaultSkinBody; }
        ImGui::SameLine();
        if (ImGui::Button("B: index 1", ImVec2(110, 24))) { defaultSkinIndex = 1; g_Pending = DefaultSkinBody; }
        ImGui::SameLine();
        if (ImGui::Button("B: index 2", ImVec2(110, 24))) { defaultSkinIndex = 2; g_Pending = DefaultSkinBody; }
        ImGui::Text("(your pawn tracks %d skins, so valid indexes are 0..%d)",
                    g_AllSkinsCount, g_AllSkinsCount > 0 ? g_AllSkinsCount - 1 : 0);
        ImGui::SameLine();
        if (ImGui::SmallButton("refresh count")) g_AllSkinsCount = SafeCalls::GetAllSkinsCount();

        if (ImGui::Button("C: Precache then SwitchClass (by name)", ImVec2(300, 24)))
            g_Pending = PrecacheThenSwitch;

        // RESULTS — always visible, never inside a collapsed section. This is the
        // only feedback telling you whether a call even went out.
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Results (newest first):");
        for (int i = 0; i < g_LogCount; ++i) {
            ImGui::TextColored(i == 0 ? ImVec4(1.0f, 1.0f, 0.6f, 1.0f)
                                      : ImVec4(0.7f, 0.7f, 0.7f, 1.0f),
                               "%s", g_Log[i]);
        }
        if (g_LogCount == 0) ImGui::TextDisabled("Nothing pressed yet.");
        ImGui::TextWrapped("'called OK' means the call didn't fault - it does NOT mean the game "
            "accepted it. Watch your character. A gated command reports OK and does nothing, "
            "which is exactly how Set3p behaves.");

        ImGui::Spacing();
        ImGui::Separator();

        // Everything below is lower-probability. Collapsed by default so the page
        // reads as "do this, then this" instead of a wall of buttons.
        if (!ImGui::TreeNode("Advanced / less likely methods (collapsed on purpose)")) {
            return;
        }

        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.4f, 1.0f)),
            ">>> METHOD A: LiveMatchSwitchChampion  <<<");
        ImGui::TextWrapped("This is the best candidate found so far, and it is not close. The dumped "
            "flags are (Native, Public) - NOT server, NOT client, NOT exec. So it runs LOCALLY and "
            "is not an RPC the server approves. It takes BodySkinId directly as an int, with nothing "
            "to satisfy about ownership. And the name says LiveMatch, i.e. mid-match.");
        ImGui::TextWrapped("Compare r_nSkinId, which is (Net) and therefore server-owned - that is "
            "exactly why the skin-id approach never worked. This one isn't.");

        if (ImGui::Button("Fill from my champion + selected skin", ImVec2(300, 26))) {
            AutoDetectChampion();
            FillLiveIdsFromSelection();
        }
        ImGui::SameLine();
        ImGui::Text("skins tracked: %d", g_AllSkinsCount);

        ImGui::PushItemWidth(120);
        ImGui::InputInt("Champion (Bot) ID", &liveBotId);
        ImGui::InputInt("Body skin ID", &liveBodySkinId);
        ImGui::InputInt("Weapon skin ID", &liveWeaponSkinId);
        ImGui::PopItemWidth();
        ImGui::TextDisabled("Keep Champion ID as YOUR champion to change only the skin.");
        ImGui::TextDisabled("A different one attempts a real champion swap.");

        if (ImGui::Button("*** LIVE SWITCH SKIN ***", ImVec2(230, 30))) g_Pending = LiveSwitch;
        ImGui::SameLine();
        ImGui::PushItemWidth(90);
        ImGui::InputInt("Voice pack", &liveVoicePackId);
        ImGui::PopItemWidth();
        if (ImGui::Button("SwitchChampion (+voice pack)", ImVec2(240, 26))) g_Pending = FullSwitch;
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip(
                "Same thing plus VoicePackId - this is the route to making the VGS\n"
                "lines match the skin, which the mesh approach cannot do.");
        }

        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.4f, 1.0f)),
            ">>> METHOD B: SetDefaultSkin(index)  <<<");
        ImGui::TextWrapped("Different shape, also strong. UTgSkeletalMeshComponent::SetDefaultSkin "
            "takes an INDEX, and the pawn carries m_pAmAllSkins (all skins, as native pointers, NOT "
            "replicated). So this picks from a list the pawn already holds - meaning the skeleton "
            "already matches and there is no bone mismatch to crash on.");
        ImGui::PushItemWidth(120);
        ImGui::InputInt("Skin index", &defaultSkinIndex);
        ImGui::PopItemWidth();
        ImGui::SameLine();
        if (ImGui::Button("Set body skin", ImVec2(130, 24))) g_Pending = DefaultSkinBody;
        ImGui::SameLine();
        if (ImGui::Button("Set head skin", ImVec2(130, 24))) g_Pending = DefaultSkinHead;
        ImGui::TextDisabled("Try 0, 1, 2, 3... up to 'skins tracked' above.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), "BY NAME  (older attempt)");

        // NO MORE TYPING. You said you hate filling in codes by hand, and you were
        // right — the whole database is already compiled in, so it can just fill
        // the boxes for you. This detects your champion and lists that champion's
        // real skins; clicking one populates god + skin + the id fields together.
        if (ImGui::Button("Auto-fill from my champion", ImVec2(220, 26))) {
            AutoDetectChampion();
        }
        ImGui::SameLine();
        ImGui::Text("detected: %s", g_DetectedChamp[0] ? g_DetectedChamp : "(press it)");

        if (g_DetectedChamp[0]) {
            ImGui::Text("Skins for %s - click one to load it:", g_DetectedChamp);
            ImGui::BeginChild("devskinlist", ImVec2(0, 150), true);
            int shown = 0;
            for (int i = 0; i < SkinDB::kSkinCount; ++i) {
                const SkinDB::Entry& e = SkinDB::kSkins[i];
                if (lstrcmpA(e.champion, g_DetectedChamp) != 0) continue;
                shown++;
                char lbl[160];
                wsprintfA(lbl, "%-6d %-9s %s##ds%d", e.id, e.rarity, e.name, i);
                if (ImGui::Selectable(lbl, precacheSkinId == e.id)) {
                    // Fill every field the various methods need, in one click.
                    lstrcpynA(godName, e.champion, sizeof(godName));
                    lstrcpynA(skinName, e.name, sizeof(skinName));
                    precacheSkinId = e.id;
                    bodyMeshId = e.id;      // best guess; mesh ids may differ
                }
            }
            if (shown == 0) ImGui::TextDisabled("No skins found for that champion name.");
            ImGui::EndChild();
        }

        ImGui::PushItemWidth(170);
        ImGui::InputText("God name", godName, sizeof(godName));
        ImGui::InputText("Skin name", skinName, sizeof(skinName));
        ImGui::InputText("Weapon skin (optional)", weaponSkinName, sizeof(weaponSkinName));
        ImGui::PopItemWidth();
        ImGui::TextDisabled("Filled automatically by the list above. Leave weapon skin");
        ImGui::TextDisabled("blank on the first try - fewer things to go wrong.");

        if (ImGui::Button("PRECACHE + SWITCH", ImVec2(190, 28))) g_Pending = PrecacheThenSwitch;
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip(
                "Best first try. Precaches the skin's assets, then switches on the\n"
                "NEXT tick so the load has a frame to complete. UE3 loads assets\n"
                "lazily, so switching without precaching may do nothing even if\n"
                "the command itself works.");
        }
        ImGui::SameLine();
        if (ImGui::Button("Precache only", ImVec2(120, 28))) g_Pending = Precache;

        if (ImGui::Button("SwitchClass", ImVec2(120, 24))) g_Pending = Switch;
        ImGui::SameLine();
        if (ImGui::Button("sc (alias)", ImVec2(120, 24))) g_Pending = SwitchAlias;
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("Console aliases are sometimes wired to a different,\n"
                              "less restricted handler than the long name. Worth trying both.");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), "THE 'HIDDEN SHOP' CANDIDATES");
        if (ImGui::Button("TestShowInventory", ImVec2(170, 24))) g_Pending = ShowInventory;
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("Closest literal match for 'hidden developer item shop'.");
        }
        ImGui::SameLine();
        if (ImGui::Button("Show ALL store items", ImVec2(180, 24))) g_Pending = ToggleAllStore;

        if (ImGui::Button("Show UNOBTAINABLE items", ImVec2(200, 24))) g_Pending = ToggleUnobtainable;
        ImGui::SameLine();
        if (ImGui::Button("Refresh store", ImVec2(130, 24))) g_Pending = RefreshStore;

        ImGui::PushItemWidth(110);
        ImGui::InputInt("Gallery #", &galleryIndex);
        ImGui::PopItemWidth();
        ImGui::SameLine();
        if (ImGui::Button("TestSkinGallery", ImVec2(150, 24))) g_Pending = SkinGallery;

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), "BY MESH ID  (fallback)");
        ImGui::PushItemWidth(110);
        ImGui::InputInt("Body mesh ID", &bodyMeshId);
        ImGui::PopItemWidth();
        ImGui::SameLine();
        if (ImGui::Button("SetBodyMesh", ImVec2(130, 24))) g_Pending = BodyMesh;

        ImGui::PushItemWidth(110);
        ImGui::InputInt("Head mesh ID", &headMeshId);
        ImGui::PopItemWidth();
        ImGui::SameLine();
        if (ImGui::Button("SetHeadMesh", ImVec2(130, 24))) g_Pending = HeadMesh;

        if (ImGui::TreeNode("Precache by ID instead of name")) {
            ImGui::TextWrapped("Use this if the name strings don't resolve - the ids come from "
                "SKINS_BY_CHAMPION.txt.");
            ImGui::PushItemWidth(110);
            ImGui::InputInt("Bot/Champ ID", &precacheBotId);
            ImGui::InputInt("Skin ID", &precacheSkinId);
            ImGui::InputInt("Weapon skin ID", &precacheWeaponId);
            ImGui::PopItemWidth();
            if (ImGui::Button("TestPrecache (ids)", ImVec2(170, 24))) g_Pending = TestPrecacheIds;
            ImGui::TreePop();
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)), "VENDOR STORE CONFIG  (hidden dev FILE lead)");
        ImGui::TextWrapped("He said the research came from a well hidden dev FILE. These three are "
            "(Config, GlobalConfig) - they load from an .ini. And in your actual install, "
            "DefaultGame.ini sets VendorStoreTabId=0 but NEVER writes VendorStoreTypeId or "
            "VendorStoreTypeRecId. Two vendor-store settings that exist but were never configured "
            "is exactly where a hidden dev store would live.");
        if (ImGui::Button("Read current values", ImVec2(170, 24))) g_PendingVendorRead = true;
        ImGui::SameLine();
        ImGui::Text("live: tab=%d type=%d rec=%d", vsLiveTab, vsLiveType, vsLiveRec);

        ImGui::PushItemWidth(100);
        ImGui::InputInt("Tab id", &vsTab);   ImGui::SameLine(); ImGui::Checkbox("write##vt", &vsWriteTab);
        ImGui::InputInt("Type id", &vsType); ImGui::SameLine(); ImGui::Checkbox("write##vy", &vsWriteType);
        ImGui::InputInt("Rec id", &vsRec);   ImGui::SameLine(); ImGui::Checkbox("write##vr", &vsWriteRec);
        ImGui::PopItemWidth();
        if (ImGui::Button("Write vendor store + refresh", ImVec2(230, 24))) g_PendingVendorWrite = true;
        ImGui::TextDisabled("Try small type ids first (1,2,3...). Then open the in-match");
        ImGui::TextDisabled("item shop and see if the tabs changed.");

        // Closes the "Advanced" TreeNode opened earlier.
        ImGui::TreePop();
    }
}
