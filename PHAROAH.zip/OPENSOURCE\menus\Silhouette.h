#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "menus/VisibilityBoxes.h"
#include "Utils/SafeCalls.h"
#include "ext/ImGUI/imgui.h"
#include <Windows.h>

// A SEPARATE feature from the boxes — recolors each player's real, existing
// engine outline/silhouette (m_OutlineMaterial), the same system the game's
// own reveal effects (e.g. Cassie's ult) use, instead of drawing a shape on
// top of them. Boxes are untouched by this file.
//
// SetVectorParameterValue is a scripted call (ProcessEvent), same category as
// GetBoneLocation/GetPlayerViewPoint before it — so this is throttled hard:
// each pawn's outline color is only re-applied once every ~2 seconds, not
// every frame, and stays SEH-wrapped.

namespace Silhouette {

    inline bool enabled = false;
    inline float allyColor[4] = { 0.2f, 0.6f, 1.0f, 1.0f };
    inline float enemyColor[4] = { 1.0f, 0.15f, 0.15f, 1.0f };

    // Same fix as grayscale/F4: the checkbox below runs on the render thread
    // (hkPresent) — can't call SetOutlines directly from there. Deferred to
    // the safe thread (HookedProcessEvent) via this flag instead.
    inline bool g_PendingMasterToggle = false;
    inline void ProcessPendingMasterToggle() {
        if (g_PendingMasterToggle && Globals::LocalController) {
            SafeCalls::SetOutlines(enabled, enabled);
            g_PendingMasterToggle = false;
        }
    }

    struct ApplyCacheEntry {
        SDK::ATgPawn* pawn;
        ULONGLONG lastAppliedMs;
    };
    inline ApplyCacheEntry g_ApplyCache[32] = {};

    // Returns true only if an ACTUAL scripted call happened this time (not
    // just "already up to date, skipped") — callers use that to know when to
    // stop, so at most one real call fires per UpdateSilhouettes pass.
    inline bool TryApplyOutlineColor(SDK::ATgPawn* pawn, const float* rgba) {
        if (!pawn) return false;
        ULONGLONG now = GetTickCount64();

        int slot = -1;
        for (int i = 0; i < 32; i++) {
            if (g_ApplyCache[i].pawn == pawn) { slot = i; break; }
        }
        if (slot == -1) {
            ULONGLONG oldest = (ULONGLONG)-1;
            for (int i = 0; i < 32; i++) {
                if (!g_ApplyCache[i].pawn) { slot = i; break; }
                if (g_ApplyCache[i].lastAppliedMs < oldest) { oldest = g_ApplyCache[i].lastAppliedMs; slot = i; }
            }
        }
        ApplyCacheEntry& entry = g_ApplyCache[slot];
        // Widened from 2s to 5s — combat generates a LOT of the game's own
        // script activity (damage/health/kill events), which raises the odds
        // of our scripted call landing badly mid-dispatch. Fewer calls/sec
        // means fewer chances to collide.
        if (entry.pawn == pawn && (now - entry.lastAppliedMs) < 5000) return false; // already recent, nothing done

        bool ok = false;
        __try {
            if (pawn->m_OutlineMaterial) {
                SDK::FLinearColor c;
                c.R = rgba[0]; c.G = rgba[1]; c.B = rgba[2]; c.A = rgba[3];
                pawn->m_OutlineMaterial->SetVectorParameterValue(SDK::FName("Color"), &c);
                ok = true;
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            ok = false;
        }
        entry.pawn = pawn;
        entry.lastAppliedMs = now; // mark as "handled" either way, so a failed pawn isn't retried every frame
        return ok;
    }

    // Reuses VisibilityBoxes' already-hardened pawn gather (same safe data,
    // no extra pawn-list walking of our own) but does nothing to boxes.
    //
    // Only applies to ONE pawn per call now, not all of them — if several
    // enemies all came due for a refresh in the same frame, firing several
    // scripted calls back-to-back during combat (when the game's own script
    // activity is already high) was likely what pushed the collision odds up
    // enough to crash. One real call per frame at most spreads the work out.
    inline void UpdateSilhouettes() {
        if (!enabled) return;
        if (!Globals::LocalController) return;

        // PERFORMANCE FIX: this used to call SafeGatherBoxes() itself every
        // frame — a full pawn-list walk plus name/string copies for every
        // real player, completely redundant with the gather VisibilityBoxes
        // already does and caches once per frame. Reusing that cache instead
        // cuts this down to zero extra gather cost. This runs whether or not
        // boxes are enabled, so it only works correctly because GatherAndCache
        // itself doesn't check the boxes "enabled" toggle for the underlying
        // data — only RenderBoxes() gates on that for drawing.
        const VisibilityBoxes::GatherResult& gathered = VisibilityBoxes::g_CachedGather;
        if (!gathered.ok) return;

        for (int i = 0; i < gathered.count; i++) {
            const auto& e = gathered.entries[i];
            if (e.kind == VisibilityBoxes::BoxKind::Other) continue; // deployables: leave alone
            const float* color = (e.kind == VisibilityBoxes::BoxKind::Ally) ? allyColor : enemyColor;
            if (TryApplyOutlineColor(e.pawnPtr, color)) break; // one real call happened — stop for this frame
        }
    }

    inline void DrawControls(bool inMatch) {
        ImGui::TextWrapped("Different from the boxes above — this recolors each player's "
            "REAL in-game outline/silhouette (the same system the game's own reveal "
            "effects use), instead of drawing a shape on top of them. Separate on/off "
            "from boxes; you can run both, either, or neither.");
        if (ImGui::Checkbox("Enable outline recoloring", &enabled)) {
            g_PendingMasterToggle = true; // actual call happens on the safe thread, see ProcessPendingMasterToggle()
        }
        ImGui::ColorEdit4("Ally outline color", allyColor);
        ImGui::ColorEdit4("Enemy outline color", enemyColor);
        if (!inMatch) {
            ImGui::TextDisabled("Join a match to test.");
        }
    }
}
