#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "types.h"
#include <vector>
#include <mutex>
#include <atomic>
#include <unordered_map>

#include "SDK.hpp"

typedef int (WINAPI* LPFN_MBA)(DWORD);

inline tProcessEvent ProcessEventOriginal = nullptr;
inline HMODULE moduleBase;
static LPFN_MBA o_getasynckeystate;

namespace Globals {
	inline DWORD_PTR UEngineAddr;
	inline SDK::UEngine* Engine;

	inline SDK::ULocalPlayer* LocalPlayer;
	inline SDK::APlayerController* LocalController;
	inline SDK::APawn* LocalPawn;
	inline SDK::ATgDevice* LocalWeapon;

	inline void* xorFunc;

	inline bool initObjects() {
		Engine = (SDK::UEngine*)(*(uintptr_t*)UEngineAddr);
		if (!Engine) return false;

		if (Engine && Engine->GamePlayers.IsValidIndex(0)) LocalPlayer = Engine->GamePlayers[0];
		if (!LocalPlayer) return false;

		if (LocalPlayer) LocalController = LocalPlayer->Actor;
		if (!LocalController) return false;

		if (LocalController) LocalPawn = LocalController->AcknowledgedPawn;
		if (!LocalPawn) return false;

		if (LocalPawn) LocalWeapon = (SDK::ATgDevice*)LocalPawn->Weapon;
		if (!LocalWeapon) return false;

		return true;
	}

	inline SDK::UUIScene* containsScene(SDK::UClass* sceneClass) {

		if (!LocalController) {
			return nullptr;
		}

		SDK::ATgClientHUD* hud = (SDK::ATgClientHUD*) LocalController->myHUD;

		if (!hud) {
			return nullptr;
		}

		if (hud->m_SceneStack.Num() <= 0) {
			return nullptr;
		}

		for (int i = 0; i < hud->m_SceneStack.Num(); i++) {
			auto scene = hud->m_SceneStack[i];
			if (scene->IsA(sceneClass)) {
				return (scene->m_UIScene);
			}
		}
		return nullptr;
	}
}