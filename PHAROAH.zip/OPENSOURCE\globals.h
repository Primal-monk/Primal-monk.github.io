#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "types.h"
#include <vector>
#include <mutex>
#include <atomic>
#include <unordered_map>

#include "SDK.hpp"

typedef int (WINAPI* LPFN_MBA)(DWORD);

inline tProcessEvent ProcessEventOriginal = nullptr;
inline HMODULE moduleBase;
static LPFN_MBA o_getasynckeystate;

namespace Globals {
	inline DWORD_PTR UEngineAddr;
	inline SDK::UEngine* Engine;

	inline SDK::ULocalPlayer* LocalPlayer;
	inline SDK::APlayerController* LocalController;
	inline SDK::APawn* LocalPawn;
	inline SDK::ATgDevice* LocalWeapon;

	inline void* xorFunc;

	// THE BUG THIS FIXES: on any early failure, LocalPlayer/LocalController/
	// LocalPawn/LocalWeapon used to be left holding whatever they were from
	// the LAST successful call - never cleared to null. Every "if
	// (!Globals::LocalController) return;" guard elsewhere in this codebase
	// (there are many) was trusting that check to mean "safe to use" - but a
	// stale, non-null pointer sails right through it. The one window where
	// this reliably bites: a match ending, when Engine->GamePlayers/the
	// local controller/pawn chain genuinely does break down for a beat while
	// the engine tears down match objects - exactly when this function
	// starts returning false, and exactly when the pointers it leaves behind
	// point at objects that are being (or have just been) destroyed. Reads
	// through a stale pointer here are a plausible root cause for
	// "works fine, then crashes on the next match" and the reported
	// freeze-like stutter (a real GC/teardown pass racing our read).
	//
	// Fixed by nulling everything up front, so ANY early return leaves
	// clean nulls - "not set" is now indistinguishable from "not set", not
	// silently aliased to "still pointing at last match."
	inline bool initObjects() {
		Engine = (SDK::UEngine*)(*(uintptr_t*)UEngineAddr);
		if (!Engine) { LocalPlayer = nullptr; LocalController = nullptr; LocalPawn = nullptr; LocalWeapon = nullptr; return false; }

		LocalPlayer = Engine->GamePlayers.IsValidIndex(0) ? Engine->GamePlayers[0] : nullptr;
		if (!LocalPlayer) { LocalController = nullptr; LocalPawn = nullptr; LocalWeapon = nullptr; return false; }

		LocalController = LocalPlayer->Actor;
		if (!LocalController) { LocalPawn = nullptr; LocalWeapon = nullptr; return false; }

		LocalPawn = LocalController->AcknowledgedPawn;
		if (!LocalPawn) { LocalWeapon = nullptr; return false; }

		LocalWeapon = (SDK::ATgDevice*)LocalPawn->Weapon;
		if (!LocalWeapon) return false;

		return true;
	}

	// __try-wrapped: this is one of the most widely-called functions in the
	// whole tool (emotes, talents, and plenty of other menus all go through
	// it). LocalController being non-null at the top doesn't guarantee the
	// HUD/scene-stack chain hanging off it stays valid for the rest of this
	// call - a real match transition can tear those objects down mid-read.
	// No C++ objects with destructors declared in this function, so the
	// whole body can sit inside one __try (see Utils/Helper.h's isolated
	// accessors for why that constraint matters elsewhere).
	inline SDK::UUIScene* containsScene(SDK::UClass* sceneClass) {

		if (!LocalController) {
			return nullptr;
		}

		__try {
			SDK::ATgClientHUD* hud = (SDK::ATgClientHUD*) LocalController->myHUD;

			if (!hud) {
				return nullptr;
			}

			if (hud->m_SceneStack.Num() <= 0) {
				return nullptr;
			}

			for (int i = 0; i < hud->m_SceneStack.Num(); i++) {
				auto scene = hud->m_SceneStack[i];
				if (scene && scene->IsA(sceneClass)) {
					return (scene->m_UIScene);
				}
			}
			return nullptr;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return nullptr;
		}
	}
}