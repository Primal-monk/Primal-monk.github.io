#pragma once

// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include <vector>
#include <string>
#include <mutex>

#include "ChampionMapping.h"
#include "TalentMapping.h"

namespace Helpers {
    struct TalentItem {
        int id = -1;
        std::string name;
        std::string description;
    };

    struct TalentSnapshot {
        bool has_deck = false;
        int step_num = 0;
        int selected_talent_id = -1;
        std::vector<TalentItem> talents;
        std::vector<const char*> talent_labels;
        int selected_index = 0;
        std::vector<std::string> openSceneNames; // diagnostic: what's actually in the scene stack right now
    };

    struct TalentPendingChange {
        int new_selected_talent_id = -1;
    };

    struct TalentShared {
        TalentSnapshot snapshot;
        TalentPendingChange pending;
        std::mutex mtx;
        bool closing;
    };

    static TalentShared g_talent;

    // THE 4TH-TALENT CRASH FIX. CacheTalentInfos walks the live HUD scene stack
    // and calls IsA() on each scene EVERY FRAME the Talents tab is open. When you
    // apply a talent, the game tears down and rebuilds the loadout scene - and
    // for a few frames a scene-stack entry points at a freed/reused object whose
    // vtable is garbage. IsA() is a virtual call, so it jumps through that garbage
    // vtable: a wild jump __try/__except CANNOT catch (it's not a clean access
    // violation). That is the "Rendering thread exception" crash after using a
    // 4th talent. Fix: the instant we apply a talent, pause the whole walk for a
    // beat so the rebuild finishes before we ever touch that scene stack again.
    inline unsigned long long g_talentReadPauseUntilMs = 0;

    // ========================================================================
    // ISOLATED (POD-only) ACCESSORS - crash hardening pass.
    // ------------------------------------------------------------------------
    // Everything below reads/writes through Globals::LocalController and the
    // HUD/scene-stack chain hanging off it. That chain is briefly invalid
    // during a real match transition (the engine tearing down last match's
    // objects) - exactly the window PRIMAL_MONKE's crash reports and the
    // "one match fine, next one crashes" / "freeze like it's freeing
    // something" pattern point at. A null CHECK on LocalController is not
    // enough by itself if the pointer is merely null-checked and then
    // dereferenced elsewhere in the same call without the SDK object it
    // points to being guaranteed alive for the duration - these small
    // functions add the actual __try/__except safety net the rest of this
    // project already uses for exactly this class of risk (see
    // AimFeatures::ProcessAimHook_Isolated in main.cpp for the established
    // pattern). Kept as separate tiny functions with ONLY POD in/out because
    // MSVC refuses to compile a __try block in a function that ALSO has
    // local C++ objects with destructors (std::string/vector/lock_guard,
    // all over CacheTalentInfos below) - C2712, documented elsewhere in this
    // project too.
    inline SDK::ATgClientHUD* SafeGetHud(SDK::APlayerController* controller) {
        if (!controller) return nullptr;
        __try { return (SDK::ATgClientHUD*)controller->myHUD; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline SDK::UUIHudDecks* SafeFindDecks(SDK::ATgClientHUD* hud) {
        if (!hud) return nullptr;
        __try {
            for (int i = 0; i < hud->m_SceneStack.Num(); ++i) {
                auto s = hud->m_SceneStack[i];
                if (s && s->IsA(SDK::UUIHudDecks::StaticClass()))
                    return static_cast<SDK::UUIHudDecks*>(s);
            }
            return nullptr;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline int SafeSceneCount(SDK::ATgClientHUD* hud) {
        if (!hud) return 0;
        __try { return hud->m_SceneStack.Num(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    inline void SafePopTopScene(SDK::ATgClientHUD* hud) {
        if (!hud) return;
        __try {
            int n = hud->m_SceneStack.Num();
            if (n > 0) hud->PopScene(n - 1);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
    }

    inline void SafeSetTalent(SDK::UUIHudDecks* decks, int id) {
        if (!decks) return;
        __try { decks->m_nTalent = id; }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
    }

    // Leaves *out_stepNum / *out_talentId untouched on failure - init them
    // before calling.
    inline bool SafeReadDeckState(SDK::UUIHudDecks* decks, int* out_stepNum, int* out_talentId) {
        if (!decks) return false;
        __try { *out_stepNum = decks->m_nStepNum; *out_talentId = decks->m_nTalent; return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Reusable: find the current loadout/deck-build scene, if it's open right now.
    inline SDK::UUIHudDecks* GetCurrentDecksScene() {
        if (!Globals::LocalController) return nullptr;
        SDK::ATgClientHUD* hud = SafeGetHud(static_cast<SDK::ATgPlayerController*>(Globals::LocalController));
        return SafeFindDecks(hud);
    }

    // Directly maxes every card's invested points across all 9 ability pools,
    // instead of relying on the game's own MaxLevel() cheat function.
    // maxPointsPerCard: try 5 first (matches "5 cards, level 5 max" description);
    // change to 10 and rebuild if 5 turns out to be wrong for this build.
    inline int MaxAllCardPoints(int maxPointsPerCard = 5) {
        SDK::UUIHudDecks* decks = GetCurrentDecksScene();
        if (!decks) return -1; // -1 = deck screen not open right now

        int touched = 0;
        __try {
            for (int p = 0; p < 9; p++) {
                SDK::UUIComponent_AbilityPointsPool* pool = decks->m_DeckAbilityPools[p];
                if (!pool) continue;
                for (int c = 0; c < 4; c++) {
                    pool->m_nPoints[c] = maxPointsPerCard;
                }
                touched++;
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return touched; }
        return touched; // how many pools were actually found/touched
    }

    inline void CacheTalentInfos() {
        // POST-APPLY PAUSE - the fix for BOTH 4th-talent crashes (the
        // "Rendering thread exception" and the "Illegal call to
        // StaticFindObject() while ... garbage collecting"). The instant we
        // change a talent, the game tears down + serialises + GCs the loadout
        // scene. If we walk that scene (IsA / StaticClass / scene-stack) during
        // that window, we either jump a freed vtable OR call an object lookup
        // mid-GC and trip the engine's own fatal guard. So while paused we touch
        // NOTHING - no hud, no scene walk, no lookups - until the rebuild ends.
        if (GetTickCount64() < g_talentReadPauseUntilMs) return;

        if (!Globals::LocalController) return;
        SDK::ATgClientHUD* hud = SafeGetHud(static_cast<SDK::ATgPlayerController*>(Globals::LocalController));
        if (!hud) return;

        SDK::UUIHudDecks* decks = SafeFindDecks(hud);   // stable scene here (pre-change)

        bool appliedThisFrame = false;
        {
            std::lock_guard<std::mutex> lock(Helpers::g_talent.mtx);
            if (decks && Helpers::g_talent.closing) {
                SafePopTopScene(hud);
                Helpers::g_talent.closing = false;
            }
            if (decks && Helpers::g_talent.pending.new_selected_talent_id != -1) {
                SafeSetTalent(decks, Helpers::g_talent.pending.new_selected_talent_id);
                Helpers::g_talent.pending.new_selected_talent_id = -1;
                appliedThisFrame = true;
            }
        }
        // We just changed the talent: the game is about to rebuild + GC the
        // loadout. Do not touch that scene again until it settles (~0.9s covers
        // the teardown+GC window). This single return is what stops the crash.
        if (appliedThisFrame) {
            g_talentReadPauseUntilMs = GetTickCount64() + 900;
            return;
        }

        Helpers::TalentSnapshot snap;

        // Diagnostic scene-stack dump removed from the hot path — it walked
        // and GetFullName()'d every open scene EVERY FRAME the menu was open
        // (not just while viewing this tab), purely for one-time debugging
        // that already found its answer (UUIHudDecks). Real per-frame string
        // allocation/deallocation churn for no visible benefit — a plausible
        // contributor to the reported stutter — with zero net loss since
        // nothing reads openSceneNames any more.

        if (decks) {
            int stepNum = 0, talentId = -1;
            if (SafeReadDeckState(decks, &stepNum, &talentId)) {
                snap.has_deck = true;
                snap.step_num = stepNum;
                snap.selected_talent_id = talentId;

                std::string currentChampion = GetCurrentChampionName();
                if (!currentChampion.empty() && championTalents.count(currentChampion)) {
                    const auto& list = championTalents[currentChampion];
                    snap.talents.reserve(list.size());
                    for (const auto& t : list) {
                        Helpers::TalentItem it;
                        it.id = t.id;
                        it.name = t.name;
                        it.description = t.description;
                        snap.talents.push_back(std::move(it));
                    }
                }

                snap.talent_labels.reserve(snap.talents.size() + 1);
                snap.selected_index = 0;
                for (size_t i = 0; i < snap.talents.size(); ++i) {
                    snap.talent_labels.push_back(snap.talents[i].name.c_str());
                    if (snap.talents[i].id == snap.selected_talent_id) {
                        snap.selected_index = static_cast<int>(i);
                    }
                }
                snap.talent_labels.push_back(nullptr);
            }
            // SafeReadDeckState failing (decks went stale between
            // SafeFindDecks and here, same frame) just leaves has_deck
            // false — same as "loadout screen not open," nothing crashes.
        }

        {
            std::lock_guard<std::mutex> lock(Helpers::g_talent.mtx);
            Helpers::g_talent.snapshot = std::move(snap);
        }
    }


    inline static std::unordered_map<int, bool> g_prevKeyDown;
    inline static std::unordered_map<int, SHORT> g_currKeyRaw;

    inline void PollKeyStates(const std::vector<int>& keys) {
        g_currKeyRaw.clear();
        for (int vk : keys) {
            if (vk == 0) continue;
            if (g_currKeyRaw.find(vk) == g_currKeyRaw.end()) {
                g_currKeyRaw[vk] = GetAsyncKeyState(vk);
            }
        }
    }

    inline bool IsKeyDown(int vk) {
        auto it = g_currKeyRaw.find(vk);
        if (it == g_currKeyRaw.end()) return false;
        return (it->second & 0x8000) != 0;
    }

    inline bool IsKeyJustPressed(int vk) {
        if (vk == 0) return false;

        bool down = IsKeyDown(vk);

        static std::unordered_map<int, bool> keyStates;
        bool wasDown = keyStates[vk];
        keyStates[vk] = down;

        return down && !wasDown;
    }

    inline void FinalizeKeyStates() {
        for (auto& [vk, raw] : g_currKeyRaw) {
            g_prevKeyDown[vk] = (raw & 0x8000) != 0;
        }
    }

    inline void listenForEmoteReset(SDK::FString name, int *id) {
        PollKeyStates({ VK_F1 });
        if (IsKeyJustPressed(VK_F1)) {
            auto championIt = emotes.find(name.ToString());
            if (championIt != emotes.end()) {
                auto& emoteList = championIt->second;
                for (auto& [emote, emoteId] : emoteList) {
                    if (emote.find("Default") != std::string::npos) {
                        *id = emoteId;
                        break;
                    }
                }
            }
        }
        FinalizeKeyStates();
    }

    // Isolated: same reasoning as SafeGetHud/SafeFindDecks above. scene is
    // whatever Globals::containsScene() returned - already validated to
    // exist AT THAT MOMENT, but this whole chain (championScene->m_eState,
    // ->m_pSkins, ->m_pSelectedEmote->m_nId) can still go stale a few
    // instructions later during a real teardown. No C++ objects declared
    // locally here (listenForEmoteReset uses its own internally, which is
    // fine - the restriction is only on THIS function's own locals), so the
    // whole body can sit in one __try.
    inline bool SafeResetEmoteToDefault(SDK::UUIScene* scene) {
        if (!scene) return false;
        __try {
            SDK::UUIScene_UIChampion* championScene = (SDK::UUIScene_UIChampion*) scene;
            if (championScene->m_eState != SDK::EUICHAMPION_STATE::UICS_EMOTES) return false;
            SDK::UUIComponent_ChampionSkins* skinComp = championScene->m_pSkins;
            if (!skinComp || !skinComp->m_pSelectedEmote) return false;

            listenForEmoteReset(championScene->m_pChampData->m_sName, &skinComp->m_pSelectedEmote->m_nId);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline void resetFirstEmoteToDefault() {
        // Was a direct, unguarded Globals::LocalController->myHUD dereference
        // - no null check on LocalController at all. Called specifically in
        // the "just left a match" path (main.cpp's !inGame branch), which is
        // precisely when LocalController is most likely to be null (or, before
        // the Globals::initObjects() fix, a stale dangling pointer that
        // wasn't even null). Now goes through the same guarded, __try-wrapped
        // accessor as everything else touching this chain.
        if (!Globals::LocalController) return;
        SDK::ATgClientHUD* hud = SafeGetHud(static_cast<SDK::APlayerController*>(Globals::LocalController));

        if (!hud) {
            return;
        }

        SDK::UUIScene* scene = Globals::containsScene(SDK::UUIChampion::StaticClass());
        SafeResetEmoteToDefault(scene);
    }
}
