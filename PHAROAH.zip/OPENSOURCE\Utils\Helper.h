#pragma once

// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include <vector>
#include <string>
#include <mutex>

#include "ChampionMapping.h"
#include "TalentMapping.h"

namespace Helpers {
    struct TalentItem {
        int id = -1;
        std::string name;
        std::string description;
    };

    struct TalentSnapshot {
        bool has_deck = false;
        int step_num = 0;
        int selected_talent_id = -1;
        std::vector<TalentItem> talents;
        std::vector<const char*> talent_labels;
        int selected_index = 0;
        std::vector<std::string> openSceneNames; // diagnostic: what's actually in the scene stack right now
    };

    struct TalentPendingChange {
        int new_selected_talent_id = -1;
    };

    struct TalentShared {
        TalentSnapshot snapshot;
        TalentPendingChange pending;
        std::mutex mtx;
        bool closing;
    };

    static TalentShared g_talent;

    // Reusable: find the current loadout/deck-build scene, if it's open right now.
    inline SDK::UUIHudDecks* GetCurrentDecksScene() {
        if (!Globals::LocalController) return nullptr;
        SDK::ATgPlayerController* controller = static_cast<SDK::ATgPlayerController*>(Globals::LocalController);
        auto* hud = static_cast<SDK::ATgClientHUD*>(controller->myHUD);
        if (!hud) return nullptr;

        for (int i = 0; i < hud->m_SceneStack.Num(); ++i) {
            auto s = hud->m_SceneStack[i];
            if (s && s->IsA(SDK::UUIHudDecks::StaticClass())) {
                return static_cast<SDK::UUIHudDecks*>(s);
            }
        }
        return nullptr;
    }

    // Directly maxes every card's invested points across all 9 ability pools,
    // instead of relying on the game's own MaxLevel() cheat function.
    // maxPointsPerCard: try 5 first (matches "5 cards, level 5 max" description);
    // change to 10 and rebuild if 5 turns out to be wrong for this build.
    inline int MaxAllCardPoints(int maxPointsPerCard = 5) {
        SDK::UUIHudDecks* decks = GetCurrentDecksScene();
        if (!decks) return -1; // -1 = deck screen not open right now

        int touched = 0;
        for (int p = 0; p < 9; p++) {
            SDK::UUIComponent_AbilityPointsPool* pool = decks->m_DeckAbilityPools[p];
            if (!pool) continue;
            for (int c = 0; c < 4; c++) {
                pool->m_nPoints[c] = maxPointsPerCard;
            }
            touched++;
        }
        return touched; // how many pools were actually found/touched
    }

    inline void CacheTalentInfos() {
        if (!Globals::LocalController) return;
        SDK::ATgPlayerController* controller = static_cast<SDK::ATgPlayerController*>(Globals::LocalController);

        auto* hud = static_cast<SDK::ATgClientHUD*>(controller->myHUD);
        if (!hud) return;

        SDK::UUIHudDecks* decks = GetCurrentDecksScene();

        {
            std::lock_guard<std::mutex> lock(Helpers::g_talent.mtx);
            if (decks && Helpers::g_talent.closing) {
                hud->PopScene(hud->m_SceneStack.Num() - 1);
                Helpers::g_talent.closing = false;
            }
            if (decks && Helpers::g_talent.pending.new_selected_talent_id != -1) {
                decks->m_nTalent = Helpers::g_talent.pending.new_selected_talent_id;
                Helpers::g_talent.pending.new_selected_talent_id = -1;
            }
        }

        Helpers::TalentSnapshot snap;

        // Diagnostic: record every scene currently in the stack, regardless of
        // whether we found the deck screen — this is how we find out the real
        // class name if UUIHudDecks isn't it for this build.
        for (int i = 0; i < hud->m_SceneStack.Num(); ++i) {
            auto s = hud->m_SceneStack[i];
            if (s) snap.openSceneNames.push_back(s->GetFullName());
        }

        if (decks) {
            snap.has_deck = true;
            snap.step_num = decks->m_nStepNum;
            snap.selected_talent_id = decks->m_nTalent;

            std::string currentChampion = GetCurrentChampionName();
            if (!currentChampion.empty() && championTalents.count(currentChampion)) {
                const auto& list = championTalents[currentChampion];
                snap.talents.reserve(list.size());
                for (const auto& t : list) {
                    Helpers::TalentItem it;
                    it.id = t.id;
                    it.name = t.name;
                    it.description = t.description;
                    snap.talents.push_back(std::move(it));
                }
            }

            snap.talent_labels.reserve(snap.talents.size() + 1);
            snap.selected_index = 0;
            for (size_t i = 0; i < snap.talents.size(); ++i) {
                snap.talent_labels.push_back(snap.talents[i].name.c_str());
                if (snap.talents[i].id == snap.selected_talent_id) {
                    snap.selected_index = static_cast<int>(i);
                }
            }
            snap.talent_labels.push_back(nullptr);
        }

        {
            std::lock_guard<std::mutex> lock(Helpers::g_talent.mtx);
            Helpers::g_talent.snapshot = std::move(snap);
        }
    }


    inline static std::unordered_map<int, bool> g_prevKeyDown;
    inline static std::unordered_map<int, SHORT> g_currKeyRaw;

    inline void PollKeyStates(const std::vector<int>& keys) {
        g_currKeyRaw.clear();
        for (int vk : keys) {
            if (vk == 0) continue;
            if (g_currKeyRaw.find(vk) == g_currKeyRaw.end()) {
                g_currKeyRaw[vk] = GetAsyncKeyState(vk);
            }
        }
    }

    inline bool IsKeyDown(int vk) {
        auto it = g_currKeyRaw.find(vk);
        if (it == g_currKeyRaw.end()) return false;
        return (it->second & 0x8000) != 0;
    }

    inline bool IsKeyJustPressed(int vk) {
        if (vk == 0) return false;

        bool down = IsKeyDown(vk);

        static std::unordered_map<int, bool> keyStates;
        bool wasDown = keyStates[vk];
        keyStates[vk] = down;

        return down && !wasDown;
    }

    inline void FinalizeKeyStates() {
        for (auto& [vk, raw] : g_currKeyRaw) {
            g_prevKeyDown[vk] = (raw & 0x8000) != 0;
        }
    }

    inline void listenForEmoteReset(SDK::FString name, int *id) {
        PollKeyStates({ VK_F1 });
        if (IsKeyJustPressed(VK_F1)) {
            auto championIt = emotes.find(name.ToString());
            if (championIt != emotes.end()) {
                auto& emoteList = championIt->second;
                for (auto& [emote, emoteId] : emoteList) {
                    if (emote.find("Default") != std::string::npos) {
                        *id = emoteId;
                        break;
                    }
                }
            }
        }
        FinalizeKeyStates();
    }

    inline void resetFirstEmoteToDefault() {
        SDK::ATgClientHUD* hud = (SDK::ATgClientHUD*) Globals::LocalController->myHUD;

        if (!hud) {
            return;
        }

        if (SDK::UUIScene* scene = Globals::containsScene(SDK::UUIChampion::StaticClass())) {
            SDK::UUIScene_UIChampion* championScene = (SDK::UUIScene_UIChampion*) scene;
            if (championScene->m_eState != SDK::EUICHAMPION_STATE::UICS_EMOTES) return;
            SDK::UUIComponent_ChampionSkins* skinComp = championScene->m_pSkins;
            if (!skinComp || !skinComp->m_pSelectedEmote) return;

            listenForEmoteReset(championScene->m_pChampData->m_sName, &skinComp->m_pSelectedEmote->m_nId);
        }
    }
}
