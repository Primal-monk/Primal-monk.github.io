#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"

// ============================================================================
// PERF  —  one place that owns "how hard is this tool allowed to work"
// ============================================================================
// WHY THIS EXISTS
//
// Users reported the game stuttering while the FPS counter stayed at 40-50.
// That combination is the signature of a periodic HITCH, not a framerate
// problem: something expensive runs on a timer, blocks a frame, and the average
// barely moves.
//
// The cause was several subsystems each walking the ENTIRE GObjects array - a
// couple of hundred thousand objects, with class-name string compares on every
// one - on their own independent timers:
//
//     Unlocker::RunPass        every 1.0s   (on by DEFAULT, hidden in dev mode)
//     HealthBarColor pass      every 1.5s   (only when recolouring is on)
//     MeshSkin scans           on spawn / tab open
//
// The Unlocker was the big one. It defaults to ON, it is not visible outside
// developer mode, so a user could turn off every feature they could SEE and
// still have a 200k-object walk running every second.
//
// On a fast machine that is invisible. On a slow one it is the whole complaint.
//
// So: every periodic full-object-array walk in the tool now asks here first.
// ============================================================================

namespace Perf {

    // ---- POTATO MODE -------------------------------------------------------
    // One switch that stops every optional background scan. Nothing that draws
    // is affected - boxes, reticle, skeletons all still work, because those read
    // an already-gathered cache rather than walking objects themselves.
    //
    // What it actually stops:
    //   - the Unlocker's periodic re-apply
    //   - health-bar recolour re-apply
    //   - continuous skin/material rescans
    //   - the card sweep's fast retry loop
    inline bool g_PotatoMode = false;

    // Multiplier applied to every periodic interval. Potato mode stretches
    // things that must still run occasionally rather than killing them.
    inline float IntervalScale() { return g_PotatoMode ? 4.0f : 1.0f; }

    // "May an expensive full-GObjects walk run right now?"
    // Optional background work asks this; anything the user just clicked does
    // not, because an explicit press should always do the thing.
    inline bool AllowBackgroundScan() { return !g_PotatoMode; }

    // ---- frame-time readout, so the effect is visible ---------------------
    // Worst frame in the last second. A hitch shows here even when the average
    // FPS looks fine, which is exactly the case users were describing.
    inline float g_WorstFrameMs = 0.0f;
    inline float g_WorstShown   = 0.0f;
    inline float g_Accum        = 0.0f;

    inline void Tick(float dtSeconds) {
        const float ms = dtSeconds * 1000.0f;
        if (ms > g_WorstFrameMs) g_WorstFrameMs = ms;
        g_Accum += dtSeconds;
        if (g_Accum >= 1.0f) {
            g_WorstShown   = g_WorstFrameMs;
            g_WorstFrameMs = 0.0f;
            g_Accum        = 0.0f;
        }
    }

    // The POTATO MODE checkbox itself lives in the header row now (next to
    // DEV MODE / SIDE TABS / NOTES) so it is visible without opening this tab.
    // This function draws the explanation and the frame-time readout only, so
    // it is not a second copy of the same checkbox.
    inline void DrawControls() {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("PERFORMANCE");
        ImGui::PopStyleColor();

        ImGui::TextWrapped("POTATO MODE (top of the window, next to DEV MODE) stops the tool's "
            "background scanning. Several parts of it walk the game's entire object list on a "
            "timer to keep things applied; on a slower PC that is a hitch every second or so.");
        ImGui::TextDisabled("Boxes, skeletons and the reticle are NOT affected - they read a cache");
        ImGui::TextDisabled("rather than scanning, so they cost nothing extra.");
        ImGui::TextColored(Ink(g_PotatoMode ? ImVec4(0.45f, 1.0f, 0.55f, 1.0f)
                                            : ImVec4(0.65f, 0.65f, 0.65f, 1.0f)),
            "Potato mode is currently %s.", g_PotatoMode ? "ON" : "OFF");

        ImGui::Spacing();
        const float avg = ImGui::GetIO().Framerate;
        ImGui::Text("FPS %.0f      worst frame in the last second: %.1f ms", avg, g_WorstShown);
        if (g_WorstShown > 50.0f) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.45f, 0.30f, 1.0f)),
                "That is a visible hitch. Try POTATO MODE.");
        } else if (g_WorstShown > 0.0f) {
            ImGui::TextColored(Ink(ImVec4(0.45f, 1.0f, 0.55f, 1.0f)), "Smooth - no hitching.");
        }
        ImGui::TextDisabled("A hitch does NOT show up in average FPS, which is why the counter can");
        ImGui::TextDisabled("read 50 while the game still feels bad. This number is the one to watch.");
    }
}
