#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "menus/Perf.h"   // POTATO MODE
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "menus/SkinDatabase.h"   // LookupSkinName: skin code -> readable name
#include <Windows.h>

// ============================================================================
// MESH SKIN SWAP — the real client-side skin method
//
// WHY THE r_nSkinId APPROACH WAS NEVER GOING TO WORK
// r_nSkinId is marked (Net). It is replicated, so the server owns it and pushes
// its own value back. Worse, the server decides what mesh that id maps to based
// on what you OWN. We were asking permission.
//
// WHAT THIS DOES INSTEAD — no permission, no server
// The mesh you see is drawn from a pointer on your own pawn:
//
//   APawn::Mesh                                 USkeletalMeshComponent*  0x048C
//   USkeletalMeshComponent::SkeletalMesh        USkeletalMesh*           0x0294
//   USkeletalMeshComponent::SetSkeletalMesh(USkeletalMesh*, bool, bool)
//
// Overwrite that pointer and the renderer draws a different mesh. That is it.
// There is no replicated field involved, no ownership check, and nothing for the
// server to validate — because we are not asking it anything. This is a local
// render change, which is exactly what "client-side skins" means.
//
// WHY THE MESHES ARE ALREADY AVAILABLE (the key insight from RESKIN_INFO.txt)
// vampi said skins are bundled per champion:
//   "skins are bundled in <character>_ASSETS_SF.upk (3rd person model and arms),
//    weapons in DEVICE<num>_ASSETS_SF"
// ALL of a champion's skins live in the SAME package — that is why
// MAEVE_ASSETS_SF.upk is 40 MB. So we do NOT need to extract anything, download
// anything, or make our own launcher. The meshes are already installed. We just
// have to point at one.
//
// THE HONEST UNKNOWN, AND WHY THERE IS A SCANNER
// UE3 loads objects lazily. A skin's mesh being IN the package does not
// guarantee it is IN MEMORY right now. So this ships a SCANNER first: it walks
// GObjects and lists every USkeletalMesh it can see, with names. That answers
// the question with data instead of assumption:
//   - many champion meshes listed  -> the method works, wire the ids up
//   - only your current skin       -> we need to force a load, and that is the
//                                     next problem to solve rather than a dead end
//
// Run the scan and send me the list. That single list decides the whole approach.
//
// THREADING: the scan and the pointer write are both raw memory operations, safe
// from the render thread. SetSkeletalMesh is scripted, so it is deferred.
// ============================================================================

namespace MeshSkin {

    inline const int kMaxResults = 256;
    inline char g_Names[kMaxResults][80];
    inline SDK::UObject* g_Objects[kMaxResults] = {};
    inline int  g_ResultCount = 0;
    inline int  g_TotalSkeletalMeshes = 0;
    inline bool g_ScanDone = false;
    inline char g_Filter[48] = {};

    inline int  g_SelectedIndex = -1;
    inline bool g_PendingApply = false;
    inline bool g_PendingRestore = false;
    inline int  g_PendingSmartIndex = -1;   // smart-route a scanned mesh by bone count
    inline char g_SmartStatus[160] = "";
    inline int  g_BoneCounts[256] = {};     // cached bone count per scanned mesh
    // OFF by default. Setting RF_RootSet/RF_Standalone on engine objects makes the
    // collector treat them as roots; if one is freed or re-created underneath us,
    // the next collection can walk a stale reference — which matches the
    // "Crashed during garbage collection" report (it happened in a match without
    // the skin tools even being used, i.e. purely from flags set earlier).
    // Only enable this deliberately, and expect it to destabilise GC.
    inline bool g_AutoKeepAlive = false;    // mark scanned meshes non-GC on scan

    // Weapon swap (new): separate selection + pending, plus 3P weapon hide.
    inline int  g_SelWeaponIndex = -1;
    inline bool g_PendingWeaponApply = false;
    inline bool g_PendingHide3PWeapon = false;
    inline bool g_Hide3PWeaponState = false;
    inline bool g_LastWeaponPaired = false;

    // Safety rail added after the Pip crash: only same-champion meshes by default.
    inline bool allowCrossChampion = false;
    inline bool showNoGeo = false;   // "nogeo" meshes are the invisible ones

    // Multi-mode scanning, since the user keeps (reasonably) wanting a better
    // scanner. Continuous keeps it fresh as skins load/unload.
    // OFF by default, and it is no longer how the lists get populated.
    //
    // Scanning now happens on EVENTS - tab opened, pawn changed - which covers
    // everything that actually alters the list. This flag is only the safety net
    // for assets being garbage-collected while you are staring at the list, and
    // even then it ticks at 3s and only while the tab is open.
    inline bool g_ContinuousScan = false;
    inline ULONGLONG g_LastAutoScanMs = 0;
    // Set by the Skins tab each frame it draws, cleared by the main render loop.
    // Auto-scan is gated on this so it cannot cost anything while you are playing.
    inline bool g_SkinsTabOpen = false;
    inline int  g_ScanAllTotal = 0;   // for the "scan everything" diagnostic

    // Texture fix: clear override materials on swap so the new skin uses its own.
    inline bool g_AutoFixTextures = true;
    inline int  g_TargetOwnMatCount = -1;   // does the new mesh have its own mats?

    // MATERIAL SCAN — the actual textures live in separate MaterialInstanceConstant
    // objects, applied per slot. This scans them so we can put the right skin's
    // textures onto the swapped mesh via SetMaterial(slot, material).
    // Was 256, which was fine while the champion filter was on but far too
    // small once 'show ALL' existed: the list filled with the first 256 objects
    // in GObjects (mostly unrelated) and the champion's own materials never got
    // in. That is why arms textures disappeared.
    inline const int kMaxMats = 3000;
    inline char g_MatNames[kMaxMats][96];
    inline SDK::UObject* g_MatObjects[kMaxMats] = {};
    inline int  g_MatCount = 0;
    inline int  g_MatTotal = 0;
    inline bool g_AutoApplyMats = true;   // auto-assign matching-skin materials on swap
    inline int  g_MatSlot = 0;            // manual slot for the material picker
    inline int  g_BodySlots = -1;         // how many material slots the body has
    inline char g_MatStatus[160] = "Scan materials to fill this.";
    inline char g_LastAppliedBodyName[96] = "";   // for auto material matching
    inline int  g_PendingManualMat = -1;          // index into g_MatObjects to apply (body)
    inline int  g_PendingWeaponMat = -1;          // index into g_MatObjects to apply (weapon)
    inline int  g_PendingArmsMat   = -1;          // index into g_MatObjects to apply (1P arms)
    inline int  g_ArmsMatSlot      = 0;
    // Remember the last weapon/arms texture so we can put it back after a death.
    // The pawn is destroyed and rebuilt on respawn, taking the override materials
    // with it — which is why weapon textures had to be re-clicked every death.
    // Store the material NAME, not an index.
    //
    // BUG THIS FIXES (caused a "Crashed during garbage collection"): the first
    // version remembered an INDEX into g_MatObjects. On respawn the old pawn's
    // materials can be collected, so g_MatObjects[idx] became a DANGLING POINTER
    // and re-applying it crashed — inside GC, because that is when the collection
    // happens. Names are stable, so we re-resolve against the CURRENT scan and
    // simply skip if the material is no longer resident.
    inline char g_LastWeaponMatName[96] = "";
    inline char g_LastArmsMatName[96]   = "";

    // THE BODY MATERIAL WAS NEVER REMEMBERED.
    //
    // Persistence re-asserted the weapon and arms materials on a timer, but
    // there was no equivalent for the body - so a texture you picked by hand
    // (MIC_ULT_DEATH_Overlay_A and the like) was applied once and then quietly
    // replaced the next time anything touched the body: an auto-apply on swap,
    // a re-scan, a respawn. It looked like the tool was undoing your click,
    // and effectively it was.
    inline char g_LastBodyMatName[96]   = "";
    inline bool g_ReapplyMatsOnRespawn = true;
    // CONTINUOUS material re-apply.
    //
    // g_ReapplyMatsOnRespawn only fires when a NEW PAWN appears. That covers
    // dying, but NOT the case you hit: an ability that cleanses crowd control
    // also resets the pawn's material overrides, without ever replacing the
    // pawn. The respawn hook never sees it, so the overlay just vanished and
    // had to be re-clicked. This timer re-applies the last chosen materials
    // regardless of why they were lost.
    inline bool  g_PersistMats     = true;
    inline float g_PersistMatSecs  = 1.0f;
    inline float g_PersistMatTimer = 0.0f;

    // Re-resolve a remembered material name to its current index. -1 = gone.
    inline int FindMatIndexByName(const char* nm) {
        if (!nm || !nm[0]) return -1;
        for (int i = 0; i < g_MatCount; ++i)
            if (lstrcmpiA(g_MatNames[i], nm) == 0) return i;
        return -1;
    }
    inline bool g_AutoWeaponShapeFix = true;       // toggle-3P-weapon shape fix on apply
    // Persistence — keep re-applying a chosen skin so it survives the game resetting it.
    inline bool g_PersistEnabled = false;
    inline char g_PersistKey[16] = "";
    inline int  g_PersistIntervalMs = 1000;
    inline ULONGLONG g_LastPersistMs = 0;
    // Weapon swap now ON by default. It used to break the body, but that was
    // before the bone-count guard + the 1P/3P split routing: the weapon mesh was
    // landing on the body component. Now it only ever touches m_WeaponMesh1P/3P,
    // so pairing the weapon with the body skin is safe — and it's the missing
    // half of the skin (Method A never swapped the weapon at all).
    inline bool g_SwapWeaponOnApply = true;

    // Full package path of the current body mesh, e.g.
    // "CharPip.skl_pc_pip_skin00a_3p". DynamicLoadObject needs this. Declared at
    // the top, before RunScan and the scan report use them — declaring these next
    // to BuildLivePath (further down) is what caused the undeclared-identifier
    // error.
    inline char g_LivePathPrefix[160] = "";   // everything up to and incl. last dot
    inline char g_LiveFullPath[200] = "";
    inline bool g_WantRescanAfterWear = false; // set after a wear; Update() rescans

    // "skin00a"-style tag of the mesh currently worn, extracted from its own name.
    // Anything NOT containing this tag is a different skin — i.e. the interesting
    // ones. Derived rather than assumed, because the worn skin isn't always 00a.
    inline char g_CurrentSkinTag[16] = {};
    inline bool g_IsOtherSkin[256] = {};
    inline char g_MyChampion[48] = {};
    // The weapon's ASSET FAMILY, learned from the live weapon mesh name.
    // "skl_wep_blades_skin00a_3p" -> "blades". Weapons are NOT named after the
    // champion (Maeve=blades, Fernando=lanceshield, Pip=potionlauncher), which is
    // why a champion-name filter finds no weapon textures at all. Declared up here
    // because both the mesh scan and the material scan consult it.
    inline char g_WeaponFamily[48] = "";
    // Bypass the champion/weapon-family filter on the MATERIAL scan entirely.
    // Weapon materials kept coming up short; rather than guess at yet another
    // naming rule, this shows everything and lets the eye do the filtering.
    // Default ON: the champion + weapon-family filter kept hiding weapon
    // materials, and a too-short list is worse than a too-long one - you can
    // always type in the search box, but you cannot click what is not shown.
    inline bool g_MatShowAll = true;
    inline int  g_AllSkinsCount = -1;

    // Big enough for the whole list; this is the thing I actually need to see.
    inline char g_ScanReport[16384];
    inline bool g_ScanCopied = false;

    inline SDK::USkeletalMesh* g_OriginalMesh = nullptr;
    // Bone count of the mesh the pawn SPAWNED with. This is the number that
    // matters, and it is NOT the same as the live mesh's bone count once a swap
    // has happened. The component's internal per-bone allocations are sized from
    // whatever it was built with; swapping the mesh pointer does not resize them.
    // Comparing a new target against the CURRENT mesh therefore drifts after the
    // first swap, which is precisely why default->skin worked and skin->skin
    // crashed. Always compare against this.
    inline int  g_OriginalBones = -1;
    // Same story for the gun: the weapon component's bone arrays are sized when
    // it is built, so a weapon mesh with a different bone count is the same hard
    // crash. Captured at pawn change alongside the body baseline.
    inline int  g_OriginalWeaponBones = -1;
    inline SDK::APawn* g_BasePawn = nullptr;
    inline char g_OriginalName[80] = "(none)";
    inline char g_LiveName[80] = "(none)";
    inline int  g_ApplyCount = 0;
    inline char g_Status[160] = "Run a scan first.";

    // Forward declarations — RunScan calls these, which are defined further down
    // so related code stays grouped. Declaration-order slips have cost build
    // cycles in this project, so they're declared explicitly up front.
    inline void BuildScanReport();
    inline void RunMaterialScan();      // fwd: RunScan auto-runs it (one click = both)
    inline void SafeRunScan();
    inline void RunScan() { SafeRunScan(); }   // every caller now goes through the guard
    inline void DrawMeshInfoSection();  // fwd: menu tool, also called from DevSkin
    inline void DrawSmartMeshList();    // fwd
    inline void BuildLivePath(SDK::UObject* mesh);
    inline SDK::USkeletalMeshComponent* TryGetMeshComp(SDK::APawn* p);
    inline SDK::USkeletalMesh* TryGetMesh(SDK::USkeletalMeshComponent* mc);

    // ---- POD-only guarded helpers (C2712: __try can't share scope with
    // anything needing unwinding, so no std::string anywhere near these) ----

    // GObjects is a TAntiCheatArray, NOT a plain TArray — that's the whole point
    // of it. It also bounds-checks internally, so IsValidIndex must be consulted
    // before indexing or it faults. Same helper shape as Testing.h uses.
    inline SDK::UObject* TryObjAt(SDK::TAntiCheatArray<SDK::UObject*>& arr, size_t i) {
        __try {
            if (!arr.IsValidIndex(i)) return nullptr;
            return arr[i];
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // Name via the GNames index. Never FName(const char*) — that scans ~200k
    // entries per call and is what caused the bone crash and the jitter.
    inline bool TryCopyName(SDK::UObject* o, char* buf, int cap) {
        __try {
            buf[0] = '\0';
            if (!o || o->Name.Index == 0) return false;
            auto& names = SDK::FName::GetGlobalNames();
            if (!names.IsValidIndex((size_t)o->Name.Index)) return false;
            SDK::FNameEntry* e = names[o->Name.Index];
            if (!e) return false;
            const char* n = e->GetAnsiName();
            if (!n) return false;
            int i = 0;
            for (; i < cap - 1 && n[i]; ++i) buf[i] = n[i];
            buf[i] = '\0';
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryCopyClassName(SDK::UObject* o, char* buf, int cap) {
        __try {
            buf[0] = '\0';
            if (!o) return false;
            SDK::UClass* c = o->Class;
            if (!c || c->Name.Index == 0) return false;
            auto& names = SDK::FName::GetGlobalNames();
            if (!names.IsValidIndex((size_t)c->Name.Index)) return false;
            SDK::FNameEntry* e = names[c->Name.Index];
            if (!e) return false;
            const char* n = e->GetAnsiName();
            if (!n) return false;
            int i = 0;
            for (; i < cap - 1 && n[i]; ++i) buf[i] = n[i];
            buf[i] = '\0';
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool HasCI(const char* hay, const char* needle) {
        if (!hay || !needle || !needle[0]) return true;
        for (int i = 0; hay[i]; ++i) {
            int j = 0;
            while (needle[j]) {
                char a = hay[i + j], b = needle[j];
                if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
                if (b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
                if (a != b) break;
                ++j;
            }
            if (!needle[j]) return true;
        }
        return false;
    }


    // UNIVERSAL OVERLAYS. mic_burncard_damage_overlay_wep_1p_a is the golden
    // see-through weapon material that works on ANY champion - it is not tied to
    // a champion or a weapon family, it is a generic overlay the game paints on
    // top of things. Anything in this family is always listed, whatever the
    // champion filter says, because they are the most reusable materials there.
    inline bool IsUniversalMat(const char* nm) {
        return HasCI(nm, "burncard")
            || HasCI(nm, "overlay")
            || HasCI(nm, "_fx_")
            || HasCI(nm, "generic")
            || HasCI(nm, "universal")
            || HasCI(nm, "shared");
    }

    // ####################################################################
    // WHY YOUR CRASH HAPPENED, and the two fixes.
    //
    // Crash was: i>=0 && (i<ArrayNum||(i==0 && ArrayNum==0))
    // That is UE3's array-bounds assertion. You were on Pip and clicked a mesh
    // named like a Pip WEAPON/hand. Assigning a weapon mesh to a character body
    // means the skeleton has a completely different bone count, so the animation
    // code indexed past the end of the bone array and the engine asserted.
    //
    // FIX 1 (this function): I was writing to APawn::Mesh. The pawn's real body
    // is ATgPawn::m_BodyMesh (0x29D0, a UTgSkeletalMeshComponent) — a DIFFERENT
    // component. Writing the base Mesh was wrong to begin with.
    //
    // FIX 2 (in the scan/apply path): the list is now filtered to the champion
    // you are playing by default, and cross-champion picks require an explicit
    // override checkbox. A body mesh from another champion is the same bone-count
    // mismatch and will assert the same way.
    // ####################################################################
    // ========================================================================
    // MESH NAME CLASSIFICATION — the key to not crashing, decoded from the
    // Viktor scan. The names tell you exactly what each mesh is:
    //
    //   skl_pc_<champ>_skin07a         BODY  (character body)      -> body swap OK
    //   skl_pc_<champ>_arms_skin07a    ARMS  (first-person arms)   -> different comp
    //   skl_wep_<champ>_skin07a_3p     WEAPON 3rd person          -> weapon swap
    //   skl_wep_<champ>_skin07a_1p     WEAPON 1st person          -> weapon swap
    //   skl_prp_<champ>_skin02a_poseb  PROP                       -> CRASHES on body
    //   ..._nogeo_..                   NO GEOMETRY (invisible)
    //
    // Putting an arms/weapon/prop mesh onto the BODY component gives it a skeleton
    // with the wrong bone count -> the i>=0 && i<ArrayNum assertion you keep
    // hitting. So the body-apply path must accept ONLY skl_pc bodies (no arms, no
    // wep, no prp, no nogeo). That single rule kills the crash.
    // ========================================================================
    enum MeshKind { MK_Body, MK_Arms, MK_Weapon1P, MK_Weapon3P, MK_Prop, MK_NoGeo, MK_Other };

    inline MeshKind ClassifyMesh(const char* nm) {
        if (HasCI(nm, "nogeo"))                       return MK_NoGeo;
        if (HasCI(nm, "skl_prp") || HasCI(nm, "_prp_")) return MK_Prop;
        if (HasCI(nm, "skl_wep") || HasCI(nm, "_wep_")) {
            if (HasCI(nm, "_1p")) return MK_Weapon1P;
            return MK_Weapon3P;                        // _3p or unmarked
        }
        if (HasCI(nm, "_arms_") || HasCI(nm, "arms_")) return MK_Arms;
        if (HasCI(nm, "skl_pc") || HasCI(nm, "_pc_"))  return MK_Body;
        return MK_Other;
    }

    // Pulls "skin07a" out of a mesh name, so a body and its matching weapon can be
    // paired and applied together as one skin.
    inline void SkinKey(const char* nm, char* out, int cap) {
        out[0] = '\0';
        for (int i = 0; nm[i]; ++i) {
            if (_strnicmp(nm + i, "skin", 4) != 0) continue;
            int j = 0;
            while (nm[i + j] && j < cap - 1) {
                char c = nm[i + j];
                if (j >= 4 && (c == '_' || c == '.')) break;
                // normalise case so skin07a == Skin07A
                if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
                out[j] = c;
                ++j;
            }
            out[j] = '\0';
            return;
        }
    }

    // ---- weapon mesh actor plumbing (pawn->m_WeaponMesh->m_WeaponMesh1P/3P) ----
    inline SDK::ATgWeaponMeshActor* TryGetWeaponActor(SDK::APawn* p) {
        __try { return ((SDK::ATgPawn*)p)->m_WeaponMesh; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // ARMS (first-person hands). Confirmed: ATgWeaponMeshActor::m_HandsMesh
    // (0x0394) is the 1P arms component — which is why "apply weapon skin"
    // re-skinned your HANDS. Now arms meshes get their own correct target
    // instead of being refused as "would crash". This is what lets you fix the
    // "3P wears the skin but 1P hands are still default" problem.
    inline bool TrySetArmsMesh(SDK::ATgWeaponMeshActor* wa, SDK::USkeletalMesh* m) {
        __try {
            if (!wa || !wa->m_HandsMesh || !m) return false;
            ((SDK::USkeletalMeshComponent*)wa->m_HandsMesh)->SkeletalMesh = m;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline int TryGetArmsBoneCount(SDK::ATgWeaponMeshActor* wa) {
        __try {
            if (!wa || !wa->m_HandsMesh) return -1;
            SDK::USkeletalMesh* m =
                ((SDK::USkeletalMeshComponent*)wa->m_HandsMesh)->SkeletalMesh;
            return m ? (int)m->RefSkeleton.Num() : -1;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }

    inline bool TrySetWeaponMesh(SDK::ATgWeaponMeshActor* wa, SDK::USkeletalMesh* m,
                                 bool do1P, bool do3P) {
        __try {
            if (do3P && wa->m_WeaponMesh3P)
                ((SDK::USkeletalMeshComponent*)wa->m_WeaponMesh3P)->SkeletalMesh = m;
            if (do1P && wa->m_WeaponMesh1P)
                ((SDK::USkeletalMeshComponent*)wa->m_WeaponMesh1P)->SkeletalMesh = m;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ========================================================================
    // SetDefaultSkin — THE game's own skin switcher, and the fix for both the
    // wrong-textures AND the "strings/extrusions" problems.
    //
    // Raw mesh-pointer writes can't work properly: they don't reinitialise the
    // animation tree (-> skinning breaks into strings/spikes) and they don't swap
    // the material set (-> the old skin's textures paint the new mesh). The game
    // never swaps meshes that way. It calls SetDefaultSkin(index), which switches
    // the skin variant on a component CORRECTLY — mesh, skeleton, and materials
    // together. It's (Native, Public), a single int, so it's safe.
    //
    // These are scripted (ProcessEvent), so they run on the safe thread only.
    // ========================================================================
    inline bool TrySetDefaultSkinBody(SDK::APawn* p, int idx) {
        __try {
            SDK::ATgPawn* tg = (SDK::ATgPawn*)p;
            if (!tg->m_BodyMesh) return false;
            tg->m_BodyMesh->SetDefaultSkin(idx);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TrySetDefaultSkinWeapon(SDK::APawn* p, int idx) {
        __try {
            SDK::ATgPawn* tg = (SDK::ATgPawn*)p;
            SDK::ATgWeaponMeshActor* wa = tg->m_WeaponMesh;
            if (!wa) return false;
            bool any = false;
            // Both first- and third-person weapon meshes carry their own skin set.
            if (wa->m_WeaponMesh1P) { wa->m_WeaponMesh1P->SetDefaultSkin(idx); any = true; }
            if (wa->m_WeaponMesh3P) { wa->m_WeaponMesh3P->SetDefaultSkin(idx); any = true; }
            return any;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Clears the component's material OVERRIDE array so the mesh falls back to its
    // own materials — the fix for "my old skin's colours are on the new skin".
    inline bool TryClearBodyMaterials(SDK::APawn* p) {
        __try {
            SDK::ATgPawn* tg = (SDK::ATgPawn*)p;
            if (!tg->m_BodyMesh) return false;
            tg->m_BodyMesh->ClearMaterials();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryHide3PWeapon(SDK::ATgWeaponMeshActor* wa, bool hide) {
        __try {
            if (hide) wa->Hide3PWeaponMesh();
            else      wa->Unhide3PWeaponMesh();
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline SDK::USkeletalMeshComponent* TryGetMeshComp(SDK::APawn* p) {
        __try {
            SDK::ATgPawn* tg = (SDK::ATgPawn*)p;
            // Prefer the real body component; fall back to the base Mesh only if
            // it is missing.
            if (tg->m_BodyMesh) return (SDK::USkeletalMeshComponent*)tg->m_BodyMesh;
            return p->Mesh;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // How many skin assemblies the pawn itself is tracking. ATgPawn carries
    // m_pAmSkin (current) and m_pAmAllSkins (TArray<FPointer>, "all skins") —
    // native asset-manager pointers, NOT replicated. If that array holds every
    // skin for the champion, picking a different entry is a far cleaner swap than
    // replacing a mesh, because the assembly already matches the skeleton.
    // This just reports the count for now; it is the next thing to chase.
    inline int TryCountAllSkins(SDK::APawn* p) {
        __try {
            SDK::ATgPawn* tg = (SDK::ATgPawn*)p;
            int n = (int)tg->m_pAmAllSkins.Num();
            if (n < 0 || n > 4096) return -1;
            return n;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }

    inline SDK::USkeletalMesh* TryGetMesh(SDK::USkeletalMeshComponent* mc) {
        __try { return mc->SkeletalMesh; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline bool TrySetMeshRaw(SDK::USkeletalMeshComponent* mc, SDK::USkeletalMesh* m) {
        __try { mc->SkeletalMesh = m; return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Bone count from the mesh's reference skeleton. The "landmine" crashes
    // (i>=0 && i<ArrayNum) happen when a mesh with a DIFFERENT bone count is put
    // on a component expecting the current skeleton. Comparing counts first lets
    // us refuse the bad ones instead of crashing.
    inline int TryGetBoneCount(SDK::USkeletalMesh* m) {
        __try {
            if (!m) return -1;
            return (int)m->RefSkeleton.Num();
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }

    // ========================================================================
    // KEEP-ALIVE (anti-GC) — the fresh unlock for the loading bottleneck.
    //
    // The confirmed problem: the menu PREVIEW loads a skin's mesh, but garbage
    // collection frees it before you reach the match (that's why the mesh stays
    // default while abilities/voice DO switch — the Maeve/Cammie test). If we mark
    // the loaded mesh with the GC "root set" flag, the collector won't free it, so
    // it survives menu -> match and Method A can render it.
    //
    // UObject::ObjectFlags is a 64-bit FQWord {int A (low); int B (high)}. In UE3,
    // RF_RootSet (0x80000000) and RF_Standalone (0x2) in the low word both mean
    // "keep this object alive." We only OR bits in (never clear), so worst case is
    // a harmless memory leak, never corruption.
    // ========================================================================
    inline int  g_KeptAliveCount = 0;

    inline bool TryKeepAlive(SDK::UObject* o) {
        __try {
            if (!o) return false;
            o->ObjectFlags.A |= 0x80000000;   // RF_RootSet - never GC
            o->ObjectFlags.A |= 0x00000002;   // RF_Standalone - keep if unreferenced
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ========================================================================
    // GLOBAL GC-BEATER  (this is the real "turn off garbage collection" answer)
    //
    // The per-scan keep-alive only pins meshes that pass the CHAMPION FILTER at
    // the moment you scan. That's why it wasn't reliably beating GC: a skin you
    // preview for a different champ, or one that loads a half-second after the
    // scan, still gets collected on the menu->match transition.
    //
    // This sweep walks the ENTIRE GObjects table and pins EVERY skin asset it
    // finds — SkeletalMesh (bodies+weapons), the material instances, and the
    // textures — regardless of champion or filter. Run once a second, it means:
    // anything that EVER loads into memory (menu preview, illusion, deployable)
    // is pinned the instant it appears and never gets freed again.
    //
    // Effect: preview a skin in the menu ONCE, and its mesh is now resident for
    // the rest of the game session. Method A (Combined Full Apply) then has a
    // loaded mesh to render in the shooting range every time — no more
    // "invisible = it got GC'd." This is as close to "GC off" as we can get
    // without patching the engine's collector.
    // ========================================================================
    inline bool g_GlobalKeepAlive   = false;    // OFF: the whole-table pin caused
                                                // the mini-freezes (1378 SEH writes +
                                                // full GObjects walk every second).
                                                // Over-engineered. Use targeted
                                                // per-scan keep-alive instead.
    inline int  g_GlobalPinnedTotal = 0;        // running count of assets pinned
    inline ULONGLONG g_LastGlobalKeepMs = 0;

    inline void RunGlobalKeepAlive() {
        auto& objects = SDK::UObject::GetGlobalObjects();
        size_t count = 0;
        __try { count = objects.Num(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
        if (count == 0 || count > 4000000) return;

        int pinnedThisPass = 0;
        for (size_t i = 0; i < count; ++i) {
            SDK::UObject* obj = TryObjAt(objects, i);
            if (!obj) continue;

            char cls[80];
            if (!TryCopyClassName(obj, cls, 80)) continue;

            // Pin the three asset classes a skin needs to render. Exact-ish
            // matches so we don't waste time flagging every UObject in the game.
            bool isAsset =
                lstrcmpA(cls, "SkeletalMesh") == 0 ||
                lstrcmpA(cls, "MaterialInstanceConstant") == 0 ||
                lstrcmpA(cls, "Material") == 0 ||
                lstrcmpA(cls, "Texture2D") == 0;
            if (!isAsset) continue;

            char nm[80];
            if (!TryCopyName(obj, nm, 80)) continue;
            if (_strnicmp(nm, "Default__", 9) == 0) continue;

            // Only bother with things that look like champion cosmetics — the
            // skl_/mic_/mat_ families — so we're not pinning UI/world textures.
            bool looksCosmetic =
                _strnicmp(nm, "skl_", 4) == 0 ||
                _strnicmp(nm, "mic_", 4) == 0 ||
                _strnicmp(nm, "mat_", 4) == 0 ||
                _strnicmp(nm, "tex_", 4) == 0 ||
                _strnicmp(nm, "t_",   2) == 0;
            if (!looksCosmetic) continue;

            if (TryKeepAlive(obj)) pinnedThisPass++;
        }
        g_GlobalPinnedTotal = pinnedThisPass;   // current resident+pinned asset count
    }

    // TEXTURE FIX (raw, render-thread safe). When we swap the mesh POINTER, the
    // component keeps its old override Materials[] — so the new skin renders with
    // the previous skin's textures (your "Invader Pip in wrong colours"). Emptying
    // the override array makes the component fall back to the NEW mesh's OWN
    // materials, which are the correct ones for that skin. Count=0 is the raw
    // equivalent of ClearMaterials() and is safe to do right here after the swap.
    // The SDK's TArray keeps Count private with no setter, so we set it through
    // its known memory layout: { T* Data (8), int32 Count (4), int32 Max (4) }.
    // Writing Count=0 (leaving Data/Max) is exactly what "empty the override
    // array" means and matches what the game's own ClearMaterials does. The
    // TArray member address is taken directly, so no offset guessing per class.
    inline void ZeroTArrayCount(void* tarrayAddr) {
        *(int*)((char*)tarrayAddr + 8) = 0;   // +8 = past the Data pointer
    }

    // The pawn itself owns material application (that's why clearing the
    // component alone didn't stick — the pawn re-applies its own materials).
    // These are the pawn-level material controls. Scripted, so safe thread only.
    // Set a material on a specific slot of the body mesh. Scripted (SetMaterial
    // goes through ProcessEvent), so safe thread only.
    inline bool TrySetBodyMaterial(SDK::APawn* p, int slot, SDK::UMaterialInterface* mat) {
        __try {
            SDK::ATgPawn* tg = (SDK::ATgPawn*)p;
            if (!tg->m_BodyMesh) return false;
            ((SDK::UMeshComponent*)tg->m_BodyMesh)->SetMaterial(slot, mat);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline int TryGetBodySlots(SDK::APawn* p) {
        __try {
            SDK::ATgPawn* tg = (SDK::ATgPawn*)p;
            if (!tg->m_BodyMesh) return -1;
            return ((SDK::UMeshComponent*)tg->m_BodyMesh)->GetNumElements();
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }

    // Set a material on the WEAPON mesh (both 1P and 3P), so a weapon texture goes
    // on the gun instead of the body. This is what keeps them separate.
    // ARMS materials — the third target you had no way to reach. Arms live on
    // ATgWeaponMeshActor::m_HandsMesh, so their materials need their own setter;
    // body and weapon setters can't touch them. This is why scanning textures
    // never offered anything that landed on your hands.
    inline bool TrySetArmsMaterial(SDK::APawn* p, int slot, SDK::UMaterialInterface* mat) {
        __try {
            SDK::ATgPawn* tg = (SDK::ATgPawn*)p;
            SDK::ATgWeaponMeshActor* wa = tg->m_WeaponMesh;
            if (!wa || !wa->m_HandsMesh) return false;
            ((SDK::UMeshComponent*)wa->m_HandsMesh)->SetMaterial(slot, mat);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TrySetWeaponMaterial(SDK::APawn* p, int slot, SDK::UMaterialInterface* mat) {
        __try {
            SDK::ATgPawn* tg = (SDK::ATgPawn*)p;
            SDK::ATgWeaponMeshActor* wa = tg->m_WeaponMesh;
            if (!wa) return false;
            bool any = false;
            if (wa->m_WeaponMesh3P) {
                ((SDK::UMeshComponent*)wa->m_WeaponMesh3P)->SetMaterial(slot, mat); any = true;
            }
            if (wa->m_WeaponMesh1P) {
                ((SDK::UMeshComponent*)wa->m_WeaponMesh1P)->SetMaterial(slot, mat); any = true;
            }
            return any;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Material classification by name prefix (decoded from the real scan):
    //   mic_pc_<champ>...   BODY
    //   mic_wep_<champ>...  WEAPON
    //   mic_acc_<champ>...  ACCESSORY (rarely needed)
    inline bool IsWeaponMaterial(const char* nm) {
        return HasCI(nm, "mic_wep") || HasCI(nm, "_wep_");
    }

    inline bool TryForceRecalcMaterial(SDK::APawn* p) {
        __try { ((SDK::ATgPawn*)p)->ForceRecalculateMaterial(); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool TryClearReplacementMaterial(SDK::APawn* p) {
        __try { ((SDK::ATgPawn*)p)->ClearReplacementMaterial(); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryClearMaterialsRaw(SDK::USkeletalMeshComponent* mc) {
        __try {
            ZeroTArrayCount(&mc->Materials);   // fall back to the mesh's own materials
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Read a mesh's OWN default materials count — diagnostic, to know whether
    // clearing the override will leave it with materials or blank it. Num() is the
    // public accessor.
    inline int TryMeshOwnMaterialCount(SDK::USkeletalMesh* m) {
        __try {
            if (!m) return -1;
            return (int)m->Materials.Num();
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }

    // ####################################################################
    // SetSkeletalMesh IS REMOVED — it is provably broken, and it is what
    // crashed you both times with:
    //   "run-time check failure #2 - stack around the variable 'params' was
    //    corrupted"
    //
    // Cause: Engine.SkeletalMeshComponent.SetSkeletalMesh is declared
    // (HasOptionalParms) with two OptionalParm bools. The SDK's dumped params
    // struct does not match what the native function actually reads off the
    // stack, so calling it writes past the struct. That is not something a
    // __try can save us from — the damage is already done by the time it
    // returns, which is why it took down the game rather than being caught.
    //
    // The lesson generalises and is worth keeping: BEFORE calling any dumped
    // function, check its flags. (HasOptionalParms) means the struct is
    // suspect. Both of the new prime candidates
    // (LiveMatchSwitchChampion, SetDefaultSkin) are plain "(Native, Public)"
    // with only int parameters, which is exactly why they were chosen.
    // ####################################################################

    // ---- the scan: this is the experiment that answers everything ----
    // Pulls the "skinNNx" token out of a mesh name like skl_pc_pip_skin03a_3p.
    inline void ExtractSkinTag(const char* meshName, char* out, int cap) {
        out[0] = '\0';
        if (!meshName) return;
        for (int i = 0; meshName[i]; ++i) {
            if (_strnicmp(meshName + i, "skin", 4) != 0) continue;
            int j = 0;
            // Copy "skin" plus the digits/letter that follow it.
            while (meshName[i + j] && j < cap - 1) {
                char c = meshName[i + j];
                if (j >= 4 && c == '_') break;
                out[j] = c;
                ++j;
            }
            out[j] = '\0';
            return;
        }
    }

    // ========================================================================
    // CHAMPION NAME FROM THE MESH, NOT THE CLASS.  *** THE MAEVE BUG ***
    //
    // The pawn CLASS uses the internal codename ("TgPawn_Blades"), but the mesh
    // ASSETS use the marketing name ("skl_pc_maeve_skin10a"). Maeve = Blades,
    // Vivian = Churchill, etc. We were filtering mesh names by the CLASS name, so
    // on Maeve the filter "Blades" matched none of her "maeve" meshes -> Method B
    // listed NOTHING. Koga/Ying/Cassie worked purely because their codename and
    // asset name happen to be identical.
    //
    // Fix: derive the champion from the LIVE BODY MESH name, which is always the
    // real asset name. Self-correcting for every champion, no alias table to
    // maintain and no guessing.
    //   "skl_pc_maeve_skin10a"          -> "maeve"
    //   "skl_pc_fernando_arms_skin00a"  -> "fernando"
    // ========================================================================
    // Codename -> asset name, for when the live mesh can't be read (dead, not yet
    // spawned, mesh hidden). Same confirmed mapping the ESP name boxes use — these
    // were verified in-game one by one, so reuse them rather than re-deriving.
    // The mesh-name path above is still preferred; this is the fallback.
    struct ChampAlias { const char* codeName; const char* assetName; };
    static const ChampAlias g_ChampAliases[] = {
        { "Blades",      "maeve"    }, { "Churchill",   "vivian"   },
        { "Longbow",     "shalin"   }, { "Gauntlet",    "torvald"  },
        { "Vampire",     "lillith"  }, { "Fairy",       "willo"    },
        { "Darklord",    "zhin"     }, { "Astro",       "jenos"    },
        { "Corrupter",   "vora"     }, { "Vanguard",    "khan"     },
        { "Owl",         "strix"    }, { "Seven",       "vii"      },
        { "Oracle",      "seris"    }, { "Druid",       "io"       },
        { "BarrierTank", "inara"    }, { "BombQueen",   "betty"    },
        { "Shadow",      "vatu"     }, { "Princess",    "lian"     },
        { "Bunny",       "rei"      }, { "Commander",   "octavia"  },
    };

    inline const char* AliasToAssetName(const char* codeName) {
        if (!codeName || !codeName[0]) return codeName;
        for (const auto& a : g_ChampAliases)
            if (_stricmp(codeName, a.codeName) == 0) return a.assetName;
        return codeName;
    }

    inline bool ExtractChampFromMeshName(const char* meshName, char* out, int cap) {
        out[0] = '\0';
        if (!meshName || !meshName[0]) return false;
        // Find the "skl_pc_" prefix case-insensitively.
        const char* p = nullptr;
        for (const char* s = meshName; *s; ++s) {
            if (_strnicmp(s, "skl_pc_", 7) == 0) { p = s + 7; break; }
        }
        if (!p) return false;
        int j = 0;
        while (p[j] && j < cap - 1) {
            // Stop at the token that follows the champion name.
            if (p[j] == '_' &&
                (_strnicmp(p + j, "_skin", 5) == 0 ||
                 _strnicmp(p + j, "_arms", 5) == 0 ||
                 _strnicmp(p + j, "_nogeo", 6) == 0)) break;
            out[j] = p[j];
            ++j;
        }
        out[j] = '\0';
        return j > 0;
    }

    // Best-effort "skin09a" -> a readable name. The mesh only carries a code, and
    // the database is keyed by id, so this maps by ORDER: skin00a is the champ's
    // first entry, skin01a the second, and so on. Not perfect (the DB has gaps and
    // duplicates) but far better than staring at "skin09a".
    inline const char* LookupSkinName(const char* champ, const char* skinKey) {
        if (!champ || !champ[0] || !skinKey || !skinKey[0]) return nullptr;
        // pull the numeric part out of "skinNNx"
        const char* p = skinKey;
        while (*p && (*p < '0' || *p > '9')) ++p;
        if (!*p) return nullptr;
        int want = 0;
        while (*p >= '0' && *p <= '9') { want = want * 10 + (*p - '0'); ++p; }

        const int total = (int)(sizeof(SkinDB::kSkins) / sizeof(SkinDB::kSkins[0]));
        int seen = 0;
        for (int i = 0; i < total; ++i) {
            if (!HasCI(SkinDB::kSkins[i].champion, champ)) continue;
            // skip obvious duplicates of the same display name
            bool dup = false;
            for (int j = 0; j < i; ++j) {
                if (!HasCI(SkinDB::kSkins[j].champion, champ)) continue;
                if (lstrcmpiA(SkinDB::kSkins[j].name, SkinDB::kSkins[i].name) == 0) { dup = true; break; }
            }
            if (dup) continue;
            if (seen == want) return SkinDB::kSkins[i].name;
            ++seen;
        }
        return nullptr;
    }

    inline void RunScanRaw();

    // GObjects is being mutated during level transitions, and walking it then is
    // exactly what takes the game down. Auto-scan runs once a second forever, so
    // it MUST be guarded and it MUST refuse to run without a live pawn.
    inline void SafeRunScan() {
        if (!Globals::LocalPawn) return;
        __try { RunScanRaw(); }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            lstrcpynA(g_Status, "Scan faulted and was caught - skipped this pass.", 160);
        }
    }

    inline void RunScanRaw() {
        g_ResultCount = 0;
        g_TotalSkeletalMeshes = 0;
        g_ScanDone = true;

        // Work out which skin we're actually wearing, from the live mesh's own
        // name, so "is this a different skin?" is measured rather than guessed.
        ExtractSkinTag(g_LiveName, g_CurrentSkinTag, 16);

        // Re-derive the champion from the LIVE mesh every scan (the Maeve fix).
        // If we're wearing skl_pc_maeve_*, the champion is "maeve" — never the
        // "Blades" codename that matches none of the asset names.
        {
            char fromMesh[48] = {};
            if (g_LiveName[0] && ExtractChampFromMeshName(g_LiveName, fromMesh, 48)
                && fromMesh[0]) {
                lstrcpynA(g_MyChampion, fromMesh, 48);
            }
        }

        // Discover the current body mesh's full package path now, so the scan
        // report can include it — it's the key to whether loading can work.
        {
            SDK::APawn* pawn = Globals::LocalPawn;
            if (pawn) {
                SDK::USkeletalMeshComponent* mc = TryGetMeshComp(pawn);
                if (mc) BuildLivePath((SDK::UObject*)TryGetMesh(mc));
            }
        }

        auto& objects = SDK::UObject::GetGlobalObjects();
        size_t count = 0;
        __try { count = objects.Num(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
        if (count == 0 || count > 4000000) {
            lstrcpynA(g_Status, "GObjects unreadable", 160);
            return;
        }

        for (size_t i = 0; i < count; ++i) {
            SDK::UObject* obj = TryObjAt(objects, i);
            if (!obj) continue;

            char cls[80];
            if (!TryCopyClassName(obj, cls, 80)) continue;
            // Exact class name match: SkeletalMesh, not SkeletalMeshComponent or
            // SkeletalMeshSocket, both of which also contain "SkeletalMesh".
            if (lstrcmpA(cls, "SkeletalMesh") != 0) continue;

            g_TotalSkeletalMeshes++;

            char nm[80];
            if (!TryCopyName(obj, nm, 80)) continue;
            if (_strnicmp(nm, "Default__", 9) == 0) continue;   // class default object
            // Same weapon-family exception as the material scan: weapon meshes are
            // named after the WEAPON (skl_wep_blades_*), not the champion, so a
            // champion filter would hide every weapon mesh for Maeve/Fernando/Pip.
            if (!HasCI(nm, g_Filter) &&
                !(g_WeaponFamily[0] && HasCI(nm, g_WeaponFamily))) continue;

            // "nogeo" = NO GEOMETRY. These are deliberately empty meshes the game
            // uses to hide a body. Picking one is EXACTLY why you turned
            // invisible — the list offered you skl_pc_pip_nogeo_skin00a. They can
            // never be a skin, so they're hidden unless explicitly asked for.
            if (!showNoGeo && HasCI(nm, "nogeo")) continue;

            // Record whether this mesh is a DIFFERENT skin from the one currently
            // worn. This is the whole point now: force-loading proved other skins
            // CAN be brought into memory (skin03a appeared for Pip), so the list
            // needs to make those stand out instead of burying them.
            // Dedupe — you noticed rescans piling up copies. Skip a name we've
            // already recorded this scan.
            bool already = false;
            for (int d = 0; d < g_ResultCount; ++d) {
                if (g_Objects[d] == obj) { already = true; break; }
            }
            if (already) continue;

            if (g_ResultCount < kMaxResults) {
                g_IsOtherSkin[g_ResultCount] =
                    (g_CurrentSkinTag[0] != '\0') && !HasCI(nm, g_CurrentSkinTag);
                lstrcpynA(g_Names[g_ResultCount], nm, 80);
                g_Objects[g_ResultCount] = obj;
                // Cache the bone count now — the second, independent "tell" for
                // what a mesh is. Body ~50+, weapon far fewer.
                g_BoneCounts[g_ResultCount] = TryGetBoneCount((SDK::USkeletalMesh*)obj);
                // Auto keep-alive: mark it non-GC the instant we find it, so a skin
                // previewed in the menu survives into the match.
                if (g_AutoKeepAlive) { if (TryKeepAlive(obj)) g_KeptAliveCount++; }
                g_ResultCount++;
            }
        }
        wsprintfA(g_Status, "Scan done: %d SkeletalMesh objects in memory, %d listed",
                  g_TotalSkeletalMeshes, g_ResultCount);
        BuildScanReport();
        // ALWAYS scan materials with meshes. You can't apply a mesh correctly
        // without its materials — separating them is what left skins wearing the
        // previous skin's textures until you manually pressed SCAN MATERIALS.
        RunMaterialScan();
    }

    // The copy-paste you asked for. THIS is the data I want — the names tell me
    // whether other skins' meshes are resident, which decides the whole approach.
    inline void BuildScanReport() {
        g_ScanReport[0] = '\0';
        char t[256];
        lstrcatA(g_ScanReport, "===== PHAROAH MESH SCAN =====\r\n");
        wsprintfA(t, "My champion (from pawn class): %s\r\n",
                  g_MyChampion[0] ? g_MyChampion : "(unknown)");
        lstrcatA(g_ScanReport, t);
        wsprintfA(t, "Total SkeletalMesh objects loaded: %d\r\n", g_TotalSkeletalMeshes);
        lstrcatA(g_ScanReport, t);
        wsprintfA(t, "m_pAmAllSkins count on my pawn  : %d\r\n", g_AllSkinsCount);
        lstrcatA(g_ScanReport, t);
        wsprintfA(t, "Name filter used                : \"%s\"\r\n", g_Filter);
        lstrcatA(g_ScanReport, t);
        wsprintfA(t, "Listed below                    : %d\r\n", g_ResultCount);
        lstrcatA(g_ScanReport, t);
        wsprintfA(t, "Live body full path             : %s\r\n\r\n",
                  g_LiveFullPath[0] ? g_LiveFullPath : "(unknown)");
        lstrcatA(g_ScanReport, t);
        for (int i = 0; i < g_ResultCount; ++i) {
            // Guard the buffer — 16KB holds a lot but not unlimited.
            if (lstrlenA(g_ScanReport) > 15600) {
                lstrcatA(g_ScanReport, "...(truncated)\r\n");
                break;
            }
            lstrcatA(g_ScanReport, g_Names[i]);
            lstrcatA(g_ScanReport, "\r\n");
        }
        lstrcatA(g_ScanReport, "===== END =====\r\n");
    }

    inline bool CopyClip(const char* text) {
        if (!OpenClipboard(nullptr)) return false;
        EmptyClipboard();
        int len = lstrlenA(text) + 1;
        HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, len);
        if (!h) { CloseClipboard(); return false; }
        void* p = GlobalLock(h);
        if (p) { memcpy(p, text, len); GlobalUnlock(h); SetClipboardData(CF_TEXT, h); }
        CloseClipboard();
        return true;
    }

    // ========================================================================
    // LOAD-AND-WEAR BY NUMBER — the real fix for "only a few skins list".
    //
    // Instead of hoping a skin is resident, we NAME it from the live mesh's own
    // pattern and fetch it. If the live body mesh is "skl_pc_pip_skin00a_3p",
    // then skin 5 is "skl_pc_pip_skin05a_3p". Fetch (find-if-loaded, else force-
    // load), write to the body, and the pawn now holds a reference so it can't be
    // garbage-collected. Same for the weapon from its own live name.
    // ========================================================================
    inline int  g_WearSkinNum = 0;
    inline bool g_PendingWearNum = false;
    inline char g_WeaponLiveName[80] = "";

    inline bool ExtractWeaponFamily(const char* meshName, char* out, int cap) {
        out[0] = '\0';
        if (!meshName || !meshName[0]) return false;
        const char* p = nullptr;
        for (const char* s = meshName; *s; ++s)
            if (_strnicmp(s, "skl_wep_", 8) == 0) { p = s + 8; break; }
        if (!p) return false;
        int j = 0;
        while (p[j] && j < cap - 1) {
            // stop at the token that follows the family name
            if (p[j] == '_' &&
                (_strnicmp(p + j, "_skin", 5) == 0 ||
                 _strnicmp(p + j, "_projectile", 11) == 0 ||
                 _strnicmp(p + j, "_1p", 3) == 0 ||
                 _strnicmp(p + j, "_3p", 3) == 0)) break;
            out[j] = p[j];
            ++j;
        }
        out[j] = '\0';
        return j > 0;
    }

    // SetDefaultSkin variant switching — the PRIMARY, correct method.
    inline int  g_PendingVariant = -1;      // >=0 means apply this variant index
    inline bool g_VariantWeaponToo = true;
    inline bool g_PendingClearMats = false;
    inline int  g_LastVariant = -1;
    inline char g_VariantStatus[128] = "Pick a variant number.";

    // Replace the skin number EVERYWHERE it appears in the path, not just the leaf.
    //
    // THIS IS THE FIX. The full path is:
    //     PC_Pip_Skin00A.Meshes.skl_pc_pip_skin00a_3p
    //                ^^^^                         ^^^^
    // The skin number is in the PACKAGE NAME (Skin00A) as well as the mesh name
    // (skin00a). Each skin lives in its own package PC_Pip_SkinNNA. Changing only
    // the leaf left the package pointing at Skin00A, so skin 06's mesh was looked
    // for in the wrong package and never found. Every "skin"+2-digits token gets
    // the new number; casing and the trailing letter are preserved.
    inline bool BuildSkinName(const char* src, int nn, char* out, int cap) {
        out[0] = '\0';
        if (!src || !src[0]) return false;
        bool replacedAny = false;
        int o = 0;
        for (int i = 0; src[i] && o < cap - 1; ) {
            if (_strnicmp(src + i, "skin", 4) == 0 &&
                src[i+4] >= '0' && src[i+4] <= '9' &&
                src[i+5] >= '0' && src[i+5] <= '9') {
                // copy the "skin" / "Skin" exactly as written
                for (int k = 0; k < 4 && o < cap - 1; ++k) out[o++] = src[i + k];
                // write the new two-digit number
                if (o < cap - 2) {
                    out[o++] = (char)('0' + (nn / 10) % 10);
                    out[o++] = (char)('0' + nn % 10);
                }
                i += 6;                 // skip "skin" + 2 digits in the source
                replacedAny = true;
            } else {
                out[o++] = src[i++];
            }
        }
        out[o] = '\0';
        return replacedAny;
    }

    // The FULL path of the current body mesh, e.g. "CharPip.skl_pc_pip_skin00a_3p".
    // DynamicLoadObject needs this — a bare object name has no package to load
    // from, which is why every number button said "not found". Built by walking
    // the Outer chain (raw pointer reads, safe on any thread).
    inline void BuildLivePath(SDK::UObject* mesh) {
        g_LivePathPrefix[0] = '\0';
        g_LiveFullPath[0] = '\0';
        __try {
            if (!mesh) return;
            // Collect the Outer chain names from immediate parent up to package.
            const int kMax = 8;
            char parts[kMax][80];
            int count = 0;
            SDK::UObject* o = mesh->Outer;
            while (o && count < kMax) {
                if (!TryCopyName(o, parts[count], 80)) break;
                count++;
                o = o->Outer;
            }
            // Assemble outermost -> innermost as "A.B.C." (prefix, trailing dot).
            int p = 0;
            for (int i = count - 1; i >= 0 && p < 150; --i) {
                for (int k = 0; parts[i][k] && p < 150; ++k) g_LivePathPrefix[p++] = parts[i][k];
                if (p < 150) g_LivePathPrefix[p++] = '.';
            }
            g_LivePathPrefix[p] = '\0';

            // Full path = prefix + leaf name.
            char leaf[80];
            if (TryCopyName(mesh, leaf, 80)) {
                lstrcpynA(g_LiveFullPath, g_LivePathPrefix, 200);
                lstrcatA(g_LiveFullPath, leaf);
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }

    // Granular so a failure is legible instead of a silent "not loadable".
    inline char g_FetchDiag[200] = "";

    inline SDK::USkeletalMesh* FetchMeshByName(const char* fullPath) {
        wchar_t w[200];
        MultiByteToWideChar(CP_ACP, 0, fullPath, -1, w, 200);

        // 1) Already resident?
        SDK::USkeletalMesh* m = SafeCalls::FindLoadedMesh(w);
        if (m) { lstrcpynA(g_FetchDiag, "found (already loaded)", 200); return m; }

        // 2) Load the PACKAGE (first path segment), then look again. This is the
        //    step that actually pulls a not-yet-loaded skin off disk.
        char pkg[96] = {};
        for (int i = 0; fullPath[i] && fullPath[i] != '.' && i < 95; ++i) pkg[i] = fullPath[i];
        if (pkg[0]) {
            wchar_t wp[96];
            MultiByteToWideChar(CP_ACP, 0, pkg, -1, wp, 96);
            SDK::UObject* p = SafeCalls::ForceLoadPackage(wp);
            m = SafeCalls::FindLoadedMesh(w);
            if (m) { wsprintfA(g_FetchDiag, "loaded via package %s", pkg); return m; }
            // 3) Last resort: force-load the object path directly.
            m = SafeCalls::ForceLoadMesh(w);
            if (m) { lstrcpynA(g_FetchDiag, "loaded via object path", 200); return m; }
            wsprintfA(g_FetchDiag, "package %s %s, mesh still missing",
                      pkg, p ? "loaded" : "NOT found on disk");
        } else {
            lstrcpynA(g_FetchDiag, "no package segment in path", 200);
        }
        return nullptr;
    }

    // Re-derive g_MyChampion from whatever pawn is live RIGHT NOW.
    //
    // g_MyChampion used to be set only inside the "pawn != g_BasePawn" branch,
    // i.e. only when a NEW pawn appeared. Switch champion in the menu and the
    // name stayed on the previous one, so every later scan filtered for the WRONG
    // champion and kept showing the old one's textures. Called at the top of each
    // scan so a rescan always means what it says.
    inline void RefreshChampionFromPawn() {
        SDK::APawn* p = Globals::LocalPawn;
        if (!p) return;
        SDK::USkeletalMeshComponent* mc = TryGetMeshComp(p);
        if (!mc) return;
        SDK::USkeletalMesh* live = TryGetMesh(mc);
        char liveName[80] = {};
        if (live) TryCopyName((SDK::UObject*)live, liveName, 80);

        char fromMesh[48] = {};
        if (liveName[0] && ExtractChampFromMeshName(liveName, fromMesh, 48) && fromMesh[0]) {
            lstrcpynA(g_MyChampion, fromMesh, 48);
            return;
        }
        char cls[80] = {};
        if (TryCopyClassName(p, cls, 80)) {
            const char* src = cls;
            if (_strnicmp(cls, "TgPawn_", 7) == 0) src = cls + 7;
            lstrcpynA(g_MyChampion, AliasToAssetName(src), 48);
        }
    }

    // Scan GObjects for MaterialInstanceConstant / MaterialInstance objects that
    // belong to this champion. These carry the actual skin textures.
    inline void RunMaterialScan() {
        RefreshChampionFromPawn();   // never scan for a stale champion
        g_MatCount = 0;
        g_MatTotal = 0;
        auto& objects = SDK::UObject::GetGlobalObjects();
        size_t count = 0;
        __try { count = objects.Num(); } __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
        if (count == 0 || count > 4000000) return;

        // TWO PASSES, and the order is the whole point.
        //
        // Pass 0 takes only RELEVANT materials: this champion's, this weapon
        // family's, and the universal overlays. Pass 1 then fills whatever room
        // is left with everything else, and only when "show ALL" is on.
        //
        // A single pass with "show ALL" is what emptied the list: it filled every
        // slot with the first materials it happened to meet walking GObjects -
        // none of them this champion's - so the display filter matched nothing.
        // Priority order means the useful ones can never be crowded out again.
        int relevantCount = 0, universalCount = 0;

        for (int pass = 0; pass < 2; ++pass) {
            if (pass == 1 && !g_MatShowAll) break;
            if (g_MatCount >= kMaxMats) break;

            for (size_t i = 0; i < count; ++i) {
                SDK::UObject* obj = TryObjAt(objects, i);
                if (!obj) continue;
                char cls[80];
                if (!TryCopyClassName(obj, cls, 80)) continue;
                // Material instances hold the textures; the base class name
                // contains "MaterialInstance".
                if (!HasCI(cls, "MaterialInstance")) continue;
                if (pass == 0) g_MatTotal++;

                char nm[96];
                if (!TryCopyName(obj, nm, 96)) continue;
                if (_strnicmp(nm, "Default__", 9) == 0) continue;

                // Weapons are named after the WEAPON FAMILY, not the champion
                // (blades / lanceshield / potionlauncher), so accept those too.
                bool universal = IsUniversalMat(nm);
                bool relevant  = universal
                              || g_MyChampion[0] == '\0'
                              || HasCI(nm, g_MyChampion)
                              || (g_WeaponFamily[0] && HasCI(nm, g_WeaponFamily));

                if (pass == 0 && !relevant) continue;   // relevant first
                if (pass == 1 && relevant)  continue;   // already taken in pass 0

                bool already = false;
                for (int d = 0; d < g_MatCount; ++d)
                    if (g_MatObjects[d] == obj) { already = true; break; }
                if (already) continue;

                if (g_MatCount < kMaxMats) {
                    lstrcpynA(g_MatNames[g_MatCount], nm, 96);
                    g_MatObjects[g_MatCount] = obj;
                    if (g_AutoKeepAlive) { if (TryKeepAlive(obj)) g_KeptAliveCount++; }
                    g_MatCount++;
                    if (pass == 0) { relevantCount++; if (universal) universalCount++; }
                } else break;
            }
        }
        wsprintfA(g_MatStatus, "Materials: %d listed (%d for %s, %d universal overlays) of %d total",
                  g_MatCount, relevantCount, g_MyChampion[0] ? g_MyChampion : "all",
                  universalCount, g_MatTotal);
    }

    // Auto-assign: after a body swap to skinNNa, find this champion's materials
    // whose name carries the SAME skin key and SetMaterial them onto the body's
    // slots in order. Runs on the safe thread (SetMaterial is scripted).
    // Is this material a BODY material (mic_pc_<champ>_...skinNN) as opposed to
    // arms / accessory / weapon / glass / lobby / mastery? Only body materials
    // belong on the body mesh slots. Applying arms/acc materials to the body is
    // what produced wrong colours. Naming decoded from the real scan:
    //   mic_pc_viktor_id1_skin00a   BODY  (slot material, "id1"/"id2")
    //   mic_pc_viktor_skin00a       BODY
    //   mic_pc_viktor_arms_skin00a  ARMS   (not body)
    //   mic_acc_viktor_skin00a      ACCESSORY
    //   mic_wep_viktor_skin00a_1p   WEAPON
    //   ..._glass / ..._lobby / ..._mastery / ..._nogeo  -> skip
    inline bool IsBodyMaterial(const char* nm) {
        if (!HasCI(nm, "mic_pc") && !HasCI(nm, "_pc_")) return false;
        if (HasCI(nm, "_arms_") || HasCI(nm, "arms_")) return false;
        if (HasCI(nm, "acc_") || HasCI(nm, "_acc")) return false;
        if (HasCI(nm, "wep_") || HasCI(nm, "_wep")) return false;
        if (HasCI(nm, "glass")) return false;
        if (HasCI(nm, "lobby")) return false;
        if (HasCI(nm, "mastery") || HasCI(nm, "gold")) return false;
        if (HasCI(nm, "nogeo")) return false;
        return true;
    }

    // ---- MATERIAL LIST FILTER ---------------------------------------------
    // The texture lists showed EVERY loaded material, so on Maeve you got Pip
    // arms, Cassie arms and Fernando arms in the ARMS column. Those cannot help
    // you - a material for another champion's model is not going to look right
    // on yours - and they buried the ones that can.
    //
    // The universal overlays are the exception: mic_burncard_* and friends work
    // on ANY champion, so a plain champion-name filter would throw away the most
    // useful entries in the list. They are always kept.
    inline bool g_MatsMyChampOnly = true;

    inline bool IsUniversalMaterial(const char* nm) {
        if (!nm) return false;
        return HasCI(nm, "burncard") || HasCI(nm, "overlay") ||
               HasCI(nm, "universal") || HasCI(nm, "generic");
    }

    // True when this material should appear in the lists.
    inline bool MatPassesChampFilter(const char* nm) {
        if (!g_MatsMyChampOnly) return true;
        if (!g_MyChampion[0])   return true;   // champion unknown - show all
        if (IsUniversalMaterial(nm)) return true;
        return HasCI(nm, g_MyChampion);
    }


    // ARMS materials. IsBodyMaterial deliberately EXCLUDES "_arms_", and the
    // weapon check only matches "wep" — so arms materials were falling through
    // every filter and appearing in no list at all. That's the missing third
    // category: body / arms / weapon, matching the three mesh targets.
    inline bool IsArmsMaterial(const char* nm) {
        if (!HasCI(nm, "_arms_") && !HasCI(nm, "arms_")) return false;
        if (HasCI(nm, "lobby") || HasCI(nm, "nogeo")) return false;
        return true;
    }

    // Apply the BODY materials whose skin key matches. id1 goes to slot 0, id2 to
    // slot 1, then anything else. Ordered so the two main body materials land in
    // the right slots instead of scan order.
    inline int ApplyMatchingMaterials(SDK::APawn* pawn, const char* bodyMeshName) {
        char key[16]; SkinKey(bodyMeshName, key, 16);
        if (!key[0]) return 0;
        int slots = TryGetBodySlots(pawn);
        g_BodySlots = slots;
        if (slots <= 0 || slots > 16) slots = 8;   // sane cap if unknown

        int applied = 0;
        // Pass order: id1 first, then id2, then remaining body materials.
        const char* passes[3] = { "id1", "id2", nullptr };
        int slot = 0;
        for (int pass = 0; pass < 3 && slot < slots; ++pass) {
            for (int i = 0; i < g_MatCount && slot < slots; ++i) {
                char k2[16]; SkinKey(g_MatNames[i], k2, 16);
                if (lstrcmpA(key, k2) != 0) continue;
                if (!IsBodyMaterial(g_MatNames[i])) continue;
                bool hasId1 = HasCI(g_MatNames[i], "id1");
                bool hasId2 = HasCI(g_MatNames[i], "id2");
                if (pass == 0 && !hasId1) continue;
                if (pass == 1 && !hasId2) continue;
                if (pass == 2 && (hasId1 || hasId2)) continue;   // already placed
                if (TrySetBodyMaterial(pawn, slot, (SDK::UMaterialInterface*)g_MatObjects[i])) {
                    applied++; slot++;
                }
            }
        }
        return applied;
    }

    // ========================================================================
    // *** LANDMINE SAFETY CLASSIFIER ***
    //
    // "Even a correct bone count still crashes." Here is why: bone COUNT matching
    // does not mean the SKELETON matches. Two meshes can both have 213 bones and
    // have completely different bone names, order and hierarchy. The anim tree is
    // built for YOUR skeleton, so it indexes bones by position — feed it a
    // same-count-but-different skeleton and it still walks off the end:
    //     i>=0 && (i<ArrayNum||(i==0 && ArrayNum==0))
    //
    // So bone count alone was never a sufficient test. The reliable predictor is
    // ASSET FAMILY: a mesh is safe on your body only if it is the same champion's
    // body mesh. That is also why Method A never landmines — it works by skin ID
    // through the game's own resolver, which can only ever produce a valid mesh
    // for the champion you are playing. Method B takes a raw pointer with no such
    // guarantee, so we have to reproduce that guarantee ourselves.
    //
    // Verdicts:
    //   SAFE   — same champion, body mesh, bone count matches the live body
    //   RISKY  — same champion + body, but bone count differs (may render wrong)
    //   DANGER — different champion / prop / projectile / lobby / nogeo / fewer
    //            bones. These are the landmines. Blocked unless explicitly allowed.
    // ========================================================================
    enum SafetyLevel { SAFE_OK = 0, SAFE_RISKY, SAFE_DANGER };

    inline SafetyLevel ClassifySafety(int idx, int liveBodyBones, char* whyOut, int whyCap) {
        if (whyOut) whyOut[0] = '\0';
        if (idx < 0 || idx >= g_ResultCount) return SAFE_DANGER;
        const char* nm = g_Names[idx];
        int bones = g_BoneCounts[idx];
        MeshKind k = ClassifyMesh(nm);

        // Hard rejects — these are the ones that crash.
        if (HasCI(nm, "nogeo"))      { if (whyOut) lstrcpynA(whyOut, "nogeo = invisible", whyCap); return SAFE_DANGER; }
        if (HasCI(nm, "projectile")) { if (whyOut) lstrcpynA(whyOut, "projectile, not a body", whyCap); return SAFE_DANGER; }
        if (k == MK_Prop)            { if (whyOut) lstrcpynA(whyOut, "prop mesh", whyCap); return SAFE_DANGER; }
        if (HasCI(nm, "lobby"))      { if (whyOut) lstrcpynA(whyOut, "lobby preview mesh", whyCap); return SAFE_DANGER; }
        if (k != MK_Body)            { if (whyOut) lstrcpynA(whyOut, "not a body mesh", whyCap); return SAFE_DANGER; }

        // Champion family check — the single best landmine predictor.
        if (g_MyChampion[0] && !HasCI(nm, g_MyChampion)) {
            if (whyOut) wsprintfA(whyOut, "different champion (need %s)", g_MyChampion);
            return SAFE_DANGER;
        }
        if (bones <= 0) { if (whyOut) lstrcpynA(whyOut, "unreadable skeleton", whyCap); return SAFE_DANGER; }
        // A skeleton mismatch is RISKY, NOT blocked.
        //
        // I briefly made any mismatch DANGER after the "more bones always crashes"
        // report. That was wrong to enforce: it turned a swap that worked SOME of
        // the time into one that could never be attempted at all, which is worse.
        // Mismatches are flagged loudly and left clickable; the landmine cases
        // above (nogeo / projectile / prop / wrong champion) stay hard-blocked
        // because those never work.
        if (liveBodyBones > 0 && bones != liveBodyBones) {
            if (whyOut) wsprintfA(whyOut, "%d bones vs your %d - %s", bones, liveBodyBones,
                                  bones > liveBodyBones ? "may hard-crash" : "may crash/render wrong");
            return SAFE_RISKY;
        }
        if (whyOut) lstrcpynA(whyOut, "same champion, same skeleton", whyCap);
        return SAFE_OK;
    }

    // ========================================================================
    // *** MESHINFO SCANNER — THE CLEAN METHOD (no bone guessing) ***
    //
    // You were right that bone count is fragile. The game does NOT guess: it uses
    // an explicit structure, and here it is.
    //
    //   struct FLobbyMeshInfo {
    //       USkeletalMesh*             SkelMesh;           // +0x1C  the mesh
    //       FName                      AttachSocketName;   // +0x50  WHERE it goes
    //       TArray<UMaterialInterface*> MaterialOverrides; // +0x58  ITS materials
    //       ...
    //   };
    //   class UTgMenuMeshInfo {
    //       FLobbyMeshInfo             MeshInfo;  // +0x60
    //       TArray<UTgMenuMeshInfo*>   Children;  // +0xCC  arms / weapon / props
    //   };
    //
    // This is exactly what you asked for: "method A applies texture AND mesh at
    // once — map it out". The pairing is right here. A skin is ONE MeshInfo tree:
    // the root is the body, and each child is a part (arms, weapon) carrying its
    // OWN mesh, its OWN materials, and the socket it attaches to.
    //
    // So the correct segmentation is NOT bone count — it is tree position +
    // AttachSocketName. Bone count stays only as a last-resort crash guard.
    // ========================================================================
    inline const int MI_MESHINFO   = 0x60;
    inline const int MI_SKELMESH   = MI_MESHINFO + 0x1C;   // 0x7C
    inline const int MI_SOCKET     = MI_MESHINFO + 0x50;   // 0xB0
    inline const int MI_MATOVR     = MI_MESHINFO + 0x58;   // 0xB8
    inline const int MI_CHILDREN   = 0xCC;

    struct MeshInfoRow {
        SDK::UObject* node;        // the UTgMenuMeshInfo
        SDK::UObject* mesh;        // its SkelMesh
        char meshName[80];
        char socket[48];           // AttachSocketName ("" = root/body)
        int  matCount;
        int  depth;                // 0 = root (body), 1+ = child part
        int  bones;
    };
    inline MeshInfoRow g_MI[128];
    inline int  g_MICount = 0;
    inline char g_MIStatus[192] = "";

    inline SDK::UObject* MI_GetMesh(SDK::UObject* node) {
        __try { return *(SDK::UObject**)((char*)node + MI_SKELMESH); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    inline int MI_GetMatCount(SDK::UObject* node) {
        __try { return *(int*)((char*)node + MI_MATOVR + 8); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }
    inline SDK::UObject* MI_GetMat(SDK::UObject* node, int i) {
        __try {
            SDK::UObject** d = *(SDK::UObject***)((char*)node + MI_MATOVR);
            int n = *(int*)((char*)node + MI_MATOVR + 8);
            if (!d || i < 0 || i >= n) return nullptr;
            return d[i];
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    inline void MI_GetSocket(SDK::UObject* node, char* out, int cap) {
        out[0] = '\0';
        __try {
            SDK::FName* fn = (SDK::FName*)((char*)node + MI_SOCKET);
            auto& names = SDK::FName::GetGlobalNames();
            if (fn->Index <= 0 || !names.IsValidIndex((size_t)fn->Index)) return;
            SDK::FNameEntry* e = names[fn->Index];
            if (!e) return;
            const char* a = e->GetAnsiName();
            if (a) lstrcpynA(out, a, cap);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }
    inline int MI_ChildCount(SDK::UObject* node) {
        __try { return *(int*)((char*)node + MI_CHILDREN + 8); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }
    inline SDK::UObject* MI_Child(SDK::UObject* node, int i) {
        __try {
            SDK::UObject** d = *(SDK::UObject***)((char*)node + MI_CHILDREN);
            int n = *(int*)((char*)node + MI_CHILDREN + 8);
            if (!d || i < 0 || i >= n) return nullptr;
            return d[i];
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline void MI_AddRow(SDK::UObject* node, int depth) {
        if (g_MICount >= 128 || !node) return;
        MeshInfoRow& r = g_MI[g_MICount];
        r.node = node; r.depth = depth;
        r.mesh = MI_GetMesh(node);
        r.meshName[0] = '\0';
        if (r.mesh) TryCopyName(r.mesh, r.meshName, 80);
        MI_GetSocket(node, r.socket, 48);
        r.matCount = MI_GetMatCount(node);
        r.bones = r.mesh ? TryGetBoneCount((SDK::USkeletalMesh*)r.mesh) : -1;
        g_MICount++;
        int n = MI_ChildCount(node);
        if (n > 0 && n < 64 && depth < 4)
            for (int i = 0; i < n; ++i) MI_AddRow(MI_Child(node, i), depth + 1);
    }

    // Walk GObjects for MeshInfo trees.
    //
    // FIX: the first version only looked for standalone "TgMenuMeshInfo" objects
    // and found NONE, reporting an empty list with no explanation. They are not
    // standalone — they hang off the lobby loader actor:
    //     ATgSkeletalMeshActor_Loader::m_CurrentMeshInfo  @0x0344
    //     ATgSkeletalMeshActor_Loader::m_PendingMeshInfo  @0x033C
    // So we now find the LOADER actors and follow their pointers, and we ALSO
    // report what we saw, so an empty result still tells us something instead of
    // just "empty".
    inline void RunMeshInfoScan() {
        g_MICount = 0;
        auto& objects = SDK::UObject::GetGlobalObjects();
        size_t count = 0;
        __try { count = objects.Num(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
        if (!count || count > 4000000) { lstrcpynA(g_MIStatus, "GObjects unreadable", 190); return; }

        int loaders = 0, standalone = 0, roots = 0, lobbyActors = 0;
        for (size_t i = 0; i < count && g_MICount < 128; ++i) {
            SDK::UObject* o = TryObjAt(objects, i);
            if (!o) continue;
            char cls[80];
            if (!TryCopyClassName(o, cls, 80)) continue;
            char nm[80];
            if (TryCopyName(o, nm, 80) && _strnicmp(nm, "Default__", 9) == 0) continue;

            // (a) standalone MeshInfo objects, if any exist
            if (lstrcmpA(cls, "TgMenuMeshInfo") == 0) {
                standalone++;
                if (MI_GetMesh(o) || MI_ChildCount(o) > 0) { MI_AddRow(o, 0); roots++; }
                continue;
            }
            // (b) any lobby / loader actor — follow its MeshInfo pointers
            bool isLoader = (strstr(cls, "SkeletalMeshActor_Loader") != nullptr);
            bool isLobby  = (strstr(cls, "Lobby") != nullptr);
            if (isLoader || isLobby) {
                if (isLoader) loaders++; else lobbyActors++;
                if (isLoader) {
                    __try {
                        SDK::UObject* cur = *(SDK::UObject**)((char*)o + 0x0344); // m_CurrentMeshInfo
                        SDK::UObject* pend = *(SDK::UObject**)((char*)o + 0x033C); // m_PendingMeshInfo
                        if (cur)  { MI_AddRow(cur, 0);  roots++; }
                        if (pend && pend != cur) { MI_AddRow(pend, 0); roots++; }
                    }
                    __except (EXCEPTION_EXECUTE_HANDLER) {}
                }
            }
        }
        // Always report the counts — an empty list must still be informative.
        wsprintfA(g_MIStatus,
                  "MeshInfo: %d nodes | %d trees | loaders:%d lobbyActors:%d standaloneMeshInfo:%d%s",
                  g_MICount, roots, loaders, lobbyActors, standalone,
                  (g_MICount == 0)
                      ? "  <- none found: are you on a champion/skin screen with a model shown?"
                      : "");
    }

    // ========================================================================
    // TARGET RESOLVER — "80-90 bones = ARMS, ~200 = SKIN, ~30 = WEAPON".
    //
    // Your rule, made into code. Two independent signals, name first because it
    // is exact, bone count as the fallback for meshes whose name tells us nothing
    // (the "[?]" rows that were refused and looked greyed out):
    //
    //   NAME:  skl_pc_*_arms_*  -> arms      skl_wep_*_1p -> weapon 1P
    //          skl_pc_*         -> body      skl_wep_*_3p -> weapon 3P
    //   BONES: compare against the LIVE components we're wearing right now, and
    //          pick whichever is closest. Measured, not hardcoded, so it adapts
    //          per champion (Koga body 170, arms 89, wep3P 19; Maeve body 228,
    //          arms 84). Hardcoding 200/90/30 would misfire on Fernando (173) or
    //          Cassie (227).
    //
    // Order matters: ARMS is tested before WEAPON, because arms and 1P weapons
    // can share a bone count (both 89 on Koga) — the name breaks that tie.
    // ========================================================================
    enum SkinTarget { TGT_None = 0, TGT_Body, TGT_Arms, TGT_Weapon1P, TGT_Weapon3P };

    inline const char* TargetName(SkinTarget t) {
        switch (t) {
            case TGT_Body:     return "BODY";
            case TGT_Arms:     return "ARMS";
            case TGT_Weapon1P: return "WEP1P";
            case TGT_Weapon3P: return "WEP3P";
            default:           return "?";
        }
    }

    inline SkinTarget ResolveTarget(const char* nm, int bones,
                                    int bodyBones, int armsBones, int wepBones) {
        // 1) NAME — exact when present.
        switch (ClassifyMesh(nm)) {
            case MK_Arms:     return TGT_Arms;
            case MK_Weapon1P: return TGT_Weapon1P;
            case MK_Weapon3P: return TGT_Weapon3P;
            case MK_Body:     return TGT_Body;
            case MK_Prop:
            case MK_NoGeo:    return TGT_None;   // never wearable
            default: break;                       // MK_Other -> fall through
        }
        // 2) BONE COUNT — nearest live component wins. This is what rescues the
        // "[?]" rows that used to be refused with no explanation.
        if (bones <= 0) return TGT_None;
        auto diff = [](int a, int b) { int d = a - b; return d < 0 ? -d : d; };
        int best = -1; SkinTarget bestT = TGT_None;
        if (bodyBones > 0) { int d = diff(bones, bodyBones); if (best < 0 || d < best) { best = d; bestT = TGT_Body; } }
        if (armsBones > 0) { int d = diff(bones, armsBones); if (best < 0 || d < best) { best = d; bestT = TGT_Arms; } }
        if (wepBones  > 0) { int d = diff(bones, wepBones);  if (best < 0 || d < best) { best = d; bestT = TGT_Weapon3P; } }
        // Only trust the guess if it's genuinely close (within 15%), otherwise
        // refuse rather than risk the bone-index crash.
        if (bestT != TGT_None && best >= 0) {
            int ref = (bestT == TGT_Body) ? bodyBones : (bestT == TGT_Arms ? armsBones : wepBones);
            if (ref > 0 && best * 100 <= ref * 15) return bestT;
        }
        return TGT_None;
    }

    // ========================================================================
    // *** SKIN PACKAGE APPLY ***  — body + arms + weapon + materials, ATOMIC.
    //
    // Two real bugs this fixes, both diagnosed from live testing:
    //
    // 1. THE BLACK / NEON-BLUE "TEXTURE". That isn't a texture at all — it's NO
    //    texture. TryClearMaterialsRaw ran immediately on the RENDER thread, but
    //    ApplyMatchingMaterials ran later on the SAFE thread. In between (and
    //    forever, if the key never matched) the mesh had its overrides cleared
    //    with nothing put back. Fix: FIND the materials FIRST, and only clear if
    //    we actually have replacements to write. No match -> leave the mesh's own
    //    materials alone. Never strip without replacing.
    //
    // 2. "IT DOESN'T APPLY ONTO ARMS / NO WEAPON." A skin is FOUR meshes that
    //    share one skin key (skin09a): body, arms, weapon 1P, weapon 3P. Applying
    //    only the body leaves 1P hands and the gun on the old skin. This applies
    //    the whole set in one pass, each to its correct component.
    //
    // Everything here is raw pointer/field writes, which are render-thread safe,
    // so mesh and materials land in the SAME frame — no gap, no wrong texture.
    // ========================================================================
    inline int  g_PkgApplyIndex = -1;      // scan index of the BODY mesh to wear
    inline char g_PkgStatus[192] = "";
    inline bool g_PkgDoArms   = true;
    inline bool g_PkgDoWeapon = true;
    inline bool g_PkgDoMats   = true;

    inline bool g_AllowDangerPicks = false;   // never auto-enable this

    inline int ApplySkinPackage(SDK::APawn* pawn, int bodyIdx) {
        if (bodyIdx < 0 || bodyIdx >= g_ResultCount) return 0;
        SDK::USkeletalMeshComponent* mc = TryGetMeshComp(pawn);
        SDK::ATgWeaponMeshActor*     wa = TryGetWeaponActor(pawn);
        if (!mc) return 0;

        // LANDMINE GUARD — refuse DANGER picks outright. This is the check that
        // stops the i>=0 && i<ArrayNum crash before it happens, rather than
        // relying on bone count alone (which demonstrably still crashed).
        {
            // Baseline, not live — see g_OriginalBones. Using the live mesh here
            // made every swap-after-a-swap compare against the wrong skeleton.
            int liveBones = (g_OriginalBones > 0) ? g_OriginalBones
                                                  : TryGetBoneCount(TryGetMesh(mc));
            char why[96];
            SafetyLevel lvl = ClassifySafety(bodyIdx, liveBones, why, 96);
            if (lvl == SAFE_DANGER && !g_AllowDangerPicks) {
                wsprintfA(g_PkgStatus, "BLOCKED '%s': %s", g_Names[bodyIdx], why);
                lstrcpynA(g_Status, g_PkgStatus, 160);
                return 0;
            }
        }

        const char* bodyName = g_Names[bodyIdx];
        char key[16]; SkinKey(bodyName, key, 16);
        int done = 0;
        int armsN = 0, wep1 = 0, wep3 = 0, matsB = 0, matsW = 0, matsA = 0;

        // ---- 1. BODY MESH (with the bone guard) ----
        SDK::USkeletalMesh* body = (SDK::USkeletalMesh*)g_Objects[bodyIdx];
        int tgtB = TryGetBoneCount(body);
        // Compare against the SPAWN skeleton, never the live one. The old check
        // used the live mesh and only blocked FEWER bones; both were wrong.
        // More bones overruns the component's bone arrays, which is the hard
        // crash. Fewer renders wrong and can still fault. The only reliably safe
        // swap is an exact skeleton match, so that is what we require.
        int baseB = (g_OriginalBones > 0) ? g_OriginalBones : TryGetBoneCount(TryGetMesh(mc));
        // Warn on a skeleton mismatch, do not refuse. Blocking these outright
        // removed swaps that did sometimes work. The baseline comparison is still
        // the right one to REPORT (the live mesh drifts after each swap), it just
        // isn't grounds to stop you trying.
        if (tgtB > 0 && baseB > 0 && tgtB != baseB)
            wsprintfA(g_PkgStatus, "WARN '%s': %d bones vs spawn skeleton %d - may crash.",
                      bodyName, tgtB, baseB);
        if (TrySetMeshRaw(mc, body)) done++;

        // ---- 2. MATCHING MESHES by skin key: arms, weapon 1P, weapon 3P ----
        if (key[0] && wa) {
            for (int i = 0; i < g_ResultCount; ++i) {
                char k2[16]; SkinKey(g_Names[i], k2, 16);
                if (k2[0] == '\0' || lstrcmpA(key, k2) != 0) continue;
                MeshKind mk = ClassifyMesh(g_Names[i]);
                SDK::USkeletalMesh* m = (SDK::USkeletalMesh*)g_Objects[i];
                if (mk == MK_Arms && g_PkgDoArms) {
                    if (TrySetArmsMesh(wa, m)) { armsN++; done++; }
                } else if (mk == MK_Weapon1P && g_PkgDoWeapon) {
                    if (TrySetWeaponMesh(wa, m, true, false)) { wep1++; done++; }
                } else if (mk == MK_Weapon3P && g_PkgDoWeapon) {
                    if (TrySetWeaponMesh(wa, m, false, true)) { wep3++; done++; }
                }
            }
        }

        // ---- 3. MATERIALS — gather FIRST, only then clear + write ----
        if (g_PkgDoMats && key[0]) {
            // Body materials for this exact skin key.
            SDK::UObject* bodyMats[16]; int nb = 0;
            const char* passes[3] = { "id1", "id2", nullptr };
            for (int pass = 0; pass < 3 && nb < 16; ++pass) {
                for (int i = 0; i < g_MatCount && nb < 16; ++i) {
                    char k2[16]; SkinKey(g_MatNames[i], k2, 16);
                    if (lstrcmpA(key, k2) != 0) continue;
                    if (!IsBodyMaterial(g_MatNames[i])) continue;
                    bool h1 = HasCI(g_MatNames[i], "id1");
                    bool h2 = HasCI(g_MatNames[i], "id2");
                    if (pass == 0 && !h1) continue;
                    if (pass == 1 && !h2) continue;
                    if (pass == 2 && (h1 || h2)) continue;
                    bodyMats[nb++] = g_MatObjects[i];
                }
            }
            // ONLY clear when we have something to put back. This is the fix for
            // the black/neon-blue "texture" — stripping with no replacement.
            if (nb > 0) {
                TryClearMaterialsRaw(mc);
                for (int s = 0; s < nb; ++s) {
                    if (TrySetBodyMaterial(pawn, s, (SDK::UMaterialInterface*)bodyMats[s]))
                        matsB++;
                }
            }

            // Weapon materials for the same key.
            SDK::UObject* wepMats[8]; int nw = 0;
            for (int i = 0; i < g_MatCount && nw < 8; ++i) {
                char k2[16]; SkinKey(g_MatNames[i], k2, 16);
                if (lstrcmpA(key, k2) != 0) continue;
                if (!IsWeaponMaterial(g_MatNames[i])) continue;
                wepMats[nw++] = g_MatObjects[i];
            }
            if (nw > 0) {
                for (int s = 0; s < nw; ++s) {
                    if (TrySetWeaponMaterial(pawn, s, (SDK::UMaterialInterface*)wepMats[s]))
                        matsW++;
                }
            }

            // ARMS materials — the third category. Without this the hands kept
            // the previous skin's textures even when the arms MESH swapped.
            for (int i = 0; i < g_MatCount && matsA < 8; ++i) {
                char k2[16]; SkinKey(g_MatNames[i], k2, 16);
                if (lstrcmpA(key, k2) != 0) continue;
                if (!IsArmsMaterial(g_MatNames[i])) continue;
                if (TrySetArmsMaterial(pawn, matsA, (SDK::UMaterialInterface*)g_MatObjects[i]))
                    matsA++;
            }
        }

        wsprintfA(g_PkgStatus,
                  "PKG '%s' key=%s -> body:1 arms:%d wep1p:%d wep3p:%d | mats body:%d arms:%d wep:%d",
                  bodyName, key[0] ? key : "?", armsN, wep1, wep3, matsB, matsA, matsW);
        lstrcpynA(g_Status, g_PkgStatus, 160);
        // Remember it so persistence can re-apply the whole package.
        lstrcpynA(g_LastAppliedBodyName, bodyName, 96);
        return done;
    }

    // ========================================================================
    // r_nSkinId WATCHER + PER-FRAME HOLD
    //
    // The question we have never actually measured: in a real match, after
    // Method A, does r_nSkinId HOLD our value or get reverted?
    //
    // It matters enormously, because the two cases need opposite fixes:
    //   HOLDS   -> the write is fine, the MESH REBUILD is what fails. Stop
    //              fighting the server; work on making the rebuild run.
    //   REVERTS -> the server is overwriting us. Then we must win the race,
    //              which is what the per-frame hold below is for.
    //
    // Evidence it may HOLD: with Method A in a real match you get the new skin's
    // ult FX and one-liners. Those read r_nSkinId LIVE at the moment of use. The
    // body mesh is built ONCE at spawn. FX changing while the body does not is
    // the signature of "write landed, rebuild didn't".
    //
    // The hold writes the raw field every frame (render thread, plain int write,
    // no scripted call). Persistence elsewhere runs at 1200ms, which loses to a
    // ~30Hz replication tick; per-frame does not.
    // ========================================================================
    inline bool g_WatchSkinId   = true;    // sample r_nSkinId every frame
    inline bool g_HoldSkinId    = false;   // and force it back every frame
    inline int  g_HoldSkinValue = 0;
    inline int  g_LiveSkinNow   = -1;
    inline int  g_SkinRevertCount = 0;     // how often it changed under us
    inline int  g_LastSeenSkin  = -1;

    inline int TryReadPawnSkinId(SDK::APawn* p) {
        __try {
            if (!p) return -1;
            return *(int*)((char*)p + 0x2828);   // ATgPawn::r_nSkinId
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }
    inline bool TryWritePawnSkinId(SDK::APawn* p, int v) {
        __try {
            if (!p) return false;
            *(int*)((char*)p + 0x2828) = v;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Raw-write path — safe from the render thread.
    inline void Update() {
        SDK::APawn* pawn = Globals::LocalPawn;
        if (!pawn) { g_BasePawn = nullptr; g_OriginalMesh = nullptr; g_OriginalBones = -1;
                     g_OriginalWeaponBones = -1; return; }

        // WATCH / HOLD r_nSkinId — runs first, every frame, before anything else.
        if (g_WatchSkinId) {
            int now = TryReadPawnSkinId(pawn);
            if (now != g_LastSeenSkin) {
                // Count a revert only when it moves AWAY from what we're holding.
                if (g_HoldSkinValue > 0 && g_LastSeenSkin == g_HoldSkinValue &&
                    now != g_HoldSkinValue) {
                    g_SkinRevertCount++;
                }
                g_LastSeenSkin = now;
            }
            g_LiveSkinNow = now;
        }
        if (g_HoldSkinId && g_HoldSkinValue > 0) {
            TryWritePawnSkinId(pawn, g_HoldSkinValue);
        }

        // A successful load-and-wear (on the safe thread) asks for a rescan; do it
        // here on the render thread where RunScan runs. This repopulates the list.
        if (g_WantRescanAfterWear) {
            g_WantRescanAfterWear = false;
            RunScan();
        }

        // SCAN WHEN SOMETHING CHANGES, NOT ON A TIMER.
        //
        // A timer was the wrong shape. The set of loaded skin assets only changes
        // when the GAME loads or unloads them - you preview skins in champion
        // select, or you switch champion. It does not drift second to second
        // while you stand in the range. Re-walking 200k objects every second to
        // watch for a change that is not happening is pure waste, and it is what
        // caused the stutter.
        //
        // So: scan once when the tab opens, and again when the pawn changes.
        // That covers every case that can actually alter the list.
        {
            static bool  s_TabWasOpen = false;
            static void* s_ScanPawn   = nullptr;

            bool tabJustOpened = (g_SkinsTabOpen && !s_TabWasOpen);
            s_TabWasOpen = g_SkinsTabOpen;

            // SPAWNING IS THE EVENT THAT MATTERS.
            //
            // A new pawn means you just spawned into a match or the range, and
            // that is exactly when the skin assets for this champion are in
            // memory and the list should already be built - BEFORE you open the
            // tab, so it is just there waiting when you do.
            //
            // This deliberately does NOT require the tab to be open. It is one
            // walk per spawn, not one per second, so it costs nothing measurable.
            bool pawnChanged = (Globals::LocalPawn && Globals::LocalPawn != s_ScanPawn);

            if (pawnChanged || tabJustOpened) {
                s_ScanPawn = (void*)Globals::LocalPawn;
                SafeRunScan();
            }

            // Optional safety net for the one case events cannot catch: assets
            // being garbage-collected out from under a list you are looking at.
            // Off by default, and even on it only ticks while the tab is open.
            // Potato mode kills the continuous rescan. The event-driven scans
            // (on spawn, on tab open) still run - those are one-offs, not a
            // timer, so they are not what causes a repeating hitch.
            if (g_ContinuousScan && g_SkinsTabOpen && Perf::AllowBackgroundScan()) {
                ULONGLONG now = GetTickCount64();
                if (now - g_LastAutoScanMs > 3000) {
                    g_LastAutoScanMs = now;
                    SafeRunScan();
                }
            }
        }

        // GLOBAL GC-BEATER: every second, pin every skin asset in memory so
        // anything you preview NEVER gets garbage-collected. This is the core
        // fix — a mesh loaded in the menu now survives into the match, so
        // Method A always has something to render instead of going invisible.
        if (g_GlobalKeepAlive) {
            ULONGLONG now = GetTickCount64();
            if (now - g_LastGlobalKeepMs > 1000) {
                g_LastGlobalKeepMs = now;
                RunGlobalKeepAlive();
            }
        }

        // PERSISTENCE — your "it clears back to default" fix. Every interval, find
        // the body mesh whose skin key matches the one we're holding and re-apply
        // it (mesh + materials). This overrides the server/game resetting the skin.
        if (g_PersistEnabled && g_PersistKey[0]) {
            ULONGLONG now = GetTickCount64();
            if (now - g_LastPersistMs > (ULONGLONG)g_PersistIntervalMs) {
                g_LastPersistMs = now;
                for (int i = 0; i < g_ResultCount; ++i) {
                    if (ClassifyMesh(g_Names[i]) != MK_Body) continue;
                    if (HasCI(g_Names[i], "lobby")) continue;
                    char k[16]; SkinKey(g_Names[i], k, 16);
                    if (k[0] && lstrcmpA(k, g_PersistKey) == 0) {
                        g_SelectedIndex = i;
                        g_PendingApply = true;   // reuses the full apply path below
                        break;
                    }
                }
            }
        }

        SDK::USkeletalMeshComponent* mc = TryGetMeshComp(pawn);
        if (!mc) return;

        // Capture the genuine mesh once per pawn, so Restore can't write another
        // champion's mesh after a respawn or champion change.
        if (pawn != g_BasePawn) {
            g_BasePawn = pawn;
            g_OriginalMesh = TryGetMesh(mc);
            g_OriginalBones = TryGetBoneCount(g_OriginalMesh);
            {
                SDK::ATgWeaponMeshActor* wa0 = TryGetWeaponActor(pawn);
                g_OriginalWeaponBones = -1;
                if (wa0) {
                    __try {
                        SDK::USkeletalMeshComponent* wc =
                            (SDK::USkeletalMeshComponent*)(wa0->m_WeaponMesh3P ? wa0->m_WeaponMesh3P
                                                                              : wa0->m_WeaponMesh1P);
                        if (wc) g_OriginalWeaponBones = TryGetBoneCount(wc->SkeletalMesh);
                    }
                    __except (EXCEPTION_EXECUTE_HANDLER) { g_OriginalWeaponBones = -1; }
                }
            }
            TryCopyName((SDK::UObject*)g_OriginalMesh, g_OriginalName, 80);

            // Champion name. PREFER the live body mesh's own name (the real asset
            // name, e.g. "maeve"), and only fall back to the pawn class codename
            // ("Blades") if the mesh isn't readable yet. This is the Maeve fix:
            // filtering by the class name hid every one of her meshes.
            char fromMesh[48] = {};
            if (g_OriginalName[0] && ExtractChampFromMeshName(g_OriginalName, fromMesh, 48)
                && fromMesh[0]) {
                lstrcpynA(g_MyChampion, fromMesh, 48);
            } else {
                char cls[80] = {};
                if (TryCopyClassName(pawn, cls, 80)) {
                    const char* src = cls;
                    if (_strnicmp(cls, "TgPawn_", 7) == 0) src = cls + 7;
                    // Translate the codename to the ASSET name ("Blades"->"maeve"),
                    // or the filter matches none of this champion's meshes.
                    lstrcpynA(g_MyChampion, AliasToAssetName(src), 48);
                }
            }
            g_AllSkinsCount = TryCountAllSkins(pawn);

            // RESPAWN RE-APPLY. A new pawn means the old one (and its override
            // materials) was destroyed — that is why weapon/arms textures had to
            // be re-clicked after every death. Queue them again automatically.
            // Re-resolve BY NAME. If the material was collected while we were dead,
            // the lookup fails and we skip it — instead of applying a dangling
            // pointer and crashing inside garbage collection.
            if (g_ReapplyMatsOnRespawn) {
                int wi = FindMatIndexByName(g_LastWeaponMatName);
                if (wi >= 0) g_PendingWeaponMat = wi;
                int ai = FindMatIndexByName(g_LastArmsMatName);
                if (ai >= 0) g_PendingArmsMat = ai;
            }
        }

        // Re-apply chosen materials on a timer, not just on respawn. Cheap: it
        // only queues indices, and the actual SetMaterial happens on the safe
        // thread in ProcessPending() like every other material write.
        if (g_PersistMats) {
            g_PersistMatTimer += 0.016f;
            if (g_PersistMatTimer >= (g_PersistMatSecs < 0.25f ? 0.25f : g_PersistMatSecs)) {
                g_PersistMatTimer = 0.0f;
                if (g_PendingWeaponMat < 0 && g_LastWeaponMatName[0]) {
                    int wi = FindMatIndexByName(g_LastWeaponMatName);
                    if (wi >= 0) g_PendingWeaponMat = wi;
                }
                if (g_PendingArmsMat < 0 && g_LastArmsMatName[0]) {
                    int ai = FindMatIndexByName(g_LastArmsMatName);
                    if (ai >= 0) g_PendingArmsMat = ai;
                }
                if (g_PendingManualMat < 0 && g_LastBodyMatName[0]) {
                    int bi = FindMatIndexByName(g_LastBodyMatName);
                    if (bi >= 0) g_PendingManualMat = bi;
                }
            }
        }

        SDK::USkeletalMesh* live = TryGetMesh(mc);
        TryCopyName((SDK::UObject*)live, g_LiveName, 80);

        // Also track the live WEAPON mesh name, so weapon skins can be constructed
        // by number the same way body skins are.
        {
            SDK::ATgWeaponMeshActor* wa = TryGetWeaponActor(pawn);
            if (wa) {
                __try {
                    if (wa->m_WeaponMesh3P) {
                        SDK::USkeletalMesh* wm =
                            ((SDK::USkeletalMeshComponent*)wa->m_WeaponMesh3P)->SkeletalMesh;
                        TryCopyName((SDK::UObject*)wm, g_WeaponLiveName, 80);
                        // Learn the weapon's asset family so scans can find its
                        // textures/meshes (they aren't named after the champion).
                        ExtractWeaponFamily(g_WeaponLiveName, g_WeaponFamily, 48);
                    }
                }
                __except (EXCEPTION_EXECUTE_HANDLER) {}
            }
        }

        // NOTE: the load-and-wear handler is NOT here. FetchMeshByName goes
        // through ProcessEvent (DynamicLoadObject), which must run on the safe
        // thread — so it lives in ProcessPending() below, not in this render-thread
        // Update(). Doing it here is the classic threading violation that corrupts
        // object state.

        if (g_PendingRestore) {
            g_PendingRestore = false;
            if (g_OriginalMesh && TrySetMeshRaw(mc, g_OriginalMesh)) {
                lstrcpynA(g_Status, "Restored your real mesh.", 160);
            }
            return;
        }

        // SMART ROUTER — your "sense what it goes on" idea. Read the target mesh's
        // bone count and match it to the component with the SAME bone count:
        //   matches the body skeleton -> put it on the body
        //   matches the weapon skeleton -> put it on the WEAPON (this is how we
        //     finally get weapon-mesh swaps that don't crash)
        //   matches neither -> it's a prop/foreign mesh, refuse it
        // No name guessing, no landmines — pure measurement.
        if (g_PendingSmartIndex >= 0 && g_PendingSmartIndex < g_ResultCount) {
            int idx = g_PendingSmartIndex;
            g_PendingSmartIndex = -1;
            SDK::USkeletalMesh* target = (SDK::USkeletalMesh*)g_Objects[idx];
            int tgtBones = TryGetBoneCount(target);

            SDK::USkeletalMesh* liveBody = TryGetMesh(mc);
            int bodyBones = TryGetBoneCount(liveBody);

            SDK::ATgWeaponMeshActor* wa = TryGetWeaponActor(pawn);
            int wepBones = -1;
            SDK::USkeletalMesh* liveWep = nullptr;
            __try {
                if (wa && wa->m_WeaponMesh3P)
                    liveWep = ((SDK::USkeletalMeshComponent*)wa->m_WeaponMesh3P)->SkeletalMesh;
            } __except (EXCEPTION_EXECUTE_HANDLER) {}
            wepBones = TryGetBoneCount(liveWep);
            int armsBones = TryGetArmsBoneCount(wa);

            // Decide the target ONCE, by name then bone count. Previously each
            // branch re-guessed, so anything the name didn't cover (the "[?]"
            // rows) fell through to "refused" with no route at all.
            SkinTarget tgt = ResolveTarget(g_Names[idx], tgtBones,
                                           bodyBones, armsBones, wepBones);

            if (tgtBones <= 0) {
                wsprintfA(g_SmartStatus, "'%s' has no readable skeleton - skipped.", g_Names[idx]);
            } else if (tgt == TGT_Arms && wa) {
                if (TrySetArmsMesh(wa, target))
                    wsprintfA(g_SmartStatus, "ARMS: '%s' (%d bones, arms=%d) -> 1P hands.",
                              g_Names[idx], tgtBones, armsBones);
                else
                    wsprintfA(g_SmartStatus, "ARMS '%s': no hands component.", g_Names[idx]);
            } else if ((tgt == TGT_Weapon1P || tgt == TGT_Weapon3P) && wa) {
                bool do1 = (tgt == TGT_Weapon1P);
                if (TrySetWeaponMesh(wa, target, do1, !do1))
                    wsprintfA(g_SmartStatus, "WEAPON: '%s' (%d bones) -> gun %s.",
                              g_Names[idx], tgtBones, do1 ? "1P" : "3P");
                else
                    wsprintfA(g_SmartStatus, "WEAPON '%s': no weapon component.", g_Names[idx]);
            } else if (tgt == TGT_Body) {
                // Route the BODY case through the full package so the matching
                // arms, weapon and MATERIALS land in the same frame. Smart mesh
                // used to swap the body only and defer textures to the safe
                // thread — that gap is what left the wrong/blank texture.
                // Body goes through the full package so arms, weapon and MATERIALS
                // land in the same frame (the deferred-material gap was what left
                // the wrong/blank texture).
                if (ApplySkinPackage(pawn, idx) > 0) {
                    lstrcpynA(g_LastAppliedBodyName, g_Names[idx], 96);
                    wsprintfA(g_SmartStatus, "BODY: '%s' (%d bones) -> body + package.",
                              g_Names[idx], tgtBones);
                }
            } else {
                // Now says WHY, and what the live parts measure, instead of a bare
                // "refused" that made valid-looking rows seem broken.
                wsprintfA(g_SmartStatus,
                    "'%s' %d bones - no match (live body=%d arms=%d wep=%d). Refused to avoid a crash.",
                    g_Names[idx], tgtBones, bodyBones, armsBones, wepBones);
            }
            lstrcpynA(g_Status, g_SmartStatus, 160);
            return;
        }

        // SKIN PACKAGE: body + arms + weapon + materials, all in this one frame.
        if (g_PkgApplyIndex >= 0) {
            int idx = g_PkgApplyIndex;
            g_PkgApplyIndex = -1;
            ApplySkinPackage(pawn, idx);
            return;
        }

        if (g_PendingApply) {
            g_PendingApply = false;
            if (g_SelectedIndex >= 0 && g_SelectedIndex < g_ResultCount) {
                const char* nm = g_Names[g_SelectedIndex];
                MeshKind kind = ClassifyMesh(nm);

                // CRASH GUARD, now driven by real classification instead of
                // guessing. ONLY a body mesh may go on the body component — a
                // prop/arms/weapon mesh has a different bone count and triggers the
                // i>=0 && i<ArrayNum assertion. This is what stops the crashes.
                bool sameChamp = (g_MyChampion[0] == '\0') || HasCI(nm, g_MyChampion);
                if (!allowCrossChampion && (kind != MK_Body || !sameChamp)) {
                    wsprintfA(g_Status,
                        "BLOCKED '%s': only same-champion BODY meshes are safe on the body.", nm);
                    return;
                }

                // Apply the BODY mesh.
                SDK::USkeletalMesh* target = (SDK::USkeletalMesh*)g_Objects[g_SelectedIndex];

                // LANDMINE CRASH PROTECTION (your hypothesis, confirmed). The
                // crashes are meshes with a DIFFERENT bone count than the body's
                // skeleton — weapon/prop meshes forced onto the body. Compare bone
                // counts by MEASUREMENT and refuse a mismatch, instead of trusting
                // the name. This is what stops the i>=0 && i<ArrayNum crashes for
                // real (a mesh that lies about its type still gets caught here).
                SDK::USkeletalMesh* liveNow = TryGetMesh(mc);
                int curBones = TryGetBoneCount(liveNow);
                int tgtBones = TryGetBoneCount(target);
                // REFINED LANDMINE GUARD. The crash (i>=0 && i<ArrayNum) happens
                // only when the target has FEWER bones than the live skeleton — the
                // anim tree then indexes past the end. A body skin with EQUAL or MORE
                // bones (extra hair/accessory bones) is safe: the base indices still
                // resolve. The old exact-match (!=) was false-rejecting those legit
                // skins — that's the "30% won't apply". Now: block only tgtBones <
                // curBones (the real crash), which frees the wrongly-blocked skins
                // and still catches weapon/prop meshes (far fewer bones).
                if (!allowCrossChampion && curBones > 0 && tgtBones > 0 &&
                    tgtBones < curBones) {
                    wsprintfA(g_Status,
                        "BLOCKED '%s': %d bones < body %d (fewer bones = crash). Skipped.",
                        nm, tgtBones, curBones);
                    return;
                }

                bool bodyOk = TrySetMeshRaw(mc, target);
                g_LastWeaponPaired = false;

                // TEXTURE FIX — the whole point of this pass. Clear the override
                // materials so the new skin uses ITS OWN textures instead of the
                // old skin's (your "Invader Pip wrong colours"). g_AutoFixTextures
                // lets you A/B it. Also record the mesh's own material count so we
                // know whether it has its own materials to fall back to.
                g_TargetOwnMatCount = TryMeshOwnMaterialCount(target);
                if (g_AutoFixTextures) TryClearMaterialsRaw(mc);
                // Remember which body skin we put on, so the safe-thread handler
                // can find and apply the MATCHING skin materials (the real fix).
                lstrcpynA(g_LastAppliedBodyName, nm, 96);
                g_PendingClearMats = true;

                // GROUPED APPLY: find the weapon mesh with the SAME skin key
                // (e.g. skin07a) and apply it to the weapon component too. OFF by
                // default now — the weapon swap never rendered right and often blew
                // the body invisible, so it's opt-in via g_SwapWeaponOnApply.
                char key[16];
                SkinKey(nm, key, 16);
                if (key[0] && g_SwapWeaponOnApply) {
                    for (int i = 0; i < g_ResultCount; ++i) {
                        if (ClassifyMesh(g_Names[i]) != MK_Weapon3P) continue;
                        char k2[16];
                        SkinKey(g_Names[i], k2, 16);
                        if (lstrcmpA(key, k2) != 0) continue;
                        SDK::ATgWeaponMeshActor* wa = TryGetWeaponActor(pawn);
                        if (wa) {
                            // Also grab the matching 1P weapon if present.
                            SDK::USkeletalMesh* w3 = (SDK::USkeletalMesh*)g_Objects[i];
                            TrySetWeaponMesh(wa, w3, false, true);
                            for (int j = 0; j < g_ResultCount; ++j) {
                                if (ClassifyMesh(g_Names[j]) != MK_Weapon1P) continue;
                                char k3[16]; SkinKey(g_Names[j], k3, 16);
                                if (lstrcmpA(key, k3) == 0) {
                                    TrySetWeaponMesh(wa, (SDK::USkeletalMesh*)g_Objects[j], true, false);
                                    break;
                                }
                            }
                            // Clear the weapon components' materials too, same reason.
                            __try {
                                if (g_AutoFixTextures) {
                                    if (wa->m_WeaponMesh3P)
                                        ZeroTArrayCount(&((SDK::USkeletalMeshComponent*)wa->m_WeaponMesh3P)->Materials);
                                    if (wa->m_WeaponMesh1P)
                                        ZeroTArrayCount(&((SDK::USkeletalMeshComponent*)wa->m_WeaponMesh1P)->Materials);
                                }
                            } __except (EXCEPTION_EXECUTE_HANDLER) {}
                            g_LastWeaponPaired = true;
                        }
                        break;
                    }
                }

                if (bodyOk) {
                    g_ApplyCount++;
                    wsprintfA(g_Status, "Applied body '%s'%s", nm,
                              g_LastWeaponPaired ? " + matching weapon" : " (no matching weapon found)");
                } else {
                    lstrcpynA(g_Status, "Body mesh write faulted.", 160);
                }
            }
        }

        // Weapon-only apply (from the weapon list), independent of the body.
        if (g_PendingWeaponApply) {
            g_PendingWeaponApply = false;
            if (g_SelWeaponIndex >= 0 && g_SelWeaponIndex < g_ResultCount) {
                SDK::ATgWeaponMeshActor* wa = TryGetWeaponActor(pawn);
                const char* nm = g_Names[g_SelWeaponIndex];
                MeshKind kind = ClassifyMesh(nm);
                // Same-champion guard: a different champion's weapon (e.g. a Maeve
                // projectile while you're Pip) has a different skeleton and is what
                // threw the i<ArrayNum crash. Block it unless explicitly overridden.
                // Weapon assets carry the WEAPON family name, not the champion's
                // (skl_wep_blades_* for Maeve, skl_wep_potionlauncher_* for Pip),
                // so accept either. Without this every legitimate gun mesh was
                // rejected as "not your champion".
                bool sameChamp = (g_MyChampion[0] == '\0') || HasCI(nm, g_MyChampion)
                                 || (g_WeaponFamily[0] && HasCI(nm, g_WeaponFamily));
                if (!allowCrossChampion && !sameChamp) {
                    wsprintfA(g_Status, "BLOCKED weapon '%s' - not your champion or weapon family.", nm);
                } else
                if (wa && (kind == MK_Weapon1P || kind == MK_Weapon3P)) {
                    SDK::USkeletalMesh* m = (SDK::USkeletalMesh*)g_Objects[g_SelWeaponIndex];
                    // WEAPON BONE GUARD — this path had NO bone check, which is why
                    // clicking 'skl_wep_blades_projectile_00a' (1 bone) crashed with
                    // i>=0 && i<ArrayNum. A projectile/prop mesh is not a gun. Compare
                    // against the matching component's current skeleton and refuse a
                    // mesh with FEWER bones (the real crash condition).
                    int tgt = TryGetBoneCount(m);
                    // Compare against the SPAWN weapon skeleton. Reading the live one
                    // drifts after the first swap, so a second swap compared against
                    // the wrong number and let a mismatch through.
                    int cur = g_OriginalWeaponBones;
                    if (cur <= 0) {
                        __try {
                            SDK::UTgSkeletalMeshComponent_Weapon* wc =
                                (kind == MK_Weapon1P) ? wa->m_WeaponMesh1P : wa->m_WeaponMesh3P;
                            if (wc) {
                                SDK::USkeletalMesh* cm =
                                    ((SDK::USkeletalMeshComponent*)wc)->SkeletalMesh;
                                if (cm) cur = (int)cm->RefSkeleton.Num();
                            }
                        } __except (EXCEPTION_EXECUTE_HANDLER) { cur = -1; }
                    }

                    if (HasCI(nm, "projectile")) {
                        wsprintfA(g_Status,
                            "BLOCKED '%s': projectile mesh, not a gun (would crash).", nm);
                    } else {
                        bool ok = TrySetWeaponMesh(wa, m, kind == MK_Weapon1P, kind == MK_Weapon3P);
                        if (!ok)
                            wsprintfA(g_Status, "Weapon set faulted: %s", nm);
                        else if (tgt > 0 && cur > 0 && tgt != cur)
                            wsprintfA(g_Status, "Weapon mesh set: %s (%d bones vs spawn %d - may crash)", nm, tgt, cur);
                        else
                            wsprintfA(g_Status, "Weapon mesh set: %s (%d bones)", nm, tgt);
                    }
                } else {
                    lstrcpynA(g_Status, "That isn't a weapon mesh.", 160);
                }
            }
        }

        // Hide/show the 3P weapon (fixes 'weapon visible again in third person').
        if (g_PendingHide3PWeapon) {
            g_PendingHide3PWeapon = false;
            SDK::ATgWeaponMeshActor* wa = TryGetWeaponActor(pawn);
            if (wa && TryHide3PWeapon(wa, g_Hide3PWeaponState)) {
                lstrcpynA(g_Status, g_Hide3PWeaponState ? "3P weapon hidden." : "3P weapon shown.", 160);
            }
        }
    }

    // SAFE-THREAD work. Only load-and-wear lives here, because FetchMeshByName
    // calls DynamicLoadObject through ProcessEvent, which is illegal from the
    // render thread. Everything else in this file is raw memory and stays in
    // Update().
    inline void ProcessPending() {
        SDK::APawn* wpawn = Globals::LocalPawn;

        // PRIMARY method: SetDefaultSkin variant. Scripted, so it lives here on the
        // safe thread. This is the one that swaps skin correctly (no strings, no
        // wrong textures).
        if (g_PendingVariant >= 0 && wpawn) {
            int idx = g_PendingVariant;
            g_PendingVariant = -1;
            bool b = TrySetDefaultSkinBody(wpawn, idx);
            bool w = g_VariantWeaponToo ? TrySetDefaultSkinWeapon(wpawn, idx) : false;
            g_LastVariant = idx;
            wsprintfA(g_VariantStatus, "Variant %d -> body:%s weapon:%s",
                      idx, b ? "ok" : "no", w ? "ok" : (g_VariantWeaponToo ? "no" : "off"));
        }

        // Manual material assignment: put the picked material on the chosen slot.
        if (g_PendingManualMat >= 0 && wpawn) {
            int mi = g_PendingManualMat;
            g_PendingManualMat = -1;
            if (mi < g_MatCount) {
                bool ok = TrySetBodyMaterial(wpawn, g_MatSlot,
                                             (SDK::UMaterialInterface*)g_MatObjects[mi]);
                // Remember it BY NAME (GC-safe, same as weapon and arms) so the
                // persistence pass can put it back instead of letting something
                // else overwrite your pick.
                if (ok) lstrcpynA(g_LastBodyMatName, g_MatNames[mi], 96);
                wsprintfA(g_VariantStatus, "%s BODY material '%s' -> slot %d",
                          ok ? "Set" : "Failed", g_MatNames[mi], g_MatSlot);
            }
        }

        // WEAPON material — goes on the gun, not the body. This is the separation
        // you asked for: click a weapon texture, it lands on the weapon.
        if (g_PendingWeaponMat >= 0 && wpawn) {
            int mi = g_PendingWeaponMat;
            g_PendingWeaponMat = -1;
            if (mi < g_MatCount) {
                bool ok = TrySetWeaponMaterial(wpawn, g_MatSlot,
                                               (SDK::UMaterialInterface*)g_MatObjects[mi]);
                if (ok) lstrcpynA(g_LastWeaponMatName, g_MatNames[mi], 96);  // by NAME (GC-safe)
                wsprintfA(g_VariantStatus, "%s WEAPON material '%s' -> slot %d",
                          ok ? "Set" : "Failed", g_MatNames[mi], g_MatSlot);
            }
        }

        // ARMS material -> m_HandsMesh (first-person hands). Separate target from
        // both body and weapon, which is why arms textures never landed before.
        if (g_PendingArmsMat >= 0 && wpawn) {
            int mi = g_PendingArmsMat;
            g_PendingArmsMat = -1;
            if (mi < g_MatCount) {
                bool ok = TrySetArmsMaterial(wpawn, g_ArmsMatSlot,
                                             (SDK::UMaterialInterface*)g_MatObjects[mi]);
                if (ok) lstrcpynA(g_LastArmsMatName, g_MatNames[mi], 96);   // by NAME (GC-safe)
                wsprintfA(g_VariantStatus, "%s ARMS material '%s' -> slot %d",
                          ok ? "Set" : "Failed", g_MatNames[mi], g_ArmsMatSlot);
                lstrcpynA(g_Status, g_VariantStatus, 160);
            }
        }

        if (g_PendingClearMats && wpawn) {
            g_PendingClearMats = false;
            // THE REAL TEXTURE FIX. Your test proved ForceRecalculateMaterial just
            // re-applies the DEFAULT skin (it reads r_nSkinId), and clearing alone
            // leaves the mesh black. So instead we ASSIGN the swapped skin's own
            // materials directly onto the body slots via SetMaterial. This needs
            // the materials scanned first (Scan Materials button).
            int applied = 0;
            // AUTO-APPLY MUST NOT STOMP A MANUAL PICK.
            //
            // Auto-apply assigns the materials that match the swapped skin. That
            // is right on a skin swap and wrong the moment you have chosen a
            // texture yourself - it was overwriting your choice seconds later.
            // If you picked one by hand, yours wins.
            if (g_AutoApplyMats && !g_LastBodyMatName[0] && g_LastAppliedBodyName[0]) {
                applied = ApplyMatchingMaterials(wpawn, g_LastAppliedBodyName);
            }
            if (applied > 0) {
                wsprintfA(g_VariantStatus, "Applied %d matching materials for %s",
                          applied, g_LastAppliedBodyName);
            } else {
                // Fall back to clearing overrides (mesh's own mats) if we found no
                // matching skin materials — at least not the OLD skin's colours.
                TryClearBodyMaterials(wpawn);
                wsprintfA(g_VariantStatus,
                    "No matching materials found (scan materials first?). Cleared overrides.");
            }

            // AUTO SHAPE-FIX (your discovery): toggling the 3P weapon hide on then
            // off forces the mesh to snap to the correct shape. Do it automatically
            // after a skin apply so the model comes out right without manual fiddling.
            if (g_AutoWeaponShapeFix) {
                SDK::ATgWeaponMeshActor* wa = TryGetWeaponActor(wpawn);
                if (wa) { TryHide3PWeapon(wa, true); TryHide3PWeapon(wa, false); }
            }
        }

        // ====================================================================
        // DISABLED — this whole path called STATIC_FindObject / DynamicLoadObject,
        // which the game force-crashes on if it happens during garbage collection
        // ("Illegal call to StaticFindObject() while ... garbage collecting"). It
        // cannot be made safe from our side (a __try can't catch a game-side abort
        // that happens mid-GC). The number-button "wear by index" feature is gone;
        // the working method is the raw mesh-pointer swap (g_PendingApply), which
        // never touches StaticFindObject.
        // ====================================================================
        g_PendingWearNum = false;
        return;
#if 0
        SDK::APawn* pawn = Globals::LocalPawn;
        if (!pawn) return;
        SDK::USkeletalMeshComponent* mc = TryGetMeshComp(pawn);
        if (!mc) return;

        // Build the FULL path of the current body mesh (Package.leaf), then swap
        // the skin number in the LEAF only. DynamicLoadObject needs the package,
        // which is the whole reason the bare-name version found nothing.
        SDK::USkeletalMesh* liveBody = TryGetMesh(mc);
        BuildLivePath((SDK::UObject*)liveBody);

        char fullName[200] = "";
        bool built = false;
        if (g_LiveFullPath[0]) {
            built = BuildSkinName(g_LiveFullPath, g_WearSkinNum, fullName, 200);
        }
        if (!built) {
            // Fallback to the bare leaf name if the path couldn't be built.
            built = BuildSkinName(g_LiveName, g_WearSkinNum, fullName, 200);
        }

        if (built) {
            SDK::USkeletalMesh* bm = FetchMeshByName(fullName);
            if (bm && TrySetMeshRaw(mc, bm)) {
                g_ApplyCount++;
                wsprintfA(g_Status, "Wore skin %02d  [%s]", g_WearSkinNum, g_FetchDiag);
            } else {
                wsprintfA(g_Status, "Skin %02d failed: %s | tried: %s",
                          g_WearSkinNum, g_FetchDiag, fullName);
            }
        } else {
            lstrcpynA(g_Status, "No skin number in the live mesh name to base it on.", 160);
        }

        // Matching weapon by the same number — BOTH first-person (what you hold
        // and see) and third-person. First person matters most, per your note.
        SDK::ATgWeaponMeshActor* wa = TryGetWeaponActor(pawn);
        if (wa) {
            char savePfx[160]; lstrcpynA(savePfx, g_LivePathPrefix, 160);
            char saveFull[200]; lstrcpynA(saveFull, g_LiveFullPath, 200);

            // 3rd-person weapon
            __try {
                if (wa->m_WeaponMesh3P) {
                    SDK::USkeletalMesh* wlive =
                        ((SDK::USkeletalMeshComponent*)wa->m_WeaponMesh3P)->SkeletalMesh;
                    char wfull[200] = {};
                    BuildLivePath((SDK::UObject*)wlive);
                    if (g_LiveFullPath[0] && BuildSkinName(g_LiveFullPath, g_WearSkinNum, wfull, 200)) {
                        SDK::USkeletalMesh* wm = FetchMeshByName(wfull);
                        if (wm) TrySetWeaponMesh(wa, wm, false, true);
                    }
                }
            } __except (EXCEPTION_EXECUTE_HANDLER) {}

            // 1st-person weapon
            __try {
                if (wa->m_WeaponMesh1P) {
                    SDK::USkeletalMesh* wlive =
                        ((SDK::USkeletalMeshComponent*)wa->m_WeaponMesh1P)->SkeletalMesh;
                    char wfull[200] = {};
                    BuildLivePath((SDK::UObject*)wlive);
                    if (g_LiveFullPath[0] && BuildSkinName(g_LiveFullPath, g_WearSkinNum, wfull, 200)) {
                        SDK::USkeletalMesh* wm = FetchMeshByName(wfull);
                        if (wm) TrySetWeaponMesh(wa, wm, true, false);
                    }
                }
            } __except (EXCEPTION_EXECUTE_HANDLER) {}

            lstrcpynA(g_LivePathPrefix, savePfx, 160);
            lstrcpynA(g_LiveFullPath, saveFull, 200);
        }

        // "Both methods": a successful load pulls a whole package into memory, so
        // rescan afterwards — the scan list then fills with that skin's meshes,
        // giving back the populated list the user liked, but reliably this time.
        g_WantRescanAfterWear = true;
#endif
    }

    // Skin key the user last clicked, for the persistence toggle.
    inline char g_ChosenKey[16] = "";

    // ---- UNIVERSAL OVERLAYS (shared by both tabs) --------------------------
    // mic_burncard_damage_overlay_wep_1p_a is the golden see-through material
    // that works on ANY champion. It is not tied to a champion or a weapon
    // family, so every champion-based filter used to throw it away.
    //
    // This lived only inside the research tab, behind a collapsing header, which
    // is why it had to be hunted for. It is a function now and both tabs call it.
    inline void DrawUniversalOverlays(const char* idTag) {
        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)),
                           "UNIVERSAL OVERLAYS  (work on any champion)");
        ImGui::TextDisabled("Pick a target, then click one. These paint on top of whatever is "
                            "already there.");

        static int s_UniTarget = 0;   // 0 = weapon, 1 = body, 2 = arms
        char r0[48], r1[48], r2[48];
        wsprintfA(r0, "WEAPON##uni%s", idTag);
        wsprintfA(r1, "BODY##uni%s",   idTag);
        wsprintfA(r2, "ARMS##uni%s",   idTag);
        ImGui::TextUnformatted("apply to:");
        ImGui::SameLine(); ImGui::RadioButton(r0, &s_UniTarget, 0);
        ImGui::SameLine(); ImGui::RadioButton(r1, &s_UniTarget, 1);
        ImGui::SameLine(); ImGui::RadioButton(r2, &s_UniTarget, 2);

        char child[48]; wsprintfA(child, "unimats%s", idTag);
        ImGui::BeginChild(child, ImVec2(0, 150), true);
        int uniShown = 0;
        for (int i = 0; i < g_MatCount; ++i) {
            if (!IsUniversalMat(g_MatNames[i])) continue;
            uniShown++;
            char lbl[160]; wsprintfA(lbl, "%s##uni%s_%d", g_MatNames[i], idTag, i);
            if (ImGui::Selectable(lbl)) {
                if (s_UniTarget == 0)      g_PendingWeaponMat = i;
                else if (s_UniTarget == 1) g_PendingManualMat = i;
                else                       g_PendingArmsMat   = i;
            }
        }
        if (uniShown == 0)
            ImGui::TextDisabled("None in memory yet. They appear once something in the match has "
                                "used one - auto-scan will pick them up on its own.");
        ImGui::EndChild();
    }

    // ========================================================================
    // CLEAN SKINS TAB — only the stuff that actually works, organised.
    // The bloated DrawControls stays for research; this is the everyday tool.
    // ========================================================================
    inline void DrawSimple(bool inMatch) {
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.6f, 1.0f)), "SKINS  (client-side, shooting range)");
        ImGui::TextWrapped("Preview the skins you want in champion select (that is what loads "
            "them), then come here. The lists below fill in on their own - there is nothing to "
            "press. Click a skin and it swaps the model and its textures together.");

        ImGui::Spacing();
        ImGui::TextDisabled("Scans automatically the moment you spawn - the list is ready before");
        ImGui::TextDisabled("you open this tab. Refreshes again on champion change.");
        ImGui::SameLine();
        ImGui::Checkbox("also every 3s", &g_ContinuousScan);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Only needed if assets are being garbage-collected while you watch.\n"
            "Scanning is a walk of every object in the game, so leaving this off\n"
            "is the reason the tool no longer stutters.");
        ImGui::SameLine();
        if (ImGui::Button("rescan now", ImVec2(110, 0))) { RunScan(); RunMaterialScan(); }
        ImGui::Text("Champion: %s     %d meshes, %d materials in memory",
                    g_MyChampion[0] ? g_MyChampion : "(unknown)", g_ResultCount, g_MatCount);

        // Count unique body skins for the header.
        DrawUniversalOverlays("simple");

        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)), "SKINS  (one click = model + textures)");

        // Live body skeleton, measured once, for the safety check on every row.
        int uiLiveBodyBones = -1;
        {
            SDK::APawn* sp = Globals::LocalPawn;
            if (sp) {
                SDK::USkeletalMeshComponent* smc = TryGetMeshComp(sp);
                if (smc) uiLiveBodyBones = TryGetBoneCount(TryGetMesh(smc));
            }
        }
        ImGui::TextColored(Ink(ImVec4(0.45f, 1.0f, 0.55f, 1.0f)), "OK = safe");
        ImGui::SameLine(); ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.4f, 1.0f)), "RISK = may look wrong");
        ImGui::SameLine(); ImGui::TextColored(Ink(ImVec4(1.0f, 0.4f, 0.4f, 1.0f)), "DANGER = would crash (blocked)");
        ImGui::Text("your body skeleton: %d bones   (hover a row for the reason)", uiLiveBodyBones);
        ImGui::Checkbox("allow DANGER picks (will crash - only for testing)", &g_AllowDangerPicks);
        ImGui::SameLine();
        ImGui::Checkbox("show ALL materials", &g_MatShowAll);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Ignores the champion + weapon-family filter on the material scan.\n"
            "Turn this on if weapon textures look like they are missing - it\n"
            "shows every material in memory, unfiltered. Re-run SCAN after.");

        ImGui::BeginChild("simpleskins", ImVec2(0, 220), true);
        int shown = 0;
        for (int i = 0; i < g_ResultCount; ++i) {
            if (ClassifyMesh(g_Names[i]) != MK_Body) continue;
            if (!allowCrossChampion && g_MyChampion[0] && !HasCI(g_Names[i], g_MyChampion)) continue;
            if (HasCI(g_Names[i], "lobby")) continue;

            char key[16]; SkinKey(g_Names[i], key, 16);
            // Dedupe by key.
            bool dup = false;
            for (int j = 0; j < i; ++j) {
                if (ClassifyMesh(g_Names[j]) != MK_Body) continue;
                if (HasCI(g_Names[j], "lobby")) continue;
                if (!allowCrossChampion && g_MyChampion[0] && !HasCI(g_Names[j], g_MyChampion)) continue;
                char kj[16]; SkinKey(g_Names[j], kj, 16);
                if (key[0] && lstrcmpA(key, kj) == 0) { dup = true; break; }
            }
            if (dup) continue;
            shown++;

            // SAFETY COLOURING — see the landmine before you click it.
            char why[96];
            SafetyLevel lvl = ClassifySafety(i, uiLiveBodyBones, why, 96);
            const char* tag = (lvl == SAFE_OK) ? "OK  " : (lvl == SAFE_RISKY ? "RISK" : "DANGER");
            // Show the real skin NAME where we can work it out, not just "skin09a".
            // The mesh name only carries a code, so map it through the skin
            // database by champion + skin index when possible.
            const char* pretty = LookupSkinName(g_MyChampion, key);
            char lbl[200];
            if (pretty)
                wsprintfA(lbl, "[%s] %s  (%s, %d bones)##ss%d",
                          tag, pretty, key[0] ? key : "?", g_BoneCounts[i], i);
            else
                wsprintfA(lbl, "[%s] Wear %s  (%d bones)##ss%d",
                          tag, key[0] ? key : g_Names[i], g_BoneCounts[i], i);
            bool isChosen = (key[0] && lstrcmpA(key, g_ChosenKey) == 0);
            ImVec4 col = (lvl == SAFE_OK)    ? ImVec4(0.45f, 1.00f, 0.55f, 1.0f)
                       : (lvl == SAFE_RISKY) ? ImVec4(1.00f, 0.85f, 0.40f, 1.0f)
                                             : ImVec4(1.00f, 0.40f, 0.40f, 1.0f);
            ImGui::PushStyleColor(ImGuiCol_Text, col);
            bool clicked = ImGui::Selectable(lbl, isChosen);
            ImGui::PopStyleColor();
            if (ImGui::IsItemHovered() && why[0]) ImGui::SetTooltip("%s", why);
            // DANGER rows are blocked in the apply path; don't even queue them.
            if (clicked && lvl == SAFE_DANGER && !g_AllowDangerPicks) {
                wsprintfA(g_Status, "BLOCKED '%s': %s", g_Names[i], why);
                clicked = false;
            }
            if (clicked) {
                g_SelectedIndex = i;
                // FULL PACKAGE: body + arms + weapon + matching materials, atomic.
                // (Was body-only, which is why 1P hands and the gun stayed default
                // and why textures could end up cleared-but-not-replaced.)
                g_PkgApplyIndex = i;
                lstrcpynA(g_ChosenKey, key, 16);
                lstrcpynA(g_PersistKey, key, 16);   // ready for persistence
            }
        }
        if (shown == 0) ImGui::TextDisabled("Nothing loaded. Preview skins in champion select, then SCAN.");
        ImGui::EndChild();
        ImGui::Checkbox("arms", &g_PkgDoArms);   ImGui::SameLine();
        ImGui::Checkbox("weapon", &g_PkgDoWeapon); ImGui::SameLine();
        ImGui::Checkbox("materials", &g_PkgDoMats);
        if (g_PkgStatus[0]) ImGui::TextWrapped("%s", g_PkgStatus);

        ImGui::Checkbox("Keep re-applied (stops it resetting to default)", &g_PersistEnabled);
        ImGui::SameLine();
        ImGui::Checkbox("Swap WEAPON with the body skin (now safe - bone guard)", &g_SwapWeaponOnApply);

        if (ImGui::Button("Restore my default skin", ImVec2(200, 26))) {
            g_PersistEnabled = false;
            g_ChosenKey[0] = '\0';
            g_PendingRestore = true;
        }
        ImGui::SameLine();
        if (ImGui::Button("Fix textures / shape now", ImVec2(190, 26))) g_PendingClearMats = true;

        ImGui::Separator();
        ImGui::Text("Now wearing : %s", g_LiveName[0] ? g_LiveName : "(none)");
        ImGui::TextColored(Ink(ImVec4(1.0f, 1.0f, 0.5f, 1.0f)), "%s", g_VariantStatus);

        // ---- MANUAL TEXTURE PICKERS, split by target ----
        // Body textures go on the body; WEAPON textures go on the gun. This is the
        // separation you wanted so a weapon texture never lands on your character.
        if (ImGui::TreeNode("Manual textures (body vs weapon)")) {
            ImGui::PushItemWidth(80);
            ImGui::InputInt("Slot", &g_MatSlot);
            ImGui::PopItemWidth();
            ImGui::TextDisabled("Slot 0 is usually the one that shows. Higher slots are minor parts.");

            // Two columns (body | weapon); ARMS gets its own full-width box below,
            // because a third column squeezed it to the point of being unusable.
            ImGui::Columns(2, "matcols", true);

            ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.7f, 1.0f)), "BODY textures");
            ImGui::BeginChild("bodymats", ImVec2(0, 150), true);
            for (int i = 0; i < g_MatCount; ++i) {
                if (!IsBodyMaterial(g_MatNames[i])) continue;
                char lbl[112]; wsprintfA(lbl, "%s##bm%d", g_MatNames[i], i);
                if (ImGui::Selectable(lbl)) g_PendingManualMat = i;
            }
            ImGui::EndChild();

            ImGui::NextColumn();

            ImGui::TextColored(Ink(ImVec4(0.6f, 0.85f, 1.0f, 1.0f)), "WEAPON textures");
            ImGui::BeginChild("wepmats", ImVec2(0, 150), true);
            for (int i = 0; i < g_MatCount; ++i) {
                if (!IsWeaponMaterial(g_MatNames[i])) continue;
                char lbl[112]; wsprintfA(lbl, "%s##wm%d", g_MatNames[i], i);
                if (ImGui::Selectable(lbl)) g_PendingWeaponMat = i;   // -> weapon, not body
            }
            ImGui::EndChild();

            ImGui::Columns(1);

            // ARMS textures — full-width box UNDER the weapon box.
            ImGui::Spacing();
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)), "ARMS / HANDS textures (first person)");
            ImGui::TextDisabled("Arm textures for OTHER champions can appear here if they are in");
            ImGui::TextDisabled("the match with you - the game loads their materials too. Filtered");
            ImGui::TextDisabled("to your champion by default; untick the filter above to see all.");
            ImGui::BeginChild("armsmats", ImVec2(0, 130), true);
            {
                int armsShown = 0;
                for (int i = 0; i < g_MatCount; ++i) {
                    if (!IsArmsMaterial(g_MatNames[i])) continue;
                    if (!MatPassesChampFilter(g_MatNames[i])) continue;
                    armsShown++;
                    char lbl[112]; wsprintfA(lbl, "%s##am%d", g_MatNames[i], i);
                    if (ImGui::Selectable(lbl)) g_PendingArmsMat = i;
                }
                if (armsShown == 0) {
                    ImGui::TextDisabled("None found for %s - press SCAN MATERIALS (named *_arms_*),",
                                        g_MyChampion[0] ? g_MyChampion : "you");
                    ImGui::TextDisabled("or untick \"Only MY champion's textures\" above.");
                }
            }
            ImGui::EndChild();
            ImGui::SetNextItemWidth(90);
            ImGui::InputInt("arms slot##t", &g_ArmsMatSlot);
            ImGui::SameLine();
            ImGui::TextDisabled("body / weapon / arms = three separate targets.");
            ImGui::TreePop();
        }

        ImGui::TextDisabled("Textures: %d loaded. If a skin looks wrong, press SCAN again then re-click it.",
                            g_MatCount);
    }

    inline void DrawControls(bool inMatch) {
        // ====================================================================
        // PRIMARY METHOD, UP FRONT: SetDefaultSkin variant switching.
        // This is the game's OWN skin switcher. It fixes the two problems raw
        // mesh-swapping can't: broken skinning (strings/spikes) and wrong
        // textures. Try these FIRST.
        // ====================================================================
        if (inMatch) {
            // The numbered 0-15 buttons. SetDefaultSkin never changed a skin in
            // testing, so they are collapsed rather than presented as the thing
            // to try first. Left in because the call is right even if the result
            // is not.
            if (ImGui::CollapsingHeader("Skin variants 0-15 (SetDefaultSkin - does nothing)")) {
            ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.4f, 1.0f)), "### SKIN VARIANTS ###");
            ImGui::TextWrapped("These call the game's own SetDefaultSkin. Unlike raw mesh swapping, "
                "they switch the skin CORRECTLY - no stringy/broken models, no wrong textures. "
                "Click through the numbers; most champions have a handful of valid ones.");
            for (int n = 0; n <= 15; ++n) {
                char b[24]; wsprintfA(b, "%d##var%d", n, n);
                if (ImGui::Button(b, ImVec2(34, 26))) g_PendingVariant = n;
                if ((n % 8) != 7 && n != 15) ImGui::SameLine();
            }
            ImGui::Checkbox("Also switch weapon variant", &g_VariantWeaponToo);
            ImGui::SameLine();
            if (ImGui::Button("Fix textures (clear overrides)", ImVec2(230, 24)))
                g_PendingClearMats = true;
            ImGui::TextColored(Ink(ImVec4(1.0f, 1.0f, 0.5f, 1.0f)), "%s", g_VariantStatus);
            }   // end variants collapse
            ImGui::Separator();
        }

        ImGui::TextColored(Ink(ImVec4(0.7f, 0.7f, 0.7f, 1.0f)), "RAW MESH TOOLS  (experimental - below)");
        ImGui::TextWrapped("Everything below swaps mesh POINTERS directly. It's how we proved skins "
            "CAN change, but it breaks skinning and textures (the strings/wrong-colour issues), so "
            "it's kept for research. Prefer the variant buttons above.");
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.7f, 1.0f)), "MESH SKIN SWAP  (the real method)");
        ImGui::TextWrapped("The skin id approach asks the SERVER for a skin, and it says no because "
            "you don't own it. This doesn't ask anyone: it overwrites the mesh pointer on your own "
            "pawn, so the renderer just draws something else. No replicated field, no ownership "
            "check, nothing to reject.");
        ImGui::TextWrapped("All of a champion's skins are bundled in one package already installed "
            "on your PC - that's why MAEVE_ASSETS_SF.upk is 40MB. Nothing to extract or download.");

        ImGui::Separator();

        // THE BIG BLUE SCANNER STAYS OUTSIDE THE COLLAPSE.
        //
        // This is the button that fills the skin list. Burying it inside a
        // collapsed header is what made the tab look like it had lost all its
        // skins - nothing had scanned, so there was nothing to show.
        ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0.13f, 0.42f, 0.72f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.55f, 0.90f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.28f, 0.65f, 1.00f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_Text,          ImVec4(1, 1, 1, 1));
        bool scanAll = ImGui::Button(">>> SCAN ALL SKINS <<<", ImVec2(260, 34));
        ImGui::PopStyleColor(4);
        ImGui::SameLine();
        ImGui::TextDisabled("%d loaded", g_ResultCount);
        if (scanAll) {
            g_Filter[0] = '\0';
            RunScan();
        }

        // The rest of the scan controls are collapsed - the scan runs itself on
        // spawn and on tab open, so these are only for driving it by hand.
        if (ImGui::CollapsingHeader("More scan options (filter, per-champion)")) {
            ImGui::TextWrapped("UE3 loads assets lazily, so the question is whether other skins' "
                "meshes are in memory right now. SCAN ALL lists everything resident.");
            ImGui::PushItemWidth(160);
            ImGui::InputText("Name filter", g_Filter, sizeof(g_Filter));
            ImGui::PopItemWidth();
            ImGui::SameLine();
            if (ImGui::Button("SCAN MESHES", ImVec2(130, 24))) RunScan();
            ImGui::SameLine();
            if (ImGui::Button("My champ only", ImVec2(120, 24))) {
                lstrcpynA(g_Filter, g_MyChampion, sizeof(g_Filter));
                RunScan();
            }
            ImGui::Checkbox("Continuous rescan (1/s)", &g_ContinuousScan);
        }

        // KEEP-ALIVE: the anti-GC unlock. When on, every scanned mesh/material is
        // marked non-collectable, so a skin previewed in the menu survives into the
        // match. This is the fix for "the mesh stays default but the abilities are
        // the new skin" = the mesh got garbage-collected on the transition.
        ImGui::Checkbox("KEEP LOADED (anti-GC: survive menu->match)", &g_AutoKeepAlive);
        ImGui::SameLine();
        if (ImGui::Button("Keep ALL now", ImVec2(120, 22))) {
            int n = 0;
            for (int i = 0; i < g_ResultCount; ++i) if (TryKeepAlive(g_Objects[i])) n++;
            for (int i = 0; i < g_MatCount; ++i)    if (TryKeepAlive(g_MatObjects[i])) n++;
            wsprintfA(g_Status, "Marked %d objects keep-alive (won't GC).", n);
        }
        ImGui::Text("Kept-alive so far: %d", g_KeptAliveCount);

        // GLOBAL GC-BEATER — the strong version. Pins EVERY skin asset in memory
        // every second, not just the filtered scan list. Leave this ON: preview a
        // skin in the menu once and it stays resident the whole session, so
        // Method A always has a mesh to render (no more invisible from GC).
        ImGui::Checkbox("BEAT GARBAGE COLLECTION (global, auto 1/s)", &g_GlobalKeepAlive);
        ImGui::SameLine();
        if (ImGui::Button("Pin ALL now", ImVec2(110, 22))) {
            RunGlobalKeepAlive();
            wsprintfA(g_Status, "Pinned %d skin assets against GC.", g_GlobalPinnedTotal);
        }
        ImGui::Text("Skin assets resident & pinned: %d", g_GlobalPinnedTotal);

        // Diagnostics — useful when I ask for a dump, but not part of the daily
        // flow, so they live behind a collapsed node instead of taking up space.
        bool showDiag = ImGui::TreeNode("Copy / diagnostics (only when asked for a dump)");
        if (showDiag) {
        if (ImGui::Button("COPY SCAN LIST", ImVec2(180, 26))) {
            BuildScanReport();
            g_ScanCopied = CopyClip(g_ScanReport);
        }
        ImGui::SameLine();
        // CLASSIFIED list: name + detected type + bone count. This is the "tell"
        // you asked for, in one paste — proves body vs weapon vs prop.
        if (ImGui::Button("COPY CLASSIFIED", ImVec2(170, 26))) {
            static char cb[24000]; cb[0] = '\0';
            char h[96]; wsprintfA(h, "=== CLASSIFIED MESHES (%s) ===\r\n", g_MyChampion);
            lstrcatA(cb, h);
            for (int i = 0; i < g_ResultCount; ++i) {
                if (lstrlenA(cb) > 23000) break;
                MeshKind k = ClassifyMesh(g_Names[i]);
                const char* t = (k==MK_Weapon1P||k==MK_Weapon3P) ? "WEAPON"
                              : (k==MK_Body?"BODY":(k==MK_Prop?"PROP":(k==MK_Arms?"ARMS":"?")));
                char line[160];
                wsprintfA(line, "%-6s  %3d bones  %s\r\n", t, g_BoneCounts[i], g_Names[i]);
                lstrcatA(cb, line);
            }
            CopyClip(cb);
        }
        ImGui::SameLine();
        // One button that copies EVERYTHING useful for diagnosis, as requested.
        if (ImGui::Button("COPY FULL REPORT", ImVec2(180, 26))) {
            BuildScanReport();
            static char big[20000];
            big[0] = '\0';
            lstrcatA(big, g_ScanReport);
            char t[400];
            wsprintfA(t, "\r\n--- APPLY STATE ---\r\nStatus: %s\r\nFetch detail: %s\r\n"
                         "Applies: %d   Weapon paired: %s\r\n"
                         "Auto-fix textures: %s\r\nNew mesh own materials: %d\r\n"
                         "Selected body idx: %d   Selected weapon idx: %d\r\n"
                         "In match: %s\r\n",
                     g_Status, g_FetchDiag, g_ApplyCount, g_LastWeaponPaired ? "yes" : "no",
                     g_AutoFixTextures ? "on" : "off", g_TargetOwnMatCount,
                     g_SelectedIndex, g_SelWeaponIndex, inMatch ? "yes" : "no");
            lstrcatA(big, t);
            g_ScanCopied = CopyClip(big);
        }
        ImGui::SameLine();
        if (g_ScanCopied) {
            ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), "Copied - paste it to me.");
        } else {
            ImGui::TextDisabled("Yes - this is the list I want.");
        }
        ImGui::TreePop();
        }   // end diagnostics TreeNode

        ImGui::Text("%s", g_Status);
        if (g_ScanDone) {
            ImGui::Text("Total SkeletalMesh objects loaded: %d", g_TotalSkeletalMeshes);
        }
        ImGui::Text("You are playing : %s", g_MyChampion[0] ? g_MyChampion : "(unknown)");
        ImGui::Text("m_pAmAllSkins   : %d", g_AllSkinsCount);
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip(
                "ATgPawn tracks m_pAmSkin (current) and m_pAmAllSkins (all skins) as\n"
                "native asset pointers - NOT replicated. If this count is greater than\n"
                "1, the pawn already knows about multiple skins and switching between\n"
                "them is a much cleaner swap than replacing a mesh.");
        }

        ImGui::Checkbox("Allow cross-champion / weapon meshes (CRASHES)", &allowCrossChampion);
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip(
                "Leave OFF. Your Pip crash was a weapon/hand mesh assigned to the body:\n"
                "different bone count, so the engine asserted on the bone array.\n"
                "Picks like that are now blocked unless you tick this.");
        }

        // NOTE: MeshInfo is drawn ONCE, by DevSkin's menu section. Drawing it here
        // too gave two widgets the same IDs -> the ImGui "conflicting ID" popup and
        // dead buttons. One owner only.

        if (!inMatch) {
            ImGui::TextDisabled("Join a match to APPLY. (Scanning + MeshInfo above work here in the menu.)");
            return;
        }

        // (The crash-prone "wear by number" buttons were removed — they called
        // StaticFindObject and force-crashed the game during GC.)
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.3f, 1.0f, 0.4f, 1.0f)),
            ">>> WORKING FLOW: preview skins in champ select -> shooting range -> SCAN -> click a skin <<<");
        ImGui::Spacing();
        // "Restore my real skin" only ever put the MESH back - textures stayed
        // whatever you had applied, so you were never actually back to default.
        // This clears the remembered material picks as well, which stops the
        // persistence pass immediately re-applying them, then restores.
        if (ImGui::Button("RESTORE EVERYTHING (mesh + textures)", ImVec2(300, 28))) {
            g_LastBodyMatName[0]   = '\0';
            g_LastWeaponMatName[0] = '\0';
            g_LastArmsMatName[0]   = '\0';
            g_PendingClearMats = true;   // hand the materials back to the game
            g_PendingRestore   = true;   // and the mesh with them
        }
        ImGui::SameLine();
        if (ImGui::Button("mesh only", ImVec2(110, 28))) g_PendingRestore = true;
        ImGui::TextColored(Ink(ImVec4(1.0f, 1.0f, 0.5f, 1.0f)), "%s", g_Status);
        ImGui::Separator();
        // ---- SMART-ROUTED list: shows ALL scanned meshes and sends each to the
        // component whose skeleton matches (body -> body, weapon -> gun). This is
        // the "sense what it goes on" tool, and it's how weapon MESHES finally swap.
        ImGui::TextColored(Ink(ImVec4(0.5f, 1.0f, 0.7f, 1.0f)), "SMART MESH (auto-routes by skeleton)");
        DrawSmartMeshList();
    }

    // ---- MESHINFO TREE: the game's own mesh->materials->socket structure ----
    // Split out so it can be drawn in the MENU (no pawn required).
    inline void DrawMeshInfoSection() {
        // Collapsed: returned empty every time so far (the menu appears to be
        // native-side, so these objects never showed up in GObjects). Kept
        // because a different game state might populate it.
        if (ImGui::CollapsingHeader("MESHINFO TREE  (returned empty so far)")) {
            ImGui::TextWrapped("This is how the GAME knows which mesh goes where. FLobbyMeshInfo pairs "
                "SkelMesh with its OWN MaterialOverrides and an AttachSocketName, and UTgMenuMeshInfo "
                "nests them: root = body, children = arms / weapon / props. Mesh AND textures together, "
                "already matched - exactly what Method A uses. socket '' = body/root.");
            if (ImGui::Button("SCAN MESHINFO TREES", ImVec2(220, 26))) RunMeshInfoScan();
            ImGui::SameLine();
            if (ImGui::Button("COPY MESHINFO", ImVec2(150, 26))) {
                static char big[128 * 200 + 256];
                big[0] = '\0';
                lstrcatA(big, "===== MESHINFO TREES =====\r\n");
                for (int i = 0; i < g_MICount; ++i) {
                    char line[220];
                    wsprintfA(line, "%*s%s  [socket:%s] mats:%d bones:%d\r\n",
                              g_MI[i].depth * 2, "",
                              g_MI[i].meshName[0] ? g_MI[i].meshName : "(no mesh)",
                              g_MI[i].socket[0] ? g_MI[i].socket : "-",
                              g_MI[i].matCount, g_MI[i].bones);
                    lstrcatA(big, line);
                }
                CopyClip(big);
            }
            ImGui::TextColored(Ink(ImVec4(1.0f, 1.0f, 0.5f, 1.0f)), "%s", g_MIStatus);
            ImGui::BeginChild("mitree", ImVec2(0, 150), true);
            for (int i = 0; i < g_MICount; ++i) {
                ImVec4 c = g_MI[i].depth == 0 ? ImVec4(0.6f, 1.0f, 0.7f, 1.0f)
                                              : ImVec4(1.0f, 0.85f, 0.5f, 1.0f);
                ImGui::PushStyleColor(ImGuiCol_Text, c);
                ImGui::Text("%*s%s  [socket:%s] mats:%d bones:%d",
                            g_MI[i].depth * 2, "",
                            g_MI[i].meshName[0] ? g_MI[i].meshName : "(no mesh)",
                            g_MI[i].socket[0] ? g_MI[i].socket : "-",
                            g_MI[i].matCount, g_MI[i].bones);
                ImGui::PopStyleColor();
            }
            if (g_MICount == 0) ImGui::TextDisabled("Press SCAN MESHINFO TREES (works best in the menu).");
            ImGui::EndChild();
        }
    }

    inline void DrawSmartMeshList() {
        ImGui::TextWrapped("Click any mesh - it reads the bone count and puts it on the matching part "
            "(body or WEAPON). Meshes that fit nothing are refused instead of crashing. This is how "
            "weapon meshes get applied.");
        ImGui::TextColored(Ink(ImVec4(1.0f, 1.0f, 0.5f, 1.0f)), "%s", g_SmartStatus);
        // Live component bone counts, measured once per frame, so each row can show
        // the EXACT part it will go to. Nothing is greyed-out-and-dead any more:
        // if a row says ARMS it will be applied to your hands when clicked.
        int uiBody = -1, uiArms = -1, uiWep = -1;
        {
            SDK::APawn* up = Globals::LocalPawn;
            if (up) {
                SDK::USkeletalMeshComponent* umc = TryGetMeshComp(up);
                if (umc) uiBody = TryGetBoneCount(TryGetMesh(umc));
                SDK::ATgWeaponMeshActor* uwa = TryGetWeaponActor(up);
                uiArms = TryGetArmsBoneCount(uwa);
                __try {
                    if (uwa && uwa->m_WeaponMesh3P)
                        uiWep = TryGetBoneCount(
                            ((SDK::USkeletalMeshComponent*)uwa->m_WeaponMesh3P)->SkeletalMesh);
                } __except (EXCEPTION_EXECUTE_HANDLER) {}
            }
        }
        ImGui::Text("your live parts:  BODY %d bones | ARMS %d | WEAPON %d", uiBody, uiArms, uiWep);
        ImGui::BeginChild("smartmesh", ImVec2(0, 130), true);
        for (int i = 0; i < g_ResultCount; ++i) {
            if (!allowCrossChampion && g_MyChampion[0] && !HasCI(g_Names[i], g_MyChampion)) continue;
            if (HasCI(g_Names[i], "nogeo")) continue;
            // Show the RESOLVED destination (name first, bone count as fallback),
            // not just the raw name-kind — so "[?]" rows now say where they land.
            SkinTarget t = ResolveTarget(g_Names[i], g_BoneCounts[i], uiBody, uiArms, uiWep);
            char lbl[160]; wsprintfA(lbl, "%-6s %3d bones  %s##sm%d",
                                     TargetName(t), g_BoneCounts[i], g_Names[i], i);
            ImVec4 col;
            switch (t) {
                case TGT_Body:     col = ImVec4(0.6f, 1.0f, 0.7f, 1.0f); break;  // green
                case TGT_Arms:     col = ImVec4(1.0f, 0.8f, 0.4f, 1.0f); break;  // orange
                case TGT_Weapon1P:
                case TGT_Weapon3P: col = ImVec4(0.6f, 0.85f, 1.0f, 1.0f); break; // blue
                default:           col = ImVec4(0.55f, 0.55f, 0.55f, 1.0f);      // truly unusable
            }
            ImGui::PushStyleColor(ImGuiCol_Text, col);
            if (ImGui::Selectable(lbl)) g_PendingSmartIndex = i;
            ImGui::PopStyleColor();
        }
        if (g_ResultCount == 0) ImGui::TextDisabled("Press SCAN MESHES first.");
        ImGui::EndChild();
        ImGui::Separator();

        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)), "BODY SKINS  (click to wear)");
        ImGui::TextWrapped("Body-only list. Preview skins in champion select to load more, then SCAN. "
            "Clicking applies the body mesh + its body textures. Landmine meshes are now blocked by "
            "bone-count check, so this won't crash.");

        // ONE-CLICK CLEAN LIST — deduplicated by skin number. Each row is ONE
        // skin; clicking it swaps the body mesh AND auto-applies that skin's
        // materials AND its weapon, all in one action. This is the automation you
        // asked for. Rows exclude lobby/arms variants so it reads as a real skin
        // picker, not a mesh dump.
        // SAFE-FIRST ORDERING.
        //
        // "Find the safe ones and put them at the top" - so the list is built as
        // an index array and sorted before it is drawn, rather than rendered in
        // whatever order GObjects happened to hold. Sort key:
        //   1. bone count == your SPAWN skeleton   (safe, will not crash)
        //   2. has a matching weapon mesh          (you get the gun too)
        //   3. has a matching arms mesh
        // Everything else falls below, still clickable, marked with what it is
        // going to cost you.
        static int  s_Order[512];
        static int  s_Score[512];
        static char s_Flags[512][8];
        int nOrder = 0;

        for (int i = 0; i < g_ResultCount && nOrder < 512; ++i) {
            if (ClassifyMesh(g_Names[i]) != MK_Body) continue;
            if (!allowCrossChampion && g_MyChampion[0] && !HasCI(g_Names[i], g_MyChampion)) continue;
            if (HasCI(g_Names[i], "lobby")) continue;

            char key[16]; SkinKey(g_Names[i], key, 16);
            bool dup = false;
            for (int j = 0; j < nOrder; ++j) {
                char kj[16]; SkinKey(g_Names[s_Order[j]], kj, 16);
                if (key[0] && lstrcmpA(key, kj) == 0) { dup = true; break; }
            }
            if (dup) continue;

            // Does this skin key also have a weapon mesh and an arms mesh loaded?
            bool hasWep = false, hasArms = false;
            if (key[0]) {
                for (int j = 0; j < g_ResultCount; ++j) {
                    char kj[16]; SkinKey(g_Names[j], kj, 16);
                    if (kj[0] == '\0' || lstrcmpA(key, kj) != 0) continue;
                    MeshKind mk = ClassifyMesh(g_Names[j]);
                    if (mk == MK_Weapon1P || mk == MK_Weapon3P) hasWep = true;
                    else if (mk == MK_Arms)                      hasArms = true;
                }
            }

            int baseB = (g_OriginalBones > 0) ? g_OriginalBones : -1;
            bool safe = (baseB > 0 && g_BoneCounts[i] == baseB);

            int sc = 0;
            if (safe)    sc += 100;
            if (hasWep)  sc += 10;
            if (hasArms) sc += 5;

            int fl = 0;
            s_Flags[nOrder][fl++] = safe ? 'S' : '!';
            if (hasWep)  s_Flags[nOrder][fl++] = 'W';
            if (hasArms) s_Flags[nOrder][fl++] = 'A';
            s_Flags[nOrder][fl] = '\0';

            s_Score[nOrder] = sc;
            s_Order[nOrder] = i;
            nOrder++;
        }

        // Simple insertion sort, highest score first. nOrder is small.
        for (int a = 1; a < nOrder; ++a) {
            int idx = s_Order[a], sc = s_Score[a];
            char fl[8]; lstrcpynA(fl, s_Flags[a], 8);
            int b = a - 1;
            while (b >= 0 && s_Score[b] < sc) {
                s_Order[b + 1] = s_Order[b];
                s_Score[b + 1] = s_Score[b];
                lstrcpynA(s_Flags[b + 1], s_Flags[b], 8);
                b--;
            }
            s_Order[b + 1] = idx; s_Score[b + 1] = sc;
            lstrcpynA(s_Flags[b + 1], fl, 8);
        }

        ImGui::TextDisabled("S = same skeleton as your spawn (safe)   ! = different (may crash)   "
                            "W = weapon mesh found   A = arms mesh found");
        ImGui::BeginChild("bodylist", ImVec2(0, 170), true);
        int bodyShown = 0;
        for (int oi = 0; oi < nOrder; ++oi) {
            int i = s_Order[oi];
            {
            char key[16]; SkinKey(g_Names[i], key, 16);
            bodyShown++;

            const char* flags = s_Flags[oi];
            bool safe = (flags[0] == 'S');

            char lbl[160];
            wsprintfA(lbl, "[%-3s] %3d bones  Wear %s##b%d",
                      flags, g_BoneCounts[i], key[0] ? key : g_Names[i], i);

            bool worn = !g_IsOtherSkin[i];
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(
                worn ? ImVec4(0.62f, 0.62f, 0.62f, 1.0f)
                     : (safe ? ImVec4(0.40f, 1.00f, 0.55f, 1.0f)
                             : ImVec4(1.00f, 0.75f, 0.40f, 1.0f))));
            bool clicked = ImGui::Selectable(lbl, g_SelectedIndex == i);
            ImGui::PopStyleColor();
            if (clicked) {
                g_SelectedIndex = i; g_PendingApply = true;
                char ck[16]; SkinKey(g_Names[i], ck, 16);   // capture for persistence
                lstrcpynA(g_ChosenKey, ck, 16);
                lstrcpynA(g_PersistKey, ck, 16);
            }
            }
        }
        if (bodyShown == 0) ImGui::TextDisabled("No body skins loaded yet - scan, or preview skins in menu first.");
        ImGui::EndChild();
        ImGui::TextDisabled("One click = body mesh + matching arms + weapon + textures, all by skin key.");

        // PERSISTENCE + weapon toggle — your two fixes.
        ImGui::Checkbox("Keep re-applied (stops reset to default)", &g_PersistEnabled);
        ImGui::Checkbox("Keep TEXTURES re-applied (survives death + CC cleanses)", &g_PersistMats);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "Cleansing crowd control resets your material overrides without\n"
            "replacing the pawn, so the respawn hook never noticed. This\n"
            "re-applies the last weapon/arms texture on a timer instead.");
        ImGui::SameLine();
        ImGui::Checkbox("Swap weapon MESH with body skin (now safe - bone guard)", &g_SwapWeaponOnApply);

        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(0.6f, 0.85f, 1.0f, 1.0f)), "WEAPONS  (click to swap gun only)");
        ImGui::BeginChild("weplist", ImVec2(0, 110), true);
        int wepShown = 0;
        for (int i = 0; i < g_ResultCount; ++i) {
            MeshKind k = ClassifyMesh(g_Names[i]);
            if (k != MK_Weapon3P && k != MK_Weapon1P) continue;
            // WEAPON-FAMILY EXCEPTION. Weapon meshes are named after the WEAPON
            // (skl_wep_blades_*, skl_wep_potionlauncher_*), never the champion, so
            // a champion-name filter hid EVERY weapon mesh - which is exactly why
            // this list kept coming up empty. The scanner already had this
            // exception; this list never got it. Accept a mesh if it matches the
            // champion OR the resolved weapon family.
            if (!allowCrossChampion && g_MyChampion[0]
                && !HasCI(g_Names[i], g_MyChampion)
                && !(g_WeaponFamily[0] && HasCI(g_Names[i], g_WeaponFamily))) continue;
            wepShown++;
            char lbl[128];
            wsprintfA(lbl, "%s##w%d", g_Names[i], i);
            if (ImGui::Selectable(lbl, g_SelWeaponIndex == i)) {
                g_SelWeaponIndex = i; g_PendingWeaponApply = true;
            }
        }
        if (wepShown == 0) ImGui::TextDisabled("No weapon meshes loaded yet.");
        ImGui::EndChild();

        // Weapon hide in 3rd person — fixes "weapon reappears in third person".
        if (ImGui::Button(g_Hide3PWeaponState ? "Show 3P weapon" : "Hide 3P weapon", ImVec2(160, 24))) {
            g_Hide3PWeaponState = !g_Hide3PWeaponState;
            g_PendingHide3PWeapon = true;
        }
        ImGui::SameLine();
        if (ImGui::Button("Restore my real body", ImVec2(180, 24))) g_PendingRestore = true;

        // TEXTURE FIX controls — the fix for "wrong colours on the new skin".
        ImGui::Checkbox("Auto-fix textures (clear override materials on swap)", &g_AutoFixTextures);
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip(
                "ON: after swapping the mesh, clear the material overrides so the\n"
                "new skin shows ITS OWN textures instead of the old skin's colours.\n"
                "If a skin turns blank/checkered with this on, that mesh has no\n"
                "own materials - tell me and I'll load them from its package.");
        }
        if (ImGui::Button("Fix textures NOW", ImVec2(150, 22))) g_PendingClearMats = true;
        ImGui::SameLine();
        ImGui::Text("new mesh's own materials: %d",
                    g_TargetOwnMatCount >= 0 ? g_TargetOwnMatCount : 0);

        // ---- MATERIAL / TEXTURE TOOLS (the real fix you kept asking for) ----
        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.9f, 1.0f)), "TEXTURES / MATERIALS");
        ImGui::TextWrapped("The colours are separate material objects. Scan them, and swapping a "
            "body skin auto-applies the matching skin's materials to fix the colours.");
        if (ImGui::Button("SCAN MATERIALS", ImVec2(150, 24))) RunMaterialScan();
        ImGui::SameLine();
        ImGui::Checkbox("Auto-apply on swap", &g_AutoApplyMats);
        ImGui::SameLine();
        if (ImGui::Button("Copy materials list", ImVec2(160, 24))) {
            static char mb[20000]; mb[0] = '\0';
            char h[128]; wsprintfA(h, "=== MATERIALS (%d for %s) ===\r\n", g_MatCount,
                                   g_MyChampion[0] ? g_MyChampion : "all");
            lstrcatA(mb, h);
            for (int i = 0; i < g_MatCount; ++i) {
                if (lstrlenA(mb) > 19000) break;
                lstrcatA(mb, g_MatNames[i]); lstrcatA(mb, "\r\n");
            }
            CopyClip(mb);
        }
        ImGui::Checkbox("Only MY champion's textures", &g_MatsMyChampOnly);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(
            "The lists used to show every loaded material, so on Maeve you got\n"
            "Pip, Cassie and Fernando arms. Another champion's material will not\n"
            "look right on your model.\n\n"
            "Universal overlays (burncard etc) are always shown either way.");
        ImGui::Text("%s   body slots: %d", g_MatStatus, g_BodySlots);
        ImGui::TextColored(Ink(ImVec4(1.0f, 1.0f, 0.5f, 1.0f)), "%s", g_VariantStatus);

        ImGui::PushItemWidth(90);
        ImGui::InputInt("Slot", &g_MatSlot);
        ImGui::PopItemWidth();
        ImGui::SameLine();
        ImGui::TextDisabled("Slot 0 is the one that shows. Left=body, right=weapon - they stay separate.");

        // SPLIT: body textures go on the body, weapon textures go on the weapon.
        ImGui::Columns(2, "matcols2", true);
        ImGui::TextColored(Ink(ImVec4(0.6f, 1.0f, 0.7f, 1.0f)), "BODY textures");
        ImGui::BeginChild("bodymats2", ImVec2(0, 130), true);
        for (int i = 0; i < g_MatCount; ++i) {
            if (!IsBodyMaterial(g_MatNames[i])) continue;
            if (!MatPassesChampFilter(g_MatNames[i])) continue;
            char lbl[128]; wsprintfA(lbl, "%s##bm2_%d", g_MatNames[i], i);
            if (ImGui::Selectable(lbl)) g_PendingManualMat = i;   // -> body
        }
        ImGui::EndChild();
        ImGui::NextColumn();
        ImGui::TextColored(Ink(ImVec4(0.6f, 0.85f, 1.0f, 1.0f)), "WEAPON textures");
        ImGui::BeginChild("wepmats2", ImVec2(0, 130), true);
        for (int i = 0; i < g_MatCount; ++i) {
            if (!IsWeaponMaterial(g_MatNames[i])) continue;
            if (!MatPassesChampFilter(g_MatNames[i])) continue;
            char lbl[128]; wsprintfA(lbl, "%s##wm2_%d", g_MatNames[i], i);
            if (ImGui::Selectable(lbl)) g_PendingWeaponMat = i;   // -> weapon, not body
        }
        ImGui::EndChild();
        ImGui::Columns(1);

        DrawUniversalOverlays("res");

        // ARMS / HANDS textures — its own FULL-WIDTH box, directly under the
        // weapon box. It was previously squeezed into a third column and was
        // effectively invisible. These exist for every skin
        // (mic_pc_maeve_arms_skin09a, _skin03a, ...) but matched no filter before:
        // IsBodyMaterial EXCLUDES "_arms_" and IsWeaponMaterial only matches
        // "wep". They apply to m_HandsMesh, not the body.
        ImGui::Spacing();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)), "ARMS / HANDS textures (first person)");
        ImGui::BeginChild("armsmats2", ImVec2(0, 130), true);
        {
            int armsShown = 0;
            for (int i = 0; i < g_MatCount; ++i) {
                if (!IsArmsMaterial(g_MatNames[i])) continue;
                armsShown++;
                char lbl[128]; wsprintfA(lbl, "%s##am2_%d", g_MatNames[i], i);
                if (ImGui::Selectable(lbl)) g_PendingArmsMat = i;   // -> m_HandsMesh
            }
            if (armsShown == 0)
                ImGui::TextDisabled("None found - press SCAN MATERIALS (they are named *_arms_*).");
        }
        ImGui::EndChild();
        ImGui::SetNextItemWidth(90);
        ImGui::InputInt("arms slot", &g_ArmsMatSlot);
        ImGui::SameLine();
        ImGui::TextDisabled("body / weapon / arms are three separate targets.");

        if (g_MatCount == 0) ImGui::TextDisabled("Press SCAN MATERIALS.");
        if (g_TargetOwnMatCount == 0) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.7f, 0.4f, 1.0f)),
                "That mesh has NO own materials - clearing makes it blank. We'd need to");
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.7f, 0.4f, 1.0f)),
                "load the skin's materials from its package. Copy this + tell me.");
        }

        ImGui::Checkbox("Allow cross-champion meshes (WILL CRASH)", &allowCrossChampion);
        ImGui::SameLine();
        ImGui::Checkbox("show nogeo/invisible", &showNoGeo);

        ImGui::Separator();
        ImGui::Text("Real body : %s", g_OriginalName);
        ImGui::Text("Now       : %s", g_LiveName);
        ImGui::Text("Applies   : %d   Weapon paired last: %s",
                    g_ApplyCount, g_LastWeaponPaired ? "yes" : "no");
        ImGui::TextWrapped("If the mesh changes but the colours look off, the MESH swapped but the "
            "materials didn't - still progress. If a skin looks 'stacked/weird', that's just how "
            "some old/removed skins look, not two skins at once.");
    }
}
