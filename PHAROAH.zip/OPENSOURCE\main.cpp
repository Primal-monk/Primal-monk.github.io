// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include <map>
#include <mutex>
#include <vector>
#include <windows.h>
#include <wininet.h>
#include <regex>
#include <chrono>
#include <d3d11.h>
#include <detours.h>
#include <cstdarg>   // InitLog

#include "ext/ImGUI/imgui.h"
#include "ext/ImGUI/imgui_impl_dx11.h"
#include "ext/ImGUI/imgui_impl_win32.h"

#include "memory_manager.h"
#include "spoofer/return_spoofer.h"
#include "globals.h"
#include "ext/kiero/kiero.h"
#include "menus/EquipEmoteMenu.h"
#include "Utils/Helper.h"
#include "UI/Style.h"

#include "menus/FireModeMenu.h"
#include "menus/VisibilityBoxes.h"
#include "menus/Silhouette.h"
#include "menus/ColorGrading.h"
#include "menus/RecoverySuite.h"
#include "menus/CallLogger.h"

int g_IsSimulatingInput = 0;
bool g_bShowMenu = true; // toggled with INSERT — hidden by default frees your mouse/aim
bool g_ShowFPS = true;

// Per-feature toggles — start OFF so you can enable one at a time and isolate
// which one (if any) causes a crash, instead of everything running at once.
bool g_bEnableFireMode = false;
bool g_bEnableTalent = false;
bool g_bEnableEmote = false;

float g_UIScale = 1.0f; // 1.0 = normal, 0.5 = half size

// CRASH FIX (ImGui assertion: WindowBorderHoverPadding > 0.0f).
// The old version called ScaleAllSizes(ratio) repeatedly, compounding on top of
// the already-scaled style. Shrinking a few times drove small style values to
// zero, and ImGui asserts on some of them being <= 0. Worse, it's lossy — those
// values never come back when you scale up again.
//
// Fix: snapshot the pristine style ONCE, then always rebuild from that snapshot
// and scale it a single time. No compounding, fully reversible.
// Set by ApplyUIScale, consumed once by the PHAROAH window on the next frame.
// 0 = nothing pending.
//
// Scaling the STYLE only ever changed fonts and padding - the window itself
// stayed the same size, so "50%" gave you tiny text rattling around in the same
// big box. The window has to be resized by the same ratio for the whole tool to
// actually get smaller, and only the window that owns itself can do that, hence
// the handoff instead of doing it here.
float g_PendingWindowScaleRatio = 0.0f;

void ApplyUIScale(float newScale) {
    static ImGuiStyle baseStyle;
    static bool baseCaptured = false;
    if (!baseCaptured) { baseStyle = ImGui::GetStyle(); baseCaptured = true; }

    if (newScale < 0.4f) newScale = 0.4f;
    if (newScale > 2.5f) newScale = 2.5f;

    // Ratio against where we ARE, so repeated 10% steps compound correctly.
    if (g_UIScale > 0.0001f && newScale != g_UIScale)
        g_PendingWindowScaleRatio = newScale / g_UIScale;

    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4 savedColors[ImGuiCol_COUNT];
    memcpy(savedColors, style.Colors, sizeof(savedColors)); // keep the current theme

    style = baseStyle;              // back to pristine geometry
    style.ScaleAllSizes(newScale);  // scale once, from clean values
    memcpy(style.Colors, savedColors, sizeof(savedColors)); // restore theme colors

    ImGui::GetIO().FontGlobalScale = newScale;
    g_UIScale = newScale;
}

void RenderControlPanel() {
    ImGui::SetNextWindowPos(ImVec2(15, 15), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(260, 0), ImGuiCond_FirstUseEver);

    if (!ImGui::Begin("Control Panel")) { ImGui::End(); return; }

    ImGui::Text("Enable one at a time to isolate crashes:");
    ImGui::Separator();
    ImGui::Checkbox("Fire Mode Panel", &g_bEnableFireMode);
    ImGui::Checkbox("Talent Selection Panel", &g_bEnableTalent);
    ImGui::Checkbox("Emote Menu", &g_bEnableEmote);

    ImGui::Separator();
    ImGui::Text("UI Size:");
    if (ImGui::Button("100%")) ApplyUIScale(1.0f);
    ImGui::SameLine();
    if (ImGui::Button("75%")) ApplyUIScale(0.75f);
    ImGui::SameLine();
    if (ImGui::Button("50%")) ApplyUIScale(0.5f);

    ImGui::Separator();
    ImGui::TextDisabled("INSERT = show/hide everything");

    ImGui::End();
}

uintptr_t xorKey;

typedef HRESULT(__stdcall* IDXGISwapChain_Present_t)(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags);
typedef HRESULT(__stdcall* IDXGISwapChain_ResizeBuffers_t)(IDXGISwapChain* pSwapChain, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT NewFormat, UINT SwapChainFlags);

IDXGISwapChain_Present_t oPresent = nullptr;
WNDPROC oWndProc;
HWND window = NULL;
ID3D11Device* pDevice = nullptr;
ID3D11DeviceContext* pContext = nullptr;
ID3D11RenderTargetView* mainRenderTargetView = nullptr;
IDXGISwapChain_ResizeBuffers_t oResizeBuffers = nullptr;

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// ===== AIM FEATURES =====
namespace AimFeatures {
    static SDK::UFunction* getAdjustedAimNativeFunc = nullptr;

    struct GetAdjustedAimNative_Params {
        class SDK::ATgDevice* Weapon;
        SDK::FVector StartFireLoc;
        SDK::FRotator Rotation;
    };

    // Calculate distance between two 3D points
    inline float Distance3D(const SDK::FVector& a, const SDK::FVector& b) {
        float dx = a.X - b.X, dy = a.Y - b.Y, dz = a.Z - b.Z;
        return sqrtf(dx*dx + dy*dy + dz*dz);
    }

    // Rotation math: convert yaw/pitch to direction and back
    inline SDK::FVector RotationToDirection(const SDK::FRotator& rot) {
        float pitchRad = rot.Pitch * (3.14159265f / 32768.0f);
        float yawRad = rot.Yaw * (3.14159265f / 32768.0f);
        return SDK::FVector{
            cosf(pitchRad) * cosf(yawRad),
            cosf(pitchRad) * sinf(yawRad),
            sinf(pitchRad)
        };
    }

    inline SDK::FRotator DirectionToRotation(const SDK::FVector& dir) {
        float yaw = atan2f(dir.Y, dir.X) * (32768.0f / 3.14159265f);
        float pitch = asinf(dir.Z) * (32768.0f / 3.14159265f);
        return SDK::FRotator{ (int)pitch, (int)yaw, 0 };
    }

    // Simple magnet: reduce rotation distance from center
    inline void ApplyAimMagnet(SDK::FRotator& rotation, float magnetX, float magnetY) {
        if (magnetX < 1.01f && magnetY < 1.01f) return;
        float pullStrength = 0.02f;
        if (magnetX > 1.01f) rotation.Yaw *= (1.0f - pullStrength * (magnetX - 1.0f));
        if (magnetY > 1.01f) rotation.Pitch *= (1.0f - pullStrength * (magnetY - 1.0f));
    }

    // Head lock: aim directly at enemy head bone position
    inline void ApplyHeadLock(SDK::FRotator& rotation, const SDK::FVector& startPos, SDK::ATgPawn* targetPawn) {
        if (!targetPawn || !targetPawn->m_HeadMesh) return;
        SDK::FVector headPos = targetPawn->m_HeadMesh->GetBoneLocation(targetPawn->m_HeadShotBoneName, 0);
        SDK::FVector dir = (headPos - startPos);
        float len = sqrtf(dir.X*dir.X + dir.Y*dir.Y + dir.Z*dir.Z);
        if (len > 1.0f) {
            dir.X /= len; dir.Y /= len; dir.Z /= len;
            rotation = DirectionToRotation(dir);
        }
    }

    // Projectile prediction: calculate lead for slow-moving projectiles
    inline void ApplyProjectilePrediction(SDK::FRotator& rotation, const SDK::FVector& startPos, SDK::ATgPawn* targetPawn, float projectileSpeed) {
        if (!targetPawn || projectileSpeed < 100.0f) return;

        SDK::FVector targetVel = targetPawn->Velocity;
        SDK::FVector targetPos = targetPawn->Location;

        // Estimate where target will be when projectile reaches them
        float distToTarget = Distance3D(startPos, targetPos);
        float timeToTarget = distToTarget / projectileSpeed;

        // Predicted position = current position + velocity * time
        SDK::FVector predictedPos = targetPos;
        predictedPos.X += targetVel.X * timeToTarget * 0.5f; // dampen for stability
        predictedPos.Y += targetVel.Y * timeToTarget * 0.5f;
        predictedPos.Z += targetVel.Z * timeToTarget * 0.5f;

        SDK::FVector dir = (predictedPos - startPos);
        float len = sqrtf(dir.X*dir.X + dir.Y*dir.Y + dir.Z*dir.Z);
        if (len > 1.0f) {
            dir.X /= len; dir.Y /= len; dir.Z /= len;
            rotation = DirectionToRotation(dir);
        }
    }

    // Isolated: NO C++ objects in scope, only POD types. Safe to call from __try.
    inline void ProcessAimHook_Isolated(AimFeatures::GetAdjustedAimNative_Params* params) {
        if (!params || !params->Weapon || !Globals::LocalPawn) return;

        if (RecoverySuite::headLockEnabled) {
            // THE ACTUAL BUG behind "locks a totally different enemy the
            // moment I fire": this hook computes the real shot's aim
            // adjustment, completely separately from RecoverySuite::
            // ProcessAimAssist()'s cosmetic camera nudge (which already picks
            // correctly, by screen distance to the cursor). This hook used to
            // walk the pawn list itself and grab whichever enemy happened to
            // be first — arbitrary engine order, nothing to do with where you
            // were aiming. Now it prefers the SAME target ProcessAimAssist()
            // already picked (published in g_FireGatedLockedTarget every
            // frame it has one).
            //
            // CRASH-HARDENING NOTE: g_FireGatedLockedTarget is a pointer
            // cached on a DIFFERENT thread, possibly several frames old by
            // the time it's read here — it must never be dereferenced
            // directly (that was the original version of this fix, and it
            // was a real risk: a stale pointer into a pawn destroyed since).
            // It is now ONLY ever compared by address against pawns this
            // exact walk just freshly discovered as genuinely alive right
            // now — so a stale/dangling value simply fails to match instead
            // of ever being read through. Falls back to the first valid
            // enemy found, same as the original behaviour, if the preferred
            // target isn't in this frame's live list at all.
            SDK::ATgPawn* preferred = RecoverySuite::g_FireGatedLockedTarget;
            SDK::ATgPawn* chosen = nullptr;
            if (Globals::LocalPawn) {
                SDK::APawn* pawn = ((SDK::ATgPawn*)Globals::LocalPawn)->WorldInfo->PawnList;
                while (pawn) {
                    SDK::ATgPawn* tgPawn = (SDK::ATgPawn*)pawn;
                    if (pawn != Globals::LocalPawn && !pawn->bDeleteMe && pawn->IsA(SDK::ATgPawn::StaticClass())) {
                        int myTeam = -1, theirTeam = -1;
                        if (((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo) {
                            SDK::ATgRepInfo_Player* myPri = (SDK::ATgRepInfo_Player*)((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo;
                            if (myPri->r_TaskForce) myTeam = myPri->r_TaskForce->TeamIndex;
                        }
                        if (tgPawn->PlayerReplicationInfo && ((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo) {
                            SDK::ATgRepInfo_Player* priThem = (SDK::ATgRepInfo_Player*)tgPawn->PlayerReplicationInfo;
                            if (priThem->r_TaskForce) theirTeam = priThem->r_TaskForce->TeamIndex;
                            if (priThem->r_nHealthCurrent > 0 && theirTeam != myTeam && theirTeam != -1) {
                                if (tgPawn == preferred) { chosen = tgPawn; break; } // confirmed alive THIS frame — safe to use
                                if (!chosen) chosen = tgPawn; // first valid candidate, kept as fallback
                            }
                        }
                    }
                    pawn = pawn->NextPawn;
                }
            }
            if (chosen) {
                AimFeatures::ApplyHeadLock(params->Rotation, params->StartFireLoc, chosen);
            }
        }
        else if (false) {  // projectilePredictionEnabled removed
            if (Globals::LocalPawn) {
                SDK::APawn* pawn = ((SDK::ATgPawn*)Globals::LocalPawn)->WorldInfo->PawnList;
                while (pawn) {
                    SDK::ATgPawn* tgPawn = (SDK::ATgPawn*)pawn;
                    if (pawn != Globals::LocalPawn && !pawn->bDeleteMe && pawn->IsA(SDK::ATgPawn::StaticClass())) {
                        int myTeam = -1, theirTeam = -1;
                        if (((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo) {
                            SDK::ATgRepInfo_Player* myPri = (SDK::ATgRepInfo_Player*)((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo;
                            if (myPri->r_TaskForce) myTeam = myPri->r_TaskForce->TeamIndex;
                        }
                        if (tgPawn->PlayerReplicationInfo && ((SDK::ATgPawn*)Globals::LocalPawn)->PlayerReplicationInfo) {
                            SDK::ATgRepInfo_Player* priThem = (SDK::ATgRepInfo_Player*)tgPawn->PlayerReplicationInfo;
                            if (priThem->r_TaskForce) theirTeam = priThem->r_TaskForce->TeamIndex;
                            if (priThem->r_nHealthCurrent > 0 && theirTeam != myTeam && theirTeam != -1) {
                                AimFeatures::ApplyProjectilePrediction(params->Rotation, params->StartFireLoc, tgPawn, 1500.0f);
                                break;
                            }
                        }
                    }
                    pawn = pawn->NextPawn;
                }
            }
        }
        else {
            AimFeatures::ApplyAimMagnet(params->Rotation, RecoverySuite::aimAssistX, RecoverySuite::aimAssistY);
        }
    }
}

void HookedProcessEvent(void* pObject, void* pFunction, void* pParms, __int64 pResult) {

    // REENTRANCY GUARD in its own scope — ends before __try below
    {
        static thread_local int recursionDepth = 0;
        struct DepthGuard {
            DepthGuard() { recursionDepth++; }
            ~DepthGuard() { recursionDepth--; }
        } depthGuard;

        if (recursionDepth > 1) {
            // We're inside our own nested call — skip all custom logic, just
            // pass through to the real engine function and return immediately.
            ProcessEventOriginal((SDK::UObject*)pObject, (SDK::UFunction*)pFunction, pParms, pResult);
            return;
        }
    } // DepthGuard scope ends here, destructor runs

    // MAJOR PERFORMANCE FIX: ProcessEvent fires for the ENTIRE game's script
    // logic, potentially thousands of times per frame — not just our stuff.
    // The old code called GetFullName() (allocates a new string, walks the
    // object hierarchy) on every single one of those calls just to check if
    // it happened to be the one function we care about. That's thousands of
    // string allocations per frame, constantly, just from being injected —
    // this is almost certainly the real cause of "FPS tanked just from
    // injecting, before touching anything." Fixed: find the target function
    // ONCE and compare raw pointers from then on (near-zero cost) instead of
    // building and comparing strings on every single call.
    // ========================================================================
    // MAJOR BUG FIX. This FindObject lookup was returning null (or a different
    // object than the one actually dispatched), so `pFunction == postRenderFunc`
    // was NEVER true and this entire block never ran — not once. Proven by the
    // safe-thread heartbeat reading 0 and g_EffectsSafe reading 0 while in a
    // live match with a valid pawn.
    //
    // Consequences, all now explained: every DEFERRED action silently never
    // fired (respawn, Octavia buffs, item shop, ServerSetValue/Exec probes, card
    // requests), and moving grayscale to "the safe thread" appeared to break it
    // because that thread's work was never executing. Render-thread features
    // (boxes, reticle, view turn) were unaffected, which is why anything worked
    // at all.
    //
    // Fix: match on the function's NAME rather than a full-path string lookup.
    // The Call Logger already resolves names reliably this way — and it logged
    // "PostRender x33357", proving the function is dispatched constantly. Names
    // are resolved once per unique UFunction* and cached by pointer, so the hot
    // path stays a pointer compare (no per-call string work — that was the
    // original, valid reason for avoiding GetFullName here).
    // ========================================================================
    // FIX #2. The previous version tried FindObject first and only fell back to
    // name matching when it returned NULL. But it returned a NON-NULL, WRONG
    // UFunction — so the fallback never triggered, `pFunction == postRenderFunc`
    // never matched, and the heartbeat stayed 0 while the UI cheerfully reported
    // "anchor found: YES". That combination is what gave it away.
    //
    // FindObject is now abandoned entirely for this. We identify PostRender
    // purely by the name on the LIVE dispatch, which is guaranteed correct
    // because it's the object actually being called. Costs one name lookup per
    // call until the first PostRender arrives (within the first frame), then
    // it's a pointer compare forever.
    // ========================================================================
    // THE INJECTION-TIMING BUG (root cause of "worked once, never again")
    //
    // "PostRender" is NOT a unique function name — several classes define one.
    // The previous version latched onto the FIRST UFunction named PostRender it
    // ever saw and cached that pointer forever. Consequences:
    //
    //   inject at the MAIN MENU -> latches the menu's PostRender. Heartbeat
    //   climbs while you're in menus, then that object STOPS being dispatched
    //   once you're in a match. Heartbeat freezes (the reported "1675 and not
    //   climbing") and every deferred feature silently dies.
    //
    //   inject AFTER spawning -> latches the in-match one, everything works.
    //
    // That is why respawn, health bar recolouring, Octavia shields and the
    // pickups all "worked once and never again" — it was never the features, it
    // was which PostRender we happened to bind to.
    //
    // FIX: don't bind to one forever. Recognise ANY function named PostRender
    // (verdict cached per pointer, so the hot path stays a cheap compare), and
    // prefer whichever one is CURRENTLY being dispatched. If the preferred one
    // goes quiet for 500ms, switch to another live one. That makes injection
    // timing irrelevant and survives menu <-> match transitions in both
    // directions.
    // ========================================================================
    static const int kPRCache = 512;
    static SDK::UFunction* prKey[kPRCache] = {};
    static unsigned char   prVal[kPRCache] = {};   // 1 = not PostRender, 2 = PostRender
    static SDK::UFunction* prPreferred = nullptr;
    static ULONGLONG       prPreferredLastMs = 0;
    static int             prDistinctSeen = 0;

    bool isPostRender = false;
    {
        size_t slot = (((size_t)pFunction) >> 4) % kPRCache;
        size_t start = slot;
        while (true) {
            if (prKey[slot] == pFunction) { isPostRender = (prVal[slot] == 2); break; }
            if (prKey[slot] == nullptr) {
                char nm[80];
                CallLogger::TryCopyFuncName((SDK::UFunction*)pFunction, nm, sizeof(nm));
                unsigned char v = 1;
                if (nm[0] && _stricmp(nm, "PostRender") == 0) { v = 2; prDistinctSeen++; }
                prKey[slot] = (SDK::UFunction*)pFunction;
                prVal[slot] = v;
                isPostRender = (v == 2);
                break;
            }
            slot = (slot + 1) % kPRCache;
            if (slot == start) break; // cache full — treat as uninteresting
        }
    }

    bool runSafeBlock = false;
    if (isPostRender) {
        ULONGLONG nowMs = GetTickCount64();
        // Adopt this one if we have no preference, or the preferred one has gone
        // quiet (i.e. we changed context: menu -> match, match -> menu).
        if (prPreferred == nullptr || (nowMs - prPreferredLastMs) > 500) {
            prPreferred = (SDK::UFunction*)pFunction;
        }
        if (pFunction == prPreferred) {
            prPreferredLastMs = nowMs;
            runSafeBlock = true;   // exactly one PostRender drives the block per frame
        }
    }

    RecoverySuite::g_PostRenderResolved = (prPreferred != nullptr);
    RecoverySuite::g_PostRenderByName = true;
    RecoverySuite::g_PostRenderVariants = prDistinctSeen;

    // ===== BORDER COLOUR VIA RANGE INTERCEPT =====
    // The game colours enemy outlines by whether the target is inside the
    // weapon's effective range (in range = red, out of range = yellow — which is
    // why Drogoz's mode 2 shows yellow at all distances). Range is computed, not
    // stored, so we override the RESULT of the call instead of a field. Same
    // technique as the aim hook: let the original run, then rewrite pResult.
    if ((VisibilityBoxes::forceOutOfRangeBorders || VisibilityBoxes::forceInRangeBorders) && pResult) {
        static SDK::UFunction* withinRangeFn = nullptr;
        static bool triedResolve = false;
        if (!triedResolve) {
            triedResolve = true;
            withinRangeFn = SDK::UObject::FindObject<SDK::UFunction>("Function TgGame.TgDeviceFire.IsWithinEffectiveRange");
        }
        bool isTarget = (withinRangeFn && pFunction == withinRangeFn);
        if (!isTarget) {
            // Name fallback, for the same reason PostRender needed one — the
            // full-path lookup is not reliable in this SDK.
            char nm[80];
            CallLogger::TryCopyFuncName((SDK::UFunction*)pFunction, nm, sizeof(nm));
            isTarget = (nm[0] && _stricmp(nm, "IsWithinEffectiveRange") == 0);
        }
        if (isTarget) {
            // Let the engine compute its real answer first, then overwrite it.
            ProcessEventOriginal((SDK::UObject*)pObject, (SDK::UFunction*)pFunction, pParms, pResult);
            *(bool*)pResult = VisibilityBoxes::forceInRangeBorders ? true : false;
            VisibilityBoxes::g_RangeHookHits++;
            return; // already dispatched — must not fall through and call it twice
        }
    }

    // Diagnostic call logger — sees EVERY script call passing through the hook,
    // which is how we can record the game's own real function sequence (and
    // spot Client*-prefixed server replies to our RPCs). Cheap no-op unless
    // explicitly enabled in the Call Log tab.
    CallLogger::OnProcessEvent((SDK::UFunction*)pFunction);

    // SKIN CAPTURE: watch the game's OWN skin calls in the menu so we can read the
    // real classId / skinId / DEVICE id / DEVICE-SKIN id it uses. This is how we
    // learn the weapon parameters instead of guessing them.
    if (RecoverySuite::g_SkinsSystemEnabled && DevSkin::g_CaptureSkinCalls && pFunction && pParms) {
        // Pointers are resolved by the UI (DevSkin::ResolveSkinCaptureFns), never
        // here — no FindObject on the hot hook path at all now.
        SDK::UFunction* fnCCM = DevSkin::g_fnCapCCM;
        SDK::UFunction* fnCTM = DevSkin::g_fnCapCTM;
        SDK::UFunction* fnSS  = DevSkin::g_fnCapSS;
        // Broad net: also record ANY function whose name contains both "Skin" and
        // a lobby/model hint, so if the real call isn't one of the three above we
        // still find out what it actually is instead of silently capturing zero.
        if (DevSkin::g_CapWideNet && pFunction) {
            DevSkin::LogWideSkinCall((SDK::UFunction*)pFunction, pParms);
        }
        if (fnCCM && pFunction == fnCCM) {
            int v[5]; for (int i = 0; i < 5; ++i) v[i] = *(int*)((char*)pParms + i * 4);
            DevSkin::LogSkinCall("ChangeClassModel class,skin,device,devSkin,pedestal", v, 5);
        } else if (fnCTM && pFunction == fnCTM) {
            int v[6]; for (int i = 0; i < 6; ++i) v[i] = *(int*)((char*)pParms + i * 4);
            DevSkin::LogSkinCall("ChangeTeamModel friendly,idx,class,skin,device,devSkin", v, 6);
        } else if (fnSS && pFunction == fnSS) {
            int v[2]; v[0] = *(int*)pParms; v[1] = *(int*)((char*)pParms + 4);
            DevSkin::LogSkinCall("Lobby.SetSkin skin,deviceSkin", v, 2);
        }
    }

    // DEV-SHOP CAPTURE: the dev menu registers each of its entries through
    // AddCommand(Section, Command, DisplayName). Watching it dumps the hidden
    // developer item shop's real command strings straight out of the game.
    if (RecoverySuite::g_SkinsSystemEnabled && DevSkin::g_CaptureDevCommands && pFunction) {
        // Same rule: resolve only outside a match (see note above).
        static SDK::UFunction* addCmdFn = nullptr;
        static bool addCmdLookedUp = false;
        if (!addCmdLookedUp && !Globals::LocalPawn) {
            addCmdLookedUp = true;
            addCmdFn = SDK::UObject::FindObject<SDK::UFunction>(
                "Function TgClient.TgDevMenuMoviePlayer.AddCommand");
        }
        if (addCmdFn && pFunction == addCmdFn) {
            DevSkin::OnDevAddCommand(pParms);
        }
    }

    // ===== AIM ASSIST HOOKS =====
    // Checked outside try/except to avoid C2712 in presence of other objects in this function
    if (RecoverySuite::aimAssistEnabled || RecoverySuite::headLockEnabled) {
        if (!AimFeatures::getAdjustedAimNativeFunc) {
            AimFeatures::getAdjustedAimNativeFunc = SDK::UObject::FindObject<SDK::UFunction>("Function TgGame.TgPawn.GetAdjustedAimNative");
        }
        if (pFunction == AimFeatures::getAdjustedAimNativeFunc) {
            // Call isolated function without try/except wrapper here
            // The function itself is safe from crashes
            AimFeatures::ProcessAimHook_Isolated((AimFeatures::GetAdjustedAimNative_Params*)pParms);
        }
    }

    if (runSafeBlock) {
        bool inGame = Globals::initObjects();
        // Gate every periodic SCRIPTED effect on this. It flips false the instant
        // we leave a match, which is what stops grayscale's reapply from firing
        // at a controller that's mid-teardown (the match-end crash).
        RecoverySuite::g_EffectsSafe = inGame;
        if (!inGame) {
            exploits.selectedTalent = -1;
            Helpers::resetFirstEmoteToDefault();

            // CRASH FIX: these were pointing at devices that get destroyed
            // when you leave a match. Next frame's render would read freed
            // memory (this is what caused the Decrypt/GetName crash on
            // match transitions). Clear them the instant we detect we're
            // no longer in a match.
            g_ManualDevice = nullptr;
            g_ScanResults.clear();

            // Match ended: just stop tracking the forced device, don't write
            // to it — see the comment on RevertForcedFireModeIfAny for why a
            // write at this exact transition point was likely a use-after-free.
            RevertForcedFireModeIfAny();

            // Third person: just reset the toggle state for the new match.
            RecoverySuite::thirdPersonOn = false;
        }

        // Extra safety: also clear if your pawn itself changed (respawn,
        // champion switch, new match) even while technically still "in game" —
        // the old device pointer could still be dangling in these cases too.
        static SDK::APawn* lastSeenPawn = nullptr;
        if (Globals::LocalPawn != lastSeenPawn) {
            g_ManualDevice = nullptr;
            g_ScanResults.clear();
            lastSeenPawn = Globals::LocalPawn;

            // Death/respawn re-applies desaturation — the game itself clears it
            // when your pawn changes (dying, respawning, new match), which was
            // why grayscale kept silently turning itself back off. This call
            // happens on the SAME thread already inside ProcessEvent dispatch
            // (not the render thread), so it's a safe same-thread recursive
            // call under the reentrancy guard above, not a cross-thread race.
            if (RecoverySuite::grayscaleOn) {
                RecoverySuite::ApplyGrayscale(true);
            }
        }

        // The ONLY place that actually writes a fire-mode revert now — every
        // frame, while genuinely still in-game with a valid current weapon
        // reference. If the weapon changed (died/respawned/switched loadout),
        // the OLD device is still safely alive at this exact moment (unlike
        // at match-end), so writing to it here is safe.
        if (Globals::LocalWeapon) {
            RevertForcedFireModeIfWeaponChanged(Globals::LocalWeapon);
        }

        // RESPAWN FIX #2: the pawn-changed check above assumes a new pawn
        // object gets created on respawn, but this engine may just reuse the
        // SAME pawn object and reset its health instead — in that case
        // lastSeenPawn never changes, so the block above never fires, and
        // grayscale silently stayed off after the first death. This catches
        // that case directly: watch health go from <=0 back to >0.
        static int lastHealth = -1;
        if (Globals::LocalPawn) {
            SDK::ATgPawn* myPawn = (SDK::ATgPawn*)Globals::LocalPawn;
            if (myPawn->PlayerReplicationInfo) {
                SDK::ATgRepInfo_Player* pri = (SDK::ATgRepInfo_Player*)myPawn->PlayerReplicationInfo;
                int health = pri->r_nHealthCurrent;
                if (lastHealth <= 0 && health > 0 && RecoverySuite::grayscaleOn) {
                    RecoverySuite::ApplyGrayscale(true); // just respawned, reapply
                }
                lastHealth = health;
            }
        }

        // PERFORMANCE + CRASH SURFACE: this rebuilds the entire talent list
        // from scratch and walks the HUD/scene-stack chain every single
        // frame. The comment here used to say "only run while the menu is
        // shown," but the actual gate was just g_bShowMenu — meaning it ran
        // on EVERY tab, not just Talents. Tightened to the tab actually
        // showing this data: fewer needless allocations per frame, and less
        // time spent touching a pointer chain that's briefly unsafe during a
        // real match transition (see Utils/Helper.h's isolated accessors).
        if (g_bShowMenu && RecoverySuite::activeSection == RecoverySuite::Section::Talents) {
            Helpers::CacheTalentInfos();
        }

        // CONCLUSION after testing: every PERIODIC scripted call (grayscale
        // reapply, silhouette, box/head gather, LOS check) silently fails to
        // take effect when called from here (inside HookedProcessEvent /
        // PostRender), even ones with zero camera dependency like grayscale —
        // so it's not specifically about camera/view timing, something about
        // this call site in general doesn't work for periodic scripted calls.
        // All periodic calls live in hkPresent now, accepting the same
        // throttled residual crash risk across the board rather than
        // features that just silently don't work. The ONE-SHOT toggles below
        // (F4 reset, outline master toggle) stay here since THOSE were the
        // ones directly tied to reproduced instant crashes, and being one-off
        // rather than periodic, moving them doesn't carry the same "silently
        // broken" risk.
        RecoverySuite::ProcessPendingSafeResets();
        Silhouette::ProcessPendingMasterToggle();
        VisualEffects::ProcessPendingEffects(); // one-shot triggers, same safe pattern as the toggles above
        Testing::ProcessPendingSafeActions(); // pickup ApplyEffect / Commander passive trigger — same fix
        CallLogger::PollState(); // always-on state watcher (self-throttled to ~3x/sec)
        RecoverySuite::ProcessPendingTurn(); // controller view-turn, scripted call so it runs here not on the render thread
        // ProcessAimAssist() removed from here — it's a plain raw field write
        // (SetLookAxes), not a scripted call, so unlike ProcessPendingTurn it
        // doesn't need this thread. Calling it here TOO, alongside hkPresent,
        // meant it could run many times per rendered frame (this hook fires
        // for essentially every scripted call, not once per frame), each time
        // writing an unsmoothed direction — the likely source of warpy/jittery
        // aim-lock movement. Now only called once per frame, from hkPresent,
        // same as trigger bot's UpdateAutoFire().

    }

    ProcessEventOriginal((SDK::UObject*) pObject, (SDK::UFunction*) pFunction, pParms, pResult);
}

// AUTO-FIRE FIX: GetAsyncKeyState(VK_LBUTTON) was being used to detect "is
// the user physically holding left click" — but our OWN synthetic clicks
// update that exact same OS key-state, so right after our first synthetic
// release, Windows reports the button as "up" even though the real finger
// never moved, breaking hold-detection after one pulse (this is what looked
// like "it holds the button down" — the repeat loop was actually getting
// confused about whether it was still being held). Fixed by tracking the
// REAL hold state from actual window messages instead, tagging our own
// synthetic input with a marker so it's never mistaken for real input.
ULONG_PTR kAutoFireExtraInfoTag = 0x50414C41; // "PALA" - arbitrary marker
bool g_RealLButtonHeld = false;
bool g_LButtonClickedThisFrame = false;

// ============================================================================
// WHY WNDPROC MESSAGES GET QUEUED INSTEAD OF HANDED TO IMGUI DIRECTLY
// ============================================================================
// WndProc runs on whatever thread owns the game window's message pump - the
// GAME thread. hkPresent (and everything ImGui does inside it - NewFrame,
// Render, the whole draw) runs on the RENDER thread. Paladins is UE3 with
// threaded rendering, so those are two different threads.
//
// ImGui_ImplWin32_WndProcHandler used to be called straight from WndProc,
// which means AddMousePosEvent/AddKeyEvent/etc were mutating
// g.InputEventsQueue (a plain, non-thread-safe ImVector) from the game
// thread while ImGui::NewFrame() drains and clears that SAME vector on the
// render thread, every frame, completely unsynchronized. That is a textbook
// data race, and it is exactly what crashed: FindLatestInputEvent() reading
// g.InputEventsQueue[n] (imgui.cpp:1735, called from AddMousePosEvent) while
// the vector's Size/Data were mid-mutation on the other thread. Confirmed
// from PRIMAL_MONKE's crash reports - one stack traced straight through
// WndProc -> ImGui_ImplWin32_WndProcHandler -> AddMousePosEvent ->
// FindLatestInputEvent -> ImVector::operator[] crash; a second, differently-
// shaped crash with no PHAROAH symbols at all is consistent with the same
// race corrupting the heap and something unrelated tripping over it moments
// later - "different crash paths, shared underlying component," which is
// exactly what a race like this looks like from the outside.
//
// This bug always existed - it just took enough mouse traffic through
// WndProc to open the window reliably, which is exactly what interacting
// with the new talent/emote combo boxes does far more of than idle tabs.
//
// Fix: WndProc no longer touches ImGui at all except reading io flags it
// already read before (last-frame values, same as always - see the
// WantCaptureMouse/Keyboard block below, unchanged). Raw messages are
// queued here and replayed into ImGui_ImplWin32_WndProcHandler on the
// RENDER thread, right before ImGui_ImplDX11_NewFrame(), so ImGui's input
// queue is only ever touched from one thread.
struct QueuedWinMsg { HWND hWnd; UINT msg; WPARAM wParam; LPARAM lParam; };
std::mutex g_WinMsgQueueMutex;
std::vector<QueuedWinMsg> g_WinMsgQueue;

LRESULT __stdcall WndProc(const HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

    {
        std::lock_guard<std::mutex> lock(g_WinMsgQueueMutex);
        g_WinMsgQueue.push_back({ hWnd, uMsg, wParam, lParam });
    }

    // Suppress the OS cursor while the menu is open. We draw our own pyramid,
    // and without this you get TWO cursors: ours plus the white system arrow
    // the game lets through once the overlay is taking input. Answering
    // WM_SETCURSOR with a NULL cursor is the clean way to do it - it does not
    // touch the ShowCursor refcount, which the game also manipulates and would
    // fight us over.
    if (uMsg == WM_SETCURSOR && g_bShowMenu) {
        SetCursor(nullptr);
        return TRUE;
    }

    if (GetMessageExtraInfo() != kAutoFireExtraInfoTag) {
        if (uMsg == WM_LBUTTONDOWN) {
            g_RealLButtonHeld = true;
            g_LButtonClickedThisFrame = true;
        }
        else if (uMsg == WM_LBUTTONUP) {
            g_RealLButtonHeld = false;
        }
    }

    // No clicking through / Typing through.
    //
    // HARD GUARD: only ever swallow input while the overlay is actually SHOWN.
    // Without this, a text field (e.g. the skins "champion filter" InputText) that
    // still holds ImGui focus keeps io.WantCaptureKeyboard true after the overlay
    // is hidden — and every keystroke gets eaten, so WASD, the item shop and every
    // bind stop responding with no visible menu to explain it. Requiring
    // g_bShowMenu makes that state impossible to get stuck in.
    if (ImGui::GetCurrentContext() && g_bShowMenu) {
        ImGuiIO& io = ImGui::GetIO();

        if (io.WantCaptureKeyboard && g_IsSimulatingInput <= 0) {
            switch (uMsg) {
            case WM_KEYDOWN:
            case WM_SYSKEYDOWN:
            case WM_KEYUP:
            case WM_SYSKEYUP:
            case WM_CHAR:
            case WM_IME_CHAR:
                return true;
            }
        }

        if (io.WantCaptureMouse) {
            switch (uMsg) {
                case WM_LBUTTONDOWN:
                case WM_LBUTTONUP:
                case WM_LBUTTONDBLCLK:
                case WM_RBUTTONDOWN:
                case WM_RBUTTONUP:
                case WM_RBUTTONDBLCLK:
                case WM_MBUTTONDOWN:
                case WM_MBUTTONUP:
                case WM_MBUTTONDBLCLK:
                case WM_MOUSEWHEEL:
                case WM_MOUSEHWHEEL:
                    return true;
            }
        }
    }

    return CallWindowProcW(oWndProc, hWnd, uMsg, wParam, lParam);
}

bool init = false;
HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags) {
    if (!init)
    {
        if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)& pDevice)))
        {
            pDevice->GetImmediateContext(&pContext);
            DXGI_SWAP_CHAIN_DESC sd;
            pSwapChain->GetDesc(&sd);
            window = sd.OutputWindow;

            ImGui::CreateContext();
            ImGuiIO& io = ImGui::GetIO();
            io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange | ImGuiConfigFlags_NavEnableKeyboard;

            ImGui_ImplWin32_Init(window);
            ImGui_ImplDX11_Init(pDevice, pContext);

            // Load the real PHAROAH logo into a D3D texture. Done here because
            // this is the one place a valid ID3D11Device is guaranteed. It tries
            // once; on failure the menu falls back to the drawn vector glyph, so a
            // missing file can never cost us the header.
            LogoTexture::EnsureLoaded(pDevice);
            io.BackendFlags |= ImGuiBackendFlags_RendererHasVtxOffset;

            ImFontConfig config;
            config.OversampleH = 2;
            config.OversampleV = 2;
            config.PixelSnapH = true;
            io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\segoeui.ttf", 15.0f, &config, io.Fonts->GetGlyphRangesDefault()); // regular weight, not bold — thinner look

            ApplyModernStyle();

            oWndProc = (WNDPROC)SetWindowLongPtrW(window, GWLP_WNDPROC, (LONG_PTR)WndProc);

            init = true;
        }
        else
            return oPresent(pSwapChain, SyncInterval, Flags);
    }

    if (!mainRenderTargetView) {
        ID3D11Texture2D* pBackBuffer;
        pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)& pBackBuffer);
        pDevice->CreateRenderTargetView(pBackBuffer, NULL, &mainRenderTargetView);
        pBackBuffer->Release();
    }

    // Edge-triggered toggles: INSERT or F3 both show/hide. F4 resets everything.
    {
        static bool insertWasDown = false, f3WasDown = false, f4WasDown = false;

        // DO NOT FIRE HOTKEYS WHILE THE USER IS TYPING.
        //
        // These read raw OS key state, which does not care that an ImGui text
        // box has focus. Typing a 9 into the notes panel therefore toggled
        // grayscale - that is the "grayscale turned on for no reason" - and
        // typing F4 silently reset every setting in the tool.
        //
        // WantTextInput is true only while a text field is actually focused, so
        // this blocks nothing during normal play.
        const bool typing = ImGui::GetCurrentContext() && ImGui::GetIO().WantTextInput;

        bool insertDown = !typing && (GetAsyncKeyState(VK_INSERT) & 0x8000) != 0;
        bool f3Down     = !typing && (GetAsyncKeyState(VK_F3)     & 0x8000) != 0;
        bool f4Down     = !typing && (GetAsyncKeyState(VK_F4)     & 0x8000) != 0;

        if ((insertDown && !insertWasDown) || (f3Down && !f3WasDown)) {
            g_bShowMenu = !g_bShowMenu;
        }
        if (f4Down && !f4WasDown) {
            RecoverySuite::ResetAllToDefaults();
        }
        // GRAYSCALE HOTKEY: F9 by default, not the bare 9 key (9 is a GAME
        // key - pressing it in a match to pick a loadout slot used to toggle
        // grayscale too). Now rebindable (Themes tab -> Keybinds) since F9
        // clashes with Steam's own FPS-overlay bind on some setups - a
        // known, previously unfixed issue.
        if (!typing && RecoverySuite::g_BindGrayscaleKey != ImGuiKey_None &&
            ImGui::IsKeyPressed(RecoverySuite::g_BindGrayscaleKey, false)) {
            RecoverySuite::ApplyGrayscale(!RecoverySuite::grayscaleOn);
        }

        // User-configurable binds (Themes tab, "Keybinds"). Skipped while
        // typing (same rule as above) and while a bind is actively being
        // captured, so the keypress that finishes a rebind can't also fire
        // the old action on the same frame.
        if (!typing && !RecoverySuite::g_CapturingBindTarget && ImGui::GetCurrentContext()) {
            if (RecoverySuite::g_BindInstantRespawn != ImGuiKey_None &&
                ImGui::IsKeyPressed(RecoverySuite::g_BindInstantRespawn, false)) {
                RecoverySuite::g_PendingInstantRespawn = true;
            }
            if (RecoverySuite::g_BindCardsAutoToggle != ImGuiKey_None &&
                ImGui::IsKeyPressed(RecoverySuite::g_BindCardsAutoToggle, false)) {
                OdinSuite::g_AutoEnabled = !OdinSuite::g_AutoEnabled;
            }
            if (RecoverySuite::g_BindAimToggle != ImGuiKey_None &&
                ImGui::IsKeyPressed(RecoverySuite::g_BindAimToggle, false)) {
                RecoverySuite::magnetAimEnabled = !RecoverySuite::magnetAimEnabled;
            }
        }

        UpdateRGBThemeIfEnabled(); // pure color math, cheap, runs every frame when the RGB theme is on

        insertWasDown = insertDown;
        f3WasDown = f3Down;
        f4WasDown = f4Down;
    }

    // Replay this frame's queued WndProc messages HERE, on the render
    // thread, before touching ImGui at all — see the big comment above
    // WndProc for why. Swap-and-release the lock immediately rather than
    // holding it while calling into ImGui, so a WndProc call arriving
    // mid-replay (game thread) never blocks on it.
    {
        std::vector<QueuedWinMsg> drained;
        {
            std::lock_guard<std::mutex> lock(g_WinMsgQueueMutex);
            drained.swap(g_WinMsgQueue);
        }
        for (const QueuedWinMsg& m : drained) {
            ImGui_ImplWin32_WndProcHandler(m.hWnd, m.msg, m.wParam, m.lParam);
        }
    }

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    // ---- SOFTWARE CURSOR ----------------------------------------------
    // The game hides the OS cursor while you play, so with the menu open there
    // was nothing to aim with. MouseDrawCursor makes ImGui draw its own cursor
    // into the same draw list as the menu, which means it is always ON TOP of
    // the tool and disappears the instant the tool does - no OS cursor to
    // leak out, nothing left behind over the game.
    // We draw our OWN cursor below, so ImGui must not also draw its default one.
    ImGui::GetIO().MouseDrawCursor = false;

    ImGui::NewFrame();

    // Track the worst frame each second. A periodic hitch does not move the
    // FPS average, which is why users reported "stuttering but FPS says 50".
    Perf::Tick(ImGui::GetIO().DeltaTime);

    bool objectsReady = Globals::initObjects();
    VisibilityBoxes::GatherAndCache(); // moved back here — see HookedProcessEvent for why the ProcessEvent-thread version broke boxes entirely
    VisibilityBoxes::UpdateLosCacheOnePerFrame(); // moved back here too — LineOfSightTo produced no visible boxes at all from the safe thread
    VisibilityBoxes::RenderBoxes(); // runs regardless of menu visibility, gated internally by its own "enabled" checkbox
    VisibilityBoxes::RenderBoxesNoWalls(); // separate test feature, own toggle, reads the LOS cache only — no scripted calls here
    VisibilityBoxes::RenderTargetReticle(); // display-only crosshair colour feedback, no input simulation
    Silhouette::UpdateSilhouettes(); // moved back here too — same reason
    RecoverySuite::ForceGrayscaleIfEnabled(); // moved back here — the safe-thread experiment made it stop working entirely, not just crash less
    RecoverySuite::UpdateAutoFire(); // pure Win32 input simulation, no SDK calls — safe from any thread
    // View turn: plain field writes only (no ProcessEvent), so it runs here on
    // the render thread as well as from the ProcessEvent side. Writing it from
    // both points covers the case where the engine consumes the input axes
    // earlier in the frame than PostRender fires.
    RecoverySuite::ProcessPendingTurn();
    UpdateSuperDrogoz(); // raw field reads/writes only — no ProcessEvent calls
    Speeden::Update();   // raw field writes to GroundSpeed/AirSpeed/AccelRate, safe here
    // All three below are raw field reads/writes only. Anything scripted they need
    // is flagged here and dispatched from RunSafeThreadSubsystems on the
    // ProcessEvent thread — calling scripted functions from this thread is what
    // corrupted pawn state previously.
    // Runs here, NOT inside RecoverySuite::Render, because Render only happens
    // while the menu is visible. The unlocker has to work inject-and-forget with
    // the menu closed, the way Genji does. Self-throttled, and a no-op unless its
    // own switch is on.
    Unlocker::Tick();
    // Every-frame re-stamp of ONLY the local player's own verified/golden
    // objects. (The CDO write that used to be here was removed - it set the
    // CLASS DEFAULT, which verified every player including enemies, exactly
    // the "everyone has a checkmark" bug PRIMAL_MONKE saw on the scoreboard.)
    Unlocker::TickCheckmarkFast();
    // HOLD-unblur, if enabled. No-op otherwise. Must run every frame to beat
    // another DLL that re-applies the blur each frame.
    ColorGrading::Update();
    // Flush the notes scratchpad to disk if it changed and typing has settled.
    // Cheap: touches the disk only when there is something new to write.
    RecoverySuite::TickNotesAutosave();
    // Persist any changed setting a second after it settles.
    Persist::Tick();
    DirectFire::Tick();
    DirectFire::TickCards();   // card-slot spam; no-op unless a slot is ticked
    OdinSuite::Tick();    // ODIN auto-fire; no-op unless enabled   // no-op unless SPAM is ticked; must run with menu closed
    InstantReload::Update();  // scales m_fTotalReloadTime (not Net)
    VGSSpam::Update();        // reads c_nCurrentVGSPlaying to learn ids; queues sends
    CameraTools::Update();    // FOVAngle/DesiredFOV/DefaultFOV (none Net)
    // Gated by the skins master switch (default OFF). This ran every single frame
    // regardless of whether the Skins tab was ever opened — it writes raw mesh
    // pointers, walks GObjects on a timer and re-applies persistence, so a fault
    // here affected normal play. Off = not executed.
    if (RecoverySuite::g_SkinsSystemEnabled)
        MeshSkin::Update();  // raw mesh pointer write - no server involvement
    Crosshair::Render();      // pure ImGui overlay — touches no game object at all
    // NOTE: 4th Talent and Emotes both used to be separate floating windows
    // called from here (RecoverySuite::DrawTalentPanel() / RenderEquipEmoteMenu()).
    // Both are now embedded tab content instead — see RecoverySuite::Talents
    // and RecoverySuite::Emotes, drawn from RecoverySuite::Render() like every
    // other tab. Nothing to call from hkPresent for either any more. The old
    // radial-wheel emote file (menus/EquipEmoteMenu.h) is left on disk, just
    // unwired.
    RecoverySuite::ProcessAimAssist(); // aim assist nudge using analog input
    g_LButtonClickedThisFrame = false; // reset click flag after this frame's firing logic

    if (g_ShowFPS) {
        char fpsText[32];
        snprintf(fpsText, sizeof(fpsText), "FPS: %.0f", ImGui::GetIO().Framerate);
        ImGui::GetForegroundDrawList()->AddText(ImVec2(10, 10), IM_COL32(255, 255, 0, 255), fpsText);
    }

    // Track show->hide so we can release keyboard focus exactly once on hide.
    // A widget that still holds focus (e.g. an InputText) keeps
    // io.WantCaptureKeyboard true, which silently eats every key — dead WASD,
    // dead binds, no visible menu to explain why.
    static bool s_MenuWasShown = false;
    if (g_bShowMenu)
    {
        // Apply any theme requested last frame BEFORE anything is drawn, so
        // the whole frame uses one palette. See RequestPharoahTheme.
        ApplyPendingTheme();
        ApplyRGBBorderAccent();
        RecoverySuite::Render(objectsReady);
        s_MenuWasShown = true;
    }
    else if (s_MenuWasShown)
    {
        s_MenuWasShown = false;
        ImGui::SetWindowFocus(nullptr);   // drop focused window + its active widget
    }

    // ---- PHAROAH CURSOR ------------------------------------------------
    // A pyramid. Drawn into the FOREGROUND draw list, which is composited
    // after every window, so it is always on top of the tool - and because it
    // is part of our own frame it vanishes with the menu, leaving nothing
    // stranded over the game.
    //
    // Two passes: a dark silhouette one pixel out, then the blue fill. Without
    // the silhouette the cursor disappears against a light wall or a skybox.
    if (g_bShowMenu) {
        ImDrawList* fg = ImGui::GetForegroundDrawList();
        ImVec2 m = ImGui::GetIO().MousePos;
        const float h = 22.0f;   // height of the pyramid
        const float w = 8.5f;    // base half-width - narrow, so it stays a pointer

        // THE TIP LEANS LEFT.
        //
        // A real mouse pointer is not symmetrical - its tip is the top-left
        // corner and the body falls away down-right. The old version put the
        // apex straight above the base, which read as a road sign rather than a
        // cursor. Shifting the apex left of the base centre gives it the lean,
        // and the hotspot stays exactly on m so clicking still lands where you
        // point.
        const float lean = 0.42f;   // how far left the tip sits, as a fraction of w

        ImVec2 apex = ImVec2(m.x, m.y);
        // Base corners, both down-right of the tip. The left corner is pulled in
        // close so the left edge is nearly vertical - that near-vertical edge is
        // what makes it read as a pointer.
        ImVec2 bl   = ImVec2(m.x + w * lean * 0.30f, m.y + h);
        ImVec2 br   = ImVec2(m.x + w * 1.45f,        m.y + h * 0.70f);

        // The notch: a real cursor has a tail. Cutting back toward the tip on
        // the lower-left turns a plain triangle into something with a waist,
        // which is most of what makes an arrow look like an arrow.
        ImVec2 waist = ImVec2(m.x + w * 0.34f, m.y + h * 0.74f);

        const ImU32 kFill    = IM_COL32(47, 182, 212, 245);  // logo aqua-blue
        const ImU32 kEdgeCol = IM_COL32(15, 74, 85, 255);    // deep blue edge
        const ImU32 kGold    = IM_COL32(217, 174, 56, 220);  // PHAROAH gold seam
        const ImU32 kShine   = IM_COL32(150, 226, 240, 210); // lit left face

        // Body as a quad: tip -> tail -> waist -> right corner. Convex, so
        // AddConvexPolyFilled renders it in one pass with no seam.
        ImVec2 body[4] = { apex, bl, waist, br };
        fg->AddConvexPolyFilled(body, 4, kFill);

        // Lit left face, so it reads as a solid pyramid rather than a flat
        // triangle. Drawn on top of the fill, inside the silhouette.
        ImVec2 lit[3] = { apex, bl, waist };
        fg->AddConvexPolyFilled(lit, 3, kShine);

        // Outline last so it sits over both fills and keeps the shape crisp
        // against a light wall or a skybox.
        fg->AddPolyline(body, 4, kEdgeCol, ImDrawFlags_Closed, 1.3f);

        // Gold seam down the ridge - the PHAROAH tell.
        fg->AddLine(apex, waist, kGold, 1.1f);
    }

    ImGui::Render();

    pContext->OMSetRenderTargets(1, &mainRenderTargetView, NULL);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

    return oPresent(pSwapChain, SyncInterval, Flags);
}

HRESULT __stdcall hkResizeBuffers(IDXGISwapChain* pSwapChain, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT NewFormat, UINT SwapChainFlags)
{
    if (mainRenderTargetView) {
        pContext->OMSetRenderTargets(0, 0, 0);
        mainRenderTargetView->Release();
        mainRenderTargetView = nullptr;
    }

    return oResizeBuffers(pSwapChain, BufferCount, Width, Height, NewFormat, SwapChainFlags);
}

bool HookKeyState() {
    HMODULE API = (HMODULE)GetModuleBase(L"win32u.dll");

    if (API != NULL)
    {
        o_getasynckeystate = (LPFN_MBA)GetProcAddress(API, "NtUserGetAsyncKeyState");
        if (o_getasynckeystate != NULL)
            return true;
        else
            return false;
    }
    return false; // win32u.dll not found — was falling off the end with no return
}

void Main() {

    printf("[Init] Main() starting...\n");

    moduleBase = (HMODULE) GetModuleBase(L"Paladins.exe");
    printf("[Init] moduleBase = 0x%p %s\n", moduleBase, moduleBase ? "(OK)" : "(FAILED - module not found!)");

    PBYTE gobject_address = GetMovAddress<PBYTE>(
        FindPattern("48 8B 05 ? ? ? ? 4C 8B 04 0A 4C 33 04 F0 44", L"Paladins.exe"));
    printf("[Init] gobject_address = 0x%p %s\n", gobject_address, gobject_address ? "(OK)" : "(FAILED - pattern not found, likely game was updated)");
    GObject = reinterpret_cast<decltype(GObject)>(gobject_address);
    SDK::UObject::GObjects = reinterpret_cast<SDK::TAntiCheatArray<SDK::UObject*>*>(gobject_address);

    PBYTE gname_address = GetMovAddress<PBYTE>(
        FindPattern("48 8B 05 ? ? ? ? B9 ? ? ? ? 48 8B 0C 0A 48 BA", L"Paladins.exe"));
    printf("[Init] gname_address = 0x%p %s\n", gname_address, gname_address ? "(OK)" : "(FAILED - pattern not found)");
    GName = gname_address;
    SDK::FName::GNames = reinterpret_cast<SDK::TAntiCheatArray<SDK::FNameEntry*>*>(gname_address);

    Globals::UEngineAddr = GetMovAddress<DWORD_PTR>(
        FindPattern("48 8B 0D ? ? ? ? 48 85 C9 0F 84 ? ? ? ? 48 39 B9 ? ? ? ?", L"Paladins.exe"));
    printf("[Init] UEngineAddr = 0x%p %s\n", (void*)Globals::UEngineAddr, Globals::UEngineAddr ? "(OK)" : "(FAILED - pattern not found)");

    ProcessEventOriginal = GetCallAddress<tProcessEvent>(
        FindPattern("E8 ? ? ? ? 8D 4E ? 41 3B CD", L"Paladins.exe"));
    printf("[Init] ProcessEventOriginal = 0x%p %s\n", (void*)ProcessEventOriginal, ProcessEventOriginal ? "(OK)" : "(FAILED - pattern not found)");

    Globals::xorFunc = GetCallAddress<void *>(
        FindPattern("E8 ? ? ? ? 85 C0 75 0F 48 8B 03", L"Paladins.exe"));
    printf("[Init] xorFunc = 0x%p %s\n", Globals::xorFunc, Globals::xorFunc ? "(OK)" : "(FAILED - pattern not found)");

    if (Globals::xorFunc) {
        xorKey = (uintptr_t) GetAndValue<void *>((void *) ((DWORD64) Globals::xorFunc + 0x63));
        printf("[Init] xorKey = 0x%p\n", (void*)xorKey);
    } else {
        printf("[Init] SKIPPED xorKey (xorFunc was null, would have crashed here otherwise)\n");
    }

    printf("[Init] HookKeyState() = %s\n", HookKeyState() ? "true" : "false");

    if (!ProcessEventOriginal) {
        printf("[Init] ABORTING hook attach — ProcessEventOriginal is null, DetourAttach would crash.\n");
        return;
    }

    if (DetourTransactionBegin() != NO_ERROR) { printf("[Init] DetourTransactionBegin FAILED\n"); return; }
    if (DetourUpdateThread(GetCurrentThread()) != NO_ERROR) { printf("[Init] DetourUpdateThread FAILED\n"); DetourTransactionAbort(); return; }
    DetourAttach(&(LPVOID&)ProcessEventOriginal, (PBYTE)HookedProcessEvent);
    LONG result = DetourTransactionCommit();
    printf("[Init] DetourTransactionCommit result = %ld %s\n", result, result == NO_ERROR ? "(OK)" : "(FAILED)");

    // CRASH FIX ("Illegal call to StaticFindObject() while serializing
    // object data or garbage collecting!"): every ::StaticClass() call is
    // cached on FIRST use (a local static pointer inside each one), but that
    // first use happens lazily, whenever a feature first actually runs — at
    // some random moment during live gameplay. If that first lookup happens
    // to land while the engine's GC is running, it's fatal (a hard engine
    // stop, not a catchable access violation — SEH can't help here). Fixed by
    // forcing every one we use to resolve HERE, right at injection, before
    // you're ever in a match and long before any GC cycle could plausibly be
    // running — so none of them ever do a "cold" lookup during gameplay again.
    printf("[Init] Pre-warming class lookups...\n");
    SDK::ATgPawn::StaticClass();
    SDK::ATgPawn_Character::StaticClass();
    SDK::UUIHudDecks::StaticClass();
    SDK::UUIChampion::StaticClass();
    SDK::UUIRadialMenuEquip::StaticClass();
    printf("[Init] Pre-warming done.\n");

    printf("[Init] Main() finished.\n");
}

bool TryBindKiero(kiero::RenderType::Enum type, const char* name) {
    kiero::Status::Enum status = kiero::init(type);
    printf("[Init]   %-8s -> status=%d %s\n", name, (int)status, status == kiero::Status::Success ? "SUCCESS" : "");
    if (status == kiero::Status::Success) {
        kiero::bind(8, (void**)&oPresent, hkPresent);
        kiero::bind(13, (void**)&oResizeBuffers, hkResizeBuffers);
        printf("[Init]   kiero::bind done for %s. Overlay should render on next Present.\n", name);
        return true;
    }
    return false;
}

void InitKiero() {
    // Loop the DLL check + every render type for up to ~60 seconds, in case
    // injection happened before the game finished creating its graphics device
    // (e.g. injected during a loading screen rather than once already in-match).
    for (int round = 0; round < 120; round++) {
        if (round % 10 == 0) {
            printf("[Init] --- round %d: graphics DLLs currently loaded ---\n", round);
            printf("[Init] d3d9.dll=%s d3d10.dll=%s d3d11.dll=%s d3d12.dll=%s dxgi.dll=%s opengl32.dll=%s\n",
                GetModuleHandleA("d3d9.dll") ? "YES" : "no",
                GetModuleHandleA("d3d10.dll") ? "YES" : "no",
                GetModuleHandleA("d3d11.dll") ? "YES" : "no",
                GetModuleHandleA("d3d12.dll") ? "YES" : "no",
                GetModuleHandleA("dxgi.dll") ? "YES" : "no",
                GetModuleHandleA("opengl32.dll") ? "YES" : "no");

            printf("[Init] --- trying every kiero RenderType directly ---\n");
            if (TryBindKiero(kiero::RenderType::D3D9,  "D3D9"))  return;
            if (TryBindKiero(kiero::RenderType::D3D10, "D3D10")) return;
            if (TryBindKiero(kiero::RenderType::D3D11, "D3D11")) return;
            if (TryBindKiero(kiero::RenderType::D3D12, "D3D12")) return;
        }
        Sleep(500);
    }

    printf("[Init] GAVE UP after ~60 seconds. None of D3D9/10/11/12 succeeded via kiero.\n");
    printf("[Init] This means either: (a) none of those DLLs were ever loaded in this process,\n");
    printf("[Init] or (b) kiero's hook-point signatures don't match this game's actual build.\n");
    printf("[Init] Send this whole log back — the DLL-loaded lines above are the key diagnostic.\n");
}

// ============================================================================
// INIT LOG  —  so a crash on inject is not a silent one
// ============================================================================
// AllocConsole gives a console, but it dies with the game: when the DLL takes
// the process down during startup there is nothing left to read, which is why
// "it just crashed, no message" was all we had to go on.
//
// This writes the same milestones to PHAROAH_init.log next to the game exe,
// flushing after every line. The file survives the crash, so the LAST line
// tells you exactly which stage died.
static void InitLog(const char* fmt, ...) {
    char msg[512];
    va_list ap;
    va_start(ap, fmt);
    _vsnprintf_s(msg, sizeof(msg), _TRUNCATE, fmt, ap);
    va_end(ap);

    // console (may not exist yet, harmless)
    printf("%s\n", msg);

    FILE* lf = nullptr;
    if (fopen_s(&lf, "PHAROAH_init.log", "a") == 0 && lf) {
        SYSTEMTIME st; GetLocalTime(&st);
        fprintf(lf, "[%02d:%02d:%02d.%03d] %s\n",
                st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, msg);
        fflush(lf);          // flush every line - a crash must not lose it
        fclose(lf);
    }
}

DWORD WINAPI InitThread(LPVOID lpParam) {
    AllocConsole();
    FILE* f;
    freopen_s(&f, "CONOUT$", "w", stdout);
    freopen_s(&f, "CONOUT$", "w", stderr);

    // Start a fresh log each injection, so what you read is THIS run.
    { FILE* lf = nullptr; if (fopen_s(&lf, "PHAROAH_init.log", "w") == 0 && lf) fclose(lf); }

    InitLog("[Init] ==== PHAROAH injected, InitThread running ====");
    InitLog("[Init] build: " __DATE__ " " __TIME__);

    InitLog("[Init] stage 1/3: Main() - SDK init, ProcessEvent detour");
    Main();
    InitLog("[Init] stage 2/3: Main() returned OK");

    InitLog("[Init] stage 3/3: InitKiero() - D3D11 Present hook");
    InitKiero();

    InitLog("[Init] ==== setup complete, everything hooked ====");
    return 0;
}

// EJECT CRASH FIX: there was no DLL_PROCESS_DETACH handling at all before —
// the ProcessEvent Detour and the kiero Present/ResizeBuffers hooks stayed
// installed, redirecting into this DLL's code, even after the DLL's pages
// were unmapped on unload. The next Present() or scripted function call then
// jumped into freed memory — instant, silent access violation, no dialog.
// Fix: remove every hook before the module actually unloads.
void UnhookEverything() {
    if (ProcessEventOriginal) {
        DetourTransactionBegin();
        DetourUpdateThread(GetCurrentThread());
        DetourDetach(&(LPVOID&)ProcessEventOriginal, (PBYTE)HookedProcessEvent);
        DetourTransactionCommit();
    }
    kiero::unbind(8);  // Present
    kiero::unbind(13); // ResizeBuffers
    kiero::shutdown();
}

BOOL WINAPI DllMain(HMODULE hModule, DWORD dwReason) {
    if (dwReason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        CreateThread(NULL, 0, InitThread, NULL, 0, NULL);
    } else if (dwReason == DLL_PROCESS_DETACH) {
        UnhookEverything();
    }
    return TRUE;
}