#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "ext/ImGUI/imgui.h"
#include <Windows.h>
#include <d3d11.h>
#include <wincodec.h>
#include <new>          // std::nothrow

#pragma comment(lib, "windowscodecs.lib")

// ============================================================================
// LOGO TEXTURE — loads the REAL blue.png logo instead of a drawn approximation
//
// WHY THIS FILE EXISTS:
// ImGui cannot draw a PNG on its own. It draws textures, and a texture has to be
// created on the graphics device. So the steps are:
//   1. Decode the PNG to raw 32-bit BGRA pixels  -> Windows Imaging Component (WIC)
//   2. Create an ID3D11Texture2D from those pixels
//   3. Create a shader resource view (SRV) for it
//   4. Hand the SRV to ImGui as an ImTextureID
// That is all "create a D3D11 shader resource view" meant. WIC is built into
// Windows, so nothing extra ships with the DLL.
//
// WHY WIC RATHER THAN LoadImage:
// LoadImage/HICON loses the alpha channel in the general case, and the logo needs
// transparency to sit on the menu background. WIC decodes PNG and ICO directly
// and converts to a guaranteed pixel format.
//
// FAILURE BEHAVIOUR — IMPORTANT:
// If the file is missing or decoding fails, this reports failure and the caller
// falls back to the drawn vector glyph. The menu must never lose its header just
// because an image didn't load. Same principle as everywhere else in this project:
// a new path is added alongside the working one, never in place of it.
//
// SEARCH PATHS:
// The DLL is injected, so the working directory is the GAME's folder, not ours.
// Rather than depend on that, several likely locations are tried in order, and
// whichever hits first wins. The path that worked is exposed for the diagnostics
// panel so a failure is legible instead of mysterious.
// ============================================================================

namespace LogoTexture {

    inline ID3D11ShaderResourceView* g_SRV = nullptr;
    inline int  g_Width = 0;
    inline int  g_Height = 0;
    inline bool g_Tried = false;
    inline bool g_Loaded = false;
    inline char g_LoadedFrom[MAX_PATH] = "(not loaded)";
    inline char g_LastError[160] = "";

    // Decode any WIC-supported image (PNG, ICO, JPG, BMP) into BGRA bytes.
    inline bool DecodeToBGRA(const wchar_t* path, unsigned char** outPixels,
                             int* outW, int* outH) {
        IWICImagingFactory* factory = nullptr;
        IWICBitmapDecoder* decoder = nullptr;
        IWICBitmapFrameDecode* frame = nullptr;
        IWICFormatConverter* converter = nullptr;
        bool ok = false;

        // ####################################################################
        // THIS IS WHERE THE GAME CRASH CAME FROM. Read before touching.
        //
        // CoInitializeEx returns S_OK only when IT did the initialising. If COM
        // was ALREADY initialised on this thread it returns S_FALSE — and
        // SUCCEEDED(S_FALSE) is TRUE. The old code therefore called
        // CoUninitialize() on a thread the GAME had already initialised, which
        // decremented the game's own COM reference count and tore COM down
        // underneath it. The game then crashed on its next COM use, which is why
        // it died at startup rather than here.
        //
        // Correct rule: only uninitialise if we got S_OK, i.e. only undo what we
        // actually did. RPC_E_CHANGED_MODE means COM exists in a different
        // apartment — fine to use, must NOT be uninitialised.
        // ####################################################################
        HRESULT hrInit = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        const bool weOwnCom = (hrInit == S_OK);

        do {
            if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr,
                    CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory)))) break;
            if (FAILED(factory->CreateDecoderFromFilename(path, nullptr,
                    GENERIC_READ, WICDecodeMetadataCacheOnLoad, &decoder))) break;

            // Frame 0. For an .ico this is one of the sizes in the file; for a
            // .png it is the whole image.
            if (FAILED(decoder->GetFrame(0, &frame))) break;
            if (FAILED(factory->CreateFormatConverter(&converter))) break;
            if (FAILED(converter->Initialize(frame, GUID_WICPixelFormat32bppPBGRA,
                    WICBitmapDitherTypeNone, nullptr, 0.0,
                    WICBitmapPaletteTypeCustom))) break;

            UINT w = 0, h = 0;
            if (FAILED(converter->GetSize(&w, &h))) break;
            if (w == 0 || h == 0 || w > 4096 || h > 4096) break;

            const UINT stride = w * 4;
            const UINT size = stride * h;
            unsigned char* pixels = new (std::nothrow) unsigned char[size];
            if (!pixels) break;

            if (FAILED(converter->CopyPixels(nullptr, stride, size, pixels))) {
                delete[] pixels;
                break;
            }

            *outPixels = pixels;
            *outW = (int)w;
            *outH = (int)h;
            ok = true;
        } while (false);

        if (converter) converter->Release();
        if (frame) frame->Release();
        if (decoder) decoder->Release();
        if (factory) factory->Release();
        // Only undo our own initialisation — see the block comment above.
        if (weOwnCom) CoUninitialize();
        return ok;
    }

    inline bool CreateFromFile(ID3D11Device* device, const wchar_t* path) {
        if (!device) return false;

        unsigned char* pixels = nullptr;
        int w = 0, h = 0;
        if (!DecodeToBGRA(path, &pixels, &w, &h)) return false;

        D3D11_TEXTURE2D_DESC desc{};
        desc.Width = w;
        desc.Height = h;
        desc.MipLevels = 1;
        desc.ArraySize = 1;
        desc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;   // matches 32bppPBGRA above
        desc.SampleDesc.Count = 1;
        desc.Usage = D3D11_USAGE_IMMUTABLE;         // never written again
        desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

        D3D11_SUBRESOURCE_DATA init{};
        init.pSysMem = pixels;
        init.SysMemPitch = (UINT)(w * 4);

        ID3D11Texture2D* tex = nullptr;
        HRESULT hr = device->CreateTexture2D(&desc, &init, &tex);
        delete[] pixels;                            // D3D has copied it by now
        if (FAILED(hr) || !tex) return false;

        D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc{};
        srvDesc.Format = desc.Format;
        srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
        srvDesc.Texture2D.MipLevels = 1;

        ID3D11ShaderResourceView* srv = nullptr;
        hr = device->CreateShaderResourceView(tex, &srvDesc, &srv);
        tex->Release();                             // the SRV holds its own ref
        if (FAILED(hr) || !srv) return false;

        if (g_SRV) g_SRV->Release();
        g_SRV = srv;
        g_Width = w;
        g_Height = h;
        return true;
    }

    // Tried once. Called from the render path, which is the only place a D3D
    // device is legitimately available.
    // Absolute path to a file sitting next to THIS DLL.
    //
    // The search list used to contain absolute paths on the machine this was
    // built on (C:\Users\<me>\Downloads\...). Those obviously do not exist on
    // anyone else's PC, so every user fell through to the drawn-glyph fallback
    // and never saw the real logo - and the paths leaked a username into an
    // open-source release for no reason.
    //
    // The DLL knows where it lives, so ask. A user unzips anywhere, the logo
    // sits beside PHAROAH.dll, and it is found.
    inline bool BesideThisDll(const wchar_t* name, wchar_t* out, size_t outChars) {
        HMODULE self = nullptr;
        if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                                GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                                (LPCWSTR)&BesideThisDll, &self) || !self) return false;

        wchar_t dllPath[MAX_PATH] = {};
        if (!GetModuleFileNameW(self, dllPath, MAX_PATH)) return false;

        wchar_t* slash = wcsrchr(dllPath, L'\\');
        if (!slash) return false;
        *(slash + 1) = 0;

        if (wcslen(dllPath) + wcslen(name) + 1 >= outChars) return false;
        wcscpy_s(out, outChars, dllPath);
        wcscat_s(out, outChars, name);
        return true;
    }

    inline void EnsureLoaded(ID3D11Device* device) {
        if (g_Tried) return;
        g_Tried = true;
        if (!device) {
            lstrcpynA(g_LastError, "no D3D11 device available", 160);
            return;
        }

        // The DLL is injected, so the working directory belongs to the GAME.
        // Absolute paths first (where the art actually lives in this project),
        // then bare filenames so dropping the png next to the game exe also works.
        // Pharoah_App-Photoroom.png is the CURRENT app logo and wins outright.
        // The blue.* files are the older artwork, kept as fallbacks so an older
        // checkout still shows something.
        //
        // Bare filenames come last so dropping a logo next to the game exe works
        // for anyone who does not have this source tree.
        // HIGH-RESOLUTION SOURCES FIRST - this is the blur fix.
        //
        // An .ico holds several frames and this loader takes the FIRST one.
        // pharoah-app.ico starts with a 16x16 frame, so the in-tool logo was a
        // 16-pixel image stretched to 72 - hence "really blurry". The PNGs are
        // full resolution and blue(1).ico is a single 227x256 frame, so any of
        // those scale down cleanly.
        //
        // The INJECTOR is unaffected: Windows picks the right frame out of the
        // .ico itself, which is why that one wants the multi-frame file.
        // Bare filenames only - resolved against the DLL's own folder first
        // (see BesideThisDll), then the process working directory as a fallback.
        // No absolute paths: they cannot work anywhere but the build machine.
        static const wchar_t* kNames[] = {
            L"blue.png",
            L"pharoah-logo.png",
            L"pharoah_logo.png",
            L"blue(1).ico",
            L"pharoah-app.ico",
            L"pharoah.ico",
        };

        // Pass 1: next to the DLL. This is where a release ZIP puts it.
        for (int i = 0; i < (int)(sizeof(kNames) / sizeof(kNames[0])); ++i) {
            wchar_t full[MAX_PATH] = {};
            if (!BesideThisDll(kNames[i], full, MAX_PATH)) continue;
            if (CreateFromFile(device, full)) {
                g_Loaded = true;
                WideCharToMultiByte(CP_ACP, 0, full, -1, g_LoadedFrom, MAX_PATH, nullptr, nullptr);
                return;
            }
        }

        // Pass 2: the working directory (belongs to the GAME when injected).
        static const wchar_t** kPaths = kNames;

        for (int i = 0; i < (int)(sizeof(kNames) / sizeof(kNames[0])); ++i) {
            if (CreateFromFile(device, kPaths[i])) {
                g_Loaded = true;
                WideCharToMultiByte(CP_ACP, 0, kPaths[i], -1, g_LoadedFrom, MAX_PATH, nullptr, nullptr);
                return;
            }
        }
        lstrcpynA(g_LastError, "no logo file found in any search path", 160);
    }

    inline ImTextureID GetTextureID() {
        return (ImTextureID)(intptr_t)g_SRV;
    }

    inline void Release() {
        if (g_SRV) { g_SRV->Release(); g_SRV = nullptr; }
        g_Loaded = false;
        g_Tried = false;
    }
}
