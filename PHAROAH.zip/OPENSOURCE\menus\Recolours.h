#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include "menus/HealthBarColor.h"
#include <Windows.h>

// ============================================================================
// RECOLOURS  —  everything that repaints the game's UI, in one place
// ============================================================================
// Health-bar recolouring used to live buried in the Highlights tab alongside
// boxes, silhouettes and the reticle. It has nothing to do with any of those:
// it walks GFx UI objects and repaints them. So it gets its own tab, and
// anything else that repaints the UI goes here too.
//
// HOW THE HEALTH-BAR RECOLOUR WORKS (since you asked)
//
//   1. Walk GObjects for UUIComponent_HealthBar_Overlay instances - one per
//      player whose bar is on screen.
//   2. Each has a CONTAINER, which is a UGFxObject: the actual Scaleform movie
//      clip the bar is drawn into.
//   3. Repaint that clip with one of two scripted calls:
//
//        SetColorMultiplier(r,g,b,a)  MULTIPLIES the existing pixels. This is
//                                     why your colours "mix" with the game's
//                                     red - a multiply can only ever darken
//                                     toward the colour, never replace it.
//        SetColorTransform(...)       Adds an offset as well, so it can push a
//                                     red bar to an actual green. Exact, but
//                                     less reliable - hence not the default.
//
//   4. Re-apply on a timer, because the game rebuilds and re-tints the bars
//      constantly.
//
// That multiply is exactly the stacking you described. "Solid mode" is the
// answer to it, and it is already in the health-bar section as an opt-in.
// ============================================================================

namespace Recolours {

    // ---- damage numbers ---------------------------------------------------
    // UUIWorldOverlay carries m_QueuedDamageNumbers, but that struct holds only
    // target id, value, source and damage type - there is NO colour field, and
    // no GFxObject member for the numbers the way the health bar has one for
    // its container. So the same trick does not simply transfer.
    //
    // Rather than ship a switch that does nothing, this probes for the objects
    // first: it sweeps GFx objects and reports any whose name looks like it
    // belongs to damage numbers. If the probe finds a container, recolouring it
    // is the same three lines as the health bar. If it finds nothing, the
    // numbers are drawn some other way and I would rather tell you that than
    // give you a dead toggle.
    inline bool  g_PendingProbe = false;
    inline bool  g_PendingCopyProbe = false;
    inline int   g_ProbeCount = 0;
    static const int kMaxProbe = 60;
    inline char  g_ProbeNames[kMaxProbe][120];
    inline char  g_ProbeStatus[200] = "Not probed yet.";

    inline bool NameLooksLikeDamage(const char* n) {
        if (!n) return false;
        static const char* kWords[] = {
            "damage", "dmg", "number", "combat", "floating", "hitnumber", "worldoverlay"
        };
        for (const char* w : kWords) {
            for (int i = 0; n[i]; ++i) {
                int j = 0;
                while (w[j] && n[i + j] && ((n[i + j] | 32) == (w[j] | 32))) ++j;
                if (!w[j]) return true;
            }
        }
        return false;
    }

    // Safe thread only - class lookups and name reads walk live objects.
    inline void ProcessPending() {
        if (g_PendingProbe) {
            g_PendingProbe = false;
            g_ProbeCount = 0;

            SDK::UClass* gfx = nullptr;
            __try { gfx = SDK::UGFxObject::StaticClass(); }
            __except (EXCEPTION_EXECUTE_HANDLER) { gfx = nullptr; }

            if (!gfx || !SDK::UObject::GObjects) {
                lstrcpynA(g_ProbeStatus, "Could not resolve UGFxObject or GObjects.", 190);
            } else {
                auto& arr = *SDK::UObject::GObjects;
                size_t count = 0;
                __try { count = arr.Num(); } __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
                int seen = 0;

                for (size_t i = 0; i < count && count < 4000000; ++i) {
                    SDK::UObject* o = nullptr;
                    __try { if (arr.IsValidIndex(i)) o = arr[i]; }
                    __except (EXCEPTION_EXECUTE_HANDLER) { o = nullptr; }
                    if (!o) continue;
                    bool is = false;
                    __try { is = o->IsA(gfx); }
                    __except (EXCEPTION_EXECUTE_HANDLER) { is = false; }
                    if (!is) continue;
                    seen++;

                    char nm[120] = {};
                    __try {
                        auto& names = SDK::FName::GetGlobalNames();
                        if (o->Name.Index && names.IsValidIndex((size_t)o->Name.Index)) {
                            SDK::FNameEntry* e = names[o->Name.Index];
                            if (e) lstrcpynA(nm, e->GetAnsiName(), 119);
                        }
                    }
                    __except (EXCEPTION_EXECUTE_HANDLER) { nm[0] = 0; }
                    if (!nm[0] || !NameLooksLikeDamage(nm)) continue;

                    bool dup = false;
                    for (int d = 0; d < g_ProbeCount; ++d)
                        if (lstrcmpiA(g_ProbeNames[d], nm) == 0) { dup = true; break; }
                    if (dup) continue;

                    if (g_ProbeCount < kMaxProbe) lstrcpynA(g_ProbeNames[g_ProbeCount++], nm, 119);
                }
                wsprintfA(g_ProbeStatus,
                    "%d GFx objects in memory, %d with damage-ish names. Take damage first, then "
                    "probe - they may not exist until a number has been drawn.", seen, g_ProbeCount);
            }
        }

        if (g_PendingCopyProbe) {
            g_PendingCopyProbe = false;
            static char big[9000];
            int n = wsprintfA(big, "===== DAMAGE NUMBER PROBE =====\r\n%s\r\n\r\n", g_ProbeStatus);
            for (int i = 0; i < g_ProbeCount && n < 8000; ++i)
                n += wsprintfA(big + n, "%s\r\n", g_ProbeNames[i]);
            if (g_ProbeCount == 0) lstrcatA(big, "(nothing matched)\r\n");
            lstrcatA(big, "===== END =====\r\n");
            ImGui::SetClipboardText(big);
        }
    }

    inline void DrawControls(bool inMatch) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("RECOLOURS");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Everything that repaints the game's own UI. Settings here are "
            "remembered between sessions.");
        ImGui::Separator();

        // ---- health bars ----
        // The real fix for "my colours mix with the game's red": stop trying to
        // paint over the game's bar and remove it instead.
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)));
        ImGui::TextUnformatted("HIDE THE GAME'S HEALTH BARS");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("Tinting multiplies, so your colour can never fully replace the game's "
            "red. The position probe was meant to let us draw exactly on top instead - it came back "
            "with x=0 y=0 for every bar, so the containers do not expose a screen position and that "
            "route is closed.");
        ImGui::TextWrapped("What the probe DID show is that alpha reads back fine, which means it "
            "can be written. So: switch the game's bars off, and use the ones in Highlights "
            "(\"Show health bars\" / \"Show ALLY health bars\") which are drawn from world "
            "positions in whatever colour you like. Nothing can mix if nothing is underneath.");
        if (ImGui::Checkbox("Hide the game's health bars", &HealthBarColor::g_HideGameBars)) {
            HealthBarColor::g_PendingHideApply = true;
        }
        ImGui::SameLine();
        ImGui::TextDisabled("(%d hidden last pass)", HealthBarColor::g_HiddenCount);
        ImGui::TextDisabled("Turn on the Highlights health bars to replace them.");

        ImGui::Spacing();
        ImGui::Separator();
        HealthBarColor::DrawControls();

        // ---- damage numbers: ANSWERED, and the answer is no ----
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.6f, 1.0f, 0.8f, 1.0f)));
        ImGui::TextUnformatted("DAMAGE NUMBERS  -  not reachable");
        ImGui::PopStyleColor();
        ImGui::TextWrapped("The probe has been run and it settled this. Out of 7703 GFx objects in "
            "memory, exactly two had damage-related names: UIWorldOverlay and its class default. "
            "That is the CONTAINER for the whole world overlay, not a per-number object.");
        ImGui::TextWrapped("Health bars can be recoloured because each bar owns its own GFx clip we "
            "can repaint. Damage numbers have no such clip - they are drawn by the overlay itself, "
            "and m_QueuedDamageNumbers carries only target, value, source and damage type. There is "
            "no colour field to write and no object to tint.");
        ImGui::TextDisabled("The probe is gone rather than left as a button that reports the same "
            "thing forever. If a per-number object ever turns up, this is three lines of work.");

        // ---- why colours mix ----
        ImGui::Spacing();
        if (ImGui::CollapsingHeader("Why my colours mix with the game's red")) {
            ImGui::TextWrapped("SetColorMultiplier MULTIPLIES the existing pixels. A multiply can "
                "only ever darken toward your colour - it can never replace what is underneath, "
                "which is why a red bar tinted green comes out muddy brown.");
            ImGui::Spacing();
            ImGui::TextWrapped("The fix already exists: untick 'use colour multiplier' in the health "
                "bar section above. That switches to SetColorTransform, which adds an offset as "
                "well and can push red to an actual green. It is exact when it works, but it is "
                "less reliable than the multiply - which is why it is not the default.");
            ImGui::Spacing();
            ImGui::TextWrapped("Drawing our own bar over the top is the third option, and that is "
                "what the position probe in the health-bar section is for.");
        }
    }
}
