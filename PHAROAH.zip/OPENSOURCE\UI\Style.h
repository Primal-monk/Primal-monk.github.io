#pragma once
#include "ext/ImGUI/imgui.h"
#include <cmath>

// 60/30/10 theme: Major (backgrounds, 60%), Mid (buttons/frames, 30%),
// Minor (highlights/active states, 10%). Presets set these three.
inline ImVec4 g_MajorColor = ImVec4(0.32f, 0.16f, 0.45f, 1.0f); // purple (default)
inline ImVec4 g_MidColor   = ImVec4(1.00f, 0.55f, 0.05f, 1.0f); // orange (default)
inline ImVec4 g_MinorColor = ImVec4(0.10f, 0.75f, 1.00f, 1.0f); // neon blue (default)

inline void ApplyThemeColors(ImVec4 major, ImVec4 mid, ImVec4 minor) {
    g_MajorColor = major;
    g_MidColor = mid;
    g_MinorColor = minor;

    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4 M = major, D = mid, N = minor;

    // Backgrounds — major color, heavily darkened so text stays readable, still transparent.
    ImVec4 BG_DARK   = ImVec4(M.x * 0.14f, M.y * 0.14f, M.z * 0.14f, 0.88f);
    ImVec4 BG_DARK_2 = ImVec4(M.x * 0.20f, M.y * 0.20f, M.z * 0.20f, 0.90f);

    style.Colors[ImGuiCol_Text] = ImVec4(0.95f, 0.95f, 0.97f, 1.00f);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.55f, 0.55f, 0.60f, 1.00f);
    style.Colors[ImGuiCol_WindowBg] = BG_DARK;
    style.Colors[ImGuiCol_ChildBg] = BG_DARK_2;
    style.Colors[ImGuiCol_PopupBg] = ImVec4(BG_DARK.x * 0.7f, BG_DARK.y * 0.7f, BG_DARK.z * 0.7f, 0.96f);
    style.Colors[ImGuiCol_Border] = N; // overridden per-frame by ApplyRGBBorderAccent anyway
    style.Colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(M.x * 0.30f, M.y * 0.30f, M.z * 0.30f, 0.75f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(D.x, D.y, D.z, 0.35f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(N.x, N.y, N.z, 0.45f);
    style.Colors[ImGuiCol_TitleBg] = ImVec4(BG_DARK.x * 0.6f, BG_DARK.y * 0.6f, BG_DARK.z * 0.6f, 1.00f);
    style.Colors[ImGuiCol_TitleBgActive] = ImVec4(M.x * 0.5f, M.y * 0.5f, M.z * 0.5f, 1.00f);
    style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(BG_DARK.x * 0.6f, BG_DARK.y * 0.6f, BG_DARK.z * 0.6f, 0.60f);
    style.Colors[ImGuiCol_MenuBarBg] = ImVec4(M.x * 0.22f, M.y * 0.22f, M.z * 0.22f, 1.00f);
    style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(BG_DARK.x * 0.5f, BG_DARK.y * 0.5f, BG_DARK.z * 0.5f, 0.60f);
    style.Colors[ImGuiCol_ScrollbarGrab] = D;
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = N;
    style.Colors[ImGuiCol_ScrollbarGrabActive] = N;
    style.Colors[ImGuiCol_CheckMark] = N;
    style.Colors[ImGuiCol_SliderGrab] = D;
    style.Colors[ImGuiCol_SliderGrabActive] = N;
    // Buttons — mid color (30%) as the base tone, minor color (10%) reserved for active/selected state.
    style.Colors[ImGuiCol_Button] = ImVec4(M.x * 0.35f, M.y * 0.35f, M.z * 0.35f, 0.85f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(D.x, D.y, D.z, 0.45f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(N.x, N.y, N.z, 0.65f);
    style.Colors[ImGuiCol_Header] = ImVec4(M.x * 0.35f, M.y * 0.35f, M.z * 0.35f, 0.60f);
    style.Colors[ImGuiCol_HeaderHovered] = ImVec4(D.x, D.y, D.z, 0.55f);
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(N.x, N.y, N.z, 0.70f);
    style.Colors[ImGuiCol_Separator] = ImVec4(0.25f, 0.25f, 0.30f, 0.60f);
    style.Colors[ImGuiCol_SeparatorHovered] = D;
    style.Colors[ImGuiCol_SeparatorActive] = N;
    style.Colors[ImGuiCol_ResizeGrip] = ImVec4(D.x, D.y, D.z, 0.30f);
    style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(N.x, N.y, N.z, 0.60f);
    style.Colors[ImGuiCol_ResizeGripActive] = N;
    style.Colors[ImGuiCol_Tab] = ImVec4(M.x * 0.25f, M.y * 0.25f, M.z * 0.25f, 0.90f);
    style.Colors[ImGuiCol_TabHovered] = ImVec4(D.x, D.y, D.z, 0.55f);
    style.Colors[ImGuiCol_TabActive] = ImVec4(M.x * 0.5f, M.y * 0.5f, M.z * 0.5f, 1.00f);
    style.Colors[ImGuiCol_TabUnfocused] = ImVec4(BG_DARK.x, BG_DARK.y, BG_DARK.z, 0.97f);
    style.Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(M.x * 0.3f, M.y * 0.3f, M.z * 0.3f, 1.00f);
    style.Colors[ImGuiCol_PlotLines] = ImVec4(0.61f, 0.61f, 0.61f, 1.00f);
    style.Colors[ImGuiCol_PlotLinesHovered] = D;
    style.Colors[ImGuiCol_PlotHistogram] = N;
    style.Colors[ImGuiCol_PlotHistogramHovered] = D;
    style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(N.x, N.y, N.z, 0.35f);
    style.Colors[ImGuiCol_DragDropTarget] = D;
    style.Colors[ImGuiCol_NavHighlight] = N;
    style.Colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
    style.Colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
    style.Colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.50f);
}

inline void ApplyModernStyle() {
    ImGuiStyle& style = ImGui::GetStyle();

    ApplyThemeColors(g_MajorColor, g_MidColor, g_MinorColor);

    style.WindowPadding = ImVec2(10.00f, 10.00f);
    style.FramePadding = ImVec2(6.00f, 5.00f);
    style.CellPadding = ImVec2(6.00f, 6.00f);
    style.ItemSpacing = ImVec2(7.00f, 7.00f);
    style.ItemInnerSpacing = ImVec2(6.00f, 6.00f);
    style.TouchExtraPadding = ImVec2(0.00f, 0.00f);
    style.IndentSpacing = 25;
    style.ScrollbarSize = 14;
    style.GrabMinSize = 10;

    style.WindowBorderSize = 2;
    style.ChildBorderSize = 1;
    style.PopupBorderSize = 1;
    style.FrameBorderSize = 1;
    style.TabBorderSize = 1;
    style.WindowRounding = 0;
    style.ChildRounding = 0;
    style.FrameRounding = 0;
    style.PopupRounding = 0;
    style.ScrollbarRounding = 0;
    style.GrabRounding = 0;
    style.TabRounding = 0;
    style.LogSliderDeadzone = 4;
}

// Soft/bubbly look — just rounds everything out. Independent of color theme,
// so any color preset below can be either sharp (default) or soft/rounded.
inline bool g_SoftRoundedStyle = false;
inline void ApplyRoundingStyle(bool soft) {
    g_SoftRoundedStyle = soft;
    ImGuiStyle& style = ImGui::GetStyle();
    float r = soft ? 12.0f : 0.0f;
    float rSmall = soft ? 8.0f : 0.0f;
    style.WindowRounding = r;
    style.ChildRounding = rSmall;
    style.FrameRounding = rSmall;
    style.PopupRounding = rSmall;
    style.ScrollbarRounding = soft ? 16.0f : 0.0f;
    style.GrabRounding = soft ? 16.0f : 0.0f;
    style.TabRounding = rSmall;
}

// Full RGB cycling — rotates ALL three theme colors through the hue wheel,
// not just the border accent. Pure color math + ImGui style writes, no game
// calls involved, safe to run every frame.
inline bool g_RGBThemeMode = false;
inline void UpdateRGBThemeIfEnabled() {
    if (!g_RGBThemeMode) return;
    static float hue = 0.0f;
    hue += 0.0015f;
    if (hue > 1.0f) hue -= 1.0f;

    ImVec4 major, mid, minor;
    ImGui::ColorConvertHSVtoRGB(hue, 0.55f, 0.35f, major.x, major.y, major.z); major.w = 1.0f;
    ImGui::ColorConvertHSVtoRGB(fmodf(hue + 0.33f, 1.0f), 0.75f, 0.95f, mid.x, mid.y, mid.z); mid.w = 1.0f;
    ImGui::ColorConvertHSVtoRGB(fmodf(hue + 0.66f, 1.0f), 0.85f, 1.00f, minor.x, minor.y, minor.z); minor.w = 1.0f;

    ApplyThemeColors(major, mid, minor);
}

// ============================================================================
// PHAROAH — Egyptian sand theme
//
// Written as its own function rather than another ApplyThemeColors() preset
// because that helper always multiplies the major colour DOWN (M * 0.14) to
// guarantee readable text on a dark window. That's the right call for neon
// themes, but it turns sand into mud. Sand needs WARM, LIGHT surfaces with DARK
// text — effectively an inverted brightness relationship — so the colours are
// set explicitly here.
//
// Palette: sun-bleached limestone and sandstone for surfaces, dark bitumen-brown
// for text, lapis blue for the highlight (the one cool accent in real Egyptian
// artwork, alongside gold), and gold for active states.
// ============================================================================
inline void ApplyPharoahSandTheme() {
    // Track these so ApplyRGBBorderAccent and the tab-highlight colour stay
    // consistent with the theme.
    g_MajorColor = ImVec4(0.76f, 0.63f, 0.41f, 1.0f); // sandstone
    g_MidColor   = ImVec4(0.85f, 0.72f, 0.48f, 1.0f); // lighter sand
    g_MinorColor = ImVec4(0.13f, 0.30f, 0.55f, 1.0f); // lapis blue

    ImGuiStyle& s = ImGui::GetStyle();

    const ImVec4 SAND_DEEP  = ImVec4(0.58f, 0.46f, 0.30f, 0.94f); // shaded dune
    const ImVec4 SAND_BASE  = ImVec4(0.80f, 0.68f, 0.47f, 0.94f); // window
    const ImVec4 SAND_LIGHT = ImVec4(0.88f, 0.78f, 0.58f, 0.96f); // raised panel
    const ImVec4 SAND_PALE  = ImVec4(0.93f, 0.86f, 0.70f, 1.00f); // limestone
    const ImVec4 INK        = ImVec4(0.16f, 0.11f, 0.06f, 1.00f); // bitumen text
    const ImVec4 INK_SOFT   = ImVec4(0.36f, 0.28f, 0.18f, 1.00f);
    const ImVec4 GOLD       = ImVec4(0.85f, 0.68f, 0.22f, 1.00f);
    const ImVec4 GOLD_HOT   = ImVec4(0.96f, 0.80f, 0.35f, 1.00f);
    const ImVec4 LAPIS      = ImVec4(0.13f, 0.30f, 0.55f, 1.00f);
    const ImVec4 TURQUOISE  = ImVec4(0.24f, 0.62f, 0.58f, 1.00f);

    // Dark text on light sand — the inversion the generic helper can't express.
    s.Colors[ImGuiCol_Text]                 = INK;
    s.Colors[ImGuiCol_TextDisabled]         = INK_SOFT;
    s.Colors[ImGuiCol_WindowBg]             = SAND_BASE;
    s.Colors[ImGuiCol_ChildBg]              = SAND_LIGHT;
    s.Colors[ImGuiCol_PopupBg]              = SAND_PALE;
    s.Colors[ImGuiCol_Border]               = ImVec4(0.42f, 0.31f, 0.16f, 1.00f); // carved edge
    s.Colors[ImGuiCol_BorderShadow]         = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);

    s.Colors[ImGuiCol_FrameBg]              = SAND_PALE;
    s.Colors[ImGuiCol_FrameBgHovered]       = ImVec4(0.97f, 0.91f, 0.76f, 1.00f);
    s.Colors[ImGuiCol_FrameBgActive]        = GOLD_HOT;

    s.Colors[ImGuiCol_TitleBg]              = SAND_DEEP;
    s.Colors[ImGuiCol_TitleBgActive]        = ImVec4(0.50f, 0.38f, 0.22f, 1.00f);
    s.Colors[ImGuiCol_TitleBgCollapsed]     = ImVec4(0.58f, 0.46f, 0.30f, 0.70f);
    s.Colors[ImGuiCol_MenuBarBg]            = SAND_DEEP;

    s.Colors[ImGuiCol_ScrollbarBg]          = ImVec4(0.70f, 0.58f, 0.40f, 0.60f);
    s.Colors[ImGuiCol_ScrollbarGrab]        = ImVec4(0.52f, 0.40f, 0.24f, 1.00f);
    s.Colors[ImGuiCol_ScrollbarGrabHovered] = GOLD;
    s.Colors[ImGuiCol_ScrollbarGrabActive]  = GOLD_HOT;

    s.Colors[ImGuiCol_CheckMark]            = LAPIS;
    s.Colors[ImGuiCol_SliderGrab]           = ImVec4(0.52f, 0.40f, 0.24f, 1.00f);
    s.Colors[ImGuiCol_SliderGrabActive]     = GOLD;

    // Buttons read as carved sandstone blocks; gold on press.
    s.Colors[ImGuiCol_Button]               = ImVec4(0.72f, 0.59f, 0.38f, 1.00f);
    s.Colors[ImGuiCol_ButtonHovered]        = ImVec4(0.82f, 0.69f, 0.45f, 1.00f);
    s.Colors[ImGuiCol_ButtonActive]         = GOLD;

    s.Colors[ImGuiCol_Header]               = ImVec4(0.68f, 0.55f, 0.34f, 1.00f);
    s.Colors[ImGuiCol_HeaderHovered]        = ImVec4(0.80f, 0.66f, 0.42f, 1.00f);
    s.Colors[ImGuiCol_HeaderActive]         = GOLD;

    s.Colors[ImGuiCol_Separator]            = ImVec4(0.45f, 0.34f, 0.18f, 0.80f);
    s.Colors[ImGuiCol_SeparatorHovered]     = GOLD;
    s.Colors[ImGuiCol_SeparatorActive]      = GOLD_HOT;

    s.Colors[ImGuiCol_ResizeGrip]           = ImVec4(0.52f, 0.40f, 0.24f, 0.70f);
    s.Colors[ImGuiCol_ResizeGripHovered]    = GOLD;
    s.Colors[ImGuiCol_ResizeGripActive]     = GOLD_HOT;

    s.Colors[ImGuiCol_Tab]                  = ImVec4(0.66f, 0.53f, 0.33f, 1.00f);
    s.Colors[ImGuiCol_TabHovered]           = GOLD;
    s.Colors[ImGuiCol_TabActive]            = ImVec4(0.86f, 0.72f, 0.46f, 1.00f);

    s.Colors[ImGuiCol_PlotLines]            = LAPIS;
    s.Colors[ImGuiCol_PlotHistogram]        = TURQUOISE;
    s.Colors[ImGuiCol_TextSelectedBg]       = ImVec4(GOLD.x, GOLD.y, GOLD.z, 0.45f);

    // Carved-stone geometry: squarer, chunkier, more deliberate than the
    // rounded neon look.
    s.WindowRounding    = 2.0f;
    s.ChildRounding     = 2.0f;
    s.FrameRounding     = 2.0f;
    s.GrabRounding      = 2.0f;
    s.PopupRounding     = 2.0f;
    s.ScrollbarRounding = 2.0f;
    s.TabRounding       = 2.0f;
    s.WindowBorderSize  = 2.0f;
    s.FrameBorderSize   = 1.0f;
}

// Sand theme uses dark text, so the slow border cycle must NOT run — it would
// drive the border toward the light sand tones and wash the outline out.
//
// g_SandThemeActive means specifically "the window background is LIGHT, so text
// must be DARK". Ink() below keys off it. The dark Egyptian theme is a normal
// dark theme in that respect, so it clears the flag and sets its own.
inline bool g_SandThemeActive = false;
inline bool g_PharoahDarkActive = false;

// ============================================================================
// Ink() — keeps coloured text readable on the LIGHT sand theme
// ============================================================================
// Most of the tool colours its headings by hand: bright green for "working",
// cyan for a section title, pale grey for a note. Those were all picked against
// a DARK window. On the sand theme the background is light limestone, so a
// bright green heading is near-invisible - which is exactly the complaint.
//
// Rather than hand-pick a second colour at several hundred call sites, this
// darkens a colour ONLY when the light theme is active, and does it by scaling
// luminance rather than by replacing the colour. The hue is preserved, so
// "green means working" still reads as green - just a dark green you can
// actually see. On every dark theme it is a no-op and returns the colour
// untouched.
inline ImVec4 Ink(const ImVec4& c) {
    if (!g_SandThemeActive) return c;

    // Rec.709 luminance. Anything above the cap gets scaled down to it.
    const float lum = 0.2126f * c.x + 0.7152f * c.y + 0.0722f * c.z;
    const float kCap = 0.34f;          // tuned against SAND_BASE (0.80,0.68,0.47)
    if (lum <= kCap || lum <= 0.0001f) return c;

    const float k = kCap / lum;
    return ImVec4(c.x * k, c.y * k, c.z * k, c.w);
}

// ============================================================================
// The PHAROAH wordmark is a button, and this is what it cycles through.
// ============================================================================
// There WAS an "Egyptian Night" theme here. It was cut: inverting the sand
// palette produced something that read as neither Egyptian nor dark, and the
// hand-picked text colours stayed dark against it because Ink() only fires on
// the light theme - so half the tool was unreadable.
//
// The themes in the Fixes tab already work properly, so the wordmark now cycles
// THOSE instead of a bespoke second palette. One list, defined once, used by
// both the title button and the Fixes tab, so they can never disagree.
//
// Egyptian Sand stays first because it is the mod's identity and the default.
struct PharoahTheme {
    const char* name;
    bool  isSand;        // sand is set directly, not through ApplyThemeColors
    ImVec4 major, mid, minor;
};

static const PharoahTheme kPharoahThemes[] = {
    // Purple/Orange/Blue is the DEFAULT now (index 0) per PRIMAL_MONKE - it's
    // easier on the eyes than the light sand for most users. Egyptian Sand is
    // second, so the FIRST click of the PHAROAH wordmark still lands on the
    // light theme, exactly as asked.
    { "Purple / Orange / Blue", false,
      ImVec4(0.32f, 0.16f, 0.45f, 1.0f), ImVec4(1.00f, 0.55f, 0.05f, 1.0f), ImVec4(0.10f, 0.75f, 1.00f, 1.0f) },
    { "Egyptian Sand", true,  ImVec4(0,0,0,1), ImVec4(0,0,0,1), ImVec4(0,0,0,1) },
    { "All Blue", false,
      ImVec4(0.10f, 0.20f, 0.40f, 1.0f), ImVec4(0.20f, 0.55f, 1.00f, 1.0f), ImVec4(0.10f, 0.85f, 1.00f, 1.0f) },
    { "All Orange", false,
      ImVec4(0.40f, 0.20f, 0.05f, 1.0f), ImVec4(1.00f, 0.60f, 0.10f, 1.0f), ImVec4(1.00f, 0.35f, 0.05f, 1.0f) },
    { "Red / White", false,
      ImVec4(0.35f, 0.08f, 0.08f, 1.0f), ImVec4(1.00f, 0.20f, 0.20f, 1.0f), ImVec4(0.95f, 0.95f, 0.95f, 1.0f) },
    { "Green / Blue", false,
      ImVec4(0.08f, 0.30f, 0.15f, 1.0f), ImVec4(0.20f, 0.90f, 0.40f, 1.0f), ImVec4(0.10f, 0.60f, 1.00f, 1.0f) },
    { "Grayscale", false,
      ImVec4(0.20f, 0.20f, 0.22f, 1.0f), ImVec4(0.75f, 0.75f, 0.78f, 1.0f), ImVec4(0.45f, 0.45f, 0.48f, 1.0f) },
    { "Sky Pastel", false,
      ImVec4(0.20f, 0.32f, 0.42f, 1.0f), ImVec4(0.60f, 0.85f, 1.00f, 1.0f), ImVec4(0.85f, 0.95f, 1.00f, 1.0f) },
};
static const int kPharoahThemeCount = (int)(sizeof(kPharoahThemes) / sizeof(kPharoahThemes[0]));

inline int g_PharoahThemeIndex = 0;

inline void ApplyPharoahThemeByIndex(int idx) {
    if (kPharoahThemeCount <= 0) return;
    g_PharoahThemeIndex = ((idx % kPharoahThemeCount) + kPharoahThemeCount) % kPharoahThemeCount;
    const PharoahTheme& th = kPharoahThemes[g_PharoahThemeIndex];
    if (th.isSand) {
        ApplyPharoahSandTheme();
        g_SandThemeActive = true;
    } else {
        ApplyThemeColors(th.major, th.mid, th.minor);
        g_SandThemeActive = false;
    }
    g_PharoahDarkActive = false;
}

// DEFERRED THEME SWITCH.
//
// Applying a theme the instant a button is clicked changes ImGui style colours
// HALFWAY THROUGH the frame. Everything already drawn that frame keeps the old
// palette and everything after it gets the new one - which is exactly the
// "background changed but the text did not" effect, and why clicking again
// appeared to fix it.
//
// The THEMES tab looked fine only because its buttons sit near the BOTTOM of
// the window, so almost everything was already drawn. The PHAROAH wordmark sits
// at the very TOP, so almost nothing was - same bug, opposite appearance.
//
// So: record the request, apply it BEFORE the next frame starts drawing. One
// frame of delay, invisible, and every widget agrees.
inline int  g_PendingThemeIndex = -1;

inline void RequestPharoahTheme(int idx) { g_PendingThemeIndex = idx; }

inline void CyclePharoahTheme() {
    RequestPharoahTheme(g_PharoahThemeIndex + 1);
}

// Called once per frame from the render hook, BEFORE any window is drawn.
inline void ApplyPendingTheme() {
    if (g_PendingThemeIndex < 0) return;
    int idx = g_PendingThemeIndex;
    g_PendingThemeIndex = -1;
    ApplyPharoahThemeByIndex(idx);
}

inline const char* PharoahThemeName() {
    return kPharoahThemes[g_PharoahThemeIndex].name;
}

// Call once per frame — border slowly cycles between the CURRENT theme's
// major and minor colors. Fixed bug: this used to hardcode purple regardless
// of theme selection, which is why switching themes didn't visibly do anything.
inline void ApplyRGBBorderAccent() {
    // The sand theme deliberately uses a dark carved-stone border against light
    // surfaces. Letting the cycler run would blend it toward sand and erase the
    // outline, so it's skipped entirely for that theme.
    if (g_SandThemeActive || g_PharoahDarkActive) return;
    static float t = 0.0f;
    t += 0.0008f; // very slow
    float phase = (sinf(t) + 1.0f) * 0.5f; // 0..1

    ImVec4 c;
    c.x = g_MajorColor.x + (g_MinorColor.x - g_MajorColor.x) * phase;
    c.y = g_MajorColor.y + (g_MinorColor.y - g_MajorColor.y) * phase;
    c.z = g_MajorColor.z + (g_MinorColor.z - g_MajorColor.z) * phase;
    c.w = 0.90f;

    ImGuiStyle& style = ImGui::GetStyle();
    style.Colors[ImGuiCol_Border] = c;
    style.Colors[ImGuiCol_TitleBgActive] = ImVec4(c.x * 0.6f, c.y * 0.6f, c.z * 0.6f, 1.0f);
}
