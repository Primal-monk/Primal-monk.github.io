#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include "menus/Gating.h"
#include <Windows.h>

// ============================================================================
// LEAVE  —  leave the current match and get back to the menu to re-queue
// ============================================================================
// Route: APlayerController::ConsoleCommand("disconnect").
//
// "disconnect" is the stock Unreal Engine 3 command for dropping the client's
// connection to a server and returning to the entry level. It is not a Paladins
// invention and it is not a Tempest one — it is engine-level, which is why it is
// the most likely of the options here to just work.
//
// WHAT THIS DOES NOT DO
//   It does not cancel a desertion penalty, hide the leave from the server, or
//   make you un-leave. The server sees a client that disconnected, exactly as
//   if the game had crashed or the network dropped. If Tempest applies a leaver
//   penalty, you will get it. This is a convenience button, not an exploit.
//
// Bot matches vs real matches: both are the same client-side action. A bot
// match may simply end; a real one continues without you.
//
// The command box below exists because "disconnect" is the best guess, not a
// certainty. If it does something unhelpful on Tempest, the alternates are one
// click away and whatever works can be promoted to the main button.
// ============================================================================

namespace LeaveMatch {

    inline bool  g_Armed = false;         // two-step confirm
    inline char  g_Status[192] = "Ready.";
    inline char  g_Custom[128] = "disconnect";

    // Alternates, in rough order of how likely they are to be the right thing.
    struct Preset { const wchar_t* cmd; const char* label; const char* note; };
    static const Preset kPresets[] = {
        { L"disconnect",     "disconnect",     "Engine-standard. Drops the server connection, returns to the entry level." },
        { L"open Front_End", "open Front_End", "Force-travel to the front-end map. Map name is a guess." },
        { L"cancel",         "cancel",         "Cancels a pending connection/travel. Useful while still loading in." },
    };

    inline void Fire(const wchar_t* cmd, const char* label) {
        if (SafeCalls::RunConsoleCommand(cmd))
            wsprintfA(g_Status, "Sent '%s'. If nothing happened, that command is not handled.", label);
        else
            wsprintfA(g_Status, "'%s' faulted or there was no controller.", label);
        g_Armed = false;
    }

    inline void DrawControls(bool inMatch) {
        // Leaving a match is deliberately NOT gated - see g_GateGroup in
        // Gating.h. The banner stays so the state is still visible.
        Gating::DrawBlockedBannerFor(Gating::Gated::Leave);

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("LEAVE MATCH");
        ImGui::PopStyleColor();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::TextUnformatted("State:");
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Text, Gating::StateColor());
        ImGui::TextUnformatted(Gating::StateName());
        ImGui::PopStyleColor();

        if (!inMatch) {
            ImGui::TextDisabled("Not in a match — nothing to leave.");
        }

        ImGui::Spacing();
        ImGui::TextWrapped("Disconnects you from the current match and returns you to the menu so "
            "you can queue again.");
        ImGui::Spacing();

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.72f, 0.3f, 1.0f)));
        ImGui::TextWrapped("The server sees a normal disconnect. If Tempest gives leaver penalties, "
            "you will get one. This does not hide anything.");
        ImGui::PopStyleColor();

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        // Two-step, because a misclick mid-match is expensive.
        if (!g_Armed) {
            if (ImGui::Button(">>> LEAVE MATCH <<<", ImVec2(260, 40))) g_Armed = true;
            ImGui::SameLine();
            ImGui::TextDisabled("(asks once more before it fires)");
        } else {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.62f, 0.16f, 0.14f, 1.0f));
            if (ImGui::Button("CONFIRM - LEAVE NOW", ImVec2(260, 40)))
                Fire(L"disconnect", "disconnect");
            ImGui::PopStyleColor();
            ImGui::SameLine();
            if (ImGui::Button("Cancel", ImVec2(110, 40))) {
                g_Armed = false;
                lstrcpynA(g_Status, "Cancelled.", 190);
            }
        }

        ImGui::Spacing();
        ImGui::TextWrapped("%s", g_Status);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        if (ImGui::CollapsingHeader("If the main button does nothing - alternates")) {
            ImGui::TextWrapped("'disconnect' is the best guess, not a guarantee. Try these and tell "
                "me which one works; whichever it is becomes the main button.");
            ImGui::Spacing();
            for (int i = 0; i < (int)(sizeof(kPresets) / sizeof(kPresets[0])); ++i) {
                char id[64];
                wsprintfA(id, "%s##lv%d", kPresets[i].label, i);
                if (ImGui::Button(id, ImVec2(190, 26))) Fire(kPresets[i].cmd, kPresets[i].label);
                ImGui::SameLine();
                ImGui::TextDisabled("%s", kPresets[i].note);
            }

            ImGui::Spacing();
            ImGui::TextUnformatted("Custom console command:");
            ImGui::SetNextItemWidth(300);
            bool go = ImGui::InputText("##lvcustom", g_Custom, sizeof(g_Custom),
                                       ImGuiInputTextFlags_EnterReturnsTrue);
            ImGui::SameLine();
            if (ImGui::Button("Run##lvrun", ImVec2(90, 0)) || go) {
                wchar_t w[128] = { 0 };
                MultiByteToWideChar(CP_ACP, 0, g_Custom, -1, w, 127);
                Fire(w, g_Custom);
            }
            ImGui::TextDisabled("Goes straight to APlayerController::ConsoleCommand. Most commands "
                                "are stripped from shipping builds and will silently do nothing.");
        }
    }
}
