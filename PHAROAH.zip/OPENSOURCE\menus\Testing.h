#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "menus/VisibilityBoxes.h"
#include "menus/ColorGrading.h"
#include "menus/CallLogger.h"
#include <Windows.h>
#include <string>

// Central place to test risky/unknown game data safely — click a button, get
// a report, copy it, paste it back. Faster than troubleshooting one feature
// at a time blind.
//
// FIXED A REAL BUG: the old outline-parameter tester applied test colors to
// YOUR OWN character's outline — but you never see your own outline in a
// first-person game, so it could never have shown you anything, regardless
// of whether the parameter name was right. Now it targets a visible bot/enemy
// instead, so you can actually watch the result.

namespace Testing {

    inline char g_Output[8192] = "Run \"FULL Diagnostic Dump\" first — it's the fastest way to get "
        "everything useful in one shot.";

    inline void SetOutput(const std::string& s) {
        strncpy_s(g_Output, sizeof(g_Output), s.c_str(), _TRUNCATE);
    }

    // ---- Pickup scanner: finds real ATgDeploy_Pickup actors in the world
    // (ult/CD/credit orbs, the Heaven & Hell-style ones you found in shooting
    // range) and lets you call ApplyEffect on them targeting yourself, instead
    // of needing to physically walk into one. All the isolation/raw-buffer
    // rules from CopyClassNameToBuf etc apply — no std::string inside any
    // __try-containing function here. ----
    inline SDK::UObject* TryGetObjectAt(SDK::TAntiCheatArray<SDK::UObject*>& arr, size_t i) {
        __try {
            if (!arr.IsValidIndex(i)) return nullptr;
            return arr[i];
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return nullptr;
        }
    }

    // FIXED after live testing: was including Default__ prefixed objects —
    // those are class DEFAULT OBJECTS (CDOs), the shared template every
    // instance of a class is built from, not real spawned pickups. Calling
    // gameplay logic (ApplyEffect) on a CDO makes no sense and is a plausible
    // crash source ("failed/crashed" on several of them). Also filters out
    // destroyed/pending-delete/hidden instances — "hidden" is the standard
    // UE3 signal a pickup is currently on cooldown/respawning, not
    // collectible, which is very likely why it "worked once, then stopped" —
    // the same pickup instance the button remembered got consumed and went
    // into its respawn-hidden state, and the stale button kept pointing at it.
    // Filter for hidden/on-cooldown orbs. Now OPTIONAL, because it may be
    // excluding perfectly usable wave-defense orbs.
    inline bool g_PickupSkipHidden = true;

    // WHY WAVE DEFENSE HAD NO BUTTONS:
    // ATgDeploy_Pickup_OwnerOnly derives from ATgDeployable, NOT from
    // ATgDeploy_Pickup. So an IsA(ATgDeploy_Pickup) test misses it entirely —
    // and owner-only is exactly what wave defense's self-buff orbs (infinite
    // ammo / damage / speed) are. It also has ONLY Touch(), no ApplyEffect().
    //
    // So detection is by CLASS NAME instead: anything whose class name contains
    // "Pickup" counts, regardless of which branch of the hierarchy it sits on.
    // Same lesson as the PostRender and HealthBar fixes — name matching beats
    // IsA/FindClass in this SDK.
    inline bool TryIsUsablePickupByName(SDK::UObject* obj, const char* clsName) {
        __try {
            if (!obj || !clsName || !clsName[0]) return false;
            if (!strstr(clsName, "Pickup")) return false;
            SDK::AActor* actor = (SDK::AActor*)obj;
            if (actor->bDeleteMe || actor->bPendingDelete) return false;
            if (g_PickupSkipHidden && actor->bHidden) return false;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // Kept for reference/compat — the IsA path that missed OwnerOnly.
    inline bool TryIsUsablePickup(SDK::UObject* obj, SDK::UClass* pickupClass) {
        __try {
            if (!obj || !pickupClass || !obj->IsA(pickupClass)) return false;
            SDK::AActor* actor = (SDK::AActor*)obj;
            if (actor->bDeleteMe || actor->bPendingDelete) return false;
            if (g_PickupSkipHidden && actor->bHidden) return false;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }


    inline void TryCopyObjName(SDK::UObject* obj, char* buf, size_t bufSize) {
        buf[0] = 0;
        __try {
            if (!obj || obj->Name.Index == 0) return;
            auto& names = SDK::FName::GetGlobalNames();
            if (!names.IsValidIndex((size_t)obj->Name.Index)) return;
            SDK::FNameEntry* entry = names[obj->Name.Index];
            if (!entry) return;
            const char* ansi = entry->GetAnsiName();
            if (ansi) strncpy_s(buf, bufSize, ansi, _TRUNCATE);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            buf[0] = 0;
        }
    }

    inline bool TryApplyPickupEffect(SDK::AActor* pickup, SDK::ATgPawn_Character* target) {
        __try {
            if (!pickup || !target) return false;
            ((SDK::ATgDeploy_Pickup*)pickup)->ApplyEffect(target);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // THE fix for "works sometimes, not other times." ATgDeploy_HHPickup (the
    // Heaven&Hell-style ult orb) overrides Touch but NOT ApplyEffect — so
    // calling ApplyEffect on one does nothing at all, while it works fine on a
    // base ATgDeploy_Pickup. Your scan returns a MIX of both classes, which is
    // exactly why some buttons worked and others silently didn't. Touch is the
    // real collection entry point (what fires when you physically walk into
    // it), so it's the correct call for both types.
    inline bool TryTouchPickup(SDK::AActor* pickup, SDK::AActor* self) {
        __try {
            if (!pickup || !self) return false;
            SDK::FVector loc = pickup->Location;
            SDK::FVector normal; normal.X = 0.0f; normal.Y = 0.0f; normal.Z = 1.0f;
            ((SDK::ATgDeploy_Pickup*)pickup)->Touch(self, nullptr, loc, normal);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // Reads the object's CLASS name (not instance name) so we can finally tell
    // TgDeploy_HHPickup apart from a plain TgDeploy_Pickup — previously every
    // entry just showed the same generic label, hiding the real difference.
    inline void TryCopyClassName(SDK::UObject* obj, char* buf, size_t bufSize) {
        buf[0] = 0;
        __try {
            if (!obj || !obj->Class) return;
            auto& names = SDK::FName::GetGlobalNames();
            int idx = obj->Class->Name.Index;
            if (idx == 0 || !names.IsValidIndex((size_t)idx)) return;
            SDK::FNameEntry* entry = names[idx];
            if (!entry) return;
            const char* ansi = entry->GetAnsiName();
            if (ansi) strncpy_s(buf, bufSize, ansi, _TRUNCATE);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            buf[0] = 0;
        }
    }

    // FIXED THE CRASH: buttons run inside hkPresent (the render thread), but
    // ApplyEffect/ApplyCommanderPassiveTeam go through ProcessEvent — calling
    // a scripted function from the wrong thread is exactly the corruption
    // pattern that's crashed every other one-shot action in this project,
    // always surfacing on the ENGINE's own next ProcessEvent dispatch (hence
    // the crash trace always pointing at the unconditional
    // ProcessEventOriginal(...) call, not the button itself). Same fix as
    // everywhere else: don't call it directly from the button, just set a
    // pending flag, and consume it from inside HookedProcessEvent instead
    // (see Testing::ProcessPendingSafeActions, called from main.cpp).
    inline int g_PendingPickupApplyIndex = -1;
    inline int g_PendingPickupTouchIndex = -1;

    inline SDK::AActor* g_FoundPickups[16] = {};
    inline char g_FoundPickupNames[16][64] = {};
    inline bool g_FoundPickupTouchOnly[16] = {}; // OwnerOnly variants have no ApplyEffect
    inline int g_FoundPickupCount = 0;
    inline ULONGLONG g_LastPickupScanMs = 0;

    // Scans the WHOLE object table (GObjects) for live, currently-usable
    // ATgDeploy_Pickup instances. Somewhat heavy (thousands of objects) but
    // only runs on a throttle now (see RunPickupScanThrottled below), not
    // every frame.
    // quiet=true (the auto-refresh path) skips writing to the output box —
    // otherwise the 2s auto-scan would constantly overwrite whatever report
    // you were trying to read/copy (environment check, card results, etc).
    inline void RunPickupScan(bool quiet = false) {
        std::string out = "=== Pickup Scan (name-based: catches Pickup, Teamwide, HHPickup AND OwnerOnly) ===\n";
        // NOTE: the old version resolved ATgDeploy_Pickup::StaticClass() here and
        // ABORTED the entire scan if it came back null. Two problems: it made a
        // failed class lookup fatal (the same trap as the health bar bug), and it
        // was pointless anyway — matching is by class NAME now, which needs no
        // resolved UClass and catches OwnerOnly pickups that IsA missed.
        auto& objects = SDK::UObject::GetGlobalObjects();
        size_t count = objects.Num();
        int found = 0;
        for (size_t i = 0; i < count && found < 16; i++) {
            SDK::UObject* obj = TryGetObjectAt(objects, i);
            if (!obj) continue;
            char nameBuf[64];
            TryCopyObjName(obj, nameBuf, sizeof(nameBuf));
            if (_strnicmp(nameBuf, "Default__", 9) == 0) continue; // CDO — skip
            // Class name drives everything now: it catches OwnerOnly (which the
            // IsA test missed) AND tells us which call to use per row.
            char classBuf[64];
            TryCopyClassName(obj, classBuf, sizeof(classBuf));
            if (!TryIsUsablePickupByName(obj, classBuf)) continue;
            // OwnerOnly has no ApplyEffect at all — only Touch. Record that so
            // the UI can offer the right button instead of a dead one.
            g_FoundPickupTouchOnly[found] = (strstr(classBuf, "OwnerOnly") != nullptr);
            if (classBuf[0]) {
                strncpy_s(g_FoundPickupNames[found], sizeof(g_FoundPickupNames[found]), classBuf, _TRUNCATE);
            } else {
                strncpy_s(g_FoundPickupNames[found], sizeof(g_FoundPickupNames[found]), nameBuf, _TRUNCATE);
            }
            g_FoundPickups[found] = (SDK::AActor*)obj;
            out += "[" + std::to_string(found) + "] " + g_FoundPickupNames[found] + "\n";
            found++;
        }
        g_LastPickupScanMs = GetTickCount64();
        g_FoundPickupCount = found;
        if (found == 0) {
            out += "None found in this map right now — the pickups may only exist in "
                "specific modes (shooting range, Heaven & Hell) or need to actually be "
                "spawned/active. Try this again while one is visibly present on screen.\n";
        } else {
            out += "\nUse the buttons below to apply one to yourself directly (no need to "
                "walk into it).\n";
        }
        if (!quiet) SetOutput(out);
    }

    // Auto-refreshes every 2s while the tab is open, instead of needing a
    // manual click every time — this is what "why did it stop working" was
    // really about: the button remembered a SPECIFIC instance that had
    // already been consumed and gone into its respawn-hidden state. A fresh
    // scan naturally drops anything no longer usable and picks up newly
    // available ones.
    inline void RunPickupScanThrottled() {
        if (GetTickCount64() - g_LastPickupScanMs < 2000) return;
        RunPickupScan(true); // quiet — don't clobber whatever's in the output box
    }

    // Isolated, SEH-only, no C++ objects in scope (MSVC forbids __try sharing
    // a scope with objects requiring unwinding — that's the "Cannot use __try
    // in functions that require object unwinding" build error seen earlier).
    inline bool HasOutlineMaterial(SDK::ATgPawn* pawn) {
        __try {
            return pawn && pawn->m_OutlineMaterial != nullptr;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    inline bool TryApplyParamToPawn(SDK::ATgPawn* pawn, const char* param, float r, float g, float b) {
        __try {
            if (!pawn || !pawn->m_OutlineMaterial) return false;
            SDK::FLinearColor c; c.R = r; c.G = g; c.B = b; c.A = 1.0f;
            pawn->m_OutlineMaterial->SetVectorParameterValue(SDK::FName(param), &c);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // Extra candidates inspired by an observation: enemies already flash white
    // when hit, and their (game's own) border shifts yellow at range instead
    // of red — meaning there's a real distance/hit-reaction color system
    // already active. If a param name here matches THAT system, it'd likely
    // behave more reliably than a generic guess.
    static const char* g_OutlineParamCandidates[] = {
        "Color", "OutlineColor", "TeamColor", "SilhouetteColor",
        "RimColor", "EmissiveColor", "HighlightColor", "Tint", "GlowColor",
        "DistanceColor", "RevealColor", "SpottedColor", "FlashColor", "HitColor"
    };

    // One click, all enemies: assigns a DIFFERENT candidate parameter name to
    // each visible enemy simultaneously (candidate #1 -> enemy #1, #2 -> #2,
    // etc, wrapping if there are more enemies than candidates), all colored
    // bright magenta so it's obvious. Look at the screen ONCE — whichever
    // enemy actually turned magenta tells you (via the legend below) which
    // parameter name is the real one. No clicking through candidates one at a
    // time on a single target.
    inline void RunOutlineParamSweep() {
        std::string out = "=== Outline Param Sweep ===\n";
        VisibilityBoxes::GatherResult g = VisibilityBoxes::SafeGatherBoxes();
        if (!g.ok) {
            out += "Gather failed — not in a match.\n";
            SetOutput(out);
            return;
        }
        int numCandidates = sizeof(g_OutlineParamCandidates) / sizeof(g_OutlineParamCandidates[0]);
        int tested = 0;
        for (int i = 0; i < g.count; i++) {
            auto& e = g.entries[i];
            if (e.kind != VisibilityBoxes::BoxKind::Enemy) continue;
            const char* param = g_OutlineParamCandidates[tested % numCandidates];
            bool ok = TryApplyParamToPawn(e.pawnPtr, param, 1.0f, 0.0f, 1.0f); // bright magenta
            out += std::string(e.championName[0] ? e.championName : "(unnamed)") + " -> tried \"" + param + "\": " + (ok ? "call OK" : "no material/failed") + "\n";
            tested++;
        }
        if (tested == 0) {
            out += "No enemies found. Enable Highlight Enemies first (Highlights tab), get some "
                "bots/enemies on screen, then run this again.\n";
        } else {
            out += "\nLook at the screen NOW. Whichever enemy above is magenta, tell me their "
                "name/line — that tells us the real parameter name.\n";
        }
        SetOutput(out);
    }

    // ---- The big one: click this first, get everything at once ----
    inline void RunFullDiagnostic() {
        std::string out = "=== FULL DIAGNOSTIC DUMP ===\n\n";

        if (!Globals::LocalController || !Globals::LocalPawn) {
            out += "Not in a match — join one (shooting range counts) and run again.\n";
            SetOutput(out);
            return;
        }

        SDK::ATgPlayerController* ctrl = (SDK::ATgPlayerController*)Globals::LocalController;
        SDK::ATgPawn* myPawn = (SDK::ATgPawn*)Globals::LocalPawn;

        out += "--- Local player ---\n";
        out += "Controller/pawn: present\n";
        out += "Own outline material: " + std::string(HasOutlineMaterial(myPawn) ? "present (but invisible to you, first-person)" : "NULL") + "\n\n";

        out += "--- Enemies/allies visible right now ---\n";
        VisibilityBoxes::GatherResult g = VisibilityBoxes::SafeGatherBoxes();
        int allies = 0, enemies = 0, withMaterial = 0;
        for (int i = 0; i < g.count; i++) {
            auto& e = g.entries[i];
            if (e.kind == VisibilityBoxes::BoxKind::Other) continue;
            if (e.kind == VisibilityBoxes::BoxKind::Ally) allies++; else enemies++;
            if (HasOutlineMaterial(e.pawnPtr)) withMaterial++;
        }
        out += "Real players seen: " + std::to_string(allies + enemies) + " (" + std::to_string(allies) + " ally, " + std::to_string(enemies) + " enemy)\n";
        out += "Of those, have m_OutlineMaterial right now: " + std::to_string(withMaterial) + "\n";
        out += (withMaterial > 0)
            ? "-> Material exists. Use \"Run Outline Param Sweep\" below to find the right color parameter name.\n\n"
            : "-> Nobody has one right now. Enable Highlight Teammates/Enemies (Highlights tab) first, then re-run this.\n\n";

        out += "--- Desaturation/grayscale internal state (raw fields) ---\n";
        out += "m_IsDesaturationInterpolating: " + std::to_string((int)ctrl->m_IsDesaturationInterpolating) + "\n";
        out += "m_DesaturationFromTo: (" + std::to_string(ctrl->m_DesaturationFromTo.X) + ", " + std::to_string(ctrl->m_DesaturationFromTo.Y) + ")\n";
        out += "m_DesaturationInterpolateSeconds: " + std::to_string(ctrl->m_DesaturationInterpolateSeconds) + "\n";
        out += "m_DesaturationUsedSeconds: " + std::to_string(ctrl->m_DesaturationUsedSeconds) + "\n";
        out += "(These prove desaturation is tracked directly on the controller, not through a "
            "named post-process effect — likely why color grading can't find one by name. Tint "
            "would need whatever internal object actually reads these fields, not yet located.)\n\n";

        out += "--- Color grading effect name candidates ---\n";
        for (const char* name : ColorGrading::g_Candidates) {
            bool real = ColorGrading::IsRealName(name);
            SDK::UTgCombinedPostProcessEffect* fx = real ? ColorGrading::TryGetEffect(name) : nullptr;
            out += std::string("[") + (fx ? "FOUND   " : (real ? "no fx   " : "no name ")) + "] " + name + "\n";
        }

        SetOutput(out);
    }

    // "Auto-max cards" mode lead: found a real field, m_nForceLoadoutCardLevels,
    // on ATgGame_Paladins (the game-mode rules object itself) — matches
    // exactly what was described as a real limited-time mode. UNKNOWN yet:
    // whether the client even has a live, writable instance of this at all —
    // GameInfo is often server-only in UE3. This checks that FIRST rather
    // than guessing with a write.
    // THE decisive diagnostic. NetMode tells us who has authority in this
    // match: 0 = Standalone (WE are the authority — cheat commands actually
    // execute), 3 = Client (the REAL server has authority — gameplay-side
    // cheat commands are just polite requests the server can ignore or even
    // kick us for). This one number likely explains every "worked in shooting
    // range, dead everywhere else" pattern we've seen.
    inline int TryReadNetMode() {
        __try {
            if (!Globals::LocalPawn || !Globals::LocalPawn->WorldInfo) return -1;
            return (int)Globals::LocalPawn->WorldInfo->NetMode.GetValue();
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return -2;
        }
    }

    inline void RunEnvironmentCheck() {
        std::string out = "=== ENVIRONMENT CHECK (run this in every mode you test!) ===\n";
        int nm = TryReadNetMode();
        out += "NetMode: " + std::to_string(nm) + "  ";
        switch (nm) {
            case 0: out += "(Standalone — WE have authority. Cheat commands should genuinely work here.)\n"; break;
            case 1: out += "(Dedicated server?? unexpected on a client)\n"; break;
            case 2: out += "(Listen server — we're hosting. Commands should work.)\n"; break;
            case 3: out += "(Client — the SERVER has authority. Gameplay commands are requests the "
                "server can silently ignore, and some may get us kicked. This explains dead buttons.)\n"; break;
            case -1: out += "(no pawn/world yet — join a match first)\n"; break;
            default: out += "(read failed)\n"; break;
        }
        out += "LocalController: " + std::string(Globals::LocalController ? "yes" : "NO") + "\n";
        out += "CheatManager:    " + std::string((Globals::LocalController && Globals::LocalController->CheatManager) ? "yes" : "NO") + "\n";
        out += "LocalPawn:       " + std::string(Globals::LocalPawn ? "yes" : "NO") + "\n";
        out += "LocalWeapon:     " + std::string(Globals::LocalWeapon ? "yes" : "NO") + "\n";
        out += "Live usable pickups found by last scan: " + std::to_string(g_FoundPickupCount) + "\n";
        out += "\nCopy this and paste it back — one paste from each mode (shooting range, bot "
            "match, wave defense, real match) tells us exactly which features CAN work where.\n";
        SetOutput(out);
    }

    inline bool TryGetGameModeObject(SDK::ATgGame_Paladins** outGame) {
        __try {
            if (!Globals::LocalPawn || !Globals::LocalPawn->WorldInfo || !Globals::LocalPawn->WorldInfo->Game) return false;
            SDK::AGameInfo* game = Globals::LocalPawn->WorldInfo->Game;
            if (!game->IsA(SDK::ATgGame_Paladins::StaticClass())) return false;
            *outGame = (SDK::ATgGame_Paladins*)game;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // Isolated — no C++ objects in scope, same reason as TryGetGameModeObject above.
    inline int TryReadForceLoadoutCardLevels(SDK::ATgGame_Paladins* game) {
        __try {
            return game->m_nForceLoadoutCardLevels;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return -999;
        }
    }

    // ---- Octavia's 4 "Commander" buffs are NOT a mystery field — they're
    // real ATgDevice subclasses (ATgDevice_CommanderPassive covers Shield/
    // Ult/Cooldown via ApplyCommanderPassiveTeam(bool); the Credit one is its
    // own class, ATgDevice_CommanderCreditPassive, with a no-arg overload).
    // Same device-slot system as any card — no separate CE-found address
    // needed. Her pawn class also caches a direct pointer to whichever one
    // is equipped (m_CachedCommanderPassive), but we find it by scanning eq
    // points like AutoMaxEquippedCards does, which works even if that cache
    // is stale/null. ----
    inline SDK::ATgDevice* TryFindCommanderPassiveDevice(SDK::ATgPawn* pawn, bool* outIsCreditVariant) {
        __try {
            SDK::UClass* passiveClass = SDK::ATgDevice_CommanderPassive::StaticClass();
            SDK::UClass* creditClass = SDK::ATgDevice_CommanderCreditPassive::StaticClass();
            for (int point = 0; point <= 20; point++) {
                SDK::ATgDevice* d = pawn->GetDeviceByEqPoint(point);
                if (!d) continue;
                if (creditClass && d->IsA(creditClass)) { *outIsCreditVariant = true; return d; }
                if (passiveClass && d->IsA(passiveClass)) { *outIsCreditVariant = false; return d; }
            }
            return nullptr;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return nullptr;
        }
    }

    inline int TryReadDeviceId(SDK::ATgDevice* d) {
        __try { return d->r_nDeviceId; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }

    inline bool TryTriggerCommanderPassive(SDK::ATgDevice* d, bool isCredit) {
        __try {
            if (isCredit) ((SDK::ATgDevice_CommanderCreditPassive*)d)->ApplyCommanderPassiveTeam();
            else ((SDK::ATgDevice_CommanderPassive*)d)->ApplyCommanderPassiveTeam(true);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    inline SDK::ATgDevice* g_CommanderPassiveDevice = nullptr;
    inline bool g_CommanderPassiveIsCredit = false;
    inline int g_CommanderPassiveDeviceId = 0;
    inline bool g_PendingCommanderPassiveTrigger = false;

    // Consumes both pending one-shot actions above — call this from
    // HookedProcessEvent (the safe thread for one-shot scripted calls),
    // never from a button/render-thread context.
    inline void ProcessPendingSafeActions() {
        if (g_PendingPickupApplyIndex >= 0) {
            int i = g_PendingPickupApplyIndex;
            g_PendingPickupApplyIndex = -1;
            if (i < g_FoundPickupCount && Globals::LocalPawn) {
                CallLogger::Mark("[us] Pickup ApplyEffect");
                bool ok = TryApplyPickupEffect(g_FoundPickups[i], (SDK::ATgPawn_Character*)Globals::LocalPawn);
                SetOutput(std::string("Applied ") + g_FoundPickupNames[i] + ": " + (ok ? "call OK, check if the effect landed.\n" : "failed/crashed (caught safely).\n"));
            }
        }
        if (g_PendingPickupTouchIndex >= 0) {
            int i = g_PendingPickupTouchIndex;
            g_PendingPickupTouchIndex = -1;
            if (i < g_FoundPickupCount && Globals::LocalPawn) {
                CallLogger::Mark("[us] Pickup Touch");
                bool ok = TryTouchPickup(g_FoundPickups[i], (SDK::AActor*)Globals::LocalPawn);
                SetOutput(std::string("Touch ") + g_FoundPickupNames[i] + ": " + (ok ? "call OK — this is the real collection path, works on HHPickup too.\n" : "failed/crashed (caught safely).\n"));
            }
        }
        if (g_PendingCommanderPassiveTrigger) {
            g_PendingCommanderPassiveTrigger = false;
            if (g_CommanderPassiveDevice) {
                bool ok = TryTriggerCommanderPassive(g_CommanderPassiveDevice, g_CommanderPassiveIsCredit);
                SetOutput(std::string("Triggered device ") + std::to_string(g_CommanderPassiveDeviceId) + ": " + (ok ? "call OK.\n" : "failed/crashed (caught safely).\n"));
            }
        }
    }

    inline void RunCommanderPassiveScan() {
        std::string out = "=== Commander Passive Scan ===\n";
        if (!Globals::LocalPawn) {
            out += "Not in a match.\n";
            SetOutput(out);
            return;
        }
        bool isCredit = false;
        SDK::ATgDevice* d = TryFindCommanderPassiveDevice((SDK::ATgPawn*)Globals::LocalPawn, &isCredit);
        g_CommanderPassiveDevice = d;
        g_CommanderPassiveIsCredit = isCredit;
        if (!d) {
            g_CommanderPassiveDeviceId = 0;
            out += "None found equipped right now. This only exists if you're playing Octavia AND "
                "picked one of her 4 buffs pregame. Join a match as her, pick one, then rescan.\n";
        } else {
            g_CommanderPassiveDeviceId = TryReadDeviceId(d);
            out += "Found it! Device ID " + std::to_string(g_CommanderPassiveDeviceId) +
                " (class: " + (isCredit ? "CommanderCreditPassive" : "CommanderPassive") + ")\n"
                "This is a real, separate device slot from her regular talent — confirms it's not "
                "the same field you were editing in Cheat Engine.\n"
                "Use the trigger button below to call ApplyCommanderPassiveTeam directly.\n";
        }
        SetOutput(out);
    }

    inline void RunCardMaxModeCheck() {
        std::string out = "=== Auto-Max Cards Mode Check ===\n";
        SDK::ATgGame_Paladins* game = nullptr;
        if (!TryGetGameModeObject(&game)) {
            out += "WorldInfo->Game is either null or not an ATgGame_Paladins on this client.\n"
                "This would mean the client doesn't have a live GameInfo instance to read/write "
                "at all (common in UE3 — GameInfo is often server-only), which would rule out "
                "this specific approach.\n";
        } else {
            int current = TryReadForceLoadoutCardLevels(game);
            out += "Got a live ATgGame_Paladins object. m_nForceLoadoutCardLevels = " + std::to_string(current) + "\n";
            out += "(0 or unset likely means the mode isn't active in this match. If you're in a "
                "match that actually replicates this, that number reveals what it looks like when "
                "the mode IS on.)\n";
        }
        SetOutput(out);
    }

    // ================= FIRE MODE INSPECTOR =================
    // The existing fire-mode menu tells you HOW MANY modes a device has, but
    // not what each one IS — so a hidden mode is indistinguishable from a
    // duplicate. This dumps the actual per-mode stats, which is how you
    // identify one by its fingerprint.
    //
    // Concrete example: Buck's "Double Barrel" (talent 23458) changes his
    // weapon to 900 damage with a 2-shot clip instead of 700 with a full clip.
    // Damage itself isn't a field on UTgDeviceFire (it flows through the item-
    // property system), but m_nAmmoClipSize IS — so a mode reporting clip size
    // 2 on Buck's weapon is almost certainly Double Barrel. Same trick works
    // for any talent that alters ammo/fire timing.
    struct FireModeInfo {
        int eqPoint;
        int deviceId;
        int modeIndex;
        int modeId;
        int clipSize;
        int ammoCost;
        int shotsPerFire;
        int fireType;
        float fireTime;
        char className[64];
    };

    // Isolated: pointers/ints only, no C++ objects (the recurring C2712 rule).
    inline bool TryReadFireMode(SDK::ATgPawn* pawn, int eqPoint, int modeIdx,
                               FireModeInfo* out, int* outModeCount, int* outDeviceId,
                               SDK::UObject** outDeviceObj) {
        __try {
            SDK::ATgDevice* d = pawn->GetDeviceByEqPoint(eqPoint);
            if (!d) return false;
            *outDeviceId = d->r_nDeviceId;
            *outDeviceObj = (SDK::UObject*)d;
            int count = d->m_FireMode.Num();
            *outModeCount = count;
            if (modeIdx < 0 || modeIdx >= count) return false;
            SDK::UTgDeviceFire* fm = d->m_FireMode[modeIdx];
            if (!fm) return false;
            out->eqPoint = eqPoint;
            out->deviceId = *outDeviceId;
            out->modeIndex = modeIdx;
            out->modeId = fm->m_nId;
            out->clipSize = fm->m_nAmmoClipSize;
            out->ammoCost = fm->m_nAmmoCostPerShot;
            out->shotsPerFire = fm->m_nShotsPerFire;
            out->fireType = (int)fm->m_nFireType.GetValue();
            out->fireTime = fm->m_fFireTime;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline void RunFireModeInspector() {
        std::string out = "=== FIRE MODE INSPECTOR ===\n"
            "Every equipped device, every fire mode, with its real stats.\n"
            "clip = m_nAmmoClipSize, cost = ammo per shot, shots = shots per trigger pull.\n"
            "A mode whose clip/timing differs from mode 0 is a genuine alternate mode.\n"
            "(Buck's Double Barrel fingerprint = clip size 2 on his weapon.)\n\n";

        if (!Globals::LocalPawn) {
            out += "Not in a match.\n";
            SetOutput(out);
            return;
        }
        SDK::ATgPawn* pawn = (SDK::ATgPawn*)Globals::LocalPawn;

        int devicesFound = 0, multiModeDevices = 0;
        for (int p = 0; p <= 20; p++) {
            int modeCount = 0, deviceId = 0;
            SDK::UObject* devObj = nullptr;
            FireModeInfo probe = {};
            // mode 0 read also gives us the device's mode count
            bool any = TryReadFireMode(pawn, p, 0, &probe, &modeCount, &deviceId, &devObj);
            if (deviceId <= 0 || modeCount <= 0) continue;
            devicesFound++;

            char clsBuf[64] = {};
            if (devObj) TryCopyClassName(devObj, clsBuf, sizeof(clsBuf));

            out += "eq" + std::to_string(p) + "  device " + std::to_string(deviceId)
                 + "  [" + (clsBuf[0] ? clsBuf : "?") + "]  modes=" + std::to_string(modeCount) + "\n";
            if (modeCount > 1) multiModeDevices++;

            for (int m = 0; m < modeCount && m < 8; m++) {
                FireModeInfo fi = {};
                int mc = 0, did = 0;
                SDK::UObject* dobj = nullptr;
                if (!TryReadFireMode(pawn, p, m, &fi, &mc, &did, &dobj)) {
                    out += "    mode " + std::to_string(m) + ": <unreadable>\n";
                    continue;
                }
                out += "    mode " + std::to_string(m)
                     + ": id=" + std::to_string(fi.modeId)
                     + " clip=" + std::to_string(fi.clipSize)
                     + " cost=" + std::to_string(fi.ammoCost)
                     + " shots=" + std::to_string(fi.shotsPerFire)
                     + " type=" + std::to_string(fi.fireType)
                     + " fireTime=" + std::to_string(fi.fireTime) + "\n";
            }
        }

        if (devicesFound == 0) {
            out += "No devices readable — are you actually spawned in with a loadout?\n";
        } else {
            out += "\nDevices: " + std::to_string(devicesFound)
                 + "   with more than one mode: " + std::to_string(multiModeDevices) + "\n";
            out += multiModeDevices > 0
                ? "Any device above with modes>1 has a switchable alternate — use the Fire Modes tab\n"
                  "to force it, then compare against the stats here to confirm what it does.\n"
                : "Nothing here has a second mode on THIS champion. Try Buck, or another champion\n"
                  "whose talent changes weapon behaviour, and re-run.\n";
        }
        SetOutput(out);
    }

    inline void DrawControls(bool inMatch) {
        ImGui::TextWrapped("Testing tab. Start with the big button below — it gathers everything "
            "in one shot. Copy the result and paste it back.");
        ImGui::Separator();

        if (!inMatch) {
            ImGui::TextDisabled("Join a match (shooting range works) first.");
        } else if (ImGui::Button("Run FULL Diagnostic Dump", ImVec2(240, 32))) {
            RunFullDiagnostic();
        }

        ImGui::Spacing();
        ImGui::Separator();
        if (ImGui::Button("RUN ENVIRONMENT CHECK", ImVec2(240, 32))) {
            RunEnvironmentCheck();
        }
        ImGui::TextWrapped("^ Click this ONCE in every mode you test (shooting range / bot match / "
            "wave defense / real match) and paste the output back. It reports who has authority "
            "(NetMode) — the single fact that decides which features can work in that mode.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(0.5f, 1.0f, 0.8f, 1.0f)), "FIRE MODE INSPECTOR — find hidden alternate modes");
        ImGui::TextWrapped("Dumps every equipped device's fire modes WITH their real stats (ammo "
            "clip, cost per shot, shots per pull, fire timing). That's how you identify what a "
            "hidden mode actually is instead of just knowing one exists. Buck's Double Barrel "
            "fingerprint is a 2-shot clip. Run this on any champion and paste the result.");
        if (inMatch && ImGui::Button("Inspect All Fire Modes", ImVec2(220, 30))) {
            RunFireModeInspector();
        }
        if (!inMatch) ImGui::TextDisabled("Join a match first.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Pickup Scan — powerup orbs (real ATgDeploy_Pickup actors)");
        ImGui::TextWrapped("Auto-refreshes every 2s. IMPORTANT: buttons can only exist for pickups "
            "that are actually spawned in the current map — the scanner finds real objects, it "
            "can't invent them. If the count below is 0, this mode has none right now.");
        // ALWAYS runs and ALWAYS shows status now (was gated behind inMatch in
        // a way that could silently show nothing with no explanation — that's
        // what "I didn't see the buttons in wave defense" was).
        RunPickupScanThrottled();
        ImGui::Text("Scanner status: %d usable pickup(s) found, last scan %llums ago.",
            g_FoundPickupCount, (unsigned long long)(GetTickCount64() - g_LastPickupScanMs));
        if (ImGui::Button("Force Rescan Now")) {
            RunPickupScan();
        }
        ImGui::SameLine();
        if (ImGui::Checkbox("Skip hidden/on-cooldown", &g_PickupSkipHidden)) {
            RunPickupScan();
        }
        ImGui::TextDisabled("Untick if wave-defense orbs are visible but not listed — bHidden may");
        ImGui::TextDisabled("be excluding usable ones.");
        ImGui::TextWrapped("Each row shows the pickup's REAL class. Try TOUCH first — it's the "
            "actual collection path and is the only one that works on TgDeploy_HHPickup (which "
            "overrides Touch but not ApplyEffect — the reason results looked random before).");
        if (g_FoundPickupCount > 0 && Globals::LocalPawn) {
            for (int i = 0; i < g_FoundPickupCount; i++) {
                ImGui::PushID(i); // several pickups can share a class name — PushID keeps buttons distinct
                ImGui::Text("[%d] %s%s", i, g_FoundPickupNames[i],
                            g_FoundPickupTouchOnly[i] ? "  (Touch only)" : "");
                ImGui::SameLine();
                if (ImGui::Button("Touch (recommended)")) {
                    g_PendingPickupTouchIndex = i;
                }
                if (!g_FoundPickupTouchOnly[i]) {
                    // ApplyEffect genuinely does not exist on OwnerOnly pickups,
                    // so offering the button there would be a guaranteed no-op.
                    ImGui::SameLine();
                    if (ImGui::Button("ApplyEffect")) {
                        g_PendingPickupApplyIndex = i;
                    }
                }
                ImGui::PopID();
            }
        } else if (g_FoundPickupCount == 0) {
            ImGui::TextDisabled("None usable right now.");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Commander Passive Scan (Octavia's real 4th slot — no CE needed)");
        ImGui::TextWrapped("Only works if you're playing Octavia and picked one of her 4 buffs "
            "pregame. Finds the real, separate device object and lets you re-trigger it directly.");
        if (inMatch && ImGui::Button("Scan For Commander Passive Device")) {
            RunCommanderPassiveScan();
        }
        if (g_CommanderPassiveDevice) {
            ImGui::SameLine();
            if (ImGui::Button("Trigger ApplyCommanderPassiveTeam")) {
                g_PendingCommanderPassiveTrigger = true; // deferred — same ProcessEvent-thread fix as the pickup buttons
            }
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Auto-Max Cards mode lead: m_nForceLoadoutCardLevels");
        ImGui::TextWrapped("Checks whether the client even has a live game-mode object to read/"
            "write at all, before attempting anything — GameInfo is often server-only in UE3.");
        if (inMatch && ImGui::Button("Check Card-Max Mode Field")) {
            RunCardMaxModeCheck();
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Outline parameter sweep — one click, tests ALL candidates on ALL enemies at once");
        ImGui::TextWrapped("Enable Highlight Enemies first (Highlights tab) so there's something "
            "to recolor. Each visible enemy gets a DIFFERENT candidate name tried on them, all "
            "turned bright magenta. Look at the screen once — whichever enemy actually changed "
            "color, tell me who (the output below lists who got which name).");
        if (inMatch && ImGui::Button("Run Outline Param Sweep", ImVec2(220, 30))) {
            RunOutlineParamSweep();
        }

        ImGui::Spacing();
        ImGui::Separator();
        if (ImGui::Button("Copy Results")) {
            ImGui::SetClipboardText(g_Output);
        }
        ImGui::InputTextMultiline("##TestOutput", g_Output, sizeof(g_Output), ImVec2(0, 260), ImGuiInputTextFlags_ReadOnly);
    }
}
