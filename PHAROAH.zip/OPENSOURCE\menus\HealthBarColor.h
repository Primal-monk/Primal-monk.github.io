#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include <Windows.h>

// ============================================================================
// HEALTH BAR RECOLOURING
//
// ORIGIN OF THIS IDEA: during the grayscale effect, everything in the 3D scene
// desaturates — including enemy outlines, which is why every attempt to recolour
// those borders failed. But the floating health bars above characters STAYED
// fully coloured (enemy red, ally blue). That observation is the whole key:
// those bars are not part of the 3D scene at all.
//
// Confirmed in the SDK: in-world health bars are UUIComponent_HealthBar_Overlay,
// which is a Scaleform/GFx UI component built from UGFxObject display objects.
// The scene post-process (SetDesaturation) only touches the rendered 3D frame;
// the Flash-based UI layer composites on top afterwards and is never affected.
//
// That also means they are recolourable through Scaleform's own API rather than
// through any material/shader work:
//     UGFxObject::SetColorMultiplier(R, G, B, A, bMaintainAdditive)
//     UGFxObject::SetColor(R, G, B, A, bMaintainMultiplier)
//
// Ally vs enemy is distinguishable without guessing — the overlay carries
// m_bFriendly and m_nTaskForce.
//
// THREADING: SetColorMultiplier is a scripted call routed through ProcessEvent,
// so it must only ever run on the ProcessEvent thread. Everything here is
// therefore deferred through pending flags, never called from the render/UI
// thread. (This is the same rule that, when broken, corrupted object state and
// produced the wrong-weapon / repeating-models bug.)
// ============================================================================

namespace HealthBarColor {

    inline bool enabled = false;
    inline bool recolorEnemies = true;
    inline bool recolorAllies = true;
    // RESTORED TO true. SetColorMultiplier is the path that DEMONSTRABLY WORKED.
    // I switched the default to the colour-transform ("solid") path to fix the
    // muddy colours, and that broke recolouring entirely — trading a working
    // feature for a cosmetic improvement. Wrong call.
    //
    // Multiplier is the default again. Solid mode stays available as an opt-in
    // toggle: it gives exact colours when it works, but it is NOT proven, so it
    // must never be what you get by default.
    inline bool useMultiplier = true;
    inline bool tintChildren = false;   // opt-in: also tint segment ticks/armour
    inline bool tintHealthText = false;

    // fwd decls — defined below, used by ApplyPass
    inline SDK::UGFxObject* TryGetContainerFwd(SDK::UUIComponent_HealthBar_Overlay* ov);
    inline void TryClearChildren(SDK::UUIComponent_HealthBar_Overlay* ov);

    inline float enemyColor[4] = { 1.00f, 0.10f, 0.10f, 1.0f }; // default red
    inline float allyColor[4]  = { 0.20f, 0.70f, 1.00f, 1.0f }; // default blue

    inline bool  g_PendingApply = false;
    inline bool  g_PendingRevert = false;

    // Hide the game's own bars so ours are the only ones on screen. See
    // TrySetOverlayAlpha for why this beats tinting.
    inline bool  g_HideGameBars      = false;
    inline bool  g_PendingHideApply  = false;
    inline int   g_HiddenCount       = 0;
    inline int   g_LastFoundOverlays = 0;
    inline int   g_LastRecolored = 0;
    inline ULONGLONG g_LastApplyMs = 0;
    inline int   reapplyIntervalMs = 1500; // bars get rebuilt/retinted by the game
                                           // 1000 meant a full GObjects walk every
                                           // second, which was measurably laggy

    // ---- isolated SEH helpers (POD only, no C++ objects) ----

    inline SDK::UObject* TryGetObjectAt(SDK::TAntiCheatArray<SDK::UObject*>& arr, size_t i) {
        __try {
            if (!arr.IsValidIndex(i)) return nullptr;
            return arr[i];
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline bool TryIsLiveOverlay(SDK::UObject* obj, SDK::UClass* cls) {
        __try {
            if (!obj || !cls || !obj->IsA(cls)) return false;
            // Skip class default objects — they're templates, not live UI.
            if (obj->Name.Index == 0) return false;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryIsDefaultObject(SDK::UObject* obj) {
        __try {
            auto& names = SDK::FName::GetGlobalNames();
            int idx = obj->Name.Index;
            if (!names.IsValidIndex((size_t)idx)) return true;
            SDK::FNameEntry* entry = names[idx];
            if (!entry) return true;
            const char* ansi = entry->GetAnsiName();
            if (!ansi) return true;
            return (_strnicmp(ansi, "Default__", 9) == 0);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return true; }
    }

    // Reads whether this overlay belongs to a teammate.
    inline bool TryIsFriendly(SDK::UUIComponent_HealthBar_Overlay* ov, bool* outFriendly) {
        __try {
            *outFriendly = ov->m_bFriendly ? true : false;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ---- SOLID (exact) recolour ----
    // WHY THE OLD VERSION LOOKED MUDDY: SetColorMultiplier MULTIPLIES the
    // existing artwork. White (1,1,1) x red = red, which is exactly the reported
    // "set it to white and it stays red". A multiplier can only ever darken or
    // tint toward a hue — it can never replace one.
    //
    // Flash's real solution is the full colour transform, which carries BOTH a
    // Multiply and an Add term:
    //     Multiply = 0        -> discard the source colour entirely
    //     Add      = target   -> and substitute ours
    // That produces a flat, exact colour no matter what the underlying art is.
    // Add is in 0-255 space, not 0-1.
    inline bool TrySolidTint(SDK::UGFxObject* o, float r, float g, float b, float a) {
        __try {
            if (!o) return false;
            SDK::FASColorTransform cx;
            cx.Multiply.R = 0.0f; cx.Multiply.G = 0.0f; cx.Multiply.B = 0.0f;
            cx.Multiply.A = a;                 // keep alpha multiplicative
            cx.Add.R = r * 255.0f;
            cx.Add.G = g * 255.0f;
            cx.Add.B = b * 255.0f;
            cx.Add.A = 0.0f;
            o->SetColorTransform(cx);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryClearTint(SDK::UGFxObject* o) {
        __try {
            if (!o) return false;
            SDK::FASColorTransform cx;
            cx.Multiply.R = 1.0f; cx.Multiply.G = 1.0f; cx.Multiply.B = 1.0f; cx.Multiply.A = 1.0f;
            cx.Add.R = 0.0f; cx.Add.G = 0.0f; cx.Add.B = 0.0f; cx.Add.A = 0.0f;
            o->SetColorTransform(cx);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Individual sub-objects that need tinting too. The container alone doesn't
    // cover everything: the segment TICKS are pooled and re-created as health
    // changes (which is why partial damage/heal segments kept their original
    // colour), and the Overlay_Player subclass owns extra pieces —
    // m_mcHealthColor plus the current/max health TEXT.
    inline int TryTintChildren(SDK::UUIComponent_HealthBar_Overlay* ov,
                               float r, float g, float b, float a, bool solid, bool includeText) {
        int n = 0;
        // health tick segments
        __try {
            int count = ov->m_mcHealthBarTicks.Num();
            for (int i = 0; i < count && i < 64; i++) {
                SDK::UGFxObject* t = ov->m_mcHealthBarTicks[i];
                if (!t) continue;
                if (solid ? TrySolidTint(t, r, g, b, a) : false) n++;
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        // armor tick segments
        __try {
            int count = ov->m_mcArmorBarTicks.Num();
            for (int i = 0; i < count && i < 64; i++) {
                SDK::UGFxObject* t = ov->m_mcArmorBarTicks[i];
                if (!t) continue;
                if (solid ? TrySolidTint(t, r, g, b, a) : false) n++;
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        // CORRECTION: m_mcHealthColor / m_mcCurrentHealthText / m_mcMaxHealthText
        // are NOT on Overlay_Player — they belong to UUIComponent_HealthBar_Player,
        // which is the HUD bar at the bottom of YOUR screen, a sibling class.
        // The in-world Overlay_Player only adds immortal brackets and Lex's
        // execute guide, so the ticks above are the right target for segments.
        __try {
            SDK::UUIComponent_HealthBar_Overlay_Player* p =
                (SDK::UUIComponent_HealthBar_Overlay_Player*)ov;
            if (p->m_mcImmortalBracketLeft && TrySolidTint(p->m_mcImmortalBracketLeft, r, g, b, a)) n++;
            if (p->m_mcImmortalBracketRight && TrySolidTint(p->m_mcImmortalBracketRight, r, g, b, a)) n++;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        // Armor bar frame lives on the base class and is easy to miss.
        __try {
            if (ov->m_mcArmorBarFrame && TrySolidTint(ov->m_mcArmorBarFrame, r, g, b, a)) n++;
            if (ov->m_mcArmorBarContainer && TrySolidTint(ov->m_mcArmorBarContainer, r, g, b, a)) n++;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        return n;
    }

    // ========================================================================
    // HIDING the game's bar, rather than tinting it
    // ========================================================================
    // Colours "mix" because SetColorMultiplier multiplies - it can only darken
    // toward your colour, never replace the game's red. The position probe was
    // meant to let us draw our own bar exactly on top instead, and it came back
    // with x=0 y=0 for every single bar: the containers do not expose a stage
    // position, so an exact overlay is not reachable that way.
    //
    // What the probe DID show is that DisplayInfo reads back cleanly
    // (alpha=100, vis=1). If it reads, it writes. So the answer is not to draw
    // over the game's bar - it is to make the game's bar go away and draw ours
    // in its place, which is what Highlights already does from world positions.
    //
    // Nothing mixes if there is nothing underneath.
    inline bool TrySetOverlayAlpha(SDK::UUIComponent_HealthBar_Overlay* ov, float alpha) {
        __try {
            SDK::UGFxObject* container = ov->m_mcHealthBarContainer;
            if (!container) return false;
            SDK::FASDisplayInfo d = container->GetDisplayInfo();
            d.Alpha = alpha;
            d.hasAlpha = 1;
            // Alpha 0 alone can still leave the clip drawing on some builds, so
            // drive Visible from it as well.
            d.Visible = (alpha > 0.5f) ? 1 : 0;
            container->SetDisplayInfo(d, true);   // bResetCache: force the movie to re-read it
            ov->m_bColorDirty = 1;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryTintOverlay(SDK::UUIComponent_HealthBar_Overlay* ov,
                               float r, float g, float b, float a, bool multiplier) {
        __try {
            SDK::UGFxObject* container = ov->m_mcHealthBarContainer;
            if (!container) return false;
            if (multiplier) container->SetColorMultiplier(r, g, b, a, false);
            else            TrySolidTint(container, r, g, b, a);
            // Mark the component's colour as dirty so the game doesn't assume
            // its cached tint is still valid and skip its own refresh logic.
            ov->m_bColorDirty = 1;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Copies an object's CLASS name. Used for name-based matching, because
    // FindClass() cannot be trusted here — the exact same style of lookup
    // (FindObject for PostRender) silently returned nothing for months and
    // broke every deferred action in the tool. Matching on the resolved name
    // is what fixed that, so the same approach is used here.
    inline void TryCopyClassName(SDK::UObject* obj, char* buf, size_t bufSize) {
        buf[0] = 0;
        __try {
            if (!obj || !obj->Class) return;
            auto& names = SDK::FName::GetGlobalNames();
            int idx = obj->Class->Name.Index;
            if (idx == 0 || !names.IsValidIndex((size_t)idx)) return;
            SDK::FNameEntry* entry = names[idx];
            if (!entry) return;
            const char* ansi = entry->GetAnsiName();
            if (ansi) strncpy_s(buf, bufSize, ansi, _TRUNCATE);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { buf[0] = 0; }
    }

    inline SDK::UGFxObject* TryGetContainerFwd(SDK::UUIComponent_HealthBar_Overlay* ov) {
        __try { return ov ? ov->m_mcHealthBarContainer : nullptr; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline void TryClearChildren(SDK::UUIComponent_HealthBar_Overlay* ov) {
        __try {
            int count = ov->m_mcHealthBarTicks.Num();
            for (int i = 0; i < count && i < 64; i++) TryClearTint(ov->m_mcHealthBarTicks[i]);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        __try {
            int count = ov->m_mcArmorBarTicks.Num();
            for (int i = 0; i < count && i < 64; i++) TryClearTint(ov->m_mcArmorBarTicks[i]);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        __try {
            SDK::UUIComponent_HealthBar_Overlay_Player* p =
                (SDK::UUIComponent_HealthBar_Overlay_Player*)ov;
            TryClearTint(p->m_mcImmortalBracketLeft);
            TryClearTint(p->m_mcImmortalBracketRight);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
        __try {
            TryClearTint(ov->m_mcArmorBarFrame);
            TryClearTint(ov->m_mcArmorBarContainer);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
    }

    // Diagnostics so a zero result is explainable rather than mysterious.
    inline int  g_ClassResolved = 0;      // did StaticClass() return anything
    inline int  g_TotalObjectsSeen = 0;
    inline int  g_NameMatchedAny = 0;     // any class name containing "HealthBar"
    inline char g_FirstMatchName[64] = {};

    // Isolated because BOTH of these can fault, and they were sitting
    // unprotected at the top of ApplyPass. A fault there didn't just break
    // recolouring — ApplyPass is called from ProcessPendingSafeResets BEFORE
    // ResolveBonesOnSafeThread, so it took the skeleton down with it. That is
    // why healthbars and bones both read 0 at the same time.
    inline SDK::UClass* TryResolveOverlayClass() {
        __try { return SDK::UUIComponent_HealthBar_Overlay::StaticClass(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline size_t TryGetObjectCount() {
        __try { return SDK::UObject::GetGlobalObjects().Num(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    inline int g_ApplyPassRuns = 0; // proves whether this function executes at all

    // ---- main pass. ProcessEvent thread ONLY. ----
    // Walks the live overlays and sets their container alpha. Same object walk
    // as ApplyPass - name match first, IsA as a bonus - because that is the walk
    // that proved reliable when FindClass silently returned nothing.
    inline int HidePass(bool hide) {
        SDK::UClass* cls = TryResolveOverlayClass();
        size_t count = TryGetObjectCount();
        if (count == 0) return 0;

        auto& objects = SDK::UObject::GetGlobalObjects();
        int done = 0;

        for (size_t i = 0; i < count; i++) {
            SDK::UObject* obj = TryGetObjectAt(objects, i);
            if (!obj) continue;

            char clsName[64];
            TryCopyClassName(obj, clsName, sizeof(clsName));
            bool nameHit  = (clsName[0] && strstr(clsName, "HealthBar") != nullptr);
            bool isOverlay = nameHit && (strstr(clsName, "Overlay") != nullptr);
            if (!isOverlay && !(cls && TryIsLiveOverlay(obj, cls))) continue;
            if (TryIsDefaultObject(obj)) continue;

            SDK::UUIComponent_HealthBar_Overlay* ov =
                (SDK::UUIComponent_HealthBar_Overlay*)obj;
            if (TrySetOverlayAlpha(ov, hide ? 0.0f : 100.0f)) done++;
        }
        return done;
    }

    inline void ApplyPass(bool revertToDefault) {
        g_ApplyPassRuns++;

        // StaticClass() is only a bonus path now — name matching is the primary
        // one, so a null here must NOT abort the pass.
        SDK::UClass* cls = TryResolveOverlayClass();
        g_ClassResolved = cls ? 1 : 0;

        size_t count = TryGetObjectCount();
        g_TotalObjectsSeen = (int)count;
        if (count == 0) return;

        auto& objects = SDK::UObject::GetGlobalObjects();
        int found = 0, done = 0, nameMatched = 0;
        g_FirstMatchName[0] = 0;

        for (size_t i = 0; i < count; i++) {
            SDK::UObject* obj = TryGetObjectAt(objects, i);
            if (!obj) continue;

            // Primary: class name match (survives a failed FindClass).
            char clsName[64];
            TryCopyClassName(obj, clsName, sizeof(clsName));
            bool nameHit = (clsName[0] && strstr(clsName, "HealthBar") != nullptr);
            if (nameHit) {
                nameMatched++;
                if (!g_FirstMatchName[0]) strncpy_s(g_FirstMatchName, sizeof(g_FirstMatchName), clsName, _TRUNCATE);
            }
            // Accept either the IsA test (when the class resolved) or a name hit
            // on the Overlay variants specifically — the in-world floating bars.
            bool isOverlay = nameHit && (strstr(clsName, "Overlay") != nullptr);
            if (!isOverlay && !(cls && TryIsLiveOverlay(obj, cls))) continue;
            if (TryIsDefaultObject(obj)) continue;
            found++;

            SDK::UUIComponent_HealthBar_Overlay* ov = (SDK::UUIComponent_HealthBar_Overlay*)obj;
            bool friendly = false;
            if (!TryIsFriendly(ov, &friendly)) continue;

            // A REVERT IGNORES THESE FILTERS.
            //
            // "Reset to default" used to skip anything the recolour filters
            // excluded, so if "Recolour enemies" was off, enemy bars kept the
            // tint they had been given earlier and could never be cleared -
            // which is exactly why restore appeared to work on allies only.
            // A reset must reach every bar, whatever the filters say.
            if (!revertToDefault) {
                if (friendly && !recolorAllies)  continue;
                if (!friendly && !recolorEnemies) continue;
            }

            if (revertToDefault) {
                // Full reset: identity transform on the container and children,
                // handing the bars back to the game untouched.
                SDK::UGFxObject* cont = TryGetContainerFwd(ov);
                if (cont) TryClearTint(cont);
                TryClearChildren(ov);
                done++;
            } else {
                const float* c = friendly ? allyColor : enemyColor;
                if (TryTintOverlay(ov, c[0], c[1], c[2], c[3], useMultiplier)) done++;
                // Also hit the segment ticks / bar element / text, which the
                // container tint does not reach — that's why partial damage and
                // heal segments kept their original colour.
                if (!useMultiplier && tintChildren) {
                    TryTintChildren(ov, c[0], c[1], c[2], c[3], true, tintHealthText);
                }
            }
        }
        g_LastFoundOverlays = found;
        g_LastRecolored = done;
        g_NameMatchedAny = nameMatched;
    }

    // ========================================================================
    // POSITION PROBE — for drawing our own bars EXACTLY over the game's.
    //
    // UGFxObject exposes GetPosition(&X,&Y) and GetDisplayInfo() (X, Y, XScale,
    // YScale, Alpha, Visible). So the real bar's position and size ARE readable.
    //
    // What is NOT known without data: those are Scaleform STAGE coordinates, not
    // screen pixels, and it's unclear whether they're local-to-parent or global.
    // Converting requires knowing the stage size and the parent chain. Rather
    // than guess and then nudge offsets forever, this dumps the raw numbers
    // alongside the screen resolution so the mapping can be derived exactly.
    // ========================================================================
    inline bool  g_PendingProbe = false;
    inline char  g_ProbeOut[4096] = "Press \"Probe Bar Positions\" while enemies/allies are visible.";

    inline bool TryGetGfxPos(SDK::UGFxObject* o, float* x, float* y) {
        __try {
            if (!o) return false;
            return o->GetPosition(x, y);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryGetGfxInfo(SDK::UGFxObject* o, float* x, float* y,
                              float* sx, float* sy, float* alpha, int* visible) {
        __try {
            if (!o) return false;
            SDK::FASDisplayInfo d = o->GetDisplayInfo();
            *x = d.X; *y = d.Y; *sx = d.XScale; *sy = d.YScale;
            *alpha = d.Alpha; *visible = d.Visible ? 1 : 0;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline SDK::UGFxObject* TryGetContainer(SDK::UUIComponent_HealthBar_Overlay* ov) {
        __try { return ov ? ov->m_mcHealthBarContainer : nullptr; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // Runs on the ProcessEvent thread (GetPosition/GetDisplayInfo are scripted).
    inline void RunPositionProbe() {
        char line[256];
        strncpy_s(g_ProbeOut, sizeof(g_ProbeOut), "=== HEALTH BAR POSITION PROBE ===\n", _TRUNCATE);

        ImVec2 ss = ImGui::GetIO().DisplaySize;
        snprintf(line, sizeof(line), "screen: %.0f x %.0f\n\n", ss.x, ss.y);
        strncat_s(g_ProbeOut, sizeof(g_ProbeOut), line, _TRUNCATE);

        SDK::UClass* cls = SDK::UUIComponent_HealthBar_Overlay::StaticClass();
        auto& objects = SDK::UObject::GetGlobalObjects();
        size_t count = objects.Num();
        int shown = 0;

        for (size_t i = 0; i < count && shown < 12; i++) {
            SDK::UObject* obj = TryGetObjectAt(objects, i);
            if (!obj) continue;
            char clsName[64];
            TryCopyClassName(obj, clsName, sizeof(clsName));
            bool nameHit = (clsName[0] && strstr(clsName, "HealthBar") && strstr(clsName, "Overlay"));
            if (!nameHit && !(cls && TryIsLiveOverlay(obj, cls))) continue;
            if (TryIsDefaultObject(obj)) continue;

            SDK::UUIComponent_HealthBar_Overlay* ov = (SDK::UUIComponent_HealthBar_Overlay*)obj;
            bool friendly = false;
            TryIsFriendly(ov, &friendly);

            SDK::UGFxObject* cont = TryGetContainer(ov);
            float px = 0, py = 0;
            bool gotPos = TryGetGfxPos(cont, &px, &py);
            float dx = 0, dy = 0, sx = 0, sy = 0, al = 0; int vis = 0;
            bool gotInfo = TryGetGfxInfo(cont, &dx, &dy, &sx, &sy, &al, &vis);

            snprintf(line, sizeof(line),
                "[%d] %s %s\n"
                "    container: %s\n"
                "    GetPosition : %s x=%.2f y=%.2f\n"
                "    DisplayInfo : %s x=%.2f y=%.2f xs=%.2f ys=%.2f alpha=%.2f vis=%d\n",
                shown, clsName, friendly ? "(ALLY)" : "(ENEMY)",
                cont ? "present" : "NULL",
                gotPos ? "ok" : "fail", px, py,
                gotInfo ? "ok" : "fail", dx, dy, sx, sy, al, vis);
            strncat_s(g_ProbeOut, sizeof(g_ProbeOut), line, _TRUNCATE);
            shown++;
        }

        if (shown == 0) {
            strncat_s(g_ProbeOut, sizeof(g_ProbeOut),
                "No live overlays found. Get players visible on screen and retry.\n", _TRUNCATE);
        } else {
            strncat_s(g_ProbeOut, sizeof(g_ProbeOut),
                "\nPaste this back. With the screen size plus these X/Y/scale values I can\n"
                "work out the stage->screen mapping and draw bars in the exact position,\n"
                "instead of eyeballing offsets.\n", _TRUNCATE);
        }
    }

    // Called from HookedProcessEvent (safe thread). Handles one-shot requests
    // plus a throttled reapply, because the game rebuilds and re-tints these
    // bars constantly (on damage, healing, range changes, respawns).
    inline void ProcessPending() {
        if (g_PendingProbe) {
            g_PendingProbe = false;
            RunPositionProbe();
            return;
        }
        if (g_PendingRevert) {
            g_PendingRevert = false;
            ApplyPass(true);
            return;
        }
        // THE RECOLOURS TAB LAG.
        //
        // Both ApplyPass and HidePass walk the ENTIRE GObjects array - a couple
        // of hundred thousand entries - doing a class-name string compare on
        // every one. Running both on their own one-second timers meant TWO full
        // walks per second, and that is what the stutter was. Same shape as the
        // material-scan stutter from before.
        //
        // Now there is ONE schedule. A single tick does whatever is switched on,
        // and if nothing is switched on it does not walk at all.
        ULONGLONG now = GetTickCount64();

        bool wantHide = g_HideGameBars;
        bool wantTint = enabled;
        bool forced   = g_PendingApply || g_PendingHideApply;

        if (!forced && !wantHide && !wantTint) return;
        if (!forced && (now - g_LastApplyMs) < (ULONGLONG)reapplyIntervalMs) return;

        g_PendingApply = false;
        g_PendingHideApply = false;
        g_LastApplyMs = now;

        // Hide first, so a bar that is being hidden is not also tinted.
        if (wantHide) {
            g_HiddenCount = HidePass(true);
        } else if (forced) {
            // Just switched off - put the alpha back once, then stop walking.
            g_HiddenCount = HidePass(false);
        }
        if (!wantTint) return;
        ApplyPass(false);
    }
    inline void DrawControls() {
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.8f, 1.0f)), "HEALTH BAR RECOLOUR");
        ImGui::TextWrapped("The floating health bars above players are Scaleform UI objects, NOT "
            "part of the 3D scene — which is why they keep their colour during grayscale while "
            "outlines lose theirs. That also means they can be recoloured directly, through the "
            "UI layer, instead of fighting materials.");
        ImGui::Separator();

        if (ImGui::Checkbox("Enable recolouring", &enabled)) {
            if (enabled) g_PendingApply = true;
            else         g_PendingRevert = true;
        }

        ImGui::Checkbox("Recolour enemies", &recolorEnemies);
        ImGui::SameLine();
        ImGui::Checkbox("Recolour allies", &recolorAllies);

        if (ImGui::ColorEdit4("Enemy bar", enemyColor, ImGuiColorEditFlags_NoInputs)) g_PendingApply = true;
        if (ImGui::ColorEdit4("Ally bar",  allyColor,  ImGuiColorEditFlags_NoInputs)) g_PendingApply = true;

        if (ImGui::Button("Apply Now", ImVec2(120, 26))) g_PendingApply = true;
        ImGui::SameLine();
        if (ImGui::Button("Reset to default", ImVec2(140, 26))) g_PendingRevert = true;

        ImGui::Spacing();
        if (ImGui::Checkbox("Use colour multiplier (PROVEN - keep this on)", &useMultiplier)) g_PendingApply = true;
        ImGui::TextWrapped("Multiplier is the path known to work. It MULTIPLIES the existing art, "
            "so it can only darken or tint — white x red = red. That's the muddiness, and it's a "
            "maths limit, not a bug.");
        if (!useMultiplier) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.6f, 0.4f, 1.0f)),
                "SOLID MODE (experimental) - gives exact colours but is UNPROVEN.");
            ImGui::TextWrapped("Uses SetColorTransform with Multiply=0, Add=your colour. If bars "
                "stop recolouring entirely, turn this back off — that's the known-good path.");
            if (ImGui::Checkbox("Also tint segment ticks + armour", &tintChildren)) g_PendingApply = true;
            ImGui::TextDisabled("Targets the pooled tick objects, which is what partial damage/heal");
            ImGui::TextDisabled("segments are made of. Solid mode only.");
        }

        ImGui::SliderInt("Reapply interval (ms)", &reapplyIntervalMs, 250, 3000);
        ImGui::TextDisabled("The game re-tints these bars on damage/heal/range changes, so the");
        ImGui::TextDisabled("colour has to be reasserted periodically or it reverts.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("ApplyPass runs           : %d", g_ApplyPassRuns);
        ImGui::Text("Objects scanned          : %d", g_TotalObjectsSeen);
        ImGui::Text("Class resolved           : %s", g_ClassResolved ? "YES" : "NO");
        ImGui::Text("Any *HealthBar* class    : %d", g_NameMatchedAny);
        if (g_FirstMatchName[0]) ImGui::Text("  first match: %s", g_FirstMatchName);
        ImGui::Text("Overlays targeted        : %d", g_LastFoundOverlays);
        ImGui::Text("Successfully recoloured  : %d", g_LastRecolored);

        // Each zero means something different — spell it out rather than leaving
        // a bare "0" that could be any of four unrelated problems.
        if (g_TotalObjectsSeen == 0) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.3f, 0.3f, 1.0f)),
                "Scanned 0 objects -> this pass never ran at all.");
            ImGui::TextWrapped("That means the ProcessEvent thread isn't executing. Check the "
                "Respawn tab: if 'Safe-thread heartbeat' is 0, that's the real bug and nothing "
                "deferred can work until it's fixed.");
        } else if (g_NameMatchedAny == 0) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)),
                "Scanned fine, but no HealthBar classes exist right now.");
            ImGui::TextWrapped("The bars may only be instantiated while players are actually "
                "visible on screen. Get an enemy or teammate in view and hit Apply Now.");
        } else if (g_LastFoundOverlays == 0) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)),
                "HealthBar classes exist, but none matched 'Overlay'.");
            ImGui::TextWrapped("Tell me the 'first match' name above — the in-world bar is "
                "evidently a different class than assumed, and that name identifies it.");
        } else if (g_LastRecolored == 0) {
            ImGui::TextColored(Ink(ImVec4(1.0f, 0.8f, 0.4f, 1.0f)),
                "Found overlays but tinting failed - m_mcHealthBarContainer was null.");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.9f, 0.5f, 1.0f)), "EXACT POSITION PROBE");
        ImGui::TextWrapped("For drawing our own bars precisely over the real ones. The game's bar "
            "position and scale ARE readable (GetPosition / GetDisplayInfo), but they come back in "
            "Scaleform stage coordinates. This dumps the raw values plus your screen size so the "
            "stage-to-screen mapping can be derived exactly rather than eyeballed.");
        if (ImGui::Button("Probe Bar Positions", ImVec2(200, 28))) g_PendingProbe = true;
        ImGui::SameLine();
        if (ImGui::Button("Copy Probe")) ImGui::SetClipboardText(g_ProbeOut);
        ImGui::InputTextMultiline("##ProbeOut", g_ProbeOut, sizeof(g_ProbeOut),
            ImVec2(0, 180), ImGuiInputTextFlags_ReadOnly);
    }
}
