#pragma once

// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
inline DWORD loopCount = NULL;

inline uintptr_t imageBase()
{
    return *(uintptr_t*)(__readgsqword(0x60) + 0x10);
}

inline int custom_strlen(const char* string)
{
    int cnt = 0;
    if (string)
    {
        for (; *string != 0; ++string) ++cnt;
    }
    return cnt;
}

inline void custom_MemCpy(void* dest, void* src, size_t n)
{
    char* csrc = (char*)src;
    char* cdest = (char*)dest;

    for (int i = 0; i < n; i++)
        cdest[i] = csrc[i];
}

inline int custom_wcslen2(const wchar_t* string)
{
    int cnt = 0;
    if (string)
    {
        for (; *string != 0; ++string) ++cnt;
    }
    return cnt;
}

inline PIMAGE_NT_HEADERS Sponge(HMODULE mxdule) {
    return (PIMAGE_NT_HEADERS)((PBYTE)mxdule + PIMAGE_DOS_HEADER(mxdule)->e_lfanew);
}