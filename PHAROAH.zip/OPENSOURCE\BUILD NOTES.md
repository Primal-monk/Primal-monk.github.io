# PHAROAH — build notes

Short version of things that will bite whoever builds this next, me included.

---

## The Release build is deliberately UNOPTIMISED

`CMakeLists.txt` forces:

```
CMAKE_CXX_FLAGS_RELEASE = /Od /Ob0 /Oy- /Zi
```

That is **no optimisation, no inlining, keep frame pointers** — the same code
generation as the Debug build.

### Why a Release config exists at all

Only one reason: **the C runtime.**

A Debug build links `MSVCP140D.dll`, `ucrtbased.dll`, `VCRUNTIME140D.dll`. Those
are the *debug* CRT. Microsoft does not permit redistributing them and they only
exist on machines with Visual Studio installed. A Debug DLL loads perfectly on a
dev box and fails silently on every user's PC.

Release links `MSVCP140.dll` / `VCRUNTIME140.dll` — the redistributable set,
which Paladins itself requires, so anyone who can run the game already has them.

### Why it is not optimised

The first optimised Release build **crashed Paladins the moment it injected**,
with no crash message. Two reasons found:

1. **`/Zc:threadSafeInit-`** was on in Release and off in Debug. Not by choice —
   in Debug it had been written into `target_compile_definitions` instead of
   `target_compile_options`, which turned it into the meaningless define
   `-D/Zc:threadSafeInit-` and did nothing. So Debug ran with thread-safe static
   init ON (the MSVC default) and Release ran with it OFF.

   This DLL has hundreds of `inline` globals in headers and touches them from
   **two threads** — the render thread in `hkPresent`, and the game's script
   thread in `RunSafeThreadSubsystems`. With thread-safe init disabled, one
   thread can read a static while another is still constructing it. That is a
   crash at injection with no message.

   **Both configs now use the default. Do not re-add that flag.**

2. **`/O2 /Ob2`** came from CMake's built-in Release flags. Adding `/Od` through
   `target_compile_options` does not remove them — CMake puts its own flags first
   and appends yours, so the real command line was `/O2 /Ob2 /Od /Oy-`. Hence the
   explicit `set(CMAKE_CXX_FLAGS_RELEASE ...)` override.

   Inlining and omitted frame pointers matter here because the DLL hooks D3D11
   Present, walks live engine objects, and leans on `__try`/`__except` to survive
   bad pointers. SEH unwinding wants real stack frames.

Also disabled: **`/OPT:ICF`**, which folds identical functions onto a single
address. A DLL that hooks by address and compares function pointers does not
want that, and it saved a few KB.

### Does unoptimised matter in practice?

**No, and here is why.** This is a UI overlay and a set of field reads, not a
renderer or a physics engine. The per-frame work is drawing some ImGui widgets
and reading a few floats off game objects — microseconds either way. The game
itself is doing all the real work, and it is compiled by Hi-Rez with their own
flags, untouched by this.

The visible costs are a larger DLL (~14 MB vs ~1.8 MB optimised) and a marginally
slower load. Neither is worth a crash on inject.

If you want to try an optimised build later: change those flags, then **test an
actual injection**. It builds and links fine either way. It just does not run.

### The proper long-term fix

Static-link the CRT (`/MT`) and the runtime question disappears entirely — no
redist dependency at all. Blocked on `ext/Detours/detours.lib`, which is prebuilt
against `/MD`; mixing gives:

```
LNK2038: mismatch detected for 'RuntimeLibrary'
```

To do it, rebuild Detours (and MinHook if it is prebuilt) with `/MT`, then set
`-DPHAROAH_STATIC_RUNTIME=ON`. The option is already wired up in CMakeLists.

The injector is already `/MT` and has **zero** runtime dependencies.

---

## Diagnosing an injection crash

`InitThread` writes **`PHAROAH_init.log`** next to the game exe, flushed after
every line, so it survives a crash. The last line tells you which stage died:

```
stage 1/3: Main()        SDK init + the ProcessEvent detour
stage 2/3: Main() OK
stage 3/3: InitKiero()   the D3D11 Present hook
setup complete
```

If the log stops after stage 1, it is the SDK or the Detours attach. After stage
3, it is the D3D11 hook. If the file is empty or missing, the DLL died before
`InitThread` ran — which points at static initialisation, i.e. the
`threadSafeInit` class of problem above.

---

## Building

```
# Release - this is what ships
cmake -S . -B out/build/x64-Release -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build out/build/x64-Release

# Debug - for development
cmake -S . -B out/build/x64-Debug -G Ninja -DCMAKE_BUILD_TYPE=Debug
cmake --build out/build/x64-Debug
```

Neither will link while Paladins is running (`LNK1168`). Close the game first.
Same for the injector and `PharoahInjector.exe`.

Then `MAKE_RELEASE.bat` to package, and `VERIFY_RELEASE.bat` to check the ZIP
before publishing — it catches the debug-CRT mistake automatically.

— PRIMAL_MONKE
