#pragma once

// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include <string>
#include <unordered_map>
#include <vector>
#include <windows.h>

struct Settings {
    int selectedTalentIndex;
    int selectedTalent;

    std::string selectedChampionName;
    std::string selectedEmoteName;

    int selectedIndexChampionName;
    int selectedIndexEmoteName;
    int selectedEmoteId;

    bool customEmote;
    int selectedEmoteID;
};

inline Settings exploits;