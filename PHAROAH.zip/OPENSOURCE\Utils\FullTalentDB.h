#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include <string>
#include <vector>
#include <unordered_map>
#include <fstream>
#include <sstream>

// Loads the full talent reference (message(1).txt) at startup so the Talents
// tab can offer EVERY known talent per champion, not just a hardcoded few.
//
// NOTE: hardcoded absolute path — this only works on the machine it was built
// on. If this ever needs to run elsewhere, copy message(1).txt next to
// Talents.dll and switch this to a path relative to the DLL's own location.
namespace FullTalentDB {

    struct Entry { int id; std::string name; std::string desc; };
    inline std::unordered_map<std::string, std::vector<Entry>> g_ByChampion;
    inline bool g_Loaded = false;

    inline void Load() {
        g_Loaded = true; // only try once, even if it fails
        // Was an absolute path on the build machine. Now relative, so it
        // resolves next to the game exe (the working directory when injected) -
        // and simply does not load if the file is absent, which is the normal
        // case for a release build and is handled below.
        const char* path = "message(1).txt";
        std::ifstream file(path);
        if (!file.is_open()) return;

        std::string line;
        std::string currentChampion;
        while (std::getline(file, line)) {
            // Champion header: "## Name"
            if (line.rfind("## ", 0) == 0) {
                currentChampion = line.substr(3);
                // trim trailing whitespace/CR
                while (!currentChampion.empty() && (currentChampion.back() == '\r' || currentChampion.back() == ' '))
                    currentChampion.pop_back();
                continue;
            }
            // Talent line: "- 12345: Name" or "- 12345: Name — description"
            if (line.rfind("- ", 0) == 0 && currentChampion != "") {
                std::string rest = line.substr(2);
                size_t colon = rest.find(':');
                if (colon == std::string::npos) continue;

                std::string idStr = rest.substr(0, colon);
                // skip censored/unknown entries like "XXXXX"
                bool allDigits = !idStr.empty();
                for (char c : idStr) if (!isdigit((unsigned char)c)) { allDigits = false; break; }
                if (!allDigits) continue;

                int id = std::stoi(idStr);
                std::string nameAndDesc = rest.substr(colon + 1);
                while (!nameAndDesc.empty() && nameAndDesc.front() == ' ') nameAndDesc.erase(nameAndDesc.begin());

                std::string name = nameAndDesc;
                std::string desc;
                size_t dash = nameAndDesc.find(" — ");
                if (dash == std::string::npos) dash = nameAndDesc.find(" - ");
                if (dash != std::string::npos) {
                    name = nameAndDesc.substr(0, dash);
                    desc = nameAndDesc.substr(dash + 3);
                }

                g_ByChampion[currentChampion].push_back({ id, name, desc });
            }
        }
    }

    inline const std::vector<Entry>* GetForChampion(const std::string& champion) {
        if (!g_Loaded) Load();
        auto it = g_ByChampion.find(champion);
        if (it == g_ByChampion.end()) return nullptr;
        return &it->second;
    }
}
