#pragma once

#define vpnter(ptr) (((unsigned long long)ptr < 0x7FFFFFFEFFFF && (unsigned long long)ptr > 0x00010000))
#define rva(addr, size) (reinterpret_cast<unsigned char*>(addr + *reinterpret_cast<int*>(addr + (size - 4)) + size))

#define Const_URotation180        32768

#include <filesystem>
#include <fstream>
#include <intrin.h>
#include <iostream>
#include <cstdio>
#include <vector>
#include <windows.h>

#include "utils/scanner.h"

#include "SDK.hpp"
using namespace SDK;

#include "render/render.h"