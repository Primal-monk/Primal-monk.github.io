#pragma once
#include "types.h"
#include "globals.h"

// Dummies
namespace SDK {
	class UObject;
	class UFunction;
}

void ProcessEventHook(SDK::UObject* pObject, SDK::UFunction* pFunction, void* pParms);
