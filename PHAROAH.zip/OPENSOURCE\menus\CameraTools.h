#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include <Windows.h>

// ============================================================================
// CAMERA TOOLS — FOV changer (parity with Anubis's "FOV Changer - up to 150")
//
// WHY THIS ONE SHOULD ACTUALLY WORK, unlike speed:
// Run it through the model — "is this me telling the server about myself, or
// telling it how the match works?" FOV is neither. It is how wide MY camera
// renders. The server has no opinion about it and nothing about it is validated,
// because nothing about it affects the simulation.
//
// The fields confirm it. On APlayerController:
//   FOVAngle    0x04C0   <- current
//   DesiredFOV  0x04C4   <- what the game lerps toward
//   DefaultFOV  0x04C8   <- the resting value
// NONE of the three carry (Net). Compare GroundSpeed, which is (Net) and is
// exactly why the speedhack kept failing outside the shooting range.
//
// WHY ALL THREE GET WRITTEN:
// Writing FOVAngle alone does nothing lasting — the camera update lerps it back
// toward DesiredFOV every frame, which is itself reset from DefaultFOV. So the
// value has to be asserted at all three levels, and re-asserted continuously,
// or it visibly springs back. Same shape of problem as the replicated fields,
// but for a local reason.
//
// Zoom/ADS is deliberately left alone: SetFOVZoomed is a separate path, and
// fighting it would break scoping on Kinessa, Strix, Vivian and friends.
//
// THREADING: all three are plain field writes, so this is safe from the render
// thread and does not need the ProcessEvent deferral.
// ============================================================================

namespace CameraTools {

    inline bool  fovEnabled = false;
    inline float fovValue = 110.0f;
    inline bool  alsoWriteDefault = true;

    inline float g_CapturedDefaultFOV = -1.0f;
    inline float g_LiveFOV = -1.0f;
    inline int   g_FovWrites = 0;
    inline SDK::APlayerController* g_BaseController = nullptr;

    // Forward declaration: Update() below calls this, but it's defined further
    // down next to the rest of the third-person code so the two halves of that
    // feature stay together. Declaration-order slips like this have cost real
    // build cycles in this project, hence being explicit about it.
    inline void UpdateThirdPerson();

    inline bool TryReadFOV(SDK::APlayerController* pc, float* cur, float* def) {
        __try {
            *cur = pc->FOVAngle;
            *def = pc->DefaultFOV;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryWriteFOV(SDK::APlayerController* pc, float v, bool writeDefault) {
        __try {
            pc->FOVAngle = v;
            pc->DesiredFOV = v;
            if (writeDefault) pc->DefaultFOV = v;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline void Update() {
        SDK::APlayerController* pc = (SDK::APlayerController*)Globals::LocalController;
        if (!pc) { g_BaseController = nullptr; return; }

        // Re-capture on controller change. A stale controller is exactly what made
        // respawn fire into nothing, so the same guard applies here.
        if (pc != g_BaseController) {
            g_BaseController = pc;
            g_CapturedDefaultFOV = -1.0f;
        }

        float cur = -1.0f, def = -1.0f;
        if (!TryReadFOV(pc, &cur, &def)) return;
        g_LiveFOV = cur;

        // Only latch a plausible original, so the baseline can't ratchet up to
        // whatever we last wrote.
        if (g_CapturedDefaultFOV <= 0.0f && def > 20.0f && def < 130.0f) {
            g_CapturedDefaultFOV = def;
        }

        if (fovEnabled) {
            if (TryWriteFOV(pc, fovValue, alsoWriteDefault)) g_FovWrites++;
        }

        // Runs regardless of the FOV toggle — they're independent features, and the
        // module-name readout is useful diagnostically even with both switched off.
        UpdateThirdPerson();
    }

    inline void Restore() {
        SDK::APlayerController* pc = (SDK::APlayerController*)Globals::LocalController;
        if (pc && g_CapturedDefaultFOV > 0.0f) TryWriteFOV(pc, g_CapturedDefaultFOV, true);
    }

    // ========================================================================
    // THIRD PERSON — a second, independent route (the existing one is broken)
    //
    // WHY THE EXISTING ONE DOESN'T WORK:
    // The current "Third person camera" checkbox calls
    // UTgBattleCheatManager::Set3p. CheatManager functions are admin/standalone
    // gated — the same wall that makes SetMountSkin useless in a real match. It
    // silently does nothing rather than erroring, which is why it looked broken
    // with no clue as to why.
    //
    // THE ROUTE THIS USES INSTEAD — all client-side, no CheatManager:
    //   APlayerController::PlayerCamera        0x0478  -> cast to ATgPlayerCamera
    //   ATgPlayerCamera::CameraModuleList      0x061C  TArray<UTgCameraModule*>
    //   ATgPlayerCamera::CurrentCameraMod      0x060C  <- the active module
    //   UTgCameraModule_ThirdPerson::vForcedCameraOffset  0x0074
    //
    // The camera calls UpdateCamera on whatever CurrentCameraMod points at, every
    // frame, on the client. So pointing it at the third-person module that already
    // exists in the list should switch the view without asking the server for
    // anything. The offset field then gives the adjustable height Anubis has.
    //
    // MARKED UNPROVEN ON PURPOSE. Per the standing rule, this is added ALONGSIDE
    // the old Set3p checkbox rather than replacing it — if this turns out to be
    // the one that works, the old one can go, but not before.
    // ========================================================================

    inline bool  tpModuleSwapEnabled = false;
    inline float tpHeight = 60.0f;
    inline float tpBack = 180.0f;
    inline float tpRight = 40.0f;

    inline int   g_ModulesFound = 0;
    inline bool  g_ThirdPersonModuleFound = false;
    inline bool  g_SwapApplied = false;
    inline char  g_CurrentModuleName[96] = "(unknown)";

    inline bool CopyObjName(SDK::UObject* o, char* buf, int cap) {
        __try {
            buf[0] = '\0';
            if (!o) return false;
            SDK::UClass* cls = o->Class;
            if (!cls || cls->Name.Index == 0) return false;
            auto& names = SDK::FName::GetGlobalNames();
            if (!names.IsValidIndex((size_t)cls->Name.Index)) return false;
            SDK::FNameEntry* e = names[cls->Name.Index];
            if (!e) return false;
            const char* n = e->GetAnsiName();
            if (!n) return false;
            int i = 0;
            for (; i < cap - 1 && n[i]; ++i) buf[i] = n[i];
            buf[i] = '\0';
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool NameHas(const char* hay, const char* needle) {
        if (!hay || !needle) return false;
        for (int i = 0; hay[i]; ++i) {
            int j = 0;
            while (needle[j]) {
                char a = hay[i + j], b = needle[j];
                if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
                if (b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
                if (a != b) break;
                ++j;
            }
            if (!needle[j]) return true;
        }
        return false;
    }

    // Walks CameraModuleList looking for the third-person module by CLASS NAME.
    // Name matching rather than IsA/FindClass — that choice has been load-bearing
    // repeatedly in this project (it's what fixed PostRender, the healthbars, and
    // the OwnerOnly pickups that IsA missed entirely).
    inline void UpdateThirdPerson() {
        SDK::APlayerController* pc = (SDK::APlayerController*)Globals::LocalController;
        if (!pc) return;

        SDK::ATgPlayerCamera* cam = nullptr;
        __try { cam = (SDK::ATgPlayerCamera*)pc->PlayerCamera; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return; }
        if (!cam) return;

        // Report the live module name whether or not the feature is on, so the
        // panel can show what the camera is actually doing. Silent failure with no
        // diagnostics is what made the old version so hard to debug.
        __try {
            if (cam->CurrentCameraMod) CopyObjName(cam->CurrentCameraMod, g_CurrentModuleName, 96);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }

        if (!tpModuleSwapEnabled) { g_SwapApplied = false; return; }

        // ####################################################################
        // TEST REPORT FINDING: CameraModuleList.Num() came back 0, but
        // CurrentCameraMod was already "TgCameraModule_ThirdPerson".
        //
        // So the list is empty (or not populated the way I assumed) while the
        // ACTIVE module pointer is perfectly valid — and it is already the
        // third-person module even during normal first-person play. Paladins
        // evidently drives first person through the same module with a zeroed
        // offset, which means there is nothing to swap: we only need to set the
        // offset on the module that is ALREADY active.
        //
        // That makes this far simpler and safer than the list walk. Doing it
        // first, and only falling back to the list if this module isn't the
        // third-person one.
        // ####################################################################
        __try {
            if (cam->CurrentCameraMod) {
                char nm[96];
                if (CopyObjName(cam->CurrentCameraMod, nm, 96) && NameHas(nm, "ThirdPerson")) {
                    g_ThirdPersonModuleFound = true;
                    SDK::UTgCameraModule_ThirdPerson* tp =
                        (SDK::UTgCameraModule_ThirdPerson*)cam->CurrentCameraMod;
                    tp->vForcedCameraOffset.X = -tpBack;
                    tp->vForcedCameraOffset.Y = tpRight;
                    tp->vForcedCameraOffset.Z = tpHeight;
                    g_SwapApplied = true;
                    return;
                }
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }

        __try {
            int count = cam->CameraModuleList.Num();
            g_ModulesFound = count;
            if (count <= 0 || count > 64) return;   // sanity bound before indexing

            for (int i = 0; i < count; ++i) {
                SDK::UTgCameraModule* mod = cam->CameraModuleList[i];
                if (!mod) continue;

                char nm[96];
                if (!CopyObjName(mod, nm, 96)) continue;
                if (!NameHas(nm, "ThirdPerson")) continue;

                g_ThirdPersonModuleFound = true;

                SDK::UTgCameraModule_ThirdPerson* tp = (SDK::UTgCameraModule_ThirdPerson*)mod;
                // X is forward/back (negative pulls the camera behind the pawn),
                // Y is right, Z is up.
                tp->vForcedCameraOffset.X = -tpBack;
                tp->vForcedCameraOffset.Y = tpRight;
                tp->vForcedCameraOffset.Z = tpHeight;

                if (cam->CurrentCameraMod != mod) cam->CurrentCameraMod = mod;
                g_SwapApplied = true;
                return;
            }
            g_ThirdPersonModuleFound = false;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { }
    }

    inline void DrawThirdPersonControls() {
        ImGui::TextColored(Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)), "THIRD PERSON  (new route - UNPROVEN)");
        ImGui::TextWrapped("The existing 'Third person camera' checkbox in the Highlights tab calls "
            "UTgBattleCheatManager::Set3p. CheatManager functions are admin-gated - the same wall "
            "that makes SetMountSkin useless in a match - so it silently does nothing. That is why "
            "it looked broken with no error.");
        ImGui::TextWrapped("This route avoids CheatManager entirely: it points the camera's "
            "CurrentCameraMod at the third-person module already sitting in CameraModuleList, and "
            "sets that module's forced offset. All client-side.");

        ImGui::Checkbox("Enable third person (module swap)", &tpModuleSwapEnabled);
        ImGui::SliderFloat("Height", &tpHeight, -50.0f, 200.0f, "%.0f");
        ImGui::SliderFloat("Distance back", &tpBack, 0.0f, 500.0f, "%.0f");
        ImGui::SliderFloat("Shoulder offset", &tpRight, -150.0f, 150.0f, "%.0f");

        ImGui::Separator();
        ImGui::Text("Active camera module : %s", g_CurrentModuleName);
        ImGui::Text("Modules in list      : %d", g_ModulesFound);
        ImGui::Text("Third-person module  : %s", g_ThirdPersonModuleFound ? "FOUND" : "not found");
        ImGui::Text("Swap applied         : %s", g_SwapApplied ? "yes" : "no");
        ImGui::TextWrapped("If 'Modules in list' is 0, the camera has no modules to swap to and this "
            "route is dead - say so and I'll try driving UpdateCamera's output directly instead. "
            "The module name above tells us what the camera is really running.");
    }

    inline void DrawControls(bool inMatch) {
        ImGui::TextColored(Ink(ImVec4(0.6f, 0.85f, 1.0f, 1.0f)), "FOV CHANGER");
        ImGui::TextWrapped("FOV is not a stat and not a capability - it is just how wide YOUR "
            "camera renders. None of the three FOV fields are replicated, which is why this "
            "should hold in real matches where the speedhack did not.");

        if (!inMatch) { ImGui::TextDisabled("Join a match first."); return; }

        ImGui::Checkbox("Enable custom FOV", &fovEnabled);
        ImGui::SliderFloat("FOV", &fovValue, 60.0f, 150.0f, "%.0f");
        ImGui::SameLine();
        if (ImGui::Button("Restore")) Restore();

        ImGui::Checkbox("Also write DefaultFOV (recommended)", &alsoWriteDefault);
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip(
                "The camera lerps FOVAngle back toward DesiredFOV, which is itself\n"
                "reset from DefaultFOV. Without this, the FOV visibly springs back.");
        }

        ImGui::Separator();
        ImGui::Text("Live FOV        : %.1f", g_LiveFOV);
        ImGui::Text("Your real FOV   : %.1f", g_CapturedDefaultFOV);
        ImGui::Text("Writes          : %d", g_FovWrites);
        ImGui::TextDisabled("Scoping/ADS is left alone on purpose - it uses a separate");
        ImGui::TextDisabled("path (SetFOVZoomed), and overriding it breaks sniper zoom.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        DrawThirdPersonControls();
    }
}
