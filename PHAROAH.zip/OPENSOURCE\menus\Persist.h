#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include <Windows.h>

// ============================================================================
// SETTINGS  —  the tool remembers itself between sessions
// ============================================================================
// The notes panel proved the pattern: write a plain file next to the DLL, read
// it back on startup. This generalises that to every setting worth keeping, so
// nobody has to re-tick the same eight boxes every launch.
//
// HOW IT WORKS
//   Modules register a pointer to their own variable with a stable key name.
//   Nothing is copied - the registry holds the addresses, so a load writes
//   straight into the real variable and a save reads straight out of it.
//
//   Values are compared against a snapshot each frame. When something differs,
//   a save is scheduled a second later; if you are dragging a colour picker,
//   that collapses into one write instead of sixty.
//
// FORMAT
//   key=value, one per line, plain text. Deliberately readable and hand-
//   editable - if a setting ever wedges the tool, the fix is to open the file
//   and delete a line rather than reinstall anything.
//
// WHAT IS NOT HERE
//   The charity gate keeps its own separate file. That is on purpose: a gate
//   that can be cleared by deleting a line from a settings file is not a gate,
//   and mixing the two would make "reset my settings" also mean "re-lock the
//   tool", which nobody would expect.
// ============================================================================

namespace Persist {

    enum Type { T_BOOL = 0, T_INT = 1, T_FLOAT = 2 };

    struct Entry {
        const char* key;
        int         type;
        void*       ptr;
        // last-known value, for change detection
        int         lastI;
        float       lastF;
    };

    static const int kMaxEntries = 256;
    inline Entry  g_Entries[kMaxEntries];
    inline int    g_Count       = 0;
    inline bool   g_Loaded      = false;
    inline bool   g_Dirty       = false;
    inline double g_SaveAt      = 0.0;
    inline int    g_SaveCount   = 0;
    inline int    g_LoadedCount = 0;

    inline const char* FilePath() {
        static char path[MAX_PATH] = { 0 };
        if (path[0]) return path;
        HMODULE self = nullptr;
        GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)&FilePath, &self);
        if (self && GetModuleFileNameA(self, path, MAX_PATH)) {
            char* slash = strrchr(path, '\\');
            if (slash) { slash[1] = 0; lstrcatA(path, "pharoah_settings.txt"); return path; }
        }
        lstrcpyA(path, "pharoah_settings.txt");
        return path;
    }

    inline void Reg(const char* key, int type, void* ptr) {
        if (g_Count >= kMaxEntries || !key || !ptr) return;
        Entry& e = g_Entries[g_Count++];
        e.key = key; e.type = type; e.ptr = ptr;
        e.lastI = (type == T_FLOAT) ? 0 : (type == T_BOOL ? (*(bool*)ptr ? 1 : 0) : *(int*)ptr);
        e.lastF = (type == T_FLOAT) ? *(float*)ptr : 0.0f;
    }
    inline void RegBool (const char* k, bool*  p) { Reg(k, T_BOOL,  (void*)p); }
    inline void RegInt  (const char* k, int*   p) { Reg(k, T_INT,   (void*)p); }
    inline void RegFloat(const char* k, float* p) { Reg(k, T_FLOAT, (void*)p); }

    inline void Snapshot() {
        for (int i = 0; i < g_Count; ++i) {
            Entry& e = g_Entries[i];
            if (e.type == T_BOOL)       e.lastI = (*(bool*)e.ptr) ? 1 : 0;
            else if (e.type == T_INT)   e.lastI = *(int*)e.ptr;
            else                        e.lastF = *(float*)e.ptr;
        }
    }

    inline bool Changed() {
        for (int i = 0; i < g_Count; ++i) {
            Entry& e = g_Entries[i];
            if (e.type == T_BOOL)     { if (((*(bool*)e.ptr) ? 1 : 0) != e.lastI) return true; }
            else if (e.type == T_INT) { if (*(int*)e.ptr != e.lastI)              return true; }
            else {
                float v = *(float*)e.ptr;
                float d = v - e.lastF; if (d < 0) d = -d;
                if (d > 0.0001f) return true;
            }
        }
        return false;
    }

    inline void Save() {
        HANDLE h = CreateFileA(FilePath(), GENERIC_WRITE, FILE_SHARE_READ, nullptr,
                               CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (h == INVALID_HANDLE_VALUE) return;

        char line[256];
        const char* hdr = "# PHAROAH settings. Plain text - safe to edit or delete.\r\n";
        DWORD w = 0;
        WriteFile(h, hdr, (DWORD)lstrlenA(hdr), &w, nullptr);

        for (int i = 0; i < g_Count; ++i) {
            Entry& e = g_Entries[i];
            int len = 0;
            if (e.type == T_BOOL)
                len = wsprintfA(line, "%s=%d\r\n", e.key, (*(bool*)e.ptr) ? 1 : 0);
            else if (e.type == T_INT)
                len = wsprintfA(line, "%s=%d\r\n", e.key, *(int*)e.ptr);
            else {
                // wsprintfA has no %f, so floats go out as thousandths of an int.
                int milli = (int)((*(float*)e.ptr) * 1000.0f);
                len = wsprintfA(line, "%s=%d\r\n", e.key, milli);
            }
            if (len > 0) WriteFile(h, line, (DWORD)len, &w, nullptr);
        }
        FlushFileBuffers(h);
        CloseHandle(h);
        g_Dirty = false;
        g_SaveCount++;
        Snapshot();
    }

    inline void ApplyLine(char* line) {
        char* eq = line;
        while (*eq && *eq != '=') ++eq;
        if (*eq != '=') return;
        *eq = 0;
        const char* key = line;
        int val = 0, sign = 1;
        const char* v = eq + 1;
        if (*v == '-') { sign = -1; ++v; }
        while (*v >= '0' && *v <= '9') { val = val * 10 + (*v - '0'); ++v; }
        val *= sign;

        for (int i = 0; i < g_Count; ++i) {
            Entry& e = g_Entries[i];
            if (lstrcmpA(e.key, key) != 0) continue;
            if (e.type == T_BOOL)       *(bool*)e.ptr  = (val != 0);
            else if (e.type == T_INT)   *(int*)e.ptr   = val;
            else                        *(float*)e.ptr = (float)val / 1000.0f;
            g_LoadedCount++;
            return;
        }
    }

    inline void LoadOnce() {
        if (g_Loaded) return;
        g_Loaded = true;

        HANDLE h = CreateFileA(FilePath(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                               nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (h == INVALID_HANDLE_VALUE) { Snapshot(); return; }

        static char buf[16384];
        DWORD read = 0;
        ReadFile(h, buf, sizeof(buf) - 1, &read, nullptr);
        buf[read < sizeof(buf) ? read : sizeof(buf) - 1] = 0;
        CloseHandle(h);

        char* p = buf;
        while (*p) {
            char* line = p;
            while (*p && *p != '\n' && *p != '\r') ++p;
            char saved = *p;
            *p = 0;
            if (line[0] && line[0] != '#') ApplyLine(line);
            *p = saved;
            while (*p == '\n' || *p == '\r') ++p;
        }
        Snapshot();
    }

    // Called every frame. Cheap: a few hundred comparisons, and it only touches
    // the disk after a change has settled.
    inline void Tick() {
        if (!g_Loaded) return;
        if (!g_Dirty) {
            if (!Changed()) return;
            g_Dirty = true;
            g_SaveAt = ImGui::GetTime() + 1.0;   // let a slider drag settle
            return;
        }
        if (ImGui::GetTime() >= g_SaveAt) Save();
    }
}
