#pragma once
#include "SDK.hpp"

typedef void(*tProcessEvent)(SDK::UObject* pObject, SDK::UFunction* pFunction, const void* pParams, __int64 pResult);