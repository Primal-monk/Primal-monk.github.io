#pragma once

// Paladins (8.1.5838.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

namespace SDK
{
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
