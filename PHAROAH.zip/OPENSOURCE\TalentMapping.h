#pragma once
#include <string>
#include <vector>
#include <unordered_map>

struct Talent {
    int id;
    std::string name;
    std::string description;
};

inline std::unordered_map<std::string, std::vector<Talent>> championTalents = {
    {"Androxus", {
        {16368, "Godslayer", "Reversal always fires back and does an additional 800 damage."},
        {16369, "Cursed Revolver", "Your Revolver applies a Bleed for 1s, dealing damage every 0.1s that increases the longer it remains on the enemy. Maximum damage per 0.1s is 20. Additional hits refresh the duration"},
        {19292, "Dark Stalker", "Nether Step now has 3 separate charges and is no longer linked"},
        {19827, "Lingering Curse", "Accursed Arm lasts 8s longer, can fire 8 more shots, and charges 15% faster"},
        {20085, "Defiant Fist", "Successful hits with your Revolver increase the damage of your next Defiance by 20%, stacking up to 100%"},
        {24721, "Cursed Cylinder v2", "Your Revolver's ammo capacity is increased by 3"},
    }},
    {"Ash", {
        {18388, "Battering Ram", "Reduce your damage taken by 75% while using Shoulder Bash"},
        {18416, "Rally Here", "Assert Dominance now charges 15% faster, stuns enemies for 2s, and causes them to take 35% more damage"},
        {18556, "Fortress Breaker", "Increase Siege Shield's maximum Health by 2500 and its size by 50%, but reduce its Movement Speed by 80%"},
        {19846, "Super Smash", "Your knockbacks knock enemies back up to 100% further based on their missing Health"},
        {20087, "Slug Shot", "Your weapon shots travel 50% faster and 100% farther, but no longer explode"}
    }},
    {"Atlas", {
        {24477, "Deja vu", "Setback becomes a lobbed explosive, capable of Rewinding multiple enemies"},
        {24483, "Temporal Divide", "Greatly increase the size of Stasis Field, but its Cooldown is increased by 65%"},
        {27390, "Unstable Fissure", "When you use Second Chance you also Rewind enemies within 20 units 3s into the past"},
        {24487, "Unstable Fissure - OLD", "Activating Second Chance also Rewinds enemies within 20 units"}
    }},
    {"Azaan", {
        {27718, "Persistence", "Gain 30% Lifesteal on your hits with Judgement"},
        {27719, "Tempering", "Tempering, Augment Reckoning, Sanctuary, and Conviction, but increase their base Cooldown by 25%"},
        {27720, "Eternal", "Your Ire no longer decays due to not taking or dealing damage, but you no longer gain the passive damage increase while above Ire threshold"}
    }},
    {"Barik", {
        {12934, "Architectonics", "Increase the damage of your Turrets by 20% and reduce their Cooldown by 2s"},
        {16397, "Fortify", "Increase the maximum Health of Barricade by 2000 and reduce its Cooldown by 3s"},
        {16400, "Tinkerin", "Modify your Blunderbuss to fire a single slug that deals 600 damage"},
        {19828, "Burninate", "Barik Turrets now shoot flames dealing 400 damage per second"},
        {20088, "Hair Trigger", "Blunderbuss fires 30% faster"},
        {27389, "Forgefire", "Dome Shield now costs 40% Ultimate charge and places a Flamethrower Turret with modified values and no Shield. Can have two active at once."}
    }},
    {"Betty la Bomba", {
        {28008, "Fiery Disposition", "Explosive damage sets enemies on fire for 0.3% of their maximum Health every 0.1s for 1.5s. Additional hits refresh the duration."},
        {28009, "Controlled Fury", "Reduce the range of Hail of Bombs by 50%, concentrating the explosions in a smaller area, and reduce the Cooldown of Hail of Bombs by 2s"},
        {28010, "Gotta Bounce", "Reduce the Cooldown of Explosive Personality by 5s, but reduce your Movement Speed by 15%"},
    }},
    {"Bomb King", {
        {16426, "Chain Reaction", "Hitting with more than one Sticky Bomb on a use of Detonate increases the damage of each explosion after the first by 30% of its base damage, up to 150%"},
        {16427, "Accelerant", "Reduces the time it takes for Grumpy Bomb to explode by 40%"},
        {16506, "Demolition", "Grumpy Bomb destroys all shields when it explodes and its blast radius is increased by 30%, Grumpy Bomb destroys all shields when it explodes and has a larger blast radius"},
        {20089, "Pop'n'Lock", "Poppy Bomb now deals {scale=425|25} damage and cripples for 2s"},
        {20216, "Royal Subjects", "Increase the radius of Sticky Bombs' explosions by 20%, but reduce maximum Ammo count by  2"},
        {20321, "zOldBKLeg2", "Increase the explosion size of Sticky bombs by 100%"}
    }},
    {"Buck", {
        {12931, "Bounce House", "Heroic Leap deals 600 damage and applies a Knockback to enemies within 20 units of your landing location"},
        {16386, "Ensnare", "Increase the damage you deal to targets Slowed by Net Shot by 20% and increases the duration of Net Shot's Slow by 0.5s. The damage increase lasts a minimum of 2s."},
        {16392, "Bulk Up", "Using Recovery instantly Heals you for 400 and increases your maximum Health by 300 for 5s"},
        {20329, "Blessed", "Receive 40% more healing"},
        {20339, "Bucking Madness", "Eliminations increase your attack speed by 20% for 10s"},
        {23458, "Double Barrel Test", "Experimental Talent for Buck"},
        {23572, "Bounce House v2", "Heroic Leap now deals 600 damage, knocks up enemies straight up and has a 20% increased radius"}
    }},
    {"Caspian", {
        {31057, "Measured Cadence", "Fire a weaker copy of Rogue's Tempo forward from your crosshairs for every 6 Ammo consumed"},
        {31058, "Everywhere at Once", "The Cooldown of Deadly Momentum  is permanently set to 5s and cannot be modified, reduced, or increased through other means. Gain 1 stack of Piercing and Sharp Momentum for each enemy hit with Deadly Momentum."},
        {31059, "It's Got Some Heft", "Increase the Range and Damage of War, but decrease its rate of fire. War's attacks now deal an additional 20% damage to each enemy hit for each enemy hit in total with your attack."},
    }},
    {"Cassie", {
        {16382, "Impulse", "Blast Shot has its damage increased by 150 and its Cooldown decreased by 2s"},
        {16384, "Exaction", "For 8s after using Dodge Roll, your next weapon shot's damage is increased by 30%"},
        {16385, "Big Game", "For 4s after hitting an enemy with Disengage, your weapon shots deal an additional 8% of that enemy's maximum Health as damage"},
        {19869, "Deadeye", "Your attack speed is increased by 20% and after hitting a target your next shot does 30% more damage to them"},
        {20193, "Just Breathe", "Crossbow shots deal 850 damage at long range"}
    }},
    {"Corvus", {
        {25366, "Spreading Influence", "Decrease the percentage of Healing given to Marked targets by 20%, but you can have two Marks out at a time"},
        {25370, "Stunning Visage", "Enemies hit by Projection are stunned for 1s and any enemy caught between your Projection and you when you Teleport takes 800 damage"},
        {25371, "Dark Gifts", "Your Marked ally gains 15% Crowd Control reduction, 15% Cooldown reduction, 15% Reload Speed increase, and they are Healed for 75 every 1s"}
    }},
    {"Dredge", {
        {23688, "Hurl", "Hits with Harpoon refund its Cooldown and generate 50% more Ultimate Charge, but no longer Slows enemies hit"},
        {23690, "Scuttle", "The projectile launched by reloading your Cursed Howitzer explodes in a 20-unit-radius area on contact"},
        {23692, "Freebooter", "Allies may Pass through your Shortcut"},
        {23807, "Abyss Spike", "Harpoon lodges into terrain and explodes when an enemy comes within 20 units, dealing 1000 damage in a 35-unit-radius area"}
    }},
    {"Drogoz", {
        {16364, "W.Y.R.M. Jets", "Increase Booster's Max Vertical Speed by 100% and Vertical Acceleration by 57%"},
        {16383, "Fusillade", "Damage dealt when hitting an enemy directly with Rocket Launcher or Salvo is increased by 25%"},
        {16514, "Combustible", "Detonating Fire Spit applies a Knockback and deals an additional 300 Burn damage over 2s"},
        {20175, "Dragonskin", "The amount of Booster you have also acts as a shield that can absorb up to 255 damage"},
        {20259, "Reign of Terror", "Salvo now activates instantly, always fires 6 shots, and has its cooldown reduced by 5s"},
        {20358, "Dragon Overdrive", "Dragon Punch deals damage equal to your victims maximum health in a radius around their location and charges 15% faster"}
    }},
    {"Evie", {
        {16370, "Over the Moon", "Increase the damage you deal with your weapon shots by 25% for 3s after Soar ends"},
        {16371, "Wormhole", "Blink leaves behind a magical wormhole. Refire Blink within 4s of its use to return to the wormhole."},
        {16372, "Reprieve", " Heal 300 Health per second during Ice Block"},
        {20235, "Snow Globe", "Ice Storm now costs 50% Ultimate Charge and deals 100% increased damage, but its duration is reduced to 3s and its Slow is reduced to 30%"},
        {20237, "Snowball", "Kills increase your damage by 5% up to 20% until you die"}
    }},
    {"Fernando", {
        {16379, "Aegis", "Increase Chivarly's Shield to 5500, and it begins regenerating 25% sooner and 25% faster. You now only need 20% Shield to activate Chivalry after it is broken."},
        {16380, "Scorch", "Increase the damage of Fireball by 35%, decrease its Cooldown by 1s, and deal 20% increased damage for each subsequent target hit after the first"},
        {16381, "Formidable", "You now have 2 charges of Charge, each Charge deals an additional 100 damage, and you are Immune to Crowd Control while Charging, but the Cooldown of Charge is increased to 13s"},
        {20090, "Overrun", "Charge now deals 700 damage"},
        {20229, "Dragonfire Lance", "Flame Lance now fires small fireballs that deal 120 damage every 0.2s"}
    }},
    {"Furia", {
        {23358, "Exterminate", "Increase the Attack Speed bonus of Wrath to 15% per tier"},
        {23362, "Solar Blessing", "Pyre Strike now can be stopped by refire & Heals yourself and allies within for 175 every 0.1s. Allies continue to heal for 1.5s on exit."},
        {23391, "Celerity", "Wings of Wrath gains an additional charge"},
        {23394, "Cherish", "Kindle Soul also heals allies within 50 units of your target at 50% effectiveness"}
    }},
    {"Grohk", {
        {16377, "Totemic Ward", "Gain a third charge of Healing Totem and increase their radius by 20%"},
        {16378, "Maelstrom", "Increase the damage of Lightning Staff to 75, your weapon shots reduce the Cooldown of Shock Pulse by 0.5s, and Shock Pulse chains 4 additional times."},
        {16425, "Wraith", "When you take lethal damage Ghost Walk activates and heals you for 15% of your maximum Health"},
        {20308, "Marked for Death", "Targets hit by Lightning Staff take 15% increased damage for 2s"},
        {20325, "Spirit's Domain", "Hitting allies with your Lightning Staff Heals them for 80 every .1s and up to 30% more if held longer on them, increases their Movement Speed by 20% for 1s, and your maximum Ammo capacity is increased by 25%."},
    }},
    {"Grover", {
        {16389, "Ferocity", "Increase your maximum damage scaling over distance by 60%"},
        {16402, "Rampant Blooming", "Heal for a burst of 350 and an additional 200 over 2s in a 50-unit radius at your location when you finish Vining"},
        {33622, "Wisps of Sylvanus", "Blossom's passive aura now also provides 15% Movement Speed"},
        {16582, "Deep Roots", "Crippling Throw travels 35% slower, but now instead Roots targets affected"},
        {20091, "Efflorescence", "Increase the passive healing of Blossom by 100% and its radius by 50%"},
        {20249, "Great Oak", "Eliminations increase your maximum Health by 150 until you die. Stacks up to 5 times."},
    }},
    {"Imani", {
        {24136, "Mana Rift", "Remaining still for 1s creates a 30-unit Mana Rift around you that generates Mana every 1s. Leaving the Mana Rift destroys it."},
        {24144, "Pyromania", "Each of your Pyre Balls explodes in a 20-unit-radius area on hit and generate more Mana. Converts Pyre Ball to Area Damage."},
        {24145, "Splitting Ice", "Frost Bolt Chains to a nearby enemy within 30 units, dealing 225 damage"}
    }},
    {"Inara", {
        {16600, "Treacherous Ground", "The radius of Warder's Field is increased by 50% and it Cripples enemies within it"},
        {16601, "Mother's Grace", "Increase the Damage Reduction of Earthen Guard by 10% and gain Immunity to Crowd Control while Earthen Guard is active"},
        {16605, "Tremors", "Impasse now has 2 charges and its Cooldown is reduced to 12s, but you are unable to destroy your walls"},
        {20214, "Wrath of the Stagalla", "Hitting all 3 shots on the same target deals an extra 200 damage"},
        {20233, "The Stone Protects", "30% of all damage dealt to you is instead taken by your deployables if they are active"}
    }},
    {"Io", {
        {24663, "Sacrifice", "If Io falls below 200 Health while Luna is active, she trades places with Luna, Heals for 50% of her Health, and Luna dies instead"},
        {24673, "Life Link", "When Io or Luna heal an ally other than each other, the other is also healed at 50% efficiency"},
        {24674, "Goddess' Blessing", "Allies being Healed by Moonlight take 15% reduced damage"}
    }},
    {"Jenos", {
        {19189, "Celestial Touch", "When you cast Astral Mark on an ally, they are immediately healed for 10% of their maximum Health"},
        {19190, "The Power Cosmeum", "Enemies affected by Void Grip are Crippled and take an additional 480 damage over its duration"},
        {19223, "Luminary", "All allies already affected by Astral Mark are Healed for an additional 285 when you use Astral Mark"},
        {20092, "Binary Star", "Star Splitter now deals 380 damage every 0.4s, but reduces your maximum Ammo to 15"},
        {20231, "Rising Star", "Weapon shots increase the duration of active Astral Marks by .1s"},
        {33594, "Luminary - Old", "Allies affected by your Astral Mark deal 15% increased weapon damage"}
    }},
    {"Khan", {
        {22888, "Lian's Shield", "Your Shield now regenerates at 120% effectiveness and regenerates while it is active"},
        {22889, "Firing Line", "Champions affected by Battle Shout now also deal 20% increased damage and gain CC immunity for 4s"},
        {22890, "Storm of Bullets", "Increase your Attack Speed by 40%, but reduce your damage-per-shot by 25%"},
        {22891, "Vortex Grip", "Targets are Stunned by Commander's Grab for an additional 1.4s and Weakened to weapon attacks by 15% during"}
    }},
    {"Kinessa", {
        {16387, "Oppression", "You can have two additional Oppressor Mines out at one time and you throw out two Mines per use of the ability instead of one, but your Mines have a lifetime of 6s and the Cooldown of Oppressor Mine is increased by 2s"},
        {16456, "Steady Aim", "For 4s after hitting a fully-charged weapon shot, your next fully-charged shot will deal an additional 20% damage"},
        {16507, "Suppression", "Oppressor Mines can now affect 2 more targets and Sniper Shots against enemies affected by Mines deal 30% more damage"},
        {20093, "Reposition", "Transporter instantly Teleports you to its target location, but has its range reduced to 75 units"},
        {20332, "Failsafe Shield", "When receiving fatal damage, instead gain a shield that absorbs 1000 damage and lasts 3 seconds"}
    }},
    // {"Koga", {
    //     {23481, "Blood Reaper"},
    //     {23482, "Dragon Fangs"},
    //     {23556, "Master of Arms"}
    // }},
    {"Lex", {
        {16807, "Heroism", "Gain Immunity to Crowd Control during Combat Slide"},
        {16909, "Death Hastens", "Your weapon shots deal 680 damage every 0.7s, but your maximum Ammo count is reduced by 6"},
        {16914, "Discovery", "Increase the damage you deal to your Retribution target by 15%"},
        {20094, "Fought The Law", "In Pursuit now deals 51% of the target's maximum health in damage over its duration"},
        {20225, "The Law Won", "Killing your Retribution target grants a 5% damage buff that stacks up to 5 times"},
        {24722, "Death Hastens v2", "Your Weapon Shots deal 25% more damage to targets over 65% Health., Weapon shots deal more damage to high-health targets"}
    }},
    {"Lian", {
        {18814, "Precision", "Hitting an enemy with Heirloom Rifle increases your Heirloom Rifle damage against that enemy by 7% for 5s, stacking up to 5 times"},
        {18815, "Eminence", "Increase the damage of Presence by up to 50% based on the range at which it hits and reduce its Cooldown by 4s"},
        {18816, "Alacrity", "Grace now hits all enemies in front of you instead of only one, but its Cooldown is increased by 1s"},
        {20095, "Death and Taxes", "Your weapon shots reduce the effect of healing on your target by 90% for 1.5s"},
        {20330, "Warrior Princess", "For every enemy you hit with Valor gain 10% increased damage for 4s"},
    }},
    {"Lillith", {
        {30806, "Cursed Accord", "Blood Hexed allies ignore damage resistance up to 10%. Heal an extra 250 Blood Health when a Blood Hexed ally eliminates an enemy."},
        {30807, "Maelstrom of Carnage", "Swarm is now cast on yourself and follows you around instead of being placed on the ground, its ability cost is decreased and its radius is increased by 40%"},
        {33002, "Murderous Intent", "Hitting an enemy with Heart of Crimson while they're affected by Blood Hex or Swarm increases your movement by 10% and attack speed by 11% for 4s. Stacks up to 3 times."}
    }},
    {"Maeve", {
        {16406, "Cat Burglar", "Increase the damage of each of your daggers from your first two Dagger sets within 5s of Prowl ending by 30%"},
        {16449, "Rogue's Gambit", "Increase the damage done by Pounce by 20%, reduce its Cooldown by 2s, and reset Pounce's Cooldown after earning an Elimination"},
        {16502, "Artful Dodger", "Activating Nine Lives interrupts and gives immunity to all Crowd Control effects for .25s. You have an additional jump."},
        {20196, "Street Justice", "Activating Midnight resets Pounce's Cooldown. During Midnight, Pounce Executes targets at or below 75% Health. Midnight's duration is increased by 2s and its charge rate is 20% faster."},
        {20213, "Queen of Knives", "Hitting both daggers reduces the cooldown of Nine Lives by 6s"}
    }},
    {"Makoa", {
        {16432, "Leviathan", "Increase your Ultimate charge rate by 25% and base Health by 500. Ancient Rage now causes Makoa to grow 50% in size, resets all his Cooldowns, and increases his Movement Speed by 45%."},
        {16433, "Pluck", "For 4s after hitting an enemy with Dredge Anchor, your next weapon shot against that enemy deals 75% increased damage"},
        {16525, "Half Shell", "Shell Shield is placed on the ground instead of channeled around you, lasts 2s longer, and has its maximum Health increased by 500"},
        {20192, "Leaden Cannonball", "Fire a burst of smaller shells that deal a total of 800 damage"},
        {20250, "Davey Jones Locker", "Your Shell Spin now lasts until canceled and you can control its direction"}
    }},
    {"Mal'Damba", {
        {16491, "Ripened Gourd OLD", "Gourd has a 50% chance to not go on Cooldown"},
        {16494, "Wekono's Wrath", "Your Snake Toss projectile travels 60% faster and deals an additional 500 damage"},
        {16495, "Spirit's Chosen", "Mending Spirits heals an additional 350 Health instantly"},
        {20191, "Ripened Gourd", "Your Gourd no longer damages enemies, but it Heals for twice as much"},
        {20257, "Gourd Season", "Every tick of healing or damage from Gourd reduces the cooldown of Gourd by 0.1s"},
        {27406, "Spirit's Chosen (punted)", "While using Slither, passing through an ally will Heal them for 800 and passing through an enemy will damage them for 650"},
    }},
    {"Moji", {
        {33418, "Realm Runner", "When entering Scamper, leave a magical dust cloud behind that applies a lingering heal for 600 over 3s. The dust cloud lasts 4s"},
        {33416, "Jubilation", "Magic Marks are now instead applied to enemies. Detonating at least 7 stacks of Magic Mark deals bonus damage, up to 550 extra damage at 10 stacks. Enemies within 15 units take 75% of the damage."},
        {33417, "Spite Shine", "Detonating 10 stacks of Magic Mark now also increases the Movement Speed of affected allies by 10% for 4s. This effects stacks up to 3 times and each stack expires individually."},
        {22033, "Snack Attack", "When you get an Elimination, drop a Health Pack that Heals the entire team for 900 when picked up by an ally. Health Packs are visible to allies and are not able to be seen or interacted with by the opposing team."},
        {22037, "Yummy", "Consuming a victim of your ultimate recharges your ultimate by 50% and heals you for 1000"},
        {22048, "Boom Boom", "Detonating a Magic Mark also damages all enemies within 15 units of the victim for 75% of its damage"},
        {22053, "Toot", "Using Scamper Heals you and allies within 25 units of your starting location for 600 over 3s"},
    }},
    {"Octavia", {
        {26957, "Paratrooper", "You can now hover for 4s and gain 50% increased air control. While in Commanding Leap, gain 10% increased weapon damage"},
        {26959, "Display of Force", "Enemies are Rooted in place when they are hit by the pre-fire beam and the Creeping Barrage deals 1450 damage"},
        {26958, "Asymmetric Warfare", "Distortion Field now damages enemies for 200 every .5s for the duration of Distortion Field and heals allies for 125 every .5 seconds while inside of the field"}
    }},
    {"Omen", {
        {32760, "Everyone Dies", "Hitting an enemy with Dark Stride now reduces Gravity Vice's Cooldown by 50%, and Dark Stride's damage is increased by 100"},
        {33052, "Umbral Lance", "Aphotic Reaver no longer ramps down, but its spread is reduced by 70%"},
        {32758, "Binary Void", "Deadly Domain now has 2 charges, but its Cooldown is increased by 3s"}
    }},
    {"Pip", {
        {16376, "Mega Potion", "Healing Potion's Healing is increased by 1000 and now provides a Stacking 200 Shield"},
        {16391, "Catalyst", "Enemies hit with Explosive Flask take 40% increased damage from your weapon shots for 4s"},
        {16516, "Combat Medic", "Potion Launcher also Heals allies hit for 700 and your Potion Launcher fire rate is increased by 15%. You no longer take damage from your weapon shots."},
        {20096, "Mischief", "Hits with your Potion Launcher reduce the Cooldown of all other skills by 1s"},
        {20194, "Lead Vial", "Healing Potions now only activate when directly hitting a target, and may persist in the world for 10s after hitting a surface. Reduces cooldown of Healing Potion by 3s."},
        {20391, "Chicken Tender-izer", "You deal 100% more damage to chickens, and for every chicken that dies your ult recharges by 20%"}
    }},
    {"Raum", {
        {24778, "Enforcer", "Gain 1.2s of Crowd Control Immunity and reduce your damage taken by 40% while using Juggernaut"},
        {24779, "Earthsplitter", "Increase your Ultimate charge rate by 60%"},
        {24780, "Subservience", "All your living allies are Healed for 1.5% of their maximum Health for each Soul Harvested"},
    }},
    {"Rei", {
        {27314, "Restraint", "While Envelop is active and you are Linked to an enemy, prevent them from Healing"},
        {27315, "Focus", "Spirit Link's Cooldown is increased to 6s and it now only lasts for 3s, but its base effects are tripled"},
        {27316, "Extension", "Chain Heal has 2 charges, but its cooldown is increased by 2 seconds"}
    }},
    {"Ruckus", {
        {16390, "Overdrive", "Deal up to 40% more damage based on your missing Health"},
        {16503, "Aerial Assault", "Advance gains a 3rd charge"},
        {33050, "Flux Generator", "Increase the Shield granted by Emitter by 1000 and reduce its Cooldown by 1s. While Emitter is active, gain Immunity to Crowd Control."},
        {20097, "Rocket Barrage", "Increase the radius of Missile Launcher's explosions by 66%"},
        {20331, "Excavation", "Weapon shots cause targets to take 1% additional damage from your Miniguns for 3s, stacking up to 25%"},
    }},
    {"Saati", {
        {27508, "Improvised", "Your Dead Ringer decoy is now rigged to explode when enemies are close, dealing 650 damage within a 20-unit radius"},
        {27509, "Window of Opportunity", "Blast Back now instead applies a Knockup and enemies take 20% more DMG from Saati for 1.5s"},
        {27510, "Heads or Tails", "Ricocheted shots now target two enemies and deal 200% more damage to Shields, but only deal 200 damage"}
    }},
    {"Seris", {
        {16608, "Agony", "For each stack of Soul Orb detonated by Rend Soul, Restore Soul heals an additional 5% True Healing (excluding Healing disable effects) up to 25% for 10s"},
        {16609, "Mortal Reach", "You can use Restore Soul during Shadow Travel, and Shadow Travel lasts 1s longer"},
        {16610, "Soul Collector", "Each Soul Charge you detonate with Rend Soul increases your maximum Health and weapon damage by 2% until you die. Stacks up to 12 times"},
        {20136, "The Void Abides", "Heal all allies within 50ft of your Restore Soul target for 50% of the healing value"},
        {20328, "The Void Protects", "When using Restore Soul on full health players, your Healing becomes Shielding up to 500"},
    }},
    {"Sha Lin", {
        {16453, "Desert Silence", "Eliminations enter you into Stealth for 2s. Shots from Stealth deal 200 increased damage"},
        {16454, "Shifting Sands", "Killing an enemy resets the Cooldown of Rapid Fire and Rapid Fire deals 20% more damage"},
        {16455, "Recurve", "Increase the rate at which your Longbow charges by 25%"},
        {20098, "Heavy Cord", "Increase your bow's maximum draw time by 10% and damage by 200"},
        {20263, "Sand Trap", "Crippling Arrow now explodes in a 20-unit-area, dealing up to 300 additional Area Damage to enemies hit, but its Cripple is reduced by 1s. The blast is fully effective within 12 units."},
    }},
    {"Skye", {
        {16373, "Surprise Attack", "Deal 500 bonus damage on your first successful Weapon Shot out of Hidden"},
        {16374, "Debilitate", "Increase the damage done by Poison Bolts by 15% and the rate at which they deal damage by 75%"},
        {16375, "Preparation", "Hidden gains a second charge and refills Wrist Crossbow's Ammo. While Hidden is active, reduce the damage you take by 50%. Permanently set the maximum duration of Hidden to 4s."},
        {20148, "Smoke and Dagger", "Benefits from your Smoke Screen cards also benefit allies who enter Smoke Screen and allies are Healed for 100 every 1s while in your Smoke Screen"},
        {20258, "Shhhh", "Enemies inside Smoke Screen are silenced"}
    }},
    {"Strix", {
        {19467, "Ambush", "Weapon Shots made in Stealth deal 15% more damage"},
        {19468, "Nocturnal", "While standing still, Stealth lasts indefinitely"},
        {19477, "Crack Shot", "Talon Rifle and Pistol gain perfect Accuracy, but Talon Rifle's damage is reduced to 950"},
        {20279, "Unauthorized Use", "Flare deals 200% base damage & Projectile Speed, and Weakens targets by 20% to your weapons on a direct hit for 2s, but it no longer Reveals. Reduce Flare's Cooldown by 8s."}
    }},
    {"Talus", {
        {19623, "Inner Strength", "Reduce the Cooldown of Overcharge and Blitz Upper by 6s when you Teleport using Rune of Travel"},
        {19624, "Raging Demon", "The duration of Overcharge is increased by 1s"},
        {19626, "Faustian Bargain", "Rune of Travel no longer automatically activates, and if the Rune is not used the Cooldown is reset"},
        {19706, "Nothing Personal", "Increase your Ultimate charge rate by 15% and enemies at or below 65% Health are Revealed to you"},
        {20197, "Secret Technique", "Deal up to 100% more damage with Blitz Upper based on your opponent's missing health"},
    }},
    {"Terminus", {
        {19943, "Undying", "Reduce the damage you take by 15% while at or below 50% Health"},
        {19944, "Decimation", "Each Calamity Blast deals an additional 100 damage"},
        {20028, "Crush", "Shatterfall Stuns enemies hit for 1s, but no longer Slows"},
        {20030, "Seething Rage", "Attack 25% faster when you have no Charges of Calamity Blast stored"},
        {20320, "Unholy Strength", "Successful Calamity Blast hits heal you for 250 health"},
    }},
    {"Tiberius", {
        {25180, "Predatory Instincts", "Combat Trance now resets your other abilities' cooldowns when activated"},
        {25181, "Tigron's Fury", "Heavy Blade now explodes on reactivation instead of recalling, but the initial throw does reduced damage"},
        {25182, "Vicious Assault", "Crouching Tigron now has 2 charges and deals 600 damage in a 20-unit-radius area on landing. Gain 40% Damage Resistance while airborne."}
    }},
    {"Torvald", {
        {16450, "Direct Current", "Double the range at which you can use Nullify"},
        {16451, "Field Study", "Increase the damage done by allies by 10% while they are Shielded by Protection"},
        {16492, "Alternating Current", "Increase Recharge's Duration by 1.5s"},
        {20099, "Thanks", "Increase Protection's Shield Health by 200"},
        {20340, "Overprotective", "Gain a second charge of Protection"}
    }},
    {"Tyra", {
        {16448, "Hunting Party", "Hunter's Mark now Weakens its target for all allies"},
        {16452, "First Blood", "Gain 30% Lifesteal"},
        {16458, "Mercy Kill", "Nade Launcher has 3 charges, but reduce the damage of each to 650"},
        {20170, "Huntress", "All enemies within 60ft of you are revealed to you"},
        {20230, "Burn", "Fire Bomb deals 30% increased damage and applies a 60% reduce healing effect"},
    }},
    {"Vatu", {
        {27084, "Omnipresence", "Your Ambush gains an additional teleport and can now be used on allies"},
        {27085, "Unerring", "Increase the explosion radius of Shadow Bombs by 5 units and they now home to enemies"},
        {33055, "Enveloping Shadows", "Reduce the Cooldown of your basic abilities by 3% for each Kunai that hits an enemy"},
    }},
    {"VII", {
        {27929, "Tribunal Upgrades", "Burst Mode now deals additional Shock damage that Reveals targets, Mag Dump adds a Burn over time, and Automatic freezes to Slow enemies"},
        {27930, "Overcharged", "Overcharge your Grappling Hook to now pull Non-Frontline Champions to VII"},
        {27931, "Spring Loaded", "Increase the travel distance of Explosive Dodge by 30%, and drop explosive traps at both your starting and ending locations"}
    }},
    {"Viktor", {
        {16429, "Burst Mode", "Switch your rifle to Three-Shot-Burst mode, increasing your effective range and firing three 210-damage shots every 0.5s"},
        {16430, "Firefight", "Gain 30% bonus damage while Hip Firing"},
        {16431, "Cardio", "Heal for 300 per second and gain 150% increased Jump Height while using Hustle"},
        {20100, "Shrapnel", "Increase the radius of Frag Grenade's explosion by 40% and its damage by 150"},
        {20171, "Standard Issue", "When receiving fatal damage, instead gain a shield that absorbs 1000 damage and lasts 3 seconds"},
    }},
    {"Vivian", {
        {20314, "Sapper Rounds", " Deal 150% increased damage to Shields"},
        {20315, "Opportunity in Chaos", "After firing continuously for 2s, gain 10% increased damage"},
        {20316, "Suspect Everyone", "Reduce Deflector Shield's cooldown by half if it is destroyed by an enemy"},
        {20318, "Ace in the Hole", "You always respawn with one Sentinel active"},
        {21261, "Booby Trap", "Your Sensor Drones explode, dealing 600 Area Damage and applying a Knockback to those hit when an enemy is within 20 units"},
    }},
    {"Willo", {
        {16888, "Disc Jump", "Gain 850 knock up when hitting yourself with Spinfusor"},
        {17111, "Scorn", "Increase the damage of each Seedling to 750 and reduce their detonation time by 25%. Secondary Seedlings now deal 1500 damage over 2s to any deployable shield hit."},
        {17112, "Scorched Earth", " Dead Zone damages shields for 50% of their maximum Health per second, and its cooldown is reduced by 3s"},
        {17137, "Blastflower", "Hitting an enemy with your weapon shots increases the damage they take from weapon shots by 15% for 3s, stacking up to 3 times"},
        {20310, "Spring Fever", "Your first shot after Flutter deals 100% more damage in a 50% larger radius"},
        {20319, "Nightshade", "Dead Zone damage is increased to 650. On hit, 25% of Dead Zone's cooldown is refunded."},
    }},
    {"Yagorath", {
        {26699, "Corrosive Acid", "Increase the damage done by Caustic Spray and your acid pools to 42. Allies within your acid pools have their Movement Speed increased by 20%"},
        {26700, "Sight Begets Strength", "Allied players within range of your Primal Vision gain a stackable 100-Health Shield and 15% increased Movement Speed for 5s each time you pulse"},
        {26701, "Unnatural Persistence", "While in Hardening, increase your Healing received from others by 50%"}
    }},
    {"Ying", {
        {16365, "Lifelike", "Illusions can now target two allies when Healing, but Illusions heal for 20% less"},
        {16366, "Resonance", "If an Illusion is killed or expires, it triggers a Shatter explosion, dealing 550 damage. Also increases your Shattered Illusions' Movement Speed by 65% and Explosion Radius by 5 units."},
        {16367, "Focusing Lens", "Deal an additional 200 damage to an enemy if you hit them with all 5 shots of Illusory Mirror"},
        {20101, "Revitalizing Link", "Dimensional Link now heals you for 400 every time you teleport"},
        {20359, "Life Exchange", "Shatter instantly Heals your target for 700, but its Cooldown is increased by 1s and it no longer explodes your Illusions. Reduce the Cooldown of Shatter by 2s if you miss."},
    }},
    {"Zhin", {
        {18302, "Smolder", "Heal for 15% of your maximum Health per second while using Billow"},
        {18303, "Guillotine", "Spite deals 20% of its target's maximum Health with each hit. If this kills the target, you are refunded 20% charge."},
        {18304, "Retaliation", "Within your Counter stance, you continually Counter and deal 10% more damage. Counter lasts an additional second."},
        {20195, "FINISH THEM!", "Whirl does up to 100% increased damage based on your opponent?s missing health"},
        {20212, "Blademaster", "Deal 30% more damage to enemies within 20ft of you"},
        {20222, "Yomi", "Whirl now Ignites enemies hit for 3s. Your Inferno Blade deals 20% increased damage to targets Burning or Ignited."},
    }},
    {"Kasumi", {
        {31303, "Empowered Curse", "Increase your Ultimate charge rate by 3% and Movement Speed by 5% per stack of Curse currently on enemies"},
        {31304, "Haunted Ground", "When a Spirit Trap is triggered, reactivate to teleport to the trap and detonate it. Increase the explosion radius by 25%, Curse stacks applied by 2, and it Fears instead of Slowing."},
        {31305, "Unfinished Business", "After the Body and Soul ends, Heal for 70% of the damage your body took (minimum of 15% max health) while traveling, unaffected by Anti-Healing"},
    }}
};
