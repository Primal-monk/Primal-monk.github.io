#pragma once
#include <unordered_map>
#include <string>

#include "globals.h"

inline std::unordered_map<int, std::string> championIdToName = {
    {12489, "Androxus"},
    {16708, "Ash"},
    {24033, "Atlas"},
    {27606, "Azaan"},
    {11197, "Barik"},
    {27924, "Betty la Bomba"},
    {14308, "Bomb King"},
    {12879, "Buck"},
    {30965, "Caspian"},
    {10772, "Cassie"},
    {25317, "Corvus"},
    {23600, "Dredge"},
    {13325, "Drogoz"},
    {10752, "Evie"},
    {10774, "Fernando"},
    {23302, "Furia"},
    {10751, "Grohk"},
    {13026, "Grover"},
    {23860, "Imani"},
    {16246, "Inara"},
    {24291, "Io"},
    {17176, "Jenos"},
    {31245, "Kasumi"},
    {19692, "Khan"},
    {12872, "Kinessa"},
    {23399, "Koga"},
    {16530, "Lex"},
    {17115, "Lian"},
    {30610, "Lillith"},
    {16218, "Maeve"},
    {14182, "Makoa"},
    {14600, "Mal'Damba"},
    {33283, "Moji"},
    {31633, "Nyx"},
    {26882, "Octavia"},
    {32617, "Omen"},
    {10773, "Pip"},
    {24548, "Raum"},
    {27309, "Rei"},
    {14581, "Ruckus"},
    {27444, "Saati"},
    {16505, "Seris"},
    {14891, "Sha Lin"},
    {10762, "Skye"},
    {19108, "Strix"},
    {17127, "Talus"},
    {19433, "Terminus"},
    {24536, "Tiberius"},
    {19720, "Torvald"},
    {15201, "Tyra"},
    {27043, "Vatu"},
    {27783, "VII"},
    {14127, "Viktor"},
    {19710, "Vivian"},
    {25527, "Vora"},
    {16508, "Willo"},
    {26711, "Yagorath"},
    {13279, "Ying"},
    {17129, "Zhin"}
};

inline std::string GetCurrentChampionName() {
    if (Globals::LocalWeapon) {
        int championId = Globals::LocalWeapon->r_nDeviceId;
        auto it = championIdToName.find(championId);
        if (it != championIdToName.end()) {
            return it->second;
        }
    }
    return "";
}