@echo off
setlocal EnableDelayedExpansion
title PHAROAH Injector - Build
cd /d "%~dp0"

REM ===========================================================================
REM  PHAROAH INJECTOR - one-click build
REM
REM  JUST DOUBLE-CLICK THIS FILE. Nothing else needed.
REM
REM  You do NOT have to find the "x64 Native Tools Command Prompt" — this script
REM  locates your Visual Studio install with vswhere and sets up the compiler
REM  environment itself. That prompt is only a normal cmd window with some
REM  variables preset; this does the same thing automatically.
REM ===========================================================================

echo.
echo  ============================================
echo    PHAROAH INJECTOR - BUILD
echo  ============================================
echo.

REM ---- 1. locate Visual Studio ----
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" set "VSWHERE=%ProgramFiles%\Microsoft Visual Studio\Installer\vswhere.exe"

if not exist "%VSWHERE%" (
    echo  [X] Could not find vswhere.exe, so Visual Studio isn't detectable.
    echo.
    echo      Install "Visual Studio 2022 Community" and make sure the
    echo      "Desktop development with C++" workload is ticked.
    echo.
    pause
    exit /b 1
)

for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSPATH=%%i"

if not defined VSPATH (
    echo  [X] Visual Studio found, but the C++ tools are missing.
    echo.
    echo      Open "Visual Studio Installer" -^> Modify -^> Workloads
    echo      -^> tick "Desktop development with C++" -^> Modify.
    echo.
    pause
    exit /b 1
)

echo  [1/3] Visual Studio: !VSPATH!

REM ---- 2. set up the x64 compiler environment ----
set "VCVARS=!VSPATH!\VC\Auxiliary\Build\vcvars64.bat"
if not exist "!VCVARS!" (
    echo  [X] vcvars64.bat not found. The C++ x64 toolset may not be installed.
    pause
    exit /b 1
)

call "!VCVARS!" >nul 2>&1
if errorlevel 1 (
    echo  [X] Failed to initialise the compiler environment.
    pause
    exit /b 1
)
echo  [2/3] Compiler environment ready ^(x64^)

REM ---- 3. compile ----
REM /SUBSYSTEM:WINDOWS  = GUI app, no console window behind it
REM /MANIFESTUAC        = requests Administrator, so Windows shows the UAC prompt
REM                       automatically instead of you right-clicking Run as admin
echo  [3/3] Compiling...
echo.

REM Compile the icon into the exe first. Without this the ZIP shows a blank
REM default icon in Explorer, because a loose pharoah.ico next to the exe only
REM affects the window - not the file icon Windows draws in a folder.
if exist app.rc (
    rc /nologo /fo app.res app.rc
    if errorlevel 1 (
        echo    WARNING: rc failed - building without the embedded icon.
        set "ICONRES="
    ) else (
        set "ICONRES=app.res"
    )
) else (
    set "ICONRES="
)

REM /MT = STATIC C runtime. Without it the injector needs the VC++ redist
REM installed on the user machine; with it the exe has no runtime dependency at
REM all and runs on a clean Windows install. It is a small GUI app, so the size
REM cost is trivial and worth it for "it just works when they unzip it".
cl /nologo /EHsc /std:c++17 /O2 /W3 /MT /DUNICODE /D_UNICODE main.cpp ^
   /Fe:PharoahInjector.exe ^
   /link !ICONRES! user32.lib gdi32.lib comdlg32.lib advapi32.lib ^
   /SUBSYSTEM:WINDOWS ^
   /MANIFESTUAC:"level='requireAdministrator' uiAccess='false'"

if errorlevel 1 (
    echo.
    echo  ============================================
    echo    BUILD FAILED - see the errors above.
    echo  ============================================
    pause
    exit /b 1
)

if exist main.obj del main.obj >nul 2>&1

echo.
echo  ============================================
echo    BUILD OK  ^> PharoahInjector.exe
echo  ============================================
echo.
if exist pharoah.ico (
    echo    pharoah.ico found - window/taskbar icon will show.
) else (
    echo    NOTE: pharoah.ico missing, a default icon will be used.
)
echo.
echo    Next: start Paladins, GET INTO A MATCH, then run
echo    PharoahInjector.exe and press INJECT.
echo.
pause
