# PHAROAH — source

This is the complete source for PHAROAH, a client-side mod for Paladins on
Tempest. The licence requires that source ships with every copy, so here it is.

**You do not need any of this to USE PHAROAH.** Unzip, run the injector, done.
This folder is for people who want to read it, change it, or build it.

---

## What is here

```
OPENSOURCE/
    menus/          every tab. This is where 95% of the work is.
    UI/             Style.h — themes, Ink(), the colour system
    Utils/          SafeCalls, helpers, the TEB xor-key reader
    SDK/            the Paladins 8.1 SDK dump (the game's classes)
    ext/            ImGui, kiero, minhook, Detours
    main.cpp        DLL entry, the D3D11 present hook, the frame loop
    globals.h       the handful of global pointers everything reads
    CMakeLists.txt  the build
    injector/       the injector's own source
```

The file to start with is **`menus/RecoverySuite.h`**. It is the big one — it
hosts every tab, the render loop, the theme code and the safe-thread dispatch.
Almost everything else hangs off it.

---

## The one thing you must understand before changing anything

**Scripted calls must not run on the render thread.**

Anything that goes through `ProcessEvent` — `GetBoneLocation`, `StartFire`,
`SetDesaturation`, most SDK methods — has to be dispatched from
`RunSafeThreadSubsystems()`, which runs on the game's own script thread.
Calling them from `hkPresent` (the render hook) corrupts game object state and
crashes, sometimes immediately, sometimes minutes later.

The pattern used throughout: the render thread sets a `g_PendingSomething` flag,
and the safe thread does the work and clears it. If you add a feature that calls
into the game, follow that pattern or it will crash.

Raw field reads and writes (position, health, velocity, a float on a weapon) are
fine from either thread. It is specifically `ProcessEvent` that is not.

---

## Building

**Requirements**

- Windows 64-bit
- Visual Studio 2022 with "Desktop development with C++"
- CMake and Ninja (both ship with VS)
- The DirectX SDK (June 2010) — only for headers; the paths are in CMakeLists.txt

**Build the DLL**

```
cmake -S . -B out/build/x64-Release -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build out/build/x64-Release
```

Output: `out/build/x64-Release/bin/Talents.dll`

> **Build Release, not Debug, for anything you give to other people.**
> A Debug build links against `MSVCP140D.dll` / `ucrtbased.dll` /
> `VCRUNTIME140D.dll`. Those are the *debug* C runtime: Microsoft does not allow
> redistributing them and they only exist on machines with Visual Studio
> installed. A Debug DLL silently fails to load on a normal user's PC. This
> caught me — the first release ZIP shipped a Debug build and would have worked
> on exactly one computer in the world.

**Build the injector**

Double-click `injector/BUILD_ME.bat`. It locates Visual Studio itself with
vswhere, so you do not need the "x64 Native Tools" prompt.

---

## Platform

Windows only. This is a Windows DLL injected into a Windows game using
Windows APIs (`CreateRemoteThread`, `LoadLibraryW`, D3D11). It does not build or
run on macOS or Linux, and it does not work under Wine.

---

## Licence, in one line

Free, open source, keep the charity gate, keep the credit. Full terms in
`LICENSE.txt`. You can fork it and change it; you cannot sell it, close it, or
strip the charity gate out.

---

## If the code confuses you

It is heavily commented, deliberately — most comments explain *why* something is
the way it is, including the things that went wrong. Feel free to drop files
into an AI to help you read them; a good deal of it was written that way.

There is a Feature Ideas tab in the tool listing what I tried and never got
working, with enough detail to pick up. Start there if you want something to do.

— PRIMAL_MONKE
