#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include <Windows.h>

// ============================================================================
// SELF-HEAL  —  UTgBattleCheatManager heal + stat multipliers
//
// Why this is worth trying rather than the card route:
//   Other modders have demonstrably shown self-heal working on ANY champion.
//   That rules out a card-specific trick (cards are per-champion) and points at
//   a global function. The cheat manager has exactly that:
//
//     Heal(int)                        direct heal
//     SetHealth(int)                   absolute set
//     HealTarget(int)                  heal who you look at
//     SetAutoHealingMultiplier(float)  scales the game's OWN out-of-combat regen
//     SetDamageMultiplier(float)
//     SetGroundSpeedMultiplier(float)  the OFFICIAL speed multiplier
//     SetMana(int)
//
//   SetAutoHealingMultiplier is the most likely match for what people showed:
//   it doesn't inject health, it scales the regen the game already runs — so it
//   behaves legitimately, needs no card, and works on every champion.
//
//   The cheat manager is NOT blanket-gated: CardsTab records that
//   TestServerRequestCard works in real matches. So some of these may land.
//
// EVERYTHING HERE IS OFF/ONE-SHOT BY DEFAULT. Scripted calls, so they run on the
// safe (ProcessEvent) thread via ProcessPending, never from the render thread.
// ============================================================================
namespace SelfHeal {

    inline int   healAmount     = 500;
    inline int   setHealthValue = 2000;
    inline float autoHealMult   = 10.0f;
    inline float damageMult     = 1.0f;
    inline float speedMult      = 1.0f;
    inline int   manaValue      = 100;

    // Hold-key repeat — matches how this was described being used ("bind it to
    // caps lock, press and it starts self healing").
    inline bool  holdToHeal   = false;
    inline int   holdKey      = VK_CAPITAL;
    inline int   repeatMs     = 250;
    inline ULONGLONG g_LastHealMs = 0;

    // one-shot request flags, drained on the safe thread
    inline bool  g_DoHeal        = false;
    inline bool  g_DoSetHealth   = false;
    inline bool  g_DoHealTarget  = false;
    inline bool  g_DoAutoHeal    = false;
    inline bool  g_DoDamageMult  = false;
    inline bool  g_DoSpeedMult   = false;
    inline bool  g_DoSetMana     = false;

    inline char  g_Status[192] = "";
    inline int   g_HealthNow = -1, g_HealthMax = -1;
    inline int   g_HealsSent = 0;

    inline void Log(const char* what, bool ok) {
        int before = g_HealthNow;
        g_HealthNow = SafeCalls::ReadHealth(&g_HealthMax);
        wsprintfA(g_Status, "%s %s | health %d -> %d / %d",
                  ok ? "sent" : "FAILED", what, before, g_HealthNow, g_HealthMax);
    }

    // Safe (ProcessEvent) thread only — these are scripted calls.
    inline void ProcessPending() {
        g_HealthNow = SafeCalls::ReadHealth(&g_HealthMax);

        // hold-to-heal repeat
        if (holdToHeal && (GetAsyncKeyState(holdKey) & 0x8000)) {
            ULONGLONG now = GetTickCount64();
            if (now - g_LastHealMs > (ULONGLONG)repeatMs) {
                g_LastHealMs = now;
                if (SafeCalls::CheatHeal(healAmount)) g_HealsSent++;
                Log("Heal (hold)", true);
            }
        }

        if (g_DoHeal)       { g_DoHeal = false;       Log("Heal", SafeCalls::CheatHeal(healAmount)); g_HealsSent++; }
        if (g_DoSetHealth)  { g_DoSetHealth = false;  Log("SetHealth", SafeCalls::CheatSetHealth(setHealthValue)); }
        if (g_DoHealTarget) { g_DoHealTarget = false; Log("HealTarget", SafeCalls::CheatHealTarget(healAmount)); }
        if (g_DoAutoHeal)   { g_DoAutoHeal = false;   Log("SetAutoHealingMultiplier", SafeCalls::CheatAutoHealMult(autoHealMult)); }
        if (g_DoDamageMult) { g_DoDamageMult = false; Log("SetDamageMultiplier", SafeCalls::CheatDamageMult(damageMult)); }
        if (g_DoSpeedMult)  { g_DoSpeedMult = false;  Log("SetGroundSpeedMultiplier", SafeCalls::CheatGroundSpeedMult(speedMult)); }
        if (g_DoSetMana)    { g_DoSetMana = false;    Log("SetMana", SafeCalls::CheatSetMana(manaValue)); }
    }

    inline void DrawControls(bool inMatch) {
        ImGui::TextColored(Ink(ImVec4(0.5f, 1.0f, 0.6f, 1.0f)), "SELF-HEAL  (UTgBattleCheatManager)");
        ImGui::TextWrapped("Others have shown self-heal working on ANY champion, which rules out a "
            "card trick (cards are per-champion) and points at a global function. These are those "
            "functions. The cheat manager is not blanket-blocked - TestServerRequestCard already "
            "works in real matches - so some of these may land.");

        if (!inMatch) { ImGui::TextDisabled("Join a match first (needs a pawn)."); return; }

        ImGui::Separator();
        ImGui::Text("health: %d / %d      heals sent: %d", g_HealthNow, g_HealthMax, g_HealsSent);
        ImGui::TextColored(Ink(ImVec4(1.0f, 1.0f, 0.5f, 1.0f)), "%s", g_Status);

        // ---- the most promising one first ----
        if (ImGui::CollapsingHeader("AUTO-HEAL MULTIPLIER  (most likely the real one)",
                                    ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::TextWrapped("Scales the game's OWN out-of-combat regen instead of injecting "
                "health. No card needed, works on any champion, and behaves like normal regen - "
                "which is exactly what people demonstrated. Try 10, then higher.");
            ImGui::SetNextItemWidth(140);
            ImGui::InputFloat("multiplier", &autoHealMult);
            if (ImGui::Button("APPLY AUTO-HEAL MULT", ImVec2(240, 28))) g_DoAutoHeal = true;
            ImGui::SameLine();
            if (ImGui::Button("reset to 1x", ImVec2(110, 28))) { autoHealMult = 1.0f; g_DoAutoHeal = true; }
        }

        if (ImGui::CollapsingHeader("DIRECT HEAL")) {
            ImGui::SetNextItemWidth(140);
            ImGui::InputInt("heal amount", &healAmount);
            if (ImGui::Button("HEAL ME NOW", ImVec2(180, 26))) g_DoHeal = true;
            ImGui::SameLine();
            if (ImGui::Button("HEAL MY TARGET", ImVec2(180, 26))) g_DoHealTarget = true;
            ImGui::Separator();
            ImGui::Checkbox("hold key to keep healing", &holdToHeal);
            ImGui::SameLine();
            ImGui::SetNextItemWidth(110);
            ImGui::InputInt("repeat ms", &repeatMs);
            ImGui::TextDisabled("Default key: CAPS LOCK. Hold it while this is ticked.");
        }

        if (ImGui::CollapsingHeader("SET HEALTH (absolute)")) {
            ImGui::SetNextItemWidth(140);
            ImGui::InputInt("health value", &setHealthValue);
            if (ImGui::Button("SET HEALTH", ImVec2(180, 26))) g_DoSetHealth = true;
            ImGui::TextDisabled("Most likely to be server-corrected - try it, but expect a snap back.");
        }

        if (ImGui::CollapsingHeader("OTHER MULTIPLIERS (bonus)")) {
            ImGui::SetNextItemWidth(140);
            ImGui::InputFloat("damage mult", &damageMult);
            ImGui::SameLine();
            if (ImGui::Button("APPLY damage", ImVec2(150, 24))) g_DoDamageMult = true;

            ImGui::SetNextItemWidth(140);
            ImGui::InputFloat("ground speed mult", &speedMult);
            ImGui::SameLine();
            if (ImGui::Button("APPLY speed", ImVec2(150, 24))) g_DoSpeedMult = true;
            ImGui::TextWrapped("This is the OFFICIAL speed multiplier. Speeden writes GroundSpeed "
                "raw and the server rejects it - this asks the game to apply it instead, which may "
                "behave completely differently. Worth a try.");

            ImGui::SetNextItemWidth(140);
            ImGui::InputInt("mana", &manaValue);
            ImGui::SameLine();
            if (ImGui::Button("SET mana", ImVec2(150, 24))) g_DoSetMana = true;
        }

        ImGui::Separator();
        ImGui::TextWrapped("WHAT TO REPORT: for each button, does the health number change, and does "
            "it HOLD or snap back? The status line shows health before -> after.");
    }
}
