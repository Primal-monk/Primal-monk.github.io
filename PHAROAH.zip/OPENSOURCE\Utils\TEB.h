#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include <Windows.h>
#include "ntapi.h"

extern HMODULE moduleBase;
extern uintptr_t xorKey;

uintptr_t GetXorKey(size_t index);