#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include "Utils/SafeCalls.h"
#include <Windows.h>
#include <shellapi.h>
#include <cstring>
#include <cstdio>

#pragma comment(lib, "shell32.lib")

// ============================================================================
// CHARITY GATE
// ============================================================================
// PHAROAH stays free. EVERYTHING works in the SHOOTING RANGE with no code and
// no payment — that is where people learn the tool. The gate only applies in a
// REAL MATCH, where the same features affect other players.
//
// The flow, as decided:
//   1. User donates $5+ to a UN charity (UNRWA or UNICEF, linked below).
//   2. User posts a screenshot in the PHAROAH Discord.
//   3. User is given the code, types it in here, and the whole tool unlocks.
//
// There is also an honour-system shortcut: "I already donated" reveals the code
// in-tool. That is deliberate. This cannot be enforced from a DLL and pretending
// otherwise would only punish honest people while stopping nobody — the code is
// plain text in the binary either way.
//
// UNLOCK PERSISTS across sessions and across versions. It is written next to
// the DLL so a rebuild does not re-lock a user who already donated. Deleting
// that file re-locks.
//
// WHAT IS GATED (in real matches only):
//   - full-rate behaviour for everything. Locked users still get the tool, but
//     the aggressive parts run on a throttle (see kLockedThrottle) instead of
//     being outright removed, so the free version is genuinely usable.
// ============================================================================

namespace Gating {

    // ========================================================================
    // MASTER KILL SWITCH — the gate is currently DISABLED.
    // ========================================================================
    // false = nothing is ever gated. The whole tool works everywhere, out of the
    //         gate, with no code. The tab stays visible so the flow can still be
    //         seen and tested, and the MENU / RANGE / MATCH detector keeps
    //         running because it is useful on its own.
    // true  = the gate is live again.
    //
    // Flip this ONE line to re-enable. Nothing else needs to change: every
    // enforcement point already routes through Allowed() / IsBlocking() /
    // RepeatInterval() below.
    // BACK ON FOR RELEASE.
    //
    // This was switched off during development so testing did not need a code
    // every session. Shipping with it off would mean shipping with no charity
    // gate at all, which is the one thing the licence says must stay.
    // ========================================================================
    // THE GATE IS OFF. NOTHING IS LOCKED. THIS IS DELIBERATE.
    // ========================================================================
    // Locking features behind a donation was the original idea and it did not
    // work out:
    //
    //   - people route around a client-side lock in minutes; it only ever
    //     inconvenienced the honest ones
    //   - it made the tool feel broken - you press a button, nothing happens,
    //     and nothing tells you why
    //   - it drew accusations of running a scam, which is the opposite of the
    //     point
    //
    // So the charity tab stays, the donation links stay, and the ask stays -
    // but it is an ASK, not a toll. Give if you want to give.
    //
    // Everything below (Allowed / IsBlocking / the per-group flags) is left in
    // place and simply always answers "allowed". It costs nothing to keep and
    // means the decision is one line, not a rewrite, if it ever changes back.
    inline constexpr bool kGateEnabled = false;

    // ---- The unlock code -------------------------------------------------
    inline const char* kCode = "SingleUse-01AA";

    // Charity links shown in the tab.
    inline const char* kUrlUnrwa   = "https://www.unrwa.org/";
    inline const char* kUrlUnicef  = "https://www.unicefusa.org";
    inline const char* kUrlDiscord = "https://discord.gg/WNtne3YauG";

    // While LOCKED and in a real match, repeat-fire effects run at this interval
    // instead of their real one. Octavia shields being the worked example: 1.2s
    // locked vs 0.06s unlocked.
    inline const float kLockedThrottle = 1.2f;
    inline const float kUnlockedRate   = 0.06f;

    // ---- Where are we? ---------------------------------------------------
    enum class State {
        Unknown,        // no controller yet, or the read faulted
        Menu,           // no pawn — lobby, loading, main menu
        ShootingRange,  // NM_Standalone: we are the server. Never gated.
        RealMatch       // NM_Client: a real server owns replication. Gated.
    };

    inline State  g_State         = State::Unknown;
    inline int    g_LastNetMode   = -1;
    inline bool   g_Unlocked      = false;   // false = gated. This is the default.
    inline bool   g_Loaded        = false;
    inline bool   g_ShowCode      = false;   // "I already donated" was clicked
    inline char   g_CodeInput[64] = { 0 };
    inline char   g_LastMessage[192] = { 0 };
    inline bool   g_LastAttemptFailed = false;

    // ---- Persistence -----------------------------------------------------
    // Stored next to the DLL rather than in the game folder, so it survives a
    // game update. A rebuild of the DLL does NOT clear it — that is the point.
    inline const char* UnlockFilePath() {
        static char path[MAX_PATH] = { 0 };
        if (path[0]) return path;
        HMODULE self = nullptr;
        GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)&UnlockFilePath, &self);
        if (self && GetModuleFileNameA(self, path, MAX_PATH)) {
            char* slash = std::strrchr(path, '\\');
            if (slash) { slash[1] = 0; std::strcat(path, "pharoah_gate.dat"); return path; }
        }
        std::strcpy(path, "pharoah_gate.dat");
        return path;
    }

    inline void SaveUnlock() {
        FILE* f = nullptr;
        if (fopen_s(&f, UnlockFilePath(), "wb") == 0 && f) {
            std::fputs("PHAROAH_GATE_UNLOCKED_V1", f);
            std::fclose(f);
        }
    }

    inline void ClearUnlock() {
        DeleteFileA(UnlockFilePath());
    }

    inline void LoadUnlockOnce() {
        if (g_Loaded) return;
        g_Loaded = true;
        FILE* f = nullptr;
        if (fopen_s(&f, UnlockFilePath(), "rb") == 0 && f) {
            char buf[64] = { 0 };
            size_t n = std::fread(buf, 1, sizeof(buf) - 1, f);
            std::fclose(f);
            if (n > 0 && std::strstr(buf, "PHAROAH_GATE_UNLOCKED_V1")) g_Unlocked = true;
        }
    }

    // Called once per frame from the main render path, before anything draws.
    inline void Poll(bool inMatch) {
        LoadUnlockOnce();

        int mode = -1;
        if (!SafeCalls::TryReadNetMode(&mode)) {
            g_State = State::Unknown;
            g_LastNetMode = -1;
            return;
        }
        g_LastNetMode = mode;

        // No pawn means we are not in a playable world yet, whatever the net
        // mode claims. inMatch is the caller's existing pawn-based check.
        if (!inMatch || !Globals::LocalPawn) {
            g_State = State::Menu;
            return;
        }

        switch (mode) {
            case 0:  g_State = State::ShootingRange; break;  // NM_Standalone
            case 2:  g_State = State::ShootingRange; break;  // NM_ListenServer — still our authority
            case 3:  g_State = State::RealMatch;     break;  // NM_Client
            default: g_State = State::Unknown;       break;
        }
    }

    inline const char* StateName() {
        switch (g_State) {
            case State::Menu:          return "MENU";
            case State::ShootingRange: return "SHOOTING RANGE";
            case State::RealMatch:     return "REAL MATCH";
            default:                   return "UNKNOWN";
        }
    }

    inline ImVec4 StateColor() {
        switch (g_State) {
            case State::Menu:          return ImVec4(0.65f, 0.68f, 0.72f, 1.0f);
            case State::ShootingRange: return ImVec4(0.40f, 1.00f, 0.50f, 1.0f);
            case State::RealMatch:     return ImVec4(1.00f, 0.72f, 0.30f, 1.0f);
            default:                   return ImVec4(0.85f, 0.55f, 0.55f, 1.0f);
        }
    }

    // ---- THE ONE QUESTION EVERY GATED FEATURE ASKS -----------------------
    // "Am I allowed to run at full strength right now?"
    // Range and menu: always yes. Real match: only once unlocked.
    inline bool Allowed() {
        if (!kGateEnabled) return true;          // gate disabled — nothing is held back
        if (g_State == State::RealMatch) return g_Unlocked;
        return true;
    }

    // ------------------------------------------------------------------------
    // PER-TAB GATING
    // ------------------------------------------------------------------------
    // The gate used to be all-or-nothing: locked meant Fire Modes and Leave were
    // held back and nothing else was. That was never the intent - some tabs are
    // pure overlay (boxes, reticle, themes) and gating them is pointless, while
    // others genuinely are the payoff.
    //
    // So gating is now per FEATURE GROUP, and the GATING tab shows exactly which
    // groups are covered. Anything not listed is free, always. Keeping the list
    // visible in the UI matters: a charity gate that quietly grows to cover
    // everything is just a paywall with extra steps.
    enum class Gated {
        FireModes,     // fire-mode switching and the confirmed exploits
        Cards,         // the device sweep / card firing
        Skins,         // mesh swapping
        Octavia,       // shield stacking
        Leave,         // leave-match
        COUNT
    };

    inline bool g_GateGroup[(int)Gated::COUNT] = {
        true,    // FireModes - the flagship
        true,    // Cards     - the thing that took longest to crack
        false,   // Skins     - cosmetic, and half-working; not worth gating
        true,    // Octavia   - shield stacking is strong
        false,   // Leave     - never gate the way out of a match
    };

    inline const char* GatedName(Gated g) {
        switch (g) {
            case Gated::FireModes: return "Fire Modes + exploits";
            case Gated::Cards:     return "Cards (device sweep)";
            case Gated::Skins:     return "Skins";
            case Gated::Octavia:   return "OCTAVIA shield stack";
            case Gated::Leave:     return "Leave match";
            default:               return "?";
        }
    }

    // True when the gate is actively holding something back.
    inline bool IsBlocking() {
        if (!kGateEnabled) return false;
        return (g_State == State::RealMatch) && !g_Unlocked;
    }

    // Is THIS group being held back right now?
    inline bool IsBlockingGroup(Gated g) {
        if ((int)g < 0 || (int)g >= (int)Gated::COUNT) return false;
        return IsBlocking() && g_GateGroup[(int)g];
    }

    inline bool AllowedGroup(Gated g) { return !IsBlockingGroup(g); }

    // For repeat-fire features (Octavia shields, heal trigger): how often may
    // this fire right now, in seconds. Locked real matches get the slow rate;
    // everywhere else gets the real one.
    inline float RepeatInterval() {
        return IsBlocking() ? kLockedThrottle : kUnlockedRate;   // full rate while disabled
    }

    inline bool VerifyCode(const char* entered) {
        return entered && std::strcmp(entered, kCode) == 0;
    }

    inline void TryUnlock() {
        if (VerifyCode(g_CodeInput)) {
            g_Unlocked = true;
            g_LastAttemptFailed = false;
            SaveUnlock();
            std::strcpy(g_LastMessage, "Unlocked, and saved. This stays unlocked on future versions.");
            std::memset(g_CodeInput, 0, sizeof(g_CodeInput));
        } else {
            g_LastAttemptFailed = true;
            std::strcpy(g_LastMessage, "That code was not accepted. Check for stray spaces.");
        }
    }

    inline void OpenUrl(const char* url) {
        ShellExecuteA(nullptr, "open", url, nullptr, nullptr, SW_SHOWNORMAL);
    }

    // ---- Compact status line, drawn in the window header -----------------
    inline void DrawStatusLine() {
        ImGui::TextUnformatted("STATE:");
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Text, StateColor());
        ImGui::TextUnformatted(StateName());
        ImGui::PopStyleColor();

        ImGui::SameLine();
        ImGui::TextUnformatted("   GATE:");
        ImGui::SameLine();
        if (g_Unlocked) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.40f, 1.00f, 0.50f, 1.0f)));
            ImGui::TextUnformatted("UNLOCKED");
        } else if (g_State == State::RealMatch) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.00f, 0.55f, 0.45f, 1.0f)));
            ImGui::TextUnformatted("LOCKED (real match)");
        } else if (!kGateEnabled) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.70f, 0.80f, 0.90f, 1.0f)));
            ImGui::TextUnformatted("DISABLED");
        } else {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.70f, 0.80f, 0.90f, 1.0f)));
            ImGui::TextUnformatted("not required here");
        }
        ImGui::PopStyleColor();

        if (g_LastNetMode >= 0) {
            ImGui::SameLine();
            ImGui::TextDisabled("   (NetMode %d)", g_LastNetMode);
        }
    }

    // A banner for gated tabs to drop at the top of themselves.
    // Group-aware banner. The old all-or-nothing DrawBlockedBanner() below is
    // kept and now simply forwards, so existing callers keep working.
    inline void DrawBlockedBannerFor(Gated g) {
        if (!IsBlockingGroup(g)) return;
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.00f, 0.72f, 0.30f, 1.0f)));
        ImGui::TextWrapped("%s is LOCKED in real matches. Free in the shooting range. "
            "To unlock it in a real match, see the GATING tab.", GatedName(g));
        ImGui::PopStyleColor();
        ImGui::Separator();
        ImGui::Spacing();
    }

    inline void DrawBlockedBanner() {
        if (!IsBlocking()) return;
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.00f, 0.72f, 0.30f, 1.0f)));
        ImGui::TextWrapped("LOCKED IN REAL MATCHES. Free to use in the shooting range. "
            "To use it in a real match, unlock in the GATING tab.");
        ImGui::PopStyleColor();
        ImGui::Separator();
        ImGui::Spacing();
    }

    // ---- The tab ---------------------------------------------------------
    inline void DrawControls(bool /*inMatch*/) {
        LoadUnlockOnce();

        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("CHARITY GATE");
        ImGui::PopStyleColor();
        ImGui::Separator();
        ImGui::Spacing();

        // EXACTLY what the gate covers, in plain sight. Everything not ticked
        // here is free forever, in every match, unlocked or not.
        if (ImGui::CollapsingHeader("What the gate actually covers")) {
            ImGui::TextWrapped("Only these are held back in real matches. Everything else - "
                "boxes, skeletons, the reticle, themes, notes, the whole DEV section - is free "
                "and always was.");
            ImGui::Spacing();
            for (int i = 0; i < (int)Gated::COUNT; ++i) {
                ImGui::Bullet();
                if (g_GateGroup[i]) {
                    ImGui::TextColored(Ink(ImVec4(1.00f, 0.72f, 0.30f, 1.0f)),
                                       "%s", GatedName((Gated)i));
                } else {
                    ImGui::TextDisabled("%s  -  free, not gated", GatedName((Gated)i));
                }
            }
            ImGui::Spacing();
            ImGui::TextDisabled("The list lives in Gating.h. It is open source: you can see it, "
                                "and you can change it.");
        }
        ImGui::Spacing();

        if (!kGateEnabled) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.40f, 1.00f, 0.50f, 1.0f)));
            ImGui::TextWrapped("GATE IS CURRENTLY DISABLED. The full tool works everywhere, out of "
                "the gate, with no code needed. Nothing below is being enforced - it is kept "
                "visible so the flow can be tested.");
            ImGui::PopStyleColor();
            ImGui::TextDisabled("Nothing in PHAROAH is locked. This tab is an ask, not a toll.");
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();
        }
        ImGui::TextWrapped("PHAROAH is free. Everything works in the SHOOTING RANGE with no code "
            "and no payment. The gate only applies in a REAL MATCH.");
        ImGui::Spacing();

        // ---- live state ----
        ImGui::TextUnformatted("Current state:");
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Text, StateColor());
        ImGui::TextUnformatted(StateName());
        ImGui::PopStyleColor();

        if (g_State == State::RealMatch && !g_Unlocked) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.00f, 0.72f, 0.30f, 1.0f)));
            ImGui::TextWrapped("Real match, gate closed. Repeat effects run at %.2fs instead of "
                "%.2fs, and gated features hold off.", kLockedThrottle, kUnlockedRate);
            ImGui::PopStyleColor();
        } else if (g_State == State::ShootingRange) {
            ImGui::TextWrapped("You are the server here, so nothing is gated. Full tool.");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        if (g_Unlocked) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(0.40f, 1.00f, 0.50f, 1.0f)));
            ImGui::TextUnformatted("GATE OPEN  -  FULL TOOL");
            ImGui::PopStyleColor();
            ImGui::TextWrapped("Thank you. This is saved next to the DLL and stays unlocked on "
                "future versions.");
            ImGui::Spacing();
            if (ImGui::Button("Re-lock (for testing)", ImVec2(240, 28))) {
                g_Unlocked = false;
                g_ShowCode = false;
                g_LastAttemptFailed = false;
                ClearUnlock();
                std::strcpy(g_LastMessage, "Re-locked and the saved unlock was deleted.");
            }
        } else {
            // ---- step 1: donate ----
            ImGui::TextWrapped("Donate $5, or more if you like, to any UN charity such as the two "
                "linked below, then send a screenshot in the Discord and you will be given the "
                "code.");
            ImGui::Spacing();

            if (ImGui::Button("UNRWA", ImVec2(150, 34)))  OpenUrl(kUrlUnrwa);
            ImGui::SameLine();
            if (ImGui::Button("UNICEF", ImVec2(150, 34))) OpenUrl(kUrlUnicef);
            ImGui::SameLine();
            if (ImGui::Button("PHAROAH Discord", ImVec2(190, 34))) OpenUrl(kUrlDiscord);

            ImGui::Spacing();
            ImGui::TextDisabled("Donate to charity, then DM me a confirmation in the Discord");
            ImGui::TextDisabled("to receive a code to unlock the charity gate.");

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();

            // ---- step 2: the honour-system shortcut ----
            if (!g_ShowCode) {
                if (ImGui::Button("I already donated to charity", ImVec2(280, 30))) {
                    g_ShowCode = true;
                }
                ImGui::SameLine();
                ImGui::TextDisabled("(shows the code — honour system)");
            } else {
                ImGui::TextWrapped("This is an honour system. If you have not donated to charity, "
                    "please do - any amount you want. Nothing checks up on you; the only thing "
                    "stopping this being empty is you.");
                ImGui::Spacing();
                ImGui::TextUnformatted("Your code:");
                ImGui::SameLine();
                ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
                ImGui::TextUnformatted(kCode);
                ImGui::PopStyleColor();
                ImGui::SameLine();
                if (ImGui::SmallButton("Copy")) ImGui::SetClipboardText(kCode);
                ImGui::TextDisabled("Type it in below to unlock. It is not filled in for you on "
                                    "purpose.");
            }

            ImGui::Spacing();

            // ---- step 3: enter it ----
            ImGui::TextUnformatted("Enter your unlock code:");
            ImGui::SetNextItemWidth(300);
            bool submitted = ImGui::InputText("##GateCode", g_CodeInput, sizeof(g_CodeInput),
                                              ImGuiInputTextFlags_EnterReturnsTrue);
            ImGui::SameLine();
            if (ImGui::Button("Unlock", ImVec2(110, 0)) || submitted) {
                TryUnlock();
            }
        }

        if (g_LastMessage[0]) {
            ImGui::Spacing();
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(g_LastAttemptFailed
                                                     ? ImVec4(1.00f, 0.55f, 0.45f, 1.0f)
                                                     : ImVec4(0.40f, 1.00f, 0.50f, 1.0f)));
            ImGui::TextWrapped("%s", g_LastMessage);
            ImGui::PopStyleColor();
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        if (ImGui::CollapsingHeader("What the gate covers")) {
            ImGui::TextWrapped("Gated in real matches:");
            ImGui::BulletText("Fire Modes - primary fire swaps");
            ImGui::BulletText("Repeat-fire effects run at %.2fs instead of %.2fs", kLockedThrottle, kUnlockedRate);
            ImGui::Spacing();
            ImGui::TextWrapped("Never gated, anywhere:");
            ImGui::BulletText("Everything in the shooting range");
            ImGui::BulletText("Cosmetic-only tools (themes, crosshair, colour grading)");
            ImGui::Spacing();
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.6f, 0.4f, 1.0f)));
            ImGui::TextWrapped("DRAFT SCOPE: only Fire Modes reads the gate so far. Other tabs "
                "still need Gating::Allowed() / Gating::RepeatInterval() wired in - the mechanism "
                "is done, the per-tab enforcement is not.");
            ImGui::PopStyleColor();
        }

        if (ImGui::CollapsingHeader("Honest note on the code")) {
            ImGui::TextWrapped("The code is compiled into the DLL in plain text, and this tab will "
                "show it to anyone who clicks the button. That is deliberate: a DLL cannot verify "
                "a donation, so any 'real' lock would only inconvenience honest people while "
                "stopping nobody. This is an honour system with a speed bump. Real enforcement "
                "would need a server that issues and validates per-user codes.");
            ImGui::Spacing();
            ImGui::TextWrapped("Unlock file: %s", UnlockFilePath());
        }
    }
}
