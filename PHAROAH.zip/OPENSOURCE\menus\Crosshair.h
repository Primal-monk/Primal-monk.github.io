#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme

// ============================================================================
// CUSTOM CROSSHAIR — parity with Anubis's "HUD Customization - Custom Crosshairs
// (Cross + Dot)"
//
// WHY THIS IS THE SAFEST FEATURE IN THE WHOLE TOOL:
// It does not touch the game. At all. No fields, no RPCs, no scripted calls, no
// pawn, no controller. It draws shapes onto the ImGui foreground draw list at the
// centre of the screen. There is nothing for the server to validate and nothing
// to reject, so unlike speed or fire rate there is no "works in the range, fails
// in a match" failure mode possible here. It either renders or it doesn't.
//
// It also cannot crash the game the way the bone/skeleton work could, because it
// never dereferences a game object — so no __try guards are needed anywhere in
// this file. That absence is deliberate, not an oversight.
//
// FOREGROUND vs BACKGROUND DRAW LIST:
// The boxes/ESP use GetBackgroundDrawList so they sit behind the menu. A
// crosshair must sit ON TOP of the game's own HUD, so this uses the foreground
// list. The menu window still draws above it, which is correct — you want to see
// the controls you're adjusting.
// ============================================================================

namespace Crosshair {

    enum class Style { CrossAndDot = 0, CrossOnly, DotOnly, Circle, TShape, XShape };

    inline bool  enabled = false;
    inline int   style = (int)Style::CrossAndDot;

    inline float length = 10.0f;      // arm length in pixels
    inline float gap = 4.0f;          // centre gap before each arm starts
    inline float thickness = 2.0f;
    inline float dotRadius = 2.0f;
    inline float circleRadius = 12.0f;

    inline bool  outline = true;      // black edge, so it stays visible on any map
    inline float outlineThickness = 1.0f;

    inline float colorRGBA[4] = { 0.15f, 1.0f, 0.45f, 1.0f };

    // Manual nudge, because "centre of the viewport" is not always where the game
    // actually aims — ultrawide and letterboxed resolutions can differ.
    inline float offsetX = 0.0f;
    inline float offsetY = 0.0f;

    inline void DrawLineOutlined(ImDrawList* d, ImVec2 a, ImVec2 b, ImU32 col, ImU32 oCol) {
        if (outline) {
            // Drawn first and thicker, so the coloured line lands on top of it.
            d->AddLine(a, b, oCol, thickness + outlineThickness * 2.0f);
        }
        d->AddLine(a, b, col, thickness);
    }

    inline void Render() {
        if (!enabled) return;

        ImGuiIO& io = ImGui::GetIO();
        if (io.DisplaySize.x <= 0.0f || io.DisplaySize.y <= 0.0f) return;

        ImDrawList* d = ImGui::GetForegroundDrawList();
        if (!d) return;

        const float cx = io.DisplaySize.x * 0.5f + offsetX;
        const float cy = io.DisplaySize.y * 0.5f + offsetY;

        const ImU32 col = ImGui::ColorConvertFloat4ToU32(
            ImVec4(colorRGBA[0], colorRGBA[1], colorRGBA[2], colorRGBA[3]));
        const ImU32 oCol = ImGui::ColorConvertFloat4ToU32(
            ImVec4(0.0f, 0.0f, 0.0f, colorRGBA[3]));

        const Style s = (Style)style;
        const bool wantCross = (s == Style::CrossAndDot || s == Style::CrossOnly || s == Style::TShape);
        const bool wantDot   = (s == Style::CrossAndDot || s == Style::DotOnly);

        if (wantCross) {
            // Left / right arms
            DrawLineOutlined(d, ImVec2(cx - gap - length, cy), ImVec2(cx - gap, cy), col, oCol);
            DrawLineOutlined(d, ImVec2(cx + gap, cy), ImVec2(cx + gap + length, cy), col, oCol);
            // Bottom arm always; top arm suppressed for the T shape, which is the
            // point of a T reticle — it keeps the area above the aim point clear.
            DrawLineOutlined(d, ImVec2(cx, cy + gap), ImVec2(cx, cy + gap + length), col, oCol);
            if (s != Style::TShape) {
                DrawLineOutlined(d, ImVec2(cx, cy - gap - length), ImVec2(cx, cy - gap), col, oCol);
            }
        }

        if (s == Style::XShape) {
            const float k = 0.7071f;   // cos/sin 45deg, so diagonal arms match `length`
            const float g = gap * k, l = (gap + length) * k;
            DrawLineOutlined(d, ImVec2(cx - l, cy - l), ImVec2(cx - g, cy - g), col, oCol);
            DrawLineOutlined(d, ImVec2(cx + g, cy + g), ImVec2(cx + l, cy + l), col, oCol);
            DrawLineOutlined(d, ImVec2(cx - l, cy + l), ImVec2(cx - g, cy + g), col, oCol);
            DrawLineOutlined(d, ImVec2(cx + g, cy - g), ImVec2(cx + l, cy - l), col, oCol);
        }

        if (s == Style::Circle) {
            if (outline) d->AddCircle(ImVec2(cx, cy), circleRadius, oCol, 48, thickness + outlineThickness * 2.0f);
            d->AddCircle(ImVec2(cx, cy), circleRadius, col, 48, thickness);
        }

        if (wantDot) {
            if (outline) d->AddCircleFilled(ImVec2(cx, cy), dotRadius + outlineThickness, oCol, 24);
            d->AddCircleFilled(ImVec2(cx, cy), dotRadius, col, 24);
        }
    }

    inline void DrawControls() {
        ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.6f, 1.0f)), "CUSTOM CROSSHAIR");
        ImGui::TextWrapped("Pure overlay drawing - it never touches a game object, so there is "
            "nothing for the server to reject and nothing that can crash. Works everywhere, "
            "including the menu and the shooting range.");
        ImGui::Separator();

        ImGui::Checkbox("Enable custom crosshair", &enabled);

        const char* styles[] = { "Cross + Dot", "Cross only", "Dot only", "Circle", "T shape", "X shape" };
        ImGui::Combo("Style", &style, styles, IM_ARRAYSIZE(styles));

        ImGui::ColorEdit4("Colour", colorRGBA, ImGuiColorEditFlags_AlphaBar);

        const Style s = (Style)style;
        if (s == Style::CrossAndDot || s == Style::CrossOnly || s == Style::TShape || s == Style::XShape) {
            ImGui::SliderFloat("Arm length", &length, 1.0f, 60.0f, "%.0f px");
            ImGui::SliderFloat("Centre gap", &gap, 0.0f, 30.0f, "%.0f px");
        }
        if (s == Style::Circle) {
            ImGui::SliderFloat("Circle radius", &circleRadius, 2.0f, 60.0f, "%.0f px");
        }
        if (s == Style::CrossAndDot || s == Style::DotOnly) {
            ImGui::SliderFloat("Dot radius", &dotRadius, 0.5f, 12.0f, "%.1f px");
        }
        ImGui::SliderFloat("Thickness", &thickness, 1.0f, 8.0f, "%.1f px");

        ImGui::Checkbox("Black outline", &outline);
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("Keeps the crosshair readable on bright maps and pale walls.");
        }
        if (outline) ImGui::SliderFloat("Outline width", &outlineThickness, 0.5f, 4.0f, "%.1f px");

        if (ImGui::TreeNode("Centre offset")) {
            ImGui::TextWrapped("The exact centre of the viewport is not always where the game aims - "
                "ultrawide and letterboxed resolutions can differ. Nudge it here if it sits off "
                "from the game's own reticle.");
            ImGui::SliderFloat("Offset X", &offsetX, -60.0f, 60.0f, "%.0f px");
            ImGui::SliderFloat("Offset Y", &offsetY, -60.0f, 60.0f, "%.0f px");
            if (ImGui::Button("Reset offset")) { offsetX = 0.0f; offsetY = 0.0f; }
            ImGui::TreePop();
        }

        ImGui::Separator();
        ImGui::TextDisabled("Tip: hide the game's own crosshair in Paladins' settings");
        ImGui::TextDisabled("if you want only this one visible.");
    }
}
