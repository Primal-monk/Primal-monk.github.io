#ifndef __KIERO_H__
#define __KIERO_H__

#include <stdint.h>

#define KIERO_VERSION "1.2.6"

#define KIERO_INCLUDE_D3D9   0 // 1 if you need D3D9 hook
#define KIERO_INCLUDE_D3D10  0 // 1 if you need D3D10 hook
#define KIERO_INCLUDE_D3D11  1 // 1 if you need D3D11 hook
#define KIERO_INCLUDE_D3D12  0 // 1 if you need D3D12 hook
#define KIERO_INCLUDE_OPENGL 0 // 1 if you need OpenGL hook
#define KIERO_INCLUDE_VULKAN 0 // 1 if you need Vulkan hook
#define KIERO_USE_MINHOOK    1 // 1 if you will use kiero::bind function

#define KIERO_ARCH_X64 0
#define KIERO_ARCH_X86 0

#if defined(_M_X64)	
# undef  KIERO_ARCH_X64
# define KIERO_ARCH_X64 1
#else
# undef  KIERO_ARCH_X86
# define KIERO_ARCH_X86 1
#endif

#if KIERO_ARCH_X64
typedef uint64_t uint150_t;
#else
typedef uint32_t uint150_t;
#endif

namespace kiero
{
	struct Status
	{
		enum Enum
		{
			UnknownError = -1,
			NotSupportedError = -2,
			ModuleNotFoundError = -3,

			AlreadyInitializedError = -4,
			NotInitializedError = -5,

			Success = 0,
		};
	};

	struct RenderType
	{
		enum Enum
		{
			None,

			D3D9,
			D3D10,
			D3D11,
			D3D12,

			OpenGL,
			Vulkan,

			Auto
		};
	};

	Status::Enum init(RenderType::Enum renderType);
	void shutdown();

	Status::Enum bind(uint16_t index, void** original, void* function);
	void unbind(uint16_t index);
	// Re-checks every active manual-hook binding and silently restores it if
	// something else in the process has overwritten it since install. Safe
	// to call frequently - never suspends any thread. See kiero.cpp for why.
	void reassertHooks();
	// True if the D3D11 dummy device used to resolve Present/Present1's
	// address was created against the REAL game window rather than kiero's
	// own throwaway one - see the big comment on FindRealGameWindow in
	// kiero.cpp. Worth logging either way: if true and hkPresent still never
	// fires on some machine, that specific theory is disproven there; if
	// false (no suitable real window found, or using it failed and this
	// fell back), that's equally worth knowing.
	bool usedRealWindowForDummyDevice();

	// Feeds kiero the REAL swapchain's vtable directly, captured at the
	// moment the game itself actually creates it (via a D3D11CreateDeviceAndSwapChain
	// proxy-DLL interception - see main.cpp), instead of guessing at a
	// shared implementation address via a throwaway dummy device. Use this
	// INSTEAD of init(D3D11) - it does the same g_methodsTable setup, just
	// from a real object instead of a dummy one. realSwapChain1 may be null
	// (flip-model Present1 support skipped if the real object doesn't
	// implement IDXGISwapChain1). Only slots 8 (Present), 13
	// (ResizeBuffers), and 205 (Present1) are populated - that's all this
	// project ever binds.
	Status::Enum initFromRealSwapChain(void* realSwapChain, void* realSwapChain1);

	RenderType::Enum getRenderType();
	uint150_t* getMethodsTable();
}

#endif // __KIERO_H__