#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"

#include <algorithm>
#include "../Utils/EquipHandler.h"
#include "Utils/Settings.h"

void RenderEquipEmoteMenu()
{
    SDK::UUIScene* scene = Globals::containsScene(SDK::UUIRadialMenuEquip::StaticClass());
    if (scene == nullptr) return;

    auto* radialMenuScene = static_cast<SDK::UUIScene_UIRadialMenuEquip*>(scene);
    if (!radialMenuScene) return;
    if (!radialMenuScene->m_bEquipEmote) return;

    InitializeEmotes();

    static char         searchBuffer[128] = "";
    static int          selectedIndex     = -1;
    static std::string  championFilter    = "";

    ImGui::SetNextWindowPos(ImVec2(15, 15), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(420, 450), ImGuiCond_FirstUseEver);

    if (!ImGui::Begin("Equip Emote", nullptr,
        ImGuiWindowFlags_NoScrollbar))
    {
        ImGui::End();
        return;
    }

    ImGui::Text("Search & filter");
    ImGui::Separator();

    {
        float fullWidth   = ImGui::GetContentRegionAvail().x;
        float searchWidth = fullWidth * 0.55f;
        float comboWidth  = fullWidth - searchWidth - ImGui::GetStyle().ItemSpacing.x;

        ImGui::PushItemWidth(searchWidth);
        bool changedSearch = ImGui::InputText("##EmoteSearch", searchBuffer, IM_ARRAYSIZE(searchBuffer));
        ImGui::PopItemWidth();

        if (changedSearch)
            selectedIndex = -1;

        ImGui::SameLine();

        const char* currentLabel = championFilter.empty()
            ? "All champions"
            : championFilter.c_str();

        ImGui::PushItemWidth(comboWidth);
        if (ImGui::BeginCombo("##ChampionFilter", currentLabel))
        {
            bool isAll = championFilter.empty();
            if (ImGui::Selectable("All champions", isAll))
            {
                championFilter.clear();
                selectedIndex = -1;
            }

            ImGui::Separator();

            for (const auto& champName : emoteChampions)
            {
                bool isSelected = (championFilter == champName);
                if (ImGui::Selectable(champName.c_str(), isSelected))
                {
                    championFilter = champName;
                    selectedIndex  = -1;
                }
            }

            ImGui::EndCombo();
        }
        ImGui::PopItemWidth();

        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Filter emotes by champion");
    }

    ImGui::Spacing();
    ImGui::Separator();

    std::vector<int> filteredIndices;
    filteredIndices.reserve(all_emotes.size());

    std::string searchStr(searchBuffer);
    std::transform(searchStr.begin(), searchStr.end(), searchStr.begin(),
        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });

    for (int i = 0; i < static_cast<int>(all_emotes.size()); ++i)
    {
        std::string emoteName = all_emotes[i].name;
        std::transform(emoteName.begin(), emoteName.end(), emoteName.begin(),
            [](unsigned char c) { return static_cast<char>(std::tolower(c)); });

        bool championMatch = championFilter.empty() || (all_emotes[i].champion == championFilter);
        bool searchMatch   = searchStr.empty() || (emoteName.find(searchStr) != std::string::npos);

        if (championMatch && searchMatch)
            filteredIndices.push_back(i);
    }

    ImGui::Text("Emotes (%d)", static_cast<int>(filteredIndices.size()));
    ImGui::BeginChild("EmoteList", ImVec2(0, 200), true);

    for (int idx = 0; idx < static_cast<int>(filteredIndices.size()); ++idx)
    {
        int actualIndex = filteredIndices[idx];
        const auto& emote = all_emotes[actualIndex];

        char label[256];
        snprintf(label, sizeof(label), "[%s] %s (ID: %d)",
                 emote.champion.c_str(), emote.name.c_str(), emote.id);

        bool isSelected = (selectedIndex == idx);
        if (ImGui::Selectable(label, isSelected))
        {
            selectedIndex            = idx;
            exploits.selectedEmoteID = emote.id;

            if (!exploits.customEmote && radialMenuScene->m_pEquipEmote)
                radialMenuScene->m_pEquipEmote->m_nId = emote.id;
        }
    }

    ImGui::EndChild();

    ImGui::Spacing();
    ImGui::Separator();

    ImGui::TextDisabled("Apply the selected emote ID\nPress F1, to reset current emote. Refresh page to take effect");

    ImGui::Spacing();
    ImGui::Separator();

    ImGui::Checkbox("Custom ID", &exploits.customEmote);

    if (!exploits.customEmote)
        ImGui::BeginDisabled();

    ImGui::SameLine();
    ImGui::PushItemWidth(100.0f);

    if (ImGui::InputInt("##EmoteID", &exploits.selectedEmoteID, 0, 0, ImGuiInputTextFlags_CharsDecimal))
    {
        if (exploits.customEmote && radialMenuScene->m_pEquipEmote)
            radialMenuScene->m_pEquipEmote->m_nId = exploits.selectedEmoteID;
    }

    ImGui::PopItemWidth();

    if (ImGui::Button("Set ID", ImVec2(100.f, 25.f)))
    {
        if (exploits.customEmote)
        {
            if (radialMenuScene->m_pEquipEmote)
                radialMenuScene->m_pEquipEmote->m_nId = exploits.selectedEmoteID;
        }
        else
        {
            if (selectedIndex != -1 && selectedIndex < static_cast<int>(filteredIndices.size()))
            {
                int actualIndex = filteredIndices[selectedIndex];
                if (radialMenuScene->m_pEquipEmote)
                    radialMenuScene->m_pEquipEmote->m_nId = all_emotes[actualIndex].id;
            }
        }
    }

    if (!exploits.customEmote)
        ImGui::EndDisabled();

    ImGui::End();
}