#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include <Windows.h>
#include <cstddef>

// ============================================================================
// ITEM UNLOCKER  —  PHAROAH's own implementation of Genji's mechanism
// ============================================================================
// Walks the global object array, keeps only UUIDataItem instances, and writes 1
// into UUIDataItem::m_qwInventorySessionId.A (+0x68) — the client's "this item
// is in my session inventory" signal.
//
// Built from the analysis in 05_DOCS/06_REVERSE_ENGINEERING/, against our own
// SDK. No Genji code was copied. Genji's hardest step (the encrypted global
// object array with its TLS-resident key table) was already solved in
// Utils/TEB.cpp before we ever saw Genji, so enumeration is free for us.
//
// ---------------------------------------------------------------------------
// CHEST MODE — why it exists and how it works
// ---------------------------------------------------------------------------
// A chest will not open once you already own everything inside it: the UI shows
// (313/313) and there is nothing left for it to give. Unlocking EVERYTHING is
// therefore self-defeating if what you want is what comes OUT of chests.
//
// The fix is not string-matching item names — that was a guess and it failed.
// The SDK hands us the real data:
//
//   UUIData_ChestExtended
//       nItemId      +0x68   int           <- the chest's own item id
//       nAllLootIds  +0x88   TArray<int>   <- every item id inside that chest
//   UUIDataItem
//       m_nId        +0x70   int           <- this item's id
//
// So chests and chest contents are identified BY ID, from the game's own tables.
// No name matching, no guessing.
//
//   MODE_EVERYTHING   - unlock all items (original Genji behaviour)
//   MODE_CHESTS_ONLY  - unlock ONLY chest items. Everything a chest could give
//                       stays locked, so every chest is full and openable.
//   MODE_NOT_CONTENTS - unlock everything EXCEPT things found inside chests.
//                       Keeps the incidental unlocks; chests stay full.
//
// THE CLASS FILTER IS NOT OPTIONAL. +0x68 means something different on every
// other UObject class; an unfiltered sweep writes into ~200k live objects and
// takes the game down. Every candidate is IsA()-checked first.
// ============================================================================

namespace Unlocker {

    // Derived from the SDK dump rather than hardcoded, so a regenerated dump
    // carries the offset automatically and a moved field breaks the build loudly
    // instead of silently scribbling on the wrong bytes.
    static const int kSessionIdOffset = (int)offsetof(SDK::UUIDataItem, m_qwInventorySessionId);
    static_assert((int)offsetof(SDK::UUIDataItem, m_qwInventorySessionId) == 0x68,
                  "UUIDataItem::m_qwInventorySessionId moved - re-verify against the new SDK dump.");

    enum Mode { MODE_EVERYTHING = 0, MODE_CHESTS_ONLY = 1, MODE_NOT_CONTENTS = 2 };

    inline bool  g_Enabled     = true;    // inject-and-done, like Genji
    inline bool  g_Persist     = true;    // menus rebuild items as you navigate
    inline float g_PersistSecs = 1.0f;
    // DEFAULT IS EVERYTHING - inject and you get all skins, all items, and the
    // one-of-each-chest side effect. This is the behaviour that actually feels
    // good to use, so it is the default again.
    //
    // CHESTS_ONLY exists and works (it does correctly unlock only chests), but
    // chests turned out to be a dead end: the grant is server-side, so an opened
    // chest never delivers anything. No reason to pay for that with fewer skins.
    //
    // NOTE if this is ever flipped back: the auto-tick fires within a second of
    // injection, so whatever this is set to has already been applied before the
    // tab can be opened. Changing mode afterwards cannot un-count a chest screen
    // that has already been built.
    inline int   g_Mode        = MODE_EVERYTHING;

    // ---- THE VALUE WE WRITE ----------------------------------------------
    // Genji writes literal 1. It turns out the UI renders this field as a
    // QUANTITY, not a yes/no - which is why chests show "1". So this is
    // adjustable, because "what happens at other values" is a real question
    // with a cheap answer.
    //
    // It is a 32-bit SIGNED int: wraps at 2147483647 -> -2147483648.
    // Interesting values to try:
    //     1           what Genji does
    //     5, 100      does the count displayed follow it?
    //     2147483647  INT_MAX
    //     -1          all bits set
    //     0           re-locks
    // None of this can make a server grant you anything. What it CAN do is
    // trip a client-side check written as (count > 0) or (count >= needed),
    // and that is worth knowing.
    inline int   g_WriteValue  = 1;

    // m_qwInventorySessionId is an FQWord {int A; int B;} - a 64-bit id in two
    // halves. We have only ever written A. B is completely untested, and is the
    // last unexamined lever on this field. Off by default because writing it
    // makes the full 64-bit id enormous, which may well read as invalid.
    inline bool  g_WriteB      = false;
    inline int   g_WriteValueB = 0;

    // Retry collecting chest ids until it succeeds - the chest objects do not
    // exist until the game has built that screen at least once.
    inline double g_NextCollect = 0.0;

    inline int   g_LastScanned = 0;
    inline int   g_LastMatched = 0;
    inline int   g_LastWritten = 0;
    inline int   g_LastAlready = 0;
    inline int   g_LastSkipped = 0;
    inline int   g_LastCleared = 0;
    inline char  g_Status[224] = "Not run yet.";
    inline double g_NextRun    = 0.0;

    // ---- chest id sets, collected from UUIData_ChestExtended --------------
    static const int kMaxChests = 512;
    static const int kMaxLoot   = 20000;
    inline int  g_ChestIds[kMaxChests];   inline int g_ChestIdCount = 0;
    inline int  g_LootIds[kMaxLoot];      inline int g_LootIdCount  = 0;
    inline int  g_ChestObjects = 0;
    inline char g_ChestStatus[192] = "Chest ids not collected yet.";

    static const int kMaxSample = 600;
    inline char g_Sample[kMaxSample][144];
    inline int  g_SampleCount = 0;

    // ---- guarded primitives (POD only; __try cannot share scope with
    // anything needing unwinding — the C2712 rule this codebase learned) ----

    inline SDK::UClass* TryGetClass_DataItem() {
        __try { return SDK::UUIDataItem::StaticClass(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    inline SDK::UClass* TryGetClass_ChestExtended() {
        __try { return SDK::UUIData_ChestExtended::StaticClass(); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    inline SDK::UObject* TryObjAt(SDK::TAntiCheatArray<SDK::UObject*>& arr, size_t i) {
        __try {
            if (!arr.IsValidIndex(i)) return nullptr;
            return arr[i];
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }
    inline bool TryIsA(SDK::UObject* o, SDK::UClass* cls) {
        __try {
            if (!o || !cls) return false;
            return o->IsA(cls);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool TryReadSessionId(SDK::UObject* o, int* out) {
        __try { *out = *(int*)((unsigned char*)o + kSessionIdOffset); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline bool TryWriteSessionId(SDK::UObject* o, int val) {
        __try {
            *(int*)((unsigned char*)o + kSessionIdOffset) = val;
            if (g_WriteB) *(int*)((unsigned char*)o + kSessionIdOffset + 4) = g_WriteValueB;
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline int TryReadItemId(SDK::UObject* o) {
        __try { return ((SDK::UUIDataItem*)o)->m_nId; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }
    inline int TryReadChestItemId(SDK::UObject* o) {
        __try { return ((SDK::UUIData_ChestExtended*)o)->nItemId; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return -1; }
    }
    // Copies a chest's loot-id list out. Returns how many were written.
    inline int TryReadChestLoot(SDK::UObject* o, int* dst, int cap) {
        __try {
            SDK::UUIData_ChestExtended* c = (SDK::UUIData_ChestExtended*)o;
            size_t n = c->nAllLootIds.Num();
            if (n > 100000) return 0;                     // obviously bad
            int w = 0;
            for (size_t i = 0; i < n && w < cap; ++i) dst[w++] = c->nAllLootIds[i];
            return w;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }
    inline bool TryCopyFStr(const SDK::FString* fs, char* buf, int cap) {
        __try {
            buf[0] = '\0';
            const wchar_t* w = fs->c_str();
            if (!w) return false;
            int n = 0;
            while (w[n] && n < cap - 1) { buf[n] = (char)(w[n] & 0x7F); n++; }
            buf[n] = '\0';
            return n > 0;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { buf[0] = '\0'; return false; }
    }
    inline bool TryCopyItemName(SDK::UObject* o, char* b, int c) {
        return TryCopyFStr(&((SDK::UUIDataItem*)o)->m_sName, b, c);
    }
    inline bool TryCopyItemIcon(SDK::UObject* o, char* b, int c) {
        return TryCopyFStr(&((SDK::UUIDataItem*)o)->m_sIcon, b, c);
    }

    inline bool IdIn(const int* set, int count, int id) {
        for (int i = 0; i < count; ++i) if (set[i] == id) return true;
        return false;
    }

    // ---- collect the chest id sets ---------------------------------------
    inline void CollectChestIds() {
        g_ChestIdCount = g_LootIdCount = g_ChestObjects = 0;

        if (!SDK::UObject::GObjects) {
            lstrcpynA(g_ChestStatus, "GObjects not initialised.", 190);
            return;
        }
        SDK::UClass* cls = TryGetClass_ChestExtended();
        if (!cls) {
            lstrcpynA(g_ChestStatus, "Could not resolve Class TgClient.UIData_ChestExtended.", 190);
            return;
        }

        auto& arr = *SDK::UObject::GObjects;
        size_t count = 0;
        __try { count = arr.Num(); } __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
        if (!count || count > 4000000) {
            lstrcpynA(g_ChestStatus, "GObjects unreadable.", 190);
            return;
        }

        static int tmp[4096];
        for (size_t i = 0; i < count; ++i) {
            SDK::UObject* o = TryObjAt(arr, i);
            if (!o || !TryIsA(o, cls)) continue;
            g_ChestObjects++;

            int cid = TryReadChestItemId(o);
            if (cid > 0 && g_ChestIdCount < kMaxChests && !IdIn(g_ChestIds, g_ChestIdCount, cid))
                g_ChestIds[g_ChestIdCount++] = cid;

            int n = TryReadChestLoot(o, tmp, 4096);
            for (int k = 0; k < n && g_LootIdCount < kMaxLoot; ++k) {
                if (tmp[k] > 0 && !IdIn(g_LootIds, g_LootIdCount, tmp[k]))
                    g_LootIds[g_LootIdCount++] = tmp[k];
            }
        }

        wsprintfA(g_ChestStatus, "%d chest objects -> %d chest ids, %d ids found inside chests.",
                  g_ChestObjects, g_ChestIdCount, g_LootIdCount);
    }

    // Should this item be unlocked under the current mode?
    inline bool ShouldUnlock(SDK::UObject* o) {
        if (g_Mode == MODE_EVERYTHING) return true;
        int id = TryReadItemId(o);
        if (id <= 0) return false;                        // unknown id: leave alone
        if (g_Mode == MODE_CHESTS_ONLY)  return IdIn(g_ChestIds, g_ChestIdCount, id);
        if (g_Mode == MODE_NOT_CONTENTS) return !IdIn(g_LootIds, g_LootIdCount, id);
        return true;
    }

    // ---- the pass ---------------------------------------------------------
    // clearUnwanted: also write 0 back over items this mode does NOT want. This
    // matters because a previous EVERYTHING pass (or a previous injection) has
    // already stamped them, and switching mode cannot un-own them otherwise —
    // which is exactly why the chest still said 313/313.
    inline void RunPass(bool dryRun, bool collectSample, bool clearUnwanted) {
        g_LastScanned = g_LastMatched = g_LastWritten = 0;
        g_LastAlready = g_LastSkipped = g_LastCleared = 0;
        if (collectSample) g_SampleCount = 0;

        if (!SDK::UObject::GObjects) { lstrcpynA(g_Status, "GObjects not initialised.", 220); return; }
        SDK::UClass* cls = TryGetClass_DataItem();
        if (!cls) { lstrcpynA(g_Status, "Could not resolve Class TgClient.UIDataItem.", 220); return; }

        if (g_Mode != MODE_EVERYTHING && g_ChestIdCount == 0 && g_LootIdCount == 0)
            CollectChestIds();

        auto& arr = *SDK::UObject::GObjects;
        size_t count = 0;
        __try { count = arr.Num(); } __except (EXCEPTION_EXECUTE_HANDLER) { count = 0; }
        if (!count || count > 4000000) { lstrcpynA(g_Status, "GObjects unreadable (bad count).", 220); return; }

        for (size_t i = 0; i < count; ++i) {
            SDK::UObject* o = TryObjAt(arr, i);
            if (!o) continue;
            g_LastScanned++;
            if (!TryIsA(o, cls)) continue;          // NOT optional
            g_LastMatched++;

            int cur = 0;
            bool readOk = TryReadSessionId(o, &cur);
            if (readOk && cur != 0) g_LastAlready++;

            bool want = ShouldUnlock(o);
            if (!want) g_LastSkipped++;

            if (collectSample && g_SampleCount < kMaxSample) {
                char nm[96], ic[96];
                bool a = TryCopyItemName(o, nm, sizeof(nm));
                if (!TryCopyItemIcon(o, ic, sizeof(ic))) ic[0] = '\0';
                int id = TryReadItemId(o);
                bool isChest = IdIn(g_ChestIds, g_ChestIdCount, id);
                bool inChest = IdIn(g_LootIds, g_LootIdCount, id);
                if (a && nm[0]) {
                    wsprintfA(g_Sample[g_SampleCount], "%s id=%-7d %-26s | %s",
                              isChest ? "[CHEST]" : (inChest ? "[loot ]" : "[     ]"),
                              id, nm, ic);
                    g_SampleCount++;
                }
            }

            if (dryRun) continue;

            if (want) {
                if (!readOk || cur != g_WriteValue) {
                    if (TryWriteSessionId(o, g_WriteValue)) g_LastWritten++;
                }
            } else if (clearUnwanted && readOk && cur != 0) {
                if (TryWriteSessionId(o, 0)) g_LastCleared++;
            }
        }

        const char* mn = (g_Mode == MODE_CHESTS_ONLY)  ? "CHESTS ONLY"
                       : (g_Mode == MODE_NOT_CONTENTS) ? "ALL EXCEPT CHEST CONTENTS"
                                                       : "EVERYTHING";
        if (dryRun)
            wsprintfA(g_Status, "SCAN [%s]: %d items, %d already owned, %d would stay locked.",
                      mn, g_LastMatched, g_LastAlready, g_LastSkipped);
        else
            wsprintfA(g_Status, "APPLIED [%s]: %d items, %d unlocked, %d re-locked, %d left alone.",
                      mn, g_LastMatched, g_LastWritten, g_LastCleared, g_LastSkipped);
    }

    inline void Tick() {
        if (!g_Enabled || !g_Persist) return;
        double now = ImGui::GetTime();

        // Keep trying to build the chest id set until we have one. The chest
        // objects only exist after the game has built that screen once, so at
        // inject time there is nothing to find - and until we DO have ids,
        // CHESTS_ONLY correctly unlocks nothing at all rather than guessing.
        if (g_Mode != MODE_EVERYTHING && g_ChestIdCount == 0 && now >= g_NextCollect) {
            g_NextCollect = now + 3.0;
            CollectChestIds();
        }

        if (now < g_NextRun) return;
        g_NextRun = now + (g_PersistSecs < 0.25f ? 0.25f : g_PersistSecs);

        // In a filtered mode with no ids yet, do nothing. Writing on a guess is
        // what caused the original problem.
        if (g_Mode != MODE_EVERYTHING && g_ChestIdCount == 0) return;

        RunPass(false, false, g_Mode != MODE_EVERYTHING);
    }

    // ---- UI ---------------------------------------------------------------
    inline void DrawControls(bool /*inMatch*/) {
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(g_Enabled ? ImVec4(0.4f, 1.0f, 0.5f, 1.0f)
                                                           : ImVec4(1.0f, 0.6f, 0.4f, 1.0f)));
        ImGui::Checkbox("ACTIVATE UNLOCKER (off = completely inactive)", &g_Enabled);
        ImGui::PopStyleColor();
        if (!g_Enabled) {
            ImGui::TextWrapped("Unlocker is OFF. Nothing runs — no scanning, no writes, no timer.");
            return;
        }

        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("WHAT TO UNLOCK");
        ImGui::PopStyleColor();
        ImGui::RadioButton("Everything (original Genji behaviour)", &g_Mode, MODE_EVERYTHING);
        ImGui::RadioButton("ONLY chests   <- chests stay full and openable", &g_Mode, MODE_CHESTS_ONLY);
        ImGui::RadioButton("Everything EXCEPT what is inside chests", &g_Mode, MODE_NOT_CONTENTS);

        ImGui::Spacing();
        ImGui::TextWrapped("A chest will not open once you own everything in it - that is the "
            "(313/313). The two filtered modes leave chest contents locked, so a chest always has "
            "something to give.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        if (ImGui::Button("Collect chest ids", ImVec2(200, 30))) CollectChestIds();
        ImGui::SameLine();
        ImGui::TextWrapped("%s", g_ChestStatus);

        if (g_ChestIdCount == 0 && g_Mode != MODE_EVERYTHING) {
            ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.6f, 0.4f, 1.0f)));
            ImGui::TextWrapped("No chest ids yet. Open the Store / Chests screen so the game builds "
                "those objects, then press Collect.");
            ImGui::PopStyleColor();
        }

        ImGui::Spacing();
        if (ImGui::Button("SCAN (read-only)", ImVec2(180, 32))) RunPass(true, true, false);
        ImGui::SameLine();
        if (ImGui::Button(">>> APPLY NOW <<<", ImVec2(190, 32)))
            RunPass(false, true, g_Mode != MODE_EVERYTHING);
        ImGui::SameLine();
        if (ImGui::Button("Copy report", ImVec2(120, 32))) {
            static char big[120000];
            int n = wsprintfA(big, "%s\r\n%s\r\n\r\nItems (%d shown):\r\n",
                              g_Status, g_ChestStatus, g_SampleCount);
            for (int i = 0; i < g_SampleCount && n < 118000; i++)
                n += wsprintfA(big + n, "%s\r\n", g_Sample[i]);
            ImGui::SetClipboardText(big);
        }

        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.55f, 0.22f, 0.18f, 1.0f));
        if (ImGui::Button("RE-LOCK EVERYTHING (write 0 to all items)", ImVec2(340, 28))) {
            int savedMode = g_Mode;
            g_Mode = MODE_CHESTS_ONLY;
            int savedChests = g_ChestIdCount;
            g_ChestIdCount = 0;              // nothing qualifies -> clears all
            RunPass(false, false, true);
            g_ChestIdCount = savedChests;
            g_Mode = savedMode;
            lstrcpynA(g_Status, "Re-locked every item (wrote 0). Menus may take a moment to catch up.", 220);
        }
        ImGui::PopStyleColor();
        ImGui::TextDisabled("Use this if a previous 'Everything' pass already marked things owned "
                            "and the chest still says it is full.");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::PushStyleColor(ImGuiCol_Text, Ink(ImVec4(1.0f, 0.85f, 0.45f, 1.0f)));
        ImGui::TextUnformatted("VALUE WRITTEN  (this is the number the UI shows as a count)");
        ImGui::PopStyleColor();
        ImGui::SetNextItemWidth(200);
        ImGui::InputInt("##wval", &g_WriteValue);
        ImGui::SameLine();
        if (ImGui::SmallButton("1"))           g_WriteValue = 1;
        ImGui::SameLine();
        if (ImGui::SmallButton("5"))           g_WriteValue = 5;
        ImGui::SameLine();
        if (ImGui::SmallButton("100"))         g_WriteValue = 100;
        ImGui::SameLine();
        if (ImGui::SmallButton("INT_MAX"))     g_WriteValue = 2147483647;
        ImGui::SameLine();
        if (ImGui::SmallButton("-1"))          g_WriteValue = -1;
        ImGui::TextDisabled("Signed 32-bit: wraps at 2147483647 to -2147483648. Chests showing '1'\n"
                            "is this value being drawn, so it IS a quantity. A bigger number cannot\n"
                            "make the server grant anything, but it may trip a client-side check.");
        ImGui::Checkbox("Also write the B half of the id (untested)", &g_WriteB);
        if (g_WriteB) {
            ImGui::SameLine();
            ImGui::SetNextItemWidth(140);
            ImGui::InputInt("B##wvalb", &g_WriteValueB);
        }
        ImGui::TextDisabled("m_qwInventorySessionId is FQWord {int A; int B;}. Only A has ever been\n"
                            "written. B is the last untried lever on this field.");
        ImGui::Separator();
        ImGui::Spacing();
        ImGui::Checkbox("Re-apply on a timer (menus rebuild items as you navigate)", &g_Persist);
        if (g_Persist) {
            ImGui::SetNextItemWidth(200);
            ImGui::SliderFloat("seconds##unlockrate", &g_PersistSecs, 0.25f, 5.0f, "%.2f s");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextWrapped("%s", g_Status);

        if (g_SampleCount > 0) {
            ImGui::Spacing();
            if (ImGui::CollapsingHeader("Items found  ([CHEST] = a chest, [loot] = inside a chest)")) {
                ImGui::TextDisabled("Showing %d of %d matched.", g_SampleCount, g_LastMatched);
                ImGui::BeginChild("##unlocklist", ImVec2(0, 280), true,
                                  ImGuiWindowFlags_HorizontalScrollbar);
                for (int i = 0; i < g_SampleCount; i++) ImGui::TextUnformatted(g_Sample[i]);
                ImGui::EndChild();
            }
        }

        if (ImGui::CollapsingHeader("How the chest filter works")) {
            ImGui::TextWrapped("UUIData_ChestExtended carries nItemId (the chest's own id) and "
                "nAllLootIds (every item id inside it). UUIDataItem carries m_nId. Chests and "
                "chest contents are matched by ID, from the game's own tables - no guessing at "
                "names, which is what failed last time.");
            ImGui::Spacing();
            ImGui::TextWrapped("If Collect finds 0 chests, the chest screen has not been built this "
                "session and those objects do not exist yet. Open it, then collect.");
        }
    }
}
