#pragma once

// Paladins (8.1.5838.0) SDK

#include "../SDK.hpp"
#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif


namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
