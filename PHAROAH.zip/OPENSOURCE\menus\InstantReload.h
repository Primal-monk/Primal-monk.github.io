#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "ext/ImGUI/imgui.h"
#include "UI/Style.h"   // Ink() - keeps coloured text readable on the light sand theme
#include <Windows.h>

// ============================================================================
// INSTANT RELOAD — Mal'Damba & Dredge only
//
// WHY ONLY THESE TWO (dev-confirmed, and confirmed again in the SDK):
// The Anubis dev said:
//   "Reloading is also server side, it just works on damba + dredge because the
//    reload thing is being spawned from the client (and the server trusts that)"
//
// The SDK backs this up exactly. Out of every weapon in the game, only these two
// classes override a reload function, and they each override precisely ONE:
//
//   class ATgDevice_MalDambaInhand : public ATgDevice { void PreReloadTimer(); };
//   class ATgDevice_DredgeInhand   : public ATgDevice { void PreReloadTimer(); };
//
// PreReloadTimer is the CLIENT-side stage of the reload. Every other weapon
// inherits ATgDevice's base version, which is driven by the server. These two
// run their own client-side version, and the server trusts the result. That is
// the whole reason this works here and nowhere else — it is not a quirk, it is
// visible in the class layout.
//
// (ATgDevice_DredgeReload additionally has its own UseNow() — a separate
// client-spawned reload device, the "reload thing being spawned from the client"
// the dev described literally.)
//
// TWO PATHS, per the standing rule: never replace a working approach with an
// unproven one — add the unproven one alongside it as an opt-in.
//
//   PATH A (default, "Timer scale"): scale m_fTotalReloadTime down.
//     0x0454 on ATgDevice, NOT (Net) — a local float. Purely a field write, so
//     it is safe from any thread and cannot corrupt object state. Lowest risk.
//
//   PATH B (opt-in, "Force-finish"): when a reload is in progress, call
//     PreReloadTimer() to complete the client stage immediately. This is the
//     function these two champions actually override, so it is the most likely
//     to give a true instant reload — but it is a scripted call, so it is
//     deferred to the ProcessEvent thread and left OFF by default.
//
// WHAT IS DELIBERATELY NOT DONE: ReloadAmmo(bToFull=true, bShouldValidate=false)
// would refill the clip directly, but it writes r_nAmmoClipCount, which IS (Net)
// and validated against the ammo transaction ledger. That is the same thing that
// gets rapid fire rejected. Skipping validation on a replicated counter is the
// fastest way to get the connection closed, so this path is not offered.
// ============================================================================

namespace InstantReload {

    inline bool  enabled = false;
    inline float reloadSpeedMult = 4.0f;   // Path A: reload time is divided by this
    inline bool  forceFinish = false;      // Path B: opt-in, scripted
    inline bool  showOnUnsupported = false;

    // Diagnostics, so a failure is legible instead of silent.
    inline bool  g_OnSupportedChamp = false;
    inline char  g_DetectedWeapon[128] = "(none)";
    inline float g_LastSeenReloadTime = -1.0f;
    inline float g_OriginalReloadTime = -1.0f;
    inline int   g_ScaleWrites = 0;
    inline int   g_ForceFinishCalls = 0;
    inline bool  g_PendingForceFinish = false;

    // POD-only helpers. __try cannot share a scope with anything that needs
    // unwinding (MSVC C2712), so every guarded read/write lives in its own
    // function with no std::string anywhere near it.
    inline bool TryReadReloadTime(SDK::ATgDevice* d, float* out) {
        __try { *out = d->m_fTotalReloadTime; return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryWriteReloadTime(SDK::ATgDevice* d, float v) {
        __try { d->m_fTotalReloadTime = v; return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // The reload-in-progress signal lives on the CONTROLLER, not the device
    // (ATgPlayerController::m_fPendingReloadTime, 0x0A88). ATgDevice::IsReloading()
    // would be the obvious call, but it is scripted, and Update() runs on the
    // render thread where scripted calls are not allowed. A field read is.
    inline bool TryIsReloading(SDK::ATgPlayerController* pc, bool* out) {
        __try {
            *out = (pc->m_fPendingReloadTime > 0.0f &&
                    pc->m_fPendingReloadTime < pc->m_fPendingReloadMaxTime);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool TryPreReloadTimer(SDK::ATgDevice* d) {
        __try { d->PreReloadTimer(); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // Name matching rather than IsA/FindClass. That choice is load-bearing all
    // over this project: IsA missed ATgDeploy_Pickup_OwnerOnly for the same
    // reason it would be fragile here, and FName(const char*) linearly scans
    // ~200k GNames entries which caused both the bone crash and the jitter.
    // GetAnsiName lives on FNameEntry, not on UClass — so the name has to be
    // resolved through the GNames table by index. Critically this does NOT use
    // FName(const char*): that linearly scans ~200k GNames entries calling
    // GetName() (which allocates a std::string) through a bounds-checked
    // anti-cheat array, and it is what caused both the bone crash and the jitter
    // elsewhere in this project. Index lookup is O(1) and allocation-free.
    inline bool CopyWeaponName(SDK::ATgDevice* d, char* buf, int cap) {
        __try {
            buf[0] = '\0';
            SDK::UClass* cls = d->Class;
            if (!cls || cls->Name.Index == 0) return false;
            auto& names = SDK::FName::GetGlobalNames();
            if (!names.IsValidIndex((size_t)cls->Name.Index)) return false;
            SDK::FNameEntry* entry = names[cls->Name.Index];
            if (!entry) return false;
            const char* n = entry->GetAnsiName();
            if (!n) return false;
            int i = 0;
            for (; i < cap - 1 && n[i]; ++i) buf[i] = n[i];
            buf[i] = '\0';
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline bool ContainsCI(const char* hay, const char* needle) {
        if (!hay || !needle) return false;
        for (int i = 0; hay[i]; ++i) {
            int j = 0;
            while (needle[j]) {
                char a = hay[i + j], b = needle[j];
                if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
                if (b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
                if (a != b) break;
                ++j;
            }
            if (!needle[j]) return true;
        }
        return false;
    }

    // Auto-detection. The champion is identified from the equipped weapon's
    // class name, so it follows champion swaps and respawns with no extra work.
    inline bool IsSupportedWeaponName(const char* n) {
        return ContainsCI(n, "MalDamba") || ContainsCI(n, "Dredge");
    }

    // Field-write path only — safe from the render thread.
    inline void Update() {
        SDK::ATgDevice* w = Globals::LocalWeapon;
        if (!w) {
            g_OnSupportedChamp = false;
            g_DetectedWeapon[0] = '\0';
            return;
        }

        char nameBuf[128] = {};
        if (!CopyWeaponName(w, nameBuf, 128)) { g_OnSupportedChamp = false; return; }

        // Reset the captured original whenever the weapon identity changes, so
        // "restore" can never write another weapon's timing into this one.
        bool weaponChanged = false;
        for (int i = 0; i < 128; ++i) {
            if (g_DetectedWeapon[i] != nameBuf[i]) { weaponChanged = true; break; }
            if (!nameBuf[i]) break;
        }
        if (weaponChanged) {
            for (int i = 0; i < 128; ++i) g_DetectedWeapon[i] = nameBuf[i];
            g_OriginalReloadTime = -1.0f;
        }

        g_OnSupportedChamp = IsSupportedWeaponName(nameBuf);

        float cur = -1.0f;
        if (!TryReadReloadTime(w, &cur)) return;
        g_LastSeenReloadTime = cur;

        if (!enabled || !g_OnSupportedChamp) return;

        // Capture the genuine value once, and only a plausible one — if we
        // latched onto an already-scaled value the baseline would ratchet down
        // every reload until it was meaningless.
        if (g_OriginalReloadTime <= 0.0f && cur > 0.01f) g_OriginalReloadTime = cur;
        if (g_OriginalReloadTime <= 0.0f) return;

        float target = g_OriginalReloadTime / (reloadSpeedMult <= 0.1f ? 0.1f : reloadSpeedMult);
        if (target < 0.02f) target = 0.02f;   // never zero; a 0 timer can divide

        if (cur > target + 0.001f) {
            if (TryWriteReloadTime(w, target)) g_ScaleWrites++;
        }

        if (forceFinish) {
            SDK::ATgPlayerController* pc = (SDK::ATgPlayerController*)Globals::LocalController;
            bool reloading = false;
            if (pc && TryIsReloading(pc, &reloading) && reloading) g_PendingForceFinish = true;
        }
    }

    // Scripted call — ProcessEvent thread only. Doing this from hkPresent is
    // what corrupted object state before (the Buck-with-Octavia's-gun bug).
    inline void ProcessPending() {
        if (!g_PendingForceFinish) return;
        g_PendingForceFinish = false;
        if (!enabled || !forceFinish || !g_OnSupportedChamp) return;
        SDK::ATgDevice* w = Globals::LocalWeapon;
        if (!w) return;
        if (TryPreReloadTimer(w)) g_ForceFinishCalls++;
    }

    inline void Restore() {
        SDK::ATgDevice* w = Globals::LocalWeapon;
        if (w && g_OriginalReloadTime > 0.0f) TryWriteReloadTime(w, g_OriginalReloadTime);
    }

    // Compact panel — sits at the very top of the Fire Modes tab.
    inline void DrawCompact() {
        ImGui::TextColored(Ink(ImVec4(0.55f, 1.0f, 0.75f, 1.0f)), "INSTANT RELOAD  (Mal'Damba / Dredge)");

        if (g_OnSupportedChamp) {
            ImGui::TextColored(Ink(ImVec4(0.4f, 1.0f, 0.5f, 1.0f)), "Supported champion detected.");
        } else {
            ImGui::TextColored(Ink(ImVec4(0.7f, 0.7f, 0.7f, 1.0f)),
                "Not on Mal'Damba or Dredge - inactive.");
        }

        ImGui::Checkbox("Enable instant reload", &enabled);
        ImGui::SliderFloat("Reload speed", &reloadSpeedMult, 1.0f, 20.0f, "%.1fx");
        ImGui::SameLine();
        if (ImGui::Button("Restore")) Restore();

        ImGui::Checkbox("Force-finish (unproven, scripted)", &forceFinish);
        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip(
                "Calls PreReloadTimer() - the one function Damba and Dredge actually\n"
                "override client-side. Most likely to give a TRUE instant reload,\n"
                "but it is a scripted call, so it is off by default. The slider\n"
                "above works on its own.");
        }

        if (ImGui::TreeNode("Instant reload details")) {
            ImGui::Text("Weapon class    : %s", g_DetectedWeapon[0] ? g_DetectedWeapon : "(none)");
            ImGui::Text("Original reload : %.3f s", g_OriginalReloadTime);
            ImGui::Text("Live reload     : %.3f s", g_LastSeenReloadTime);
            ImGui::Text("Scale writes    : %d", g_ScaleWrites);
            ImGui::Text("Force-finishes  : %d", g_ForceFinishCalls);
            ImGui::TextWrapped(
                "m_fTotalReloadTime (0x0454) is NOT replicated, so scaling it is a "
                "plain local field write. The clip refill path is deliberately not "
                "used: it writes r_nAmmoClipCount, which IS replicated and checked "
                "against the ammo transaction ledger - the same validation that "
                "rejects rapid fire.");
            ImGui::TreePop();
        }
        ImGui::Separator();
    }
}
