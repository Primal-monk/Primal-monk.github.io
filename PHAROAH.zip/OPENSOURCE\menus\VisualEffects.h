#pragma once
// ============================================================================
//  PHAROAH  —  client-side modding tool for Paladins (Tempest)
//  Copyright (c) 2026 PRIMAL_MONKE.  See LICENSE - free, open source,
//  charity gate and credit must stay. Keep this notice with any copy.
// ============================================================================
#include "globals.h"
#include "Utils/SafeCalls.h"
#include "ext/ImGUI/imgui.h"

// Central place for every REAL, confirmed, controller/local-player-level
// visual effect found in the SDK — same exact safety pattern used to fix the
// grayscale crashes: every button/checkbox here ONLY sets a plain flag (no
// scripted call happens on the render thread, ever). ProcessPendingEffects()
// is called from HookedProcessEvent (the safe thread) and is the ONLY place
// that actually calls into the game.
//
// DELIBERATELY NOT INCLUDED: champion-specific ability/ult visual effects
// (e.g. Lillith's ult). Those are triggered through per-ability state
// machines (cooldowns, animation state, replication) that don't exist if
// called cold from a menu — exactly the kind of call likely to crash. Sticking
// to controller/local-player level effects that are safe to trigger standalone.

namespace VisualEffects {

    // ---- Desaturation / grayscale (duplicated control here for convenience —
    // same underlying state as the Highlights tab's grayscale checkbox) ----
    inline bool g_PendingDesaturation = false;
    inline float g_DesaturationAmount = 1.0f;

    // ---- Colorblind vision modes ----
    inline bool g_PendingColorBlind = false;
    inline int g_ColorBlindMode = 0;
    inline float g_ColorBlindIntensity = 1.0f;

    // ---- Low health / near-death vision — the composite effect found while
    // fixing the grayscale "stuck muted" bug. Exposed here directly so you
    // can preview it on demand instead of only using it as a reset helper. ----
    inline bool g_PendingLowHealthEffect = false;
    inline float g_LowHealthPct = 0.3f;
    inline float g_LowHealthLostPct = 0.0f;
    inline bool g_LowHealthDeathVision = false;

    // ---- Master outline toggle ----
    inline bool g_PendingOutlineEffectOn = false;
    inline bool g_PendingOutlineEffectOff = false;

    // Called from HookedProcessEvent (the safe thread) — the ONLY place any
    // of these actually get called.
    inline void ProcessPendingEffects() {
        if (g_PendingDesaturation && Globals::LocalController) {
            SafeCalls::SetDesaturation(g_DesaturationAmount, 0.0f);
            g_PendingDesaturation = false;
        }
        if (g_PendingColorBlind && Globals::LocalController) {
            SafeCalls::EnableColorBlindEffect(g_ColorBlindMode != 0, g_ColorBlindMode, g_ColorBlindIntensity);
            g_PendingColorBlind = false;
        }
        if (g_PendingLowHealthEffect && Globals::LocalController) {
            SafeCalls::UpdateLowHealthEffect(0.0f, g_LowHealthPct, g_LowHealthLostPct, g_LowHealthDeathVision);
            g_PendingLowHealthEffect = false;
        }
        if (g_PendingOutlineEffectOn && Globals::LocalPlayer) {
            SafeCalls::EnableOutlineEffect(true);
            g_PendingOutlineEffectOn = false;
        }
        if (g_PendingOutlineEffectOff && Globals::LocalPlayer) {
            SafeCalls::EnableOutlineEffect(false);
            g_PendingOutlineEffectOff = false;
        }
    }

    inline void DrawControls(bool inMatch) {
        ImGui::TextWrapped("Every REAL visual effect function found in the SDK that's safe to "
            "trigger on its own, in one place. Same crash-safety pattern as the grayscale fix — "
            "nothing here calls the game directly from this menu; it's all deferred to a safe "
            "spot. Champion-specific ult effects (e.g. Lillith's) are deliberately NOT here — "
            "triggering those cold, outside their real ability state, is a likely crash.");
        if (!inMatch) { ImGui::TextDisabled("Join a match first."); return; }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Desaturation");
        ImGui::SliderFloat("Amount##Desat", &g_DesaturationAmount, 0.0f, 1.0f);
        if (ImGui::Button("Apply##Desat")) g_PendingDesaturation = true;

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Colorblind Vision Mode");
        const char* modeNames[] = { "None", "Protanope", "Deuteranope", "Tritanope" };
        ImGui::Combo("Mode##CB", &g_ColorBlindMode, modeNames, 4);
        ImGui::SliderFloat("Intensity##CB", &g_ColorBlindIntensity, 0.0f, 1.0f);
        if (ImGui::Button("Apply##CB")) g_PendingColorBlind = true;

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Low Health / Near-Death Vision (composite effect)");
        ImGui::TextWrapped("The real function behind the round-end/near-death fade — desaturation, "
            "tint, and vignette together as one package. Preview it directly here.");
        ImGui::SliderFloat("Health %%##LH", &g_LowHealthPct, 0.0f, 1.0f);
        ImGui::SliderFloat("Health Lost %%##LH", &g_LowHealthLostPct, 0.0f, 1.0f);
        ImGui::Checkbox("Death Vision", &g_LowHealthDeathVision);
        if (ImGui::Button("Apply##LH")) g_PendingLowHealthEffect = true;
        ImGui::SameLine();
        if (ImGui::Button("Reset to Full Health##LH")) {
            g_LowHealthPct = 1.0f; g_LowHealthLostPct = 0.0f; g_LowHealthDeathVision = false;
            g_PendingLowHealthEffect = true;
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Master Outline Toggle");
        if (ImGui::Button("Enable All Outlines")) g_PendingOutlineEffectOn = true;
        ImGui::SameLine();
        if (ImGui::Button("Disable All Outlines")) g_PendingOutlineEffectOff = true;
    }
}
